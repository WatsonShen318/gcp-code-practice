const express = require('express');
const logger = require('../logger');
const { lookupQl } = require('./utils');

const router = express.Router();

// POST /quantity-limit/lookup
// Looks up quantity limit data for a confirmed formularyId + GPI + drugName.
// Called after the formAlts flow has resolved the formularyId.
//
// Body: { formularyId, gpi, drugName, quantityRequested, daysSupplyRequested, memberId? }
// Response (not supported): { status, data: { supported: false, reason } }
// Response (picker needed): { status, data: { supported: true, requiresPicker: true, options: [...] } }
// Response (single result): { status, data: { supported: true, requiresPicker: false, result, verbiage } }
router.post('/lookup', async (req, res) => {
  const { formularyId, gpi, drugName, quantityRequested, daysSupplyRequested, memberId, receivedDate } = req.body;

  const missing = [];
  if (!formularyId)                        missing.push('formularyId');
  if (!gpi)                                missing.push('gpi');
  if (!drugName)                           missing.push('drugName');
  if (quantityRequested === undefined || quantityRequested === null) missing.push('quantityRequested');
  if (daysSupplyRequested === undefined || daysSupplyRequested === null) missing.push('daysSupplyRequested');

  if (missing.length > 0) {
    logger.warn('[QL] /lookup validation failed - missing params:', missing);
    return res.status(400).json({
      status: 'error',
      message: `Missing required parameters: ${missing.join(', ')}`,
      receivedParams: { formularyId, gpi, drugName, quantityRequested, daysSupplyRequested },
    });
  }

  try {
    logger.debug('[QL] /lookup requested', { formularyId, gpi, drugName, quantityRequested, daysSupplyRequested });
    const data = await lookupQl(formularyId, gpi, drugName, Number(quantityRequested), Number(daysSupplyRequested), memberId || null, receivedDate || null);
    logger.info('[QL] /lookup succeeded', { formularyId, gpi, supported: data.supported });
    res.status(200).json({ status: 'success', data });
  } catch (error) {
    logger.error('[QL] /lookup failed', {
      params: { formularyId, gpi, drugName, quantityRequested, daysSupplyRequested },
      errorMessage: error.message,
      errorStack: error.stack,
    });
    res.status(400).json({
      status: 'error',
      message: 'Failed to look up quantity limit data',
      details: error.message,
      requestParams: { formularyId, gpi, drugName, quantityRequested, daysSupplyRequested },
    });
  }
});

module.exports = router;
