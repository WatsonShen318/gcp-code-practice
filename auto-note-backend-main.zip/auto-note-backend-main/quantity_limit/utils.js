const { BigQuery } = require('@google-cloud/bigquery');
const logger = require('../logger');
const {
  COMPUTE_PROJECT_ID,
  FORM_ALTS_FORMULARY_DATA_TABLE,
} = require('../parameters/parameterConfig');
const { getQualifyingClaimForGpi } = require('../claims_history/utils');

const BQ_LOCATION = 'US';
const BQ_TIMEOUT_MS = 60000;

async function _fetchFromBq(formularyId, gpi) {
  const bq = new BigQuery({ projectId: COMPUTE_PROJECT_ID });

  const query = `
    SELECT FormularyId, GPI, PartialDrugName, DrugNameFormStrength,
           QL, QD, QlType, Unit, Units, Tier
    FROM \`${FORM_ALTS_FORMULARY_DATA_TABLE}\`
    WHERE FormularyId = @formularyId
      AND GPI = @gpi
  `;

  const [rows] = await bq.query({
    query,
    params: { formularyId, gpi },
    location: BQ_LOCATION,
    timeoutMs: BQ_TIMEOUT_MS,
  });

  logger.info(`[QL] BQ fetch: formularyId=${formularyId} gpi=${gpi} → ${rows.length} row(s)`);
  return rows;
}

async function lookupQl(formularyId, gpi, drugName, quantityRequested, daysSupplyRequested, memberId, receivedDate) {
  const [rows, claimDetail] = await Promise.all([
    _fetchFromBq(formularyId, gpi),
    getQualifyingClaimForGpi(memberId, gpi, receivedDate),
  ]);

  const drugUpper = (drugName || '').toUpperCase();
  const candidates = rows.filter(r =>
    r.PartialDrugName && drugUpper.includes(r.PartialDrugName.toUpperCase())
  );

  if (candidates.length === 0) {
    logger.info(`[QL] no match: formularyId=${formularyId} gpi=${gpi} drugName=${drugName}`);
    return { supported: false, reason: 'no_match' };
  }

  const parsed = candidates.map(r => ({
    drugNameFormStrength: (r.DrugNameFormStrength || '').trim(),
    ql:     r.QL,
    qd:     r.QD,
    qlType: (r.QlType || '').trim() || null,
    unit:   (r.Unit   || '').trim(),
    units:  (r.Units  || '').trim(),
    tier:   r.Tier,
  }));

  // Business rule: if any required column is empty/null the row cannot be supported.
  // QL/QD arrive from BQ as a number or null — check both null and NaN.
  const complete = parsed.filter(r =>
    r.drugNameFormStrength &&
    r.ql != null && !isNaN(r.ql) &&
    r.qd != null && !isNaN(r.qd) &&
    r.unit &&
    r.units
  );

  if (complete.length === 0) {
    logger.warn(`[QL] incomplete_data: formularyId=${formularyId} gpi=${gpi}`);
    return { supported: false, reason: 'incomplete_data' };
  }

  if (complete.every(r => r.tier === 0)) {
    logger.info(`[QL] nf_drug: formularyId=${formularyId} gpi=${gpi}`);
    return { supported: false, reason: 'nf_drug' };
  }

  const valid = complete.filter(r => r.tier !== 0);

  const allAgree = valid.length === 1 || valid.every(
    r => r.ql === valid[0].ql && r.qd === valid[0].qd && r.unit === valid[0].unit
      && r.drugNameFormStrength === valid[0].drugNameFormStrength
  );

  if (!allAgree) {
    return {
      supported: true,
      requiresPicker: true,
      options: valid.map(r => {
        const hasQualifyingClaims = _computeHasQualifyingClaims(r, claimDetail);
        return {
          drugNameFormStrength: r.drugNameFormStrength,
          ql: r.ql,
          qd: r.qd,
          qlType: r.qlType,
          unit: r.unit,
          units: r.units,
          hasQualifyingClaims,
          qualifyingClaim: _buildQualifyingClaim(hasQualifyingClaims, claimDetail, r.units),
        };
      }),
    };
  }

  const r = valid[0];
  const hasQualifyingClaims = _computeHasQualifyingClaims(r, claimDetail);
  logger.info(`[QL] match: formularyId=${formularyId} gpi=${gpi} → ${r.drugNameFormStrength} hasQualifyingClaims=${hasQualifyingClaims}`);
  return {
    supported: true,
    requiresPicker: false,
    result: {
      drugNameFormStrength: r.drugNameFormStrength,
      ql: r.ql,
      qd: r.qd,
      qlType: r.qlType,
      unit: r.unit,
      units: r.units,
      hasQualifyingClaims,
      qualifyingClaim: _buildQualifyingClaim(hasQualifyingClaims, claimDetail, r.units),
    },
    verbiage: _buildVerbiage(r, quantityRequested, daysSupplyRequested),
  };
}

function _computeHasQualifyingClaims(option, claimDetail) {
  if (!claimDetail || claimDetail.maxMdd == null) return false;
  const ql = Number(option.ql);
  const qd = Number(option.qd);
  if (qd <= 0) return false;

  const round8 = n => Math.round(n * 1e8) / 1e8;
  const mdd = round8(claimDetail.maxMdd);
  const ratio = round8(ql / qd);
  return mdd >= ratio;
}

function _buildQualifyingClaim(hasQualifyingClaims, claimDetail, units) {
  if (!hasQualifyingClaims || !claimDetail) return null;
  return {
    dispQty:  claimDetail.dispQty,
    daysSply: claimDetail.daysSply,
    fillDt:   claimDetail.fillDt,
    units,
  };
}

function _buildVerbiage(r, qtyReq, daysReq) {
  const planUnitLabel = r.ql     === 1 ? r.unit : r.units;
  const planDayLabel  = r.qd     === 1 ? 'DAY'  : 'DAYS';
  const reqUnitLabel  = qtyReq   === 1 ? r.unit : r.units;
  const reqDayLabel   = daysReq  === 1 ? 'DAY'  : 'DAYS';
  return {
    drugAndRequestedQl: `${r.drugNameFormStrength}, ${qtyReq} ${reqUnitLabel} PER ${daysReq} ${reqDayLabel}`,
    drugAndPlanQl:      `${r.drugNameFormStrength}, ${r.ql} ${planUnitLabel} PER ${r.qd} ${planDayLabel}`,
    planQlOnly:         `${r.ql} ${planUnitLabel} PER ${r.qd} ${planDayLabel}`,
  };
}

module.exports = { lookupQl };
