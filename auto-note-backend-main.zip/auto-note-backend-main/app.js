var path = require("path");
var express = require("express");
var session = require("cookie-session");
var createError = require("http-errors");
var cookieParser = require("cookie-parser");
const logger = require("./logger");
const morgan = require("morgan");

var indexRouter = require("./index");
var usersRouter = require("./users/users");
var authRouter = require("./auth/ping");
var medhokRouter = require("./medhok/medhok");
var bigTableRouter = require("./bigtable/bigtable");
var cdrdBQRouter = require("./cdrd/bigquery");
var cdrdBTRouter = require("./cdrd/bigtable");
var adminRouter = require("./admin/admin");
var drugGuidelineMappingRouter = require("./dlt_guidelines/drug-guideline-mapping");
var insulinPumpTargetListRouter = require("./dlt_guidelines/insulin-pump-target-list");
var dltMonthlyValidationDataRouter = require("./dlt_guidelines/dlt-monthly-validation-data");
var drugDenormDataRouter = require("./dlt_guidelines/drug-denorm-data");
var formularyAlternativesRouter = require("./form_alts/form-alts");
var quantityLimitRouter = require("./quantity_limit/quantity-limit");
var aetnaQuestionsRouter = require("./aetna_questions/aetna-questions");

const PORT = process.env.PORT || 3000;
const cors = require("cors");

const { createExpressSessionConfig } = require("./helpers/sessionConfig");
const { AUTONOTE_MAIN_URL, AUTONOTE_BETA_URL } = require("./parameters/parameterConfig");

async function startServer() {
  createExpressSessionConfig();

  var app = express();
  // Trust the X-Forwarded-Proto header from Istio so req.protocol === 'https'.
  // Without this, cookie-session silently drops Secure cookies (throws internally
  // because req.protocol is 'http' behind the proxy, then catches the error).
  app.set('trust proxy', 1);
  app.use(express.static("./"));
  // Allow the configured frontend origin to send credentialed requests (cookies).
  // A wildcard origin (default cors()) blocks credentials, breaking cross-site auth.
  const allowedOrigins = [AUTONOTE_MAIN_URL, AUTONOTE_BETA_URL].filter(Boolean);
  app.use(cors({
    origin: (origin, cb) => cb(null, !origin || allowedOrigins.includes(origin)),
    credentials: true,
  }));
  app.use(session(JSON.parse(process.env.EXPRESS_SESSION_PARAMS)));

  app.set("views", path.join(__dirname, "views"));
  app.set("view engine", "hbs");

  app.use(
    morgan("combined", {
      stream: {
        write: (message) => logger.info(message.trim()),
      },
    })
  );
  app.use(express.json());
  app.use(cookieParser());
  app.use(express.urlencoded({ extended: false }));
  app.use(express.static(path.join(__dirname, "public")));

  // Browsers auto-request /favicon.ico on every page. Respond 204 (No Content)
  // so it doesn't fall through to the 404 handler and generate a log entry.
  app.get("/favicon.ico", (req, res) => res.status(204).end());

  app.use("/", indexRouter);
  app.use("/users", usersRouter);
  app.use("/auth", authRouter);
  app.use("/medhok", medhokRouter);
  app.use("/bigtable", bigTableRouter);
  app.use("/cdrd/bigquery", cdrdBQRouter);
  app.use("/cdrd/bigtable", cdrdBTRouter);
  app.use("/admin", adminRouter);
  app.use("/drug-guideline-mapping/", drugGuidelineMappingRouter);
  app.use("/insulin-pump-target-list/", insulinPumpTargetListRouter);
  app.use("/dlt-monthly-validation-data/", dltMonthlyValidationDataRouter);
  app.use("/drug-denorm-data/", drugDenormDataRouter);
  app.use("/formulary-alternatives/", formularyAlternativesRouter);
  app.use("/quantity-limit/", quantityLimitRouter);
  app.use("/aetna-questions/", aetnaQuestionsRouter);

  app.use(function (req, res, next) {
    // A 404 is a client-side condition (missing static asset, browser auto-request,
    // bot probe), not a server failure. Don't log here — the error handler below
    // logs it once at the appropriate severity, avoiding duplicate entries.
    next(createError(404, "Resource not found"));
  });

  app.use(function (err, req, res, next) {
    const status = err.status || 500;
    const logLine = `Request failed (${status}): ${req.method} ${req.originalUrl} - ${err.message}`;
    // 5xx = genuine server error -> ERROR; 4xx = client error (e.g. 404 for a
    // missing favicon/static asset) -> WARN, so it doesn't add ERROR-level noise.
    if (status >= 500) {
      logger.error(logLine);
    } else {
      logger.warn(logLine);
    }

    if (res.headersSent) {
      return next(err);
    }

    return res.status(status).json({
      error: err.message || "Internal Server Error",
    });
  });

  app.listen(PORT, (error) => {
    if (!error)
      logger.info(
        "Server is Successfully Running, and App is listening on port " + PORT
      );
    else logger.error("Error occurred, server can't start", error);
  });
}

startServer();
