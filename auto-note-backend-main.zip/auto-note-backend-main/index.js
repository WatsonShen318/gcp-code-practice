const logger = require("./logger");
const { isDeployedEnv } = require("./parameters/parameterConfig");

var { AUTONOTE_MAIN_URL } = require('./parameters/parameterConfig');

var express = require('express');
var router = express.Router();

router.get('/', function (req, res, next) {
    res.render('index', {
        title: "Auto Note Tool's Authentication Portal",
    });
});

router.get('/health', (req, res) => {
    res.status(200).json({status:'UP'});
});

router.get('/form', (req, res) => {
    res.redirect(AUTONOTE_MAIN_URL);
});

router.get('/test-alerts', (req, res) => {
    if (isDeployedEnv() && process.env.ENV_NAME.includes("dev")) {
    // enable alerts testing for pdev only to avoid alert fatigue in other environments
    // if (isDeployedEnv()) {
        // Alert triggers can be uncommented for testing
        logger.error("Error while automating CD_RD responses");
        logger.error("Failed to fetch DLT Monthly Validation Data for GPI");
        logger.error("Error while reading Drug Denorm Data from BigTable for NDC");
        logger.error("Error while reading Drug Guideline Mapping data from BigTable for id");
        logger.error("Error while reading insulin pump target list data from GCS");
        logger.error("retrieve-casedetails-upstream-unavailable");
        logger.error("add-outboundcontact-upstream-unavailable");
        logger.error("Error while pushing audit data to the BT table");
    }
    return res.status(200).json({ name: "Auto Note Tool Alerts" });
});

module.exports = router;
