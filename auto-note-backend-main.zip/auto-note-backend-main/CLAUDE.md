# CLAUDE.md

This file provides guidance to Claude Code when working in this repository.

## Git Workflow Rules

- Always execute the `/commit` command immediately after completing a logical unit of work, task, or iteration.
- Follow each commit command by running the `ai-commit` git alias command.
- Do not proceed to the next feature or task until the previous changes are committed.
- Use conventional commit messages (e.g., `feat: [description]`, `fix: [description]`, `refactor: [description]`).
- Do not push to the remote repository unless explicitly asked.
