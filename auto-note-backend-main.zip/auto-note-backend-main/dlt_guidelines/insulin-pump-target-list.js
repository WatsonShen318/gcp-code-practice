var express = require("express");
const logger = require("../logger");
var router = express.Router();

const { readInsulinPumpTargetListFromGCS } = require("./utils");

router.get("/", async (req, res) => {
  try {
    const insulinPumpTargetList = await readInsulinPumpTargetListFromGCS();

    res.status(200).json({
      status: "success",
      data: insulinPumpTargetList
    });
  } catch (error) {
    logger.error("Error while reading insulin pump target list data from GCS", error);
    res
      .status(400)
      .send(
        `An Error occured while reading insulin pump target list data from GCS, error: ${error}.`
      );
  }
});

module.exports = router;
