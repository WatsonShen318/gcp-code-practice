const express = require("express");
const logger = require("../logger");
const {
  queryDLTMonthlyValidationDataFromBQ,
  queryDLTMonthlyValidationDataFromBT
} = require("./utils");

const router = express.Router();

router.get("/:id", async (req, res) => {
  const { id: gpi_cd } = req.params;
  try {
    let data;
    try {
      logger.info(`Fetching DLT Monthly Validation Data for GPI: ${gpi_cd} from Bigtable...`);
      data = await queryDLTMonthlyValidationDataFromBT(gpi_cd);
    } catch (errorBT) {
      logger.error(`Bigtable query failed for GPI: ${gpi_cd}: ${errorBT}. Falling back to BigQuery.`);
      data = await queryDLTMonthlyValidationDataFromBQ(gpi_cd);
    }
    
    logger.info(`Successfully fetched DLT Monthly Validation Data for GPI: ${gpi_cd}.`);
    res.status(200).json({
      status: "success",
      data,
    });
  } catch (errorParent) {
    logger.error(`Failed to fetch DLT Monthly Validation Data for GPI: ${gpi_cd}, error: ${errorParent}`);
    res
      .status(400)
      .send(`An error occurred while querying DLT Monthly Validation Data for GPI. Please check logs for more details.`);
  }
});

module.exports = router;