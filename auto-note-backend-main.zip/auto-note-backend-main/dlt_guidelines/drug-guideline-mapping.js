var express = require("express");
const logger = require("../logger");
var router = express.Router();

const { readDrugGuidelineMappingFromGCS, readGuidelineFormFromBigTable, searchDrugNameInBigTable } = require("./utils");

router.get("/", async (req, res) => {
  try {
    const drugGuidelineMapping = await readDrugGuidelineMappingFromGCS();

    res.status(200).json({
      status: "success",
      data: drugGuidelineMapping
    });
  } catch (error) {
    logger.error("Error while reading drug guideline mapping data from GCS", error);
    res
      .status(400)
      .send(
        `An Error occured while reading drug guideline mapping data from GCS, error: ${error}.`
      );
  }
});

router.get("/:id", async (req, res) => {
  try {
    const { id } = req.params;
    
    // Replace with your actual BigTable read function
    const data = await readGuidelineFormFromBigTable(id);

    res.status(200).json({
      status: "success",
      data: data
    });
  } catch (error) {
    logger.error(`Error while reading Drug Guideline Mapping data from BigTable for id: ${req.params.id}`, error);
    res
      .status(400)
      .send(
        `An Error occured while reading Drug Guideline Mapping data from BigTable, error: ${error}.`
      );
  }
});

router.post("/search-drug-list", async (req, res) => {
  try {
    const { searchDrugName } = req.body;
    
    if (!searchDrugName) {
      return res.status(400).json({
        status: "error",
        message: "searchDrugName is required in request body"
      });
    }
    
    const trimmedSearchDrugName = searchDrugName?.trim();
    const matchedRecords = await searchDrugNameInBigTable(trimmedSearchDrugName);

    res.status(200).json({
      status: "success",
      searchTerm: trimmedSearchDrugName,
      matchCount: matchedRecords.length,
      data: matchedRecords
    });
  } catch (error) {
    logger.error(`Error while searching drug name in BigTable: ${req.body.searchDrugName}`, error);
    res
      .status(400)
      .send(
        `An Error occurred while searching drug name, error: ${error}.`
      );
  }
});

module.exports = router;
