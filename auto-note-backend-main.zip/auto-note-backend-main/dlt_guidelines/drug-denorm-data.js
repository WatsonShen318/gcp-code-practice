var express = require("express");
const logger = require("../logger");
var router = express.Router();

const { readDrugDenormDataFromBigTable } = require("./utils");

/* id has to be NDC received from MHK */
router.get("/:id", async (req, res) => {
  try {
    const { id } = req.params;
    
    // Replace with your actual BigTable read function
    const data = await readDrugDenormDataFromBigTable(id);

    res.status(200).json({
      status: "success",
      data: data
    });
  } catch (error) {
    logger.error(`Error while reading Drug Denorm Data from BigTable for NDC: ${req.params.id}`, error);
    res
      .status(400)
      .send(
        `An Error occurred while reading Drug Denorm Data from BigTable, error: ${error}.`
      );
  }
});

module.exports = router;
