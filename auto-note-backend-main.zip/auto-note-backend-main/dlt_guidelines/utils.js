const logger = require("../logger");
const { Bigtable } = require("@google-cloud/bigtable");
const { Storage } = require("@google-cloud/storage");
const { BigQuery } = require("@google-cloud/bigquery");
const JSON5 = require("json5");
const moment = require("moment-timezone");

const {
  COMPUTE_PROJECT_ID,
  DATA_BUCKET_NAME,
  DRUG_GUIDELINE_FILE_NAME,
  INSULIN_PUMP_TARGET_LIST_FILE_NAME,
  PROJECT_ID,
  INSTANCE_ID,
  DRUG_ID_GUIDELINE_MAPPING_TABLE_ID,
  DRUG_NAME_GUIDELINE_MAPPING_TABLE_ID,
  BQ_DLT_MONTHLY_VALIDATION_DATA,
  BT_DLT_MONTHLY_VALIDATION_DATA_TABLE_ID,
  AUTO_NOTE_DRUG_DENORM_TABLE_ID
} = require("../parameters/parameterConfig");

const bucketName = DATA_BUCKET_NAME;
const drugGuidelineFileName = DRUG_GUIDELINE_FILE_NAME;
const insulinPumpTargetListFileName = INSULIN_PUMP_TARGET_LIST_FILE_NAME;

const storage = new Storage();
const bucket = storage.bucket(bucketName);

async function readDrugGuidelineMappingFromGCS() {
  try {
    logger.info(
      `[readDrugGuidelineMappingFromGCS] Starting to read drug guideline mapping file: ${drugGuidelineFileName} from GCS bucket: ${bucket.name}`
    );
    const file = bucket.file(drugGuidelineFileName);
    // Check if file exists
    const [exists] = await file.exists();
    if (!exists) {
      throw new Error(
        `File ${drugGuidelineFileName} does not exist in bucket ${bucketName}`
      );
    }

    // Download file contents
    const [contents] = await file.download();
    const jsonData = JSON.parse(contents.toString());

    logger.info(
      `[readDrugGuidelineMappingFromGCS] Successfully read and parsed drug guideline mapping JSON file: ${drugGuidelineFileName} from GCS bucket: ${bucketName}, data size: ${
        JSON.stringify(jsonData).length
      } bytes`
    );
    return jsonData;
  } catch (error) {
    logger.error(
      `[readDrugGuidelineMappingFromGCS] Failed to read drug guideline mapping from GCS bucket: ${bucketName}, file: ${drugGuidelineFileName}`,
      error
    );
    throw error;
  }
}

async function readGuidelineFormFromBigTable(gpi) {
  const bigtable = new Bigtable({
    projectId: PROJECT_ID,
  });

  const rowKeyPrefix = gpi;

  try {
    logger.info(
      `[readGuidelineFormFromBigTable] Starting BigTable query for GPI-Guideline mapping with row key prefix: ${rowKeyPrefix} in table: ${DRUG_ID_GUIDELINE_MAPPING_TABLE_ID}`
    );

    const instance = bigtable.instance(INSTANCE_ID);
    const table = instance.table(DRUG_ID_GUIDELINE_MAPPING_TABLE_ID);

    // Use getRows with prefix filter to find rows starting with the prefix
    const [rows] = await table.getRows({
      prefix: rowKeyPrefix,
    });

    if (!rows || rows.length === 0) {
      logger.warn(
        `[readGuidelineFormFromBigTable] No matching rows found for GPI prefix: ${rowKeyPrefix} in table: ${DRUG_ID_GUIDELINE_MAPPING_TABLE_ID}`
      );
      // throw new Error(
      //   `No GPI - Guideline Form data found for row key prefix: ${rowKeyPrefix}`
      // );
      return [];
    }

    logger.info(
      `[readGuidelineFormFromBigTable] Found ${rows.length} row(s) matching prefix: ${rowKeyPrefix}, processing all rows`
    );

    // Process all matching rows
    const results = [];
    for (const row of rows) {
      const data = { rowKey: row.id };

      if (row.data["autonote"]) {
        for (const [column, cells] of Object.entries(row.data["autonote"])) {
          // Get the latest cell value
          data[column] = cells[0].value.toString();
        }
      }

      results.push(data);
    }
    return results;
  } catch (error) {
    logger.error(
      `[readGuidelineFormFromBigTable] BigTable read operation failed for table: ${DRUG_ID_GUIDELINE_MAPPING_TABLE_ID}, row key prefix: ${rowKeyPrefix}`,
      error
    );
    throw error;
  } finally {
    if (bigtable) {
      await bigtable.close();
      logger.info(
        `[readGuidelineFormFromBigTable] BigTable connection closed for instance: ${INSTANCE_ID}`
      );
    }
  }
}

async function searchDrugNameInBigTable(drugName) {
  const bigtable = new Bigtable({
    projectId: PROJECT_ID,
  });

  try {
    const searchTerm = drugName.toUpperCase();
    logger.info(
      `[searchDrugNameInBigTable] Starting BigTable search for drug name: ${drugName} in table: ${DRUG_NAME_GUIDELINE_MAPPING_TABLE_ID}`
    );

    const instance = bigtable.instance(INSTANCE_ID);
    const table = instance.table(DRUG_NAME_GUIDELINE_MAPPING_TABLE_ID);

    // Use row key regex filter for filtering list of matched drugs
    // const [rows] = await table.getRows({
    //   filter: {
    //     row: {
    //       key: new RegExp(`.*${searchTerm}.*`),
    //       // key: new RegExp(`.*#.*${searchTerm}.*`)
    //     },
    //   },
    // });

    // Use getRows with prefix filter to find rows starting with the prefix
    const [rows] = await table.getRows({
      prefix: searchTerm,
    });

    const matchedRecords = [];
    for (const row of rows) {
      const data = { rowKey: row.id };

      if (row.data["autonote"]) {
        for (const [column, cells] of Object.entries(row.data["autonote"])) {
          data[column] = cells[0].value.toString();
        }
      }

      matchedRecords.push(data);
      logger.debug(
        `[searchDrugNameInBigTable] Processed matching row: ${row.id}`
      );
    }

    logger.info(
      `[searchDrugNameInBigTable] Found ${matchedRecords.length} matching records for drug name: ${drugName} using efficient filtering`
    );
    return matchedRecords;
  } catch (error) {
    logger.error(
      `[searchDrugNameInBigTable] Efficient BigTable search failed for drug name: ${drugName}`,
      error
    );
    return [];
  } finally {
    if (bigtable) {
      await bigtable.close();
      logger.info(
        `[searchDrugNameInBigTable] BigTable connection closed for instance: ${INSTANCE_ID}`
      );
    }
  }
}

async function readInsulinPumpTargetListFromGCS() {
  try {
    logger.info(
      `[readInsulinPumpTargetListFromGCS] Starting to read insulin pump target list file: ${insulinPumpTargetListFileName} from GCS bucket: ${bucket.name}`
    );
    const file = bucket.file(insulinPumpTargetListFileName);
    // Check if file exists
    const [exists] = await file.exists();
    if (!exists) {
      throw new Error(
        `File ${insulinPumpTargetListFileName} does not exist in bucket ${bucketName}`
      );
    }

    // Download file contents
    const [contents] = await file.download();
    const jsonData = JSON.parse(contents.toString());

    logger.info(
      `[readInsulinPumpTargetListFromGCS] Successfully read and parsed insulin pump target list JSON file: ${insulinPumpTargetListFileName} from GCS bucket: ${bucketName}, data size: ${
        JSON.stringify(jsonData).length
      } bytes`
    );
    return jsonData;
  } catch (error) {
    logger.error(
      `[readInsulinPumpTargetListFromGCS] Failed to read insulin pump target list from GCS bucket: ${bucketName}, file: ${insulinPumpTargetListFileName}`,
      error
    );
    throw error;
  }
}

async function queryDLTMonthlyValidationDataFromBQ(gpi_cd) {
  try {
    logger.info(
      `[queryDLTMonthlyValidationDataFromBQ] Starting BigQuery query for DLT Monthly Validation Data${
        gpi_cd ? " with gpi_cd: " + gpi_cd : ""
      }...`
    );
    const bigquery = new BigQuery({ projectId: COMPUTE_PROJECT_ID });
    let query = "";
    let options = {};

    if (gpi_cd) {
      query = `SELECT * FROM ${BQ_DLT_MONTHLY_VALIDATION_DATA} WHERE gpi_cd = @gpi_cd`;
      options = { query, params: { gpi_cd } };
    } else {
      logger.error(
        `[queryDLTMonthlyValidationDataFromBQ] Missing required parameter: gpi_cd`
      );
      throw new Error("Missing required parameter: gpi_cd");
    }

    const [rows] = await bigquery.query(options);
    logger.info(
      `[queryDLTMonthlyValidationDataFromBQ] Successfully executed query for DLT Monthly Validation Data for GPI: ${gpi_cd}, retrieved ${rows.length} row(s).`
    );
    return rows;
  } catch (error) {
    logger.error(
      `[queryDLTMonthlyValidationDataFromBQ] Error executing BigQuery query for DLT Monthly Validation Data for GPI: ${gpi_cd}:`,
      error
    );
    throw error;
  }
}

async function queryDLTMonthlyValidationDataFromBT(gpi_cd) {
  const bigtable = new Bigtable({ projectId: PROJECT_ID });
  
  try {
    if (!gpi_cd) {
      logger.error(
        "[queryDLTMonthlyValidationDataFromBT] Missing required parameter: gpi_cd"
      );
      throw new Error("Missing required parameter: gpi_cd");
    }
    logger.info(
      `[queryDLTMonthlyValidationDataFromBT] Starting Bigtable query for DLT Monthly Validation Data with gpi_cd: ${gpi_cd}...`
    );

    const instance = bigtable.instance(INSTANCE_ID);
    // Ensure BT_DLT_MONTHLY_VALIDATION_DATA is defined in your parameters (similar to BQ_DLT_MONTHLY_VALIDATION_DATA)
    const nowEastern = moment().tz('America/New_York');

    const table_suffix = nowEastern.format('YYYY_MM_DD');
    logger.info(`[queryDLTMonthlyValidationDataFromBT] Table suffix for Bigtable query: ${table_suffix}`);
    const table = instance.table(
      `${BT_DLT_MONTHLY_VALIDATION_DATA_TABLE_ID}_${table_suffix}`
    );

    const [rows] = await table.getRows({ prefix: gpi_cd });

    const results = rows.map((row) => {
      let dlt_validation_icd_code = "";
      let dlt_validation_indication = "";

      // Expected column family: cf_dlt_monthly_validation_data_${table_suffix} with qualifier 'data'
      if (
        row.data[`cf_dlt_monthly_validation_data_${table_suffix}`] &&
        row.data[`cf_dlt_monthly_validation_data_${table_suffix}`]["data"] &&
        row.data[`cf_dlt_monthly_validation_data_${table_suffix}`]["data"].length
      ) {
        let rawData =
          row.data[`cf_dlt_monthly_validation_data_${table_suffix}`][
            "data"
          ][0].value.toString('utf8');

        // rawData = rawData.replace(/'/g, '"');//
        try {
          const parsed = JSON5.parse(rawData);
          dlt_validation_icd_code = parsed.dlt_validation_icd_code || "";
          // dlt_validation_indication = parsed.dlt_validation_indication || "";
        } catch (e) {
          logger.info(
            `[queryDLTMonthlyValidationDataFromBT] Raw data that failed to parse for row: ${row.id} is: ${rawData}`
          );
          logger.error(
            `[queryDLTMonthlyValidationDataFromBT] JSON parse error for row: ${row.id}`,
            e
          );
          throw new Error("Failed to parse JSON from Bigtable");
        }
      }

      return {
        gpi_cd: row.id,
        dlt_validation_indication,
        dlt_validation_icd_code,
      };
    });

    logger.info(
      `[queryDLTMonthlyValidationDataFromBT] Successfully executed Bigtable query for gpi_cd: ${gpi_cd}, retrieved ${rows.length} row(s).`
    );
    return results;
  } catch (error) {
    logger.error(
      `[queryDLTMonthlyValidationDataFromBT] Error executing Bigtable query for gpi_cd: ${gpi_cd}:`,
      error
    );
    throw error;
  } finally {
    if (bigtable) {
      await bigtable.close();
      logger.info(
        `[queryDLTMonthlyValidationDataFromBT] BigTable connection closed for instance: ${INSTANCE_ID}`
      );
    }
  }
}

async function readDrugDenormDataFromBigTable(ndc) {
  const bigtable = new Bigtable({
    projectId: PROJECT_ID,
  });

  const rowKeyPrefix = ndc;

  try {
    logger.info(
      `[readDrugDenormDataFromBigTable] Starting BigTable query for Drug Denorm Data with row key prefix: ${rowKeyPrefix} in table: ${AUTO_NOTE_DRUG_DENORM_TABLE_ID}`
    );

    const instance = bigtable.instance(INSTANCE_ID);
    const table = instance.table(AUTO_NOTE_DRUG_DENORM_TABLE_ID);

    // Use getRows with prefix filter to find rows starting with the prefix
    const [rows] = await table.getRows({
      prefix: rowKeyPrefix,
    });

    if (!rows || rows.length === 0) {
      logger.warn(
        `[readDrugDenormDataFromBigTable] No matching rows found for NDC prefix: ${rowKeyPrefix} in table: ${AUTO_NOTE_DRUG_DENORM_TABLE_ID}`
      );
        // throw new Error(
        //   `No NDC - Drug Denorm data found for row key prefix: ${rowKeyPrefix}`
        // );
        return [];
    }

    logger.info(
      `[readDrugDenormDataFromBigTable] Found ${rows.length} row(s) matching prefix: ${rowKeyPrefix}, processing all rows`
    );

    // Process all matching rows
    const results = [];
    for (const row of rows) {
      const data = { rowKey: row.id };

      if (row.data["autonote"]) {
        for (const [column, cells] of Object.entries(row.data["autonote"])) {
          // Get the latest cell value
          data[column] = cells[0].value.toString();
        }
      }

      results.push(data);
    }
    return results;
  } catch (error) {
    logger.error(
      `[readDrugDenormDataFromBigTable] BigTable read operation failed for table: ${AUTO_NOTE_DRUG_DENORM_TABLE_ID}, row key prefix: ${rowKeyPrefix}`,
      error
    );
    throw error;
  } finally {
    if (bigtable) {
      await bigtable.close();
      logger.info(
        `[readDrugDenormDataFromBigTable] BigTable connection closed for instance: ${INSTANCE_ID}`
      );
    }
  }
}

module.exports = {
  readDrugGuidelineMappingFromGCS,
  readGuidelineFormFromBigTable,
  searchDrugNameInBigTable,
  readInsulinPumpTargetListFromGCS,
  queryDLTMonthlyValidationDataFromBQ,
  queryDLTMonthlyValidationDataFromBT,
  readDrugDenormDataFromBigTable
};
