const { BigQuery } = require('@google-cloud/bigquery');
const logger = require('../logger');
const {
  COMPUTE_PROJECT_ID,
  FORM_ALTS_MASTER_VIEW_TABLE,
  FORM_ALTS_CAG_CROSSWALK_TABLE,
  FORM_ALTS_GPI_DRUG_TABLE,
  FORM_ALTS_INDICATION_SET_TABLE,
  FORM_ALTS_ICD10_LIST_TABLE,
  FORM_ALTS_ICD10_CROSSWALK_TABLE,
  FORM_ALTS_DRUG_NAME_NOTES_TABLE,
} = require('../parameters/parameterConfig');
const { getNfCheckedGpi12s } = require('../claims_history/utils');

// ── In-memory reference data (stale-while-revalidate) ────────────────
// First request loads from BQ and caches the Maps.
// After REFRESH_TTL_MS, the next request is served instantly from the
// stale cache while a background BQ refresh fires silently - no request ever
// waits for a refresh. This means every GKE pod self-heals after a DAG run
// without needing a restart or a manual /reload call.
//
// Timeline:
//   [pod start]     → refData = null → first request waits ~5s for BQ load
//   [0–TTL]         → all requests served from memory (<1ms)
//   [TTL expires]   → next request served from stale cache immediately;
//                     background BQ query fires; ~5s later refData is fresh
//   [after refresh] → all requests served from new data (<1ms)

const REFRESH_TTL_MS = 60 * 60 * 1000; // 1 hour
const BQ_LOCATION = 'US';
const BQ_TIMEOUT_MS = 60000;
const TF_REQUIRED_CAP = 3;
const ALT_TYPE_RFI = 'RFI';
const ALT_TYPE_DENIAL = 'DenialLetter';

let refData = null;
let loadPromise = null;

function _runLoad() {
  if (loadPromise) return loadPromise; // deduplicate concurrent load attempts

  loadPromise = (async () => {
    logger.info('[FormAlts] Loading reference tables from BigQuery...');
    const bq = new BigQuery({ projectId: COMPUTE_PROJECT_ID });

    const [[cagRows], [gpiRows], [indicationRows], [icd10ListRows], [icd10CrosswalkRows], [drugNameNotesRows]] = await Promise.all([
      bq.query({
        query: `SELECT Id, Client, SubclientName, FormularyName, FormularyId, CAG, RxPlanId FROM \`${FORM_ALTS_CAG_CROSSWALK_TABLE}\``,
        location: BQ_LOCATION,
        timeoutMs: BQ_TIMEOUT_MS,
      }),
      bq.query({
        query: `SELECT GPI, DrugName, PartialDrugName, IndicationSetId FROM \`${FORM_ALTS_GPI_DRUG_TABLE}\``,
        location: BQ_LOCATION,
        timeoutMs: BQ_TIMEOUT_MS,
      }),
      bq.query({
        query: `SELECT IndicationSetId, Indication FROM \`${FORM_ALTS_INDICATION_SET_TABLE}\``,
        location: BQ_LOCATION,
        timeoutMs: BQ_TIMEOUT_MS,
      }),
      bq.query({
        query: `SELECT Indication, Icd10List FROM \`${FORM_ALTS_ICD10_LIST_TABLE}\``,
        location: BQ_LOCATION,
        timeoutMs: BQ_TIMEOUT_MS,
      }),
      bq.query({
        query: `SELECT Indication, ICD10 FROM \`${FORM_ALTS_ICD10_CROSSWALK_TABLE}\``,
        location: BQ_LOCATION,
        timeoutMs: BQ_TIMEOUT_MS,
      }),
      bq.query({
        query: `SELECT DrugName, Notes FROM \`${FORM_ALTS_DRUG_NAME_NOTES_TABLE}\``,
        location: BQ_LOCATION,
        timeoutMs: BQ_TIMEOUT_MS,
      }).catch(err => {
        logger.warn('[FormAlts] Failed to load drug name notes table (non-blocking):', err);
        return [[]];
      }),
    ]);

    // CAG string → FormularyId  e.g. "9110-3TIER-32" → "45734"
    // Filter rows where CAG or FormularyId is null — they can't be resolved or used.
    const cagMap = new Map(
      cagRows.filter(r => r.CAG && r.FormularyId).map(r => [r.CAG, r.FormularyId])
    );

    // Sorted unique FormularyIds (kept for backward compat with /formulary-ids endpoint)
    const formularyIds = [...new Set(cagRows.map(r => r.FormularyId).filter(Boolean))].sort();

    // Client → deduplicated, sorted [{formularyId, formularyName, subClientName}]
    // Dedup by (formularyId, subClientName, formularyName): a single FormularyId can carry
    // distinct display names (e.g. CY26_EXP → "…Carrier: 5522…" and "…Carrier: 82SE"), and
    // each distinct name is a separate dropdown option even when SubclientName is blank.
    // Rows that are identical in id+name+subclient (differing only by GroupId) still collapse.
    const _clientFormMap = new Map(); // client → Map<formularyId||subClientName||formularyName, entry>
    for (const r of cagRows) {
      if (!r.FormularyId || !r.FormularyName) continue;
      if (!_clientFormMap.has(r.Client)) _clientFormMap.set(r.Client, new Map());
      const formMap = _clientFormMap.get(r.Client);
      const key = `${r.FormularyId}||${r.SubclientName || ''}||${r.FormularyName || ''}`;
      if (!formMap.has(key)) {
        formMap.set(key, {
          formularyId:   r.FormularyId,
          formularyName: r.FormularyName,
          subClientName: r.SubclientName || null,
        });
      }
    }
    const clientFormularyMap = new Map();
    for (const [client, formMap] of _clientFormMap) {
      const entries = [...formMap.values()].sort((a, b) => {
        const sc = (a.subClientName || '').localeCompare(b.subClientName || '');
        return sc !== 0 ? sc : (a.formularyName || '').localeCompare(b.formularyName || '');
      });
      clientFormularyMap.set(client, entries);
    }

    // GPI → [{ drugName, partialDrugName, indicationSetId }, ...]
    const gpiMap = new Map();
    for (const r of gpiRows) {
      if (!gpiMap.has(r.GPI)) gpiMap.set(r.GPI, []);
      gpiMap.get(r.GPI).push({
        drugName: r.DrugName,
        partialDrugName: r.PartialDrugName,
        indicationSetId: r.IndicationSetId,
      });
    }

    // IndicationSetId → [indication, ...]
    // Skip rows where Indication is null — a null indication can't be displayed or matched.
    const indicationSetMap = new Map();
    for (const r of indicationRows) {
      if (!r.Indication) continue;
      if (!indicationSetMap.has(r.IndicationSetId)) indicationSetMap.set(r.IndicationSetId, []);
      indicationSetMap.get(r.IndicationSetId).push(r.Indication);
    }

    // Indication → Icd10List string (null when absent)
    const icd10ListMap = new Map(
      icd10ListRows.filter(r => r.Indication).map(r => [r.Indication, r.Icd10List || null])
    );

    // ICD10 → Set<indication>  (one ICD-10 can map to multiple indications)
    // Skip rows where either column is null — they can't participate in auto-selection.
    const icd10CrosswalkMap = new Map();
    for (const r of icd10CrosswalkRows) {
      if (!r.ICD10 || !r.Indication) continue;
      if (!icd10CrosswalkMap.has(r.ICD10)) icd10CrosswalkMap.set(r.ICD10, new Set());
      icd10CrosswalkMap.get(r.ICD10).add(r.Indication);
    }

    const drugNameNotesMap = new Map();
    drugNameNotesRows.forEach(r => {
      if (r.DrugName && r.Notes) drugNameNotesMap.set(r.DrugName, r.Notes);
    });

    logger.info(`[FormAlts] Reference data loaded - CAG: ${cagMap.size} entries, clients: ${clientFormularyMap.size}, GPI: ${gpiMap.size} entries, drug notes: ${drugNameNotesMap.size} entries`);
    refData = { cagMap, formularyIds, clientFormularyMap, gpiMap, indicationSetMap, icd10ListMap, icd10CrosswalkMap, drugNameNotesMap, loadedAt: Date.now() };
    loadPromise = null; // refData is now the source of truth; release the Promise reference
    return refData;
  })().catch(err => {
    loadPromise = null;
    logger.error('[FormAlts] Reference data load failed:', err);
    throw err;
  });

  return loadPromise;
}

async function loadReferenceData() {
  // Data is fresh - return immediately (hot path, <1ms)
  if (refData && Date.now() - refData.loadedAt < REFRESH_TTL_MS) {
    return refData;
  }

  // No data yet - first request must wait for the BQ load
  if (!refData) {
    return _runLoad();
  }

  // Data exists but TTL expired - serve stale data immediately, refresh in background
  if (!loadPromise) {
    logger.info('[FormAlts] TTL expired - triggering background refresh (serving stale data until complete)');
    _runLoad(); // fire-and-forget; errors are logged inside _runLoad
  }
  return refData;
}

async function reloadReferenceData() {
  refData = null;
  loadPromise = null;
  return _runLoad();
}

async function getFormularyIds() {
  const { formularyIds } = await loadReferenceData();
  return formularyIds;
}

// ── /resolve-formulary ─────────────────────────────────────────────────

// Builds the CAG string and looks it up in the in-memory crosswalk.
// Returns availableFormularyIds on not-found so the frontend can populate a fallback dropdown.
async function resolveFormularyId(companyLob, companyAccounts, companyAccountGroup) {
  const { cagMap } = await loadReferenceData();
  const cag = `${companyLob}-${companyAccounts}-${companyAccountGroup}`;
  const formularyId = cagMap.get(cag);

  if (formularyId) {
    logger.info(`[FormAlts] resolveFormularyId: CAG=${cag} → ${formularyId}`);
    return { found: true, formularyId };
  }

  logger.info(`[FormAlts] resolveFormularyId: no match for CAG=${cag}`);
  return { found: false };
}

// Returns formulary options for a given client, grouped for the picker UI.
// formularies: [{formularyId, formularyName, subClientName}] — sorted by subClient then name.
// subClients: sorted unique subClientName values (non-null) — used to render optgroups.
async function getFormularyOptions(client) {
  const { clientFormularyMap } = await loadReferenceData();
  const formularies = clientFormularyMap.get(client) || [];
  const subClients = [...new Set(formularies.map(e => e.subClientName).filter(Boolean))].sort();
  logger.info(`[FormAlts] getFormularyOptions: client=${client} → ${formularies.length} formularies, ${subClients.length} subclients`);
  return { formularies, subClients };
}

// ── /lookup ────────────────────────────────────────────────────────────

// Matches drug by GPI + substring on mhkDrugName, builds indication list for each match,
// and optionally auto-selects an indication from the Primary Dx ICD-10.
//
// Returns:
//   { supported: false }              - 0 GPI/name matches; drug not in Auto Note Tool
//   { supported: true, drugOptions }  - 1+ matches; frontend shows picker if >1
//
// Each drugOption:
//   { drugName, indicationSetId, indications: [{ indication, icd10List }], autoSelectedIndication }
//   autoSelectedIndication is non-null only when exactly 1 crosswalk match exists for this drug's set.
async function lookupDrugAndIndications(gpi, mhkDrugName, primaryDxIcd10) {
  const { gpiMap, indicationSetMap, icd10ListMap, icd10CrosswalkMap, drugNameNotesMap } = await loadReferenceData();

  // Step 1: GPI exact match + first word of mhkDrugName contains PartialDrugName (case-insensitive)
  const mhkUpper = (((mhkDrugName || '').trim().split(/\s+/, 1)[0]) || '').toUpperCase();
  const candidates = (gpiMap.get(gpi) || []).filter(d =>
    d.partialDrugName && mhkUpper.includes(d.partialDrugName.toUpperCase())
  );

  if (candidates.length === 0) {
    logger.info(`[FormAlts] lookupDrug: no match - GPI=${gpi} name=${mhkDrugName}`);
    return { supported: false };
  }

  const icd10Upper = primaryDxIcd10 ? primaryDxIcd10.toUpperCase() : null;
  const crosswalkSet = icd10Upper ? (icd10CrosswalkMap.get(icd10Upper) || new Set()) : new Set();

  let drugOptions = candidates.map(drug => {
    const indications = (indicationSetMap.get(drug.indicationSetId) || []).map(indication => ({
      indication,
      icd10List: icd10ListMap.get(indication) || null,
    }));

    // Step 2b: auto-select when exactly 1 crosswalk indication is in this drug's indication set
    const drugIndicationSet = new Set(indications.map(i => i.indication));
    const crosswalkMatches = [...crosswalkSet].filter(i => drugIndicationSet.has(i));
    const autoSelectedIndication = crosswalkMatches.length === 1 ? crosswalkMatches[0] : null;

    return {
      drugName: drug.drugName,
      indicationSetId: drug.indicationSetId,
      indications,
      autoSelectedIndication,
      notes: drugNameNotesMap.get(drug.drugName) || null,
    };
  });

  drugOptions = drugOptions?.sort((a, b) => a.drugName.localeCompare(b.drugName));

  // If mhkDrugName matches one option exactly, return only that option so the frontend
  // never shows a picker for a drug the case already identifies unambiguously.
  const mhkNameUpper = (mhkDrugName || '').trim().toUpperCase();
  const exactMatch = drugOptions.find(opt => opt.drugName.toUpperCase() === mhkNameUpper);
  const resolvedOptions = exactMatch ? [exactMatch] : drugOptions;

  logger.info(`[FormAlts] lookupDrug: ${drugOptions.length} candidate(s), returning ${resolvedOptions.length} (exact name match: ${!!exactMatch}) - GPI=${gpi}`);
  return { supported: true, drugOptions: resolvedOptions };
}

// ── /fetch ─────────────────────────────────────────────────────────────

// Fetches RFI + DenialLetter alternatives for a formularyId + drugName + indication
// in a single BQ query using a window function for the T/F count.
//
// indication = '' for no-diagnosis / Pharmacist "None of the above" paths.
// Do NOT call for Technician + "None of the above" - frontend handles that escalation.
//
// The view currently stores empty indication as NULL (NULLIF applied at build time).
// The WHERE clause handles both NULL (current) and '' (after DAG redeployment) so this
// works in both states without requiring a view redeploy to unblock testing.
async function fetchFormAlts(formularyId, drugName, indication, memberId, receivedDate) {
  const bq = new BigQuery({ projectId: COMPUTE_PROJECT_ID });

  // COALESCE(Indication, '') = @indication normalizes NULL (current view) and '' (after DAG redeploy)
  // to the same value, so indication='' correctly matches no-dx rows in both view states.
  // Fetching only the requested indication's rows (not a dual IN fetch) keeps the result set
  // small and lets BigQuery skip unrelated blocks efficiently.
  const query = `
    SELECT
        Type,
        FormularyAlternative,
        FormularyAlternativeGpi12,
        LEFT(FormularyAlternativeGpi12, 10)                              AS Gpi10,
        FormularyAlternativeGroupId,
        GpiSimilarity,
        COUNT(DISTINCT LEFT(FormularyAlternativeGpi12, 10))
            OVER (PARTITION BY Type)                                     AS unique_gpi10_count
    FROM \`${FORM_ALTS_MASTER_VIEW_TABLE}\`
    WHERE FormularyId              = @formularyId
      AND RequestedDrugDrugName   = @drugName
      AND COALESCE(Indication, '') = @indication
    ORDER BY Type, GpiSimilarity
  `;

  logger.info(`[FormAlts] fetchFormAlts: formularyId=${formularyId} drugName=${drugName} indication=${indication} receivedDate=${receivedDate}`);

  const [rows] = await bq.query({
    query,
    params: { formularyId, drugName, indication },
    location: BQ_LOCATION,
  });

  const rfiRows    = rows.filter(r => r.Type === ALT_TYPE_RFI);
  const denialRows = rows.filter(r => r.Type === ALT_TYPE_DENIAL);

  // tfRequired: distinct Gpi10 count capped at 3. Display even when 0 (per Steve's update).
  const tfRequired = Math.min(rfiRows.length > 0 ? Number(rfiRows[0].unique_gpi10_count) : 0, TF_REQUIRED_CAP);

  logger.info(`[FormAlts] fetchFormAlts result: rfi=${rfiRows.length} denial=${denialRows.length} tfRequired=${tfRequired}`);

  // Claims check: which rfi alts does this member have paid claims for?
  // Each alt gets its own (gpi12, partialDrugName) pair — no dedup by gpi12 —
  // so alts that share a GPI12 but differ by drug name are checked independently.
  const rfiGpi12Pairs = rfiRows
    .filter(r => r.FormularyAlternativeGpi12)
    .map(r => ({
      gpi12: r.FormularyAlternativeGpi12,
      partialDrugName: ((/^[^ \/\-]+/.exec(r.FormularyAlternative || '') || [''])[0]).substring(0, 25).toUpperCase(),
    }));
  const checkedKeys = await getNfCheckedGpi12s(memberId, rfiGpi12Pairs, receivedDate);
  console.log(`[FormAlts] fetchFormAlts claims check: memberId=${memberId} checkedKeys=${[...checkedKeys].join(',')}`);

  const mapAlt = r => {
    const partialName = ((/^[^ \/\-]+/.exec(r.FormularyAlternative || '') || [''])[0]).substring(0, 25).toUpperCase();
    return {
      formularyAlternative: r.FormularyAlternative,
      gpi12: r.FormularyAlternativeGpi12,
      gpi10: r.Gpi10,
      formularyAlternativeGroupId: r.FormularyAlternativeGroupId,
      gpiSimilarity: r.GpiSimilarity,
      // TODO: Enable the line below instead to also match on partialDrugName (drug_brnd_nm LIKE filter).
      // autoCheck: checkedKeys.has(`${r.FormularyAlternativeGpi12}|${partialName}`),
      autoCheck: checkedKeys.has(r.FormularyAlternativeGpi12),
    };
  };

  return {
    rfi: {
      alternatives: rfiRows.map(mapAlt),
      tfRequired,
    },
    denial: {
      alternatives: denialRows.map(mapAlt),
    },
  };
}

module.exports = {
  resolveFormularyId,
  getFormularyOptions,
  lookupDrugAndIndications,
  fetchFormAlts,
  reloadReferenceData,
  getFormularyIds,
};
