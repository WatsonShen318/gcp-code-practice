const express = require('express');
const logger = require('../logger');
const {
  resolveFormularyId,
  getFormularyOptions,
  lookupDrugAndIndications,
  fetchFormAlts,
  reloadReferenceData,
  getFormularyIds,
} = require('./utils');

const router = express.Router();

// POST /formulary-alternatives/resolve-formulary
// Resolves FormularyId from CAG components. Fires immediately on case load.
// On not-found, returns availableFormularyIds for the frontend fallback dropdown.
//
// Body: { companyLob, companyAccounts, companyAccountGroup }
// Response (found):     { status, data: { found: true,  formularyId } }
// Response (not found): { status, data: { found: false, availableFormularyIds: [...] } }
router.post('/resolve-formulary', async (req, res) => {
  const { companyLob, companyAccounts, companyAccountGroup } = req.body;
  
  if (!companyLob || !companyAccounts || !companyAccountGroup) {
    const missing = [];
    if (!companyLob) missing.push('companyLob');
    if (!companyAccounts) missing.push('companyAccounts');
    if (!companyAccountGroup) missing.push('companyAccountGroup');
    logger.warn('[FormAlts] /resolve-formulary validation failed - missing params:', missing);
    return res.status(400).json({
      status: 'error',
      message: `Missing required parameters: ${missing.join(', ')}`,
      receivedParams: { companyLob, companyAccounts, companyAccountGroup },
    });
  }
  
  try {
    logger.debug('[FormAlts] /resolve-formulary requested', { companyLob, companyAccounts, companyAccountGroup });
    const data = await resolveFormularyId(companyLob, companyAccounts, companyAccountGroup);
    logger.info('[FormAlts] /resolve-formulary succeeded', { companyLob, formularyFound: data.found });
    res.status(200).json({ status: 'success', data });
  } catch (error) {
    logger.error('[FormAlts] /resolve-formulary failed', {
      params: { companyLob, companyAccounts, companyAccountGroup },
      errorMessage: error.message,
      errorStack: error.stack,
    });
    res.status(400).json({
      status: 'error',
      message: 'Failed to resolve FormularyId',
      details: error.message,
      requestParams: { companyLob, companyAccounts, companyAccountGroup },
    });
  }
});

// POST /formulary-alternatives/lookup
// Matches drug by GPI + drug name, returns indication list with optional auto-selection.
// Frontend shows a drug picker if drugOptions.length > 1; proceeds automatically if 1.
// Frontend shows an indication picker if autoSelectedIndication is null; otherwise pre-selects.
//
// Body: { gpi, mhkDrugName, primaryDxIcd10? }
// Response (not supported): { status, data: { supported: false } }
// Response (supported):     { status, data: { supported: true, drugOptions: [
//   { drugName, indicationSetId, indications: [{ indication, icd10List }], autoSelectedIndication }
// ] } }
router.post('/lookup', async (req, res) => {
  const { gpi, mhkDrugName, primaryDxIcd10 } = req.body;
  
  if (!gpi || !mhkDrugName) {
    const missing = [];
    if (!gpi) missing.push('gpi');
    if (!mhkDrugName) missing.push('mhkDrugName');
    logger.warn('[FormAlts] /lookup validation failed - missing params:', missing);
    return res.status(400).json({
      status: 'error',
      message: `Missing required parameters: ${missing.join(', ')}`,
      receivedParams: { gpi, mhkDrugName, primaryDxIcd10 },
    });
  }
  
  try {
    logger.debug('[FormAlts] /lookup requested', { gpi, mhkDrugName, primaryDxIcd10 });
    const data = await lookupDrugAndIndications(gpi, mhkDrugName, primaryDxIcd10 || null);
    logger.info('[FormAlts] /lookup succeeded', { gpi, mhkDrugName, supported: data.supported });
    res.status(200).json({ status: 'success', data });
  } catch (error) {
    logger.error('[FormAlts] /lookup failed', {
      params: { gpi, mhkDrugName, primaryDxIcd10 },
      errorMessage: error.message,
      errorStack: error.stack,
    });
    res.status(400).json({
      status: 'error',
      message: 'Failed to look up drug and indications',
      details: error.message,
      requestParams: { gpi, mhkDrugName, primaryDxIcd10 },
    });
  }
});

// POST /formulary-alternatives/fetch
// Fetches RFI + DenialLetter alternatives in a single BQ query.
// Frontend handles T/F selection (step 5) and output generation (steps 6a/6b) client-side
// using the returned gpi10 + formularyAlternativeGroupId fields.
//
// Body: { formularyId, drugName, indication }
//   indication: '' for no-diagnosis or Pharmacist "None of the above"
//   Do NOT call for Technician + "None of the above" — escalate to Clinical Review instead
//
// Response: { status, data: {
//   rfi:    { alternatives: [{ formularyAlternative, gpi10, formularyAlternativeGroupId, gpiSimilarity }],
//             tfRequired: number },   ← LEAST(distinct Gpi10 count, 3); display even when 0
//   denial: { alternatives: [...] }
// } }
router.post('/fetch', async (req, res) => {
  const { formularyId, drugName, indication, memberId, receivedDate } = req.body;
  
  if (!formularyId || !drugName) {
    const missing = [];
    if (!formularyId) missing.push('formularyId');
    if (!drugName) missing.push('drugName');
    logger.warn('[FormAlts] /fetch validation failed - missing required params:', missing);
    return res.status(400).json({
      status: 'error',
      message: `Missing required parameters: ${missing.join(', ')}`,
      receivedParams: { formularyId, drugName, indication, memberId },
    });
  }

  if (indication === undefined || indication === null) {
    logger.warn('[FormAlts] /fetch validation failed - indication is required', { formularyId, drugName });
    return res.status(400).json({
      status: 'error',
      message: 'indication is required (pass empty string for no-diagnosis / None-of-above path)',
      receivedParams: { formularyId, drugName, indication },
    });
  }
  
  try {
    logger.debug('[FormAlts] /fetch requested', { formularyId, drugName, indication });
    const data = await fetchFormAlts(formularyId, drugName, indication, memberId || null, receivedDate || null);
    logger.info('[FormAlts] /fetch succeeded', { formularyId, drugName, rfiCount: data.rfi?.alternatives?.length || 0, denialCount: data.denial?.alternatives?.length || 0 });
    res.status(200).json({ status: 'success', data });
  } catch (error) {
    logger.error('[FormAlts] /fetch failed', {
      params: { formularyId, drugName, indication },
      errorMessage: error.message,
      errorStack: error.stack,
    });
    res.status(400).json({
      status: 'error',
      message: 'Failed to fetch formulary alternatives',
      details: error.message,
      requestParams: { formularyId, drugName, indication },
    });
  }
});

// POST /formulary-alternatives/formulary-options
// Returns formulary options for a given client, grouped by sub-client.
// Called when CAG lookup returns found:false — frontend shows a searchable picker.
//
// Body: { client } (required) — the client name as it appears in the crosswalk table
// Response: { status, data: {
//   formularies: [{ formularyId, formularyName, subClientName }],  ← sorted by subClient then name
//   subClients:  [string]                                          ← unique non-null subClient values
// }}
router.post('/formulary-options', async (req, res) => {
  const { client } = req.body;
  
  if (!client) {
    logger.warn('[FormAlts] /formulary-options validation failed - missing client param');
    return res.status(400).json({
      status: 'error',
      message: 'Missing required parameter: client',
      receivedParams: { client },
    });
  }
  
  try {
    logger.debug('[FormAlts] /formulary-options requested', { client });
    const data = await getFormularyOptions(client);
    logger.info('[FormAlts] /formulary-options succeeded', { client, formularyCount: data.formularies?.length || 0, subClientCount: data.subClients?.length || 0 });
    res.status(200).json({ status: 'success', data });
  } catch (error) {
    logger.error('[FormAlts] /formulary-options failed', {
      params: { client },
      errorMessage: error.message,
      errorStack: error.stack,
    });
    res.status(400).json({
      status: 'error',
      message: 'Failed to fetch formulary options',
      details: error.message,
      requestParams: { client },
    });
  }
});

// GET /formulary-alternatives/formulary-ids
// Returns all available FormularyIds from the in-memory crosswalk.
// Used to populate the fallback FormularyId dropdown when CAG lookup returns not-found.
router.get('/formulary-ids', async (req, res) => {
  try {
    logger.debug('[FormAlts] /formulary-ids requested');
    const formularyIds = await getFormularyIds();
    logger.info('[FormAlts] /formulary-ids succeeded', { formularyIdCount: formularyIds?.length || 0 });
    res.status(200).json({ status: 'success', data: { formularyIds } });
  } catch (error) {
    logger.error('[FormAlts] /formulary-ids failed', {
      errorMessage: error.message,
      errorStack: error.stack,
    });
    res.status(400).json({
      status: 'error',
      message: 'Failed to fetch FormularyIds',
      details: error.message,
    });
  }
});

// POST /formulary-alternatives/reload
// Reloads in-memory reference tables from BigQuery.
// Call after the reference-tables DAG run completes to pick up data updates.
router.post('/reload', async (req, res) => {
  try {
    logger.info('[FormAlts] /reload requested - initiating reference data reload');
    const startTime = Date.now();
    await reloadReferenceData();
    const duration = Date.now() - startTime;
    logger.info('[FormAlts] /reload succeeded', { durationMs: duration, message: 'Reference data reloaded successfully' });
    res.status(200).json({ status: 'success', data: { message: 'Reference data reloaded successfully', durationMs: duration } });
  } catch (error) {
    logger.error('[FormAlts] /reload failed', {
      errorMessage: error.message,
      errorStack: error.stack,
    });
    res.status(400).json({
      status: 'error',
      message: 'Failed to reload reference data',
      details: error.message,
    });
  }
});

module.exports = router;
