const { BigQuery } = require("@google-cloud/bigquery");
const {
  isDeployedEnv,
  PROJECT_ID,
  COMPUTE_PROJECT_ID,
  GPI_OVERRIDE_LEVEL_CAG_TABLE,
  GPI_OVERRIDE_LEVEL_DRUG_TABLE,
  GPI_OVERRIDE_LEVEL_HIERARCHY_TABLE,
  GPI_OVERRIDE_LEVEL_OVERRIDE_TABLE,
} = require("../parameters/parameterConfig");
const logger = require("../logger");

const REFRESH_TTL_MS = 60 * 60 * 1000; // 1 hour — monthly data, TTL matches form_alts
const BQ_LOCATION = "US";

let q7Data = null;    // { cagRows, drugRowsWithPattern, overrideRows, cagHierarchyMap, drugHierarchyMap, loadedAt }
let loadPromise = null;

// Parses ORCA date strings to YYYY-MM-DD regardless of source format.
// Handles both MM/DD/YYYY and YYYY-MM-DD.
function _toIsoDate(str) {
  if (!str) return null;
  if (str.includes("/")) {
    const [m, d, y] = str.split("/");
    return `${y}-${m.padStart(2, "0")}-${d.padStart(2, "0")}`;
  }
  return str.slice(0, 10);
}

function _isActive(row, today) {
  const eff = _toIsoDate(row.EffectiveDate);
  const thru = _toIsoDate(row.ThruDate);
  return eff !== null && thru !== null && eff <= today && thru > today;
}

function _runLoad() {
  if (loadPromise) return loadPromise;

  loadPromise = (async () => {
    logger.info("[Q7] Loading GPI override level tables from BigQuery...");
    const bq = new BigQuery({
      projectId: isDeployedEnv() ? COMPUTE_PROJECT_ID : PROJECT_ID,
    });

    const BQ_TIMEOUT_MS = 60000;
    const [[cagRows], [drugRows], [overrideRows], [hierarchyRows]] = await Promise.all([
      bq.query({ query: `SELECT CagClusterName, CagClusterType, EffectiveDate, ThruDate, Carrier, Account, \`Group\` FROM \`${GPI_OVERRIDE_LEVEL_CAG_TABLE}\``, location: BQ_LOCATION, timeoutMs: BQ_TIMEOUT_MS }),
      bq.query({ query: `SELECT DrugClusterName, DrugClusterType, EffectiveDate, ThruDate, DrugIdentifier FROM \`${GPI_OVERRIDE_LEVEL_DRUG_TABLE}\``, location: BQ_LOCATION, timeoutMs: BQ_TIMEOUT_MS }),
      bq.query({ query: `SELECT CagCluster, DrugCluster, EffectiveDate, ThruDate, OverrideType, GpiOf FROM \`${GPI_OVERRIDE_LEVEL_OVERRIDE_TABLE}\``, location: BQ_LOCATION, timeoutMs: BQ_TIMEOUT_MS }),
      bq.query({ query: `SELECT ClusterColumnName, ClusterType, HierarchyLevel FROM \`${GPI_OVERRIDE_LEVEL_HIERARCHY_TABLE}\``, location: BQ_LOCATION, timeoutMs: BQ_TIMEOUT_MS }),
    ]);

    // ClusterType → numeric hierarchy level (lower = more specific).
    // Steve's queries filter tblGpiOverrideLevelHierarchy by ClusterColumnName
    // ("CagClusterType" for CAG lookups, "DrugClusterType" for Drug lookups).
    // In practice the two sets of ClusterType values don't overlap, so a single
    // Map is safe — but we build separate Maps to exactly match the spec.
    const cagHierarchyMap = new Map(
      hierarchyRows
        .filter(r => r.ClusterColumnName === "CagClusterType")
        .map(r => [r.ClusterType, parseInt(r.HierarchyLevel, 10)])
    );
    const drugHierarchyMap = new Map(
      hierarchyRows
        .filter(r => r.ClusterColumnName === "DrugClusterType")
        .map(r => [r.ClusterType, parseInt(r.HierarchyLevel, 10)])
    );

    // Pre-compile DrugIdentifier wildcard patterns once at load time.
    // Each * = exactly one alphanumeric character (fixed-length GPI/NDC patterns).
    const drugRowsWithPattern = drugRows.map(r => ({
      ...r,
      pattern: new RegExp("^" + r.DrugIdentifier.replace(/\*/g, "[A-Za-z0-9]") + "$"),
    }));

    logger.info(
      `[Q7] Loaded: cag=${cagRows.length} drug=${drugRows.length} ` +
      `override=${overrideRows.length} hierarchy=${hierarchyRows.length}`
    );

    q7Data = { cagRows, drugRowsWithPattern, overrideRows, cagHierarchyMap, drugHierarchyMap, loadedAt: Date.now() };
    loadPromise = null;
    return q7Data;
  })().catch(err => {
    loadPromise = null;
    logger.error("[Q7] Reference data load failed:", err);
    throw err;
  });

  return loadPromise;
}

async function _loadQ7Data() {
  // Fresh cache — hot path, <1ms
  if (q7Data && Date.now() - q7Data.loadedAt < REFRESH_TTL_MS) return q7Data;

  // No data yet — first request must wait
  if (!q7Data) return _runLoad();

  // TTL expired — serve stale immediately, refresh in background
  if (!loadPromise) {
    logger.info("[Q7] TTL expired — triggering background refresh (serving stale data)");
    _runLoad();
  }
  return q7Data;
}

// Synchronous lookup against in-memory data — called after _loadQ7Data resolves.
function _lookupQ7({ carrier, account, group, ndc, gpi, requestReason }, data) {
  const { cagRows, drugRowsWithPattern, overrideRows, cagHierarchyMap, drugHierarchyMap } = data;
  const today = new Date().toISOString().slice(0, 10); // YYYY-MM-DD

  // Step 1: qryGpiOverrideLevelCag equivalent
  // WHERE (Carrier = <carrier> OR Carrier Like "*All")
  //   AND (Account = <account> OR Account Like "*All")
  //   AND (Group   = <group>   OR Group   Like "*All")
  //   AND EffectiveDate <= today AND ThruDate > today
  //   AND ClusterColumnName = "CagClusterType"   ← enforced by cagHierarchyMap
  // JOIN tblGpiOverrideLevelHierarchy ON CagClusterType = ClusterType → get HierarchyLevel
  const matchedCag = cagRows
    .filter(r => _isActive(r, today))
    .filter(r =>
      (r.Carrier === carrier || r.Carrier?.endsWith("All")) &&
      (r.Account === account || r.Account?.endsWith("All")) &&
      (r.Group   === group   || r.Group?.endsWith("All"))
    )
    .map(r => ({ name: r.CagClusterName, level: cagHierarchyMap.get(r.CagClusterType) ?? 99 }));

  if (matchedCag.length === 0) return { result: false, gpiOf: null, cagCluster: null, drugCluster: null, totalLevel: null };

  // Step 2: qryGpiOverrideLevelDrug equivalent
  // WHERE (DrugClusterType = "NDC-11" AND <ndc> Like DrugIdentifier
  //     OR  DrugClusterType <> "NDC-11" AND <gpi> Like DrugIdentifier)
  //   AND EffectiveDate <= today AND ThruDate > today
  //   AND ClusterColumnName = "DrugClusterType"  ← enforced by drugHierarchyMap
  // JOIN tblGpiOverrideLevelHierarchy ON DrugClusterType = ClusterType → get HierarchyLevel
  const matchedDrug = drugRowsWithPattern
    .filter(r => _isActive(r, today))
    .filter(r =>
      r.DrugClusterType === "NDC-11"
        ? (!!ndc && r.pattern.test(ndc))
        : (!!gpi && r.pattern.test(gpi))
    )
    .map(r => ({ name: r.DrugClusterName, level: drugHierarchyMap.get(r.DrugClusterType) ?? 99 }));

  if (matchedDrug.length === 0) return { result: false, gpiOf: null, cagCluster: null, drugCluster: null, totalLevel: null };

  // Step 3: qryGpiOverrideLevelOverride equivalent
  // FROM qryGpiOverrideLevelDrug
  //   INNER JOIN (qryGpiOverrideLevelCag
  //     INNER JOIN tblGpiOverrideLevelOverride ON CagClusterName = CagCluster)
  //   ON DrugClusterName = DrugCluster
  // WHERE EffectiveDate <= today AND ThruDate > today
  //   AND OverrideType = <requestReason>
  // ORDER BY cagHierarchyLevel + drugHierarchyLevel ASC
  // → first result (lowest sum) is the most specific matching rule
  const cagLevelByName  = new Map(matchedCag.map(c  => [c.name, c.level]));
  const drugLevelByName = new Map(matchedDrug.map(d => [d.name, d.level]));

  const matches = overrideRows
    .filter(r => _isActive(r, today))
    .filter(r =>
      cagLevelByName.has(r.CagCluster) &&
      drugLevelByName.has(r.DrugCluster) &&
      r.OverrideType === requestReason
    )
    .map(r => ({
      gpiOf:       r.GpiOf,
      cagCluster:  r.CagCluster,
      drugCluster: r.DrugCluster,
      totalLevel:  (cagLevelByName.get(r.CagCluster) ?? 99) + (drugLevelByName.get(r.DrugCluster) ?? 99),
    }))
    .sort((a, b) => a.totalLevel - b.totalLevel);

  if (matches.length === 0) return { result: false, gpiOf: null, cagCluster: null, drugCluster: null, totalLevel: null };

  // Step 4: GpiOf of first result (most specific rule) — 8 or 10 → Yes, anything else → No
  const { gpiOf, cagCluster, drugCluster, totalLevel } = matches[0];
  const gpiOfStr = String(gpiOf).trim();
  return { result: gpiOfStr === "8" || gpiOfStr === "10", gpiOf: gpiOfStr, cagCluster, drugCluster, totalLevel };
}

/**
 * Determines Q7 answer using in-memory GPI override level data.
 * Returns true (Q7 = "Yes") if GpiOf is 8 or 10, false (Q7 = "No") otherwise.
 *
 * @param {Object} params
 * @param {string} params.carrier       - Carrier identifier from MHK payload (companyLob)
 * @param {string} params.account       - Account identifier from MHK payload (companyAccounts)
 * @param {string} params.group         - Group identifier from MHK payload (companyAccountGroup)
 * @param {string} params.ndc           - NDC-11 string (zero-padded); pass '' if unavailable
 * @param {string} params.gpi           - GPI code from MHK payload (gpiCode)
 * @param {string} params.requestReason - Request reason from MHK payload (matches OverrideType)
 * @param {string} params.caseId        - For logging only
 */
async function determineQ7GpiOverrideLevel({ carrier, account, group, ndc, gpi, requestReason, caseId }) {
  try {
    const data = await _loadQ7Data();
    const { result, gpiOf, cagCluster, drugCluster, totalLevel } = _lookupQ7(
      { carrier, account, group, ndc: ndc || "", gpi: gpi || "", requestReason: requestReason || "" },
      data
    );
    logger.info(
      `[Q7] caseId=${caseId} → ${result ? "Yes" : "No"} | ` +
      `gpiOf=${gpiOf ?? "no match"} | ` +
      `cagCluster=${cagCluster ?? "none"} | drugCluster=${drugCluster ?? "none"} | totalLevel=${totalLevel ?? "-"} | ` +
      `carrier=${carrier} account=${account} group=${group} gpi=${gpi} ndc=${ndc || ""} requestReason=${requestReason}`
    );
    return result;
  } catch (error) {
    logger.error(`[Q7] determineQ7GpiOverrideLevel failed for caseId=${caseId}, falling back to false`, error);
    return false;
  }
}

async function reloadQ7Data() {
  q7Data = null;
  loadPromise = null;
  return _runLoad();
}

module.exports = { determineQ7GpiOverrideLevel, reloadQ7Data };
