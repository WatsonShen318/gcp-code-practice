const { GoogleAuth } = require('google-auth-library');
const axios = require('axios');
const logger = require("../logger");

function formatEncryptedValue(encryptedValue) {
    // Escape backslashes
    let formattedValue = encryptedValue?.replace(/\\/g, '\\\\');
    // Escape single quotes
    formattedValue = formattedValue?.replace(/'/g, "\\'");
    // Escape double quotes
    formattedValue = formattedValue?.replace(/"/g, '\\"');

    return formattedValue;
}

async function getIdentityToken(audience) {
    try {
        const auth = new GoogleAuth();
        const client = await auth.getIdTokenClient(audience);
        const idToken = await client.getRequestHeaders();
        return idToken['Authorization'].split(' ')[1];
    } catch (error) {
        logger.error(`Error getting identity token: ${error}`);
        return;
    }
}

async function encryptDecryptData(DATA_TO_ENCRYPT, ALIAS, PRIOR_ATHZN_NBR, MODE_OF_OPERATION, COMPUTE_PROJECT_ID) {
    try {
        const ENCRYPT_CLOUD_FUNCTION = `https://us-east4-${COMPUTE_PROJECT_ID}.cloudfunctions.net/paops_encrypt-decrypt-pss`;
        logger.info(`PA Number - ${PRIOR_ATHZN_NBR} - Initiating cloud function to encrypt data`);
        const identityToken = await getIdentityToken(ENCRYPT_CLOUD_FUNCTION);
        logger.info(`PA Number - ${PRIOR_ATHZN_NBR} - ID token fetched successfully`);

        if (identityToken) {
            const payload = {
                data_to_encrypt: DATA_TO_ENCRYPT,
                alias: ALIAS,
                prior_athzn_nbr: PRIOR_ATHZN_NBR,
                mode: MODE_OF_OPERATION // should only be either 'encrypt' or 'decrypt'
            };

            const headers = {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${identityToken}`
            };
            logger.info(`PA Number - ${PRIOR_ATHZN_NBR} - Calling encryption cloud function to encrypt the data`);

            try {
                const response = await axios.post(ENCRYPT_CLOUD_FUNCTION, payload, { headers });
                const replies = response.data[0].replies.map(reply => reply);
                if(replies && replies[0]) {
                    return replies[0];
                }
                return;
            } catch (error) {
                const errorMessage = `PA Number - ${PRIOR_ATHZN_NBR} - Error while encrypting and retrieving data from cloud function: ${error}`;
                logger.error(errorMessage);
                return;
            }
        } else {
            logger.error("Failed to fetch ID token, no request made");
            return;
        }
    } catch (error) {
        logger.error('Error while encrypting data using cloud function: ', error);
        return;
    }
}

module.exports = {
    encryptDecryptData,
    formatEncryptedValue
}