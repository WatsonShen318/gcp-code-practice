const { format, subDays } = require("date-fns");
const { toZonedTime } = require("date-fns-tz");
const logger = require("../logger");

/* This list gets updated change yearly */
const CLIENT_EXCEPTION_DOA_TERM_LIST = [
  "Aetna",
  "SilverScript (Main)",
  "Aetna SSI PDP",
  "HMSA",
  "Neighborhood Health Plan Rhode Island",
  "EGWP",
];

const REQUEST_REASON_EXCEPTION_LIST = ["Non-Formulary", "Quantity Limits"];

const COVERAGE_DETERMINATION = "CD";
const REDETERMINATION = "RD";
const REDETERMINATION_POSSIBLE_3RD_CASE = "RD (Possible 3rd Case)";
const QUANTITY_LIMIT = "Quantity Limit";

/* Helper to format date based on number of days provided.
   baseDate defaults to now, so existing callers are unaffected; Q8 passes the
   current request's received date as the anchor for its 65-day window. */
function formattedDate(daysAgo = 0, baseDate = new Date()) {
  const anchor =
    baseDate instanceof Date && !isNaN(baseDate.getTime())
      ? baseDate
      : new Date();
  const pastDate = subDays(anchor, daysAgo);
  const pastZonedDate = toZonedTime(pastDate, "UTC");
  const pastFormattedDate = format(pastZonedDate, "yyyy-MM-dd'T'HH:mm:ss'Z'");

  return pastFormattedDate;
}

/* find start of year formatted date */
function findStartOfYearFormattedDate() {
  const now = new Date();
  const currentYear = now.getFullYear();
  const firstDayOfCurrentYear = new Date(Date.UTC(currentYear, 0, 1)); // January is month 0 in JavaScript
  const startOfYearZonedDate = toZonedTime(firstDayOfCurrentYear, "UTC");
  const startOfYearFormattedDate = format(
    startOfYearZonedDate,
    "yyyy-MM-dd'T'HH:mm:ss'Z'"
  );

  return startOfYearFormattedDate;
}

/* Helper to calculate Lookback period before querying Teradata */
function calculateLookBackTimeStamp(caseDetails) {
  const { memberEligibilityTermDate, requestReason, client } = caseDetails;

  let lookBackTimestamp = "";

  // Current Formatted Date
  const currentFormattedDate = formattedDate();
  // Current Year Start Date and Time
  const startOfYearFormattedDate = findStartOfYearFormattedDate();
  // Date and Time before 365 days
  const formattedDate365DaysAgo = formattedDate(365);
  if (memberEligibilityTermDate > currentFormattedDate) {
    if (
      REQUEST_REASON_EXCEPTION_LIST.includes(requestReason) &&
      CLIENT_EXCEPTION_DOA_TERM_LIST.includes(client)
    ) {
      lookBackTimestamp = startOfYearFormattedDate;
    } else {
      lookBackTimestamp = formattedDate365DaysAgo;
    }
  } else {
    lookBackTimestamp = startOfYearFormattedDate;
  }

  return lookBackTimestamp;
}

/* Helper to find matching drug pattern — deprecated, replaced by gpi-override-level.js.
   Kept for reference only; calls below are commented out. */
function matcheDrugPattern(drugId, drugIdentifiers) {
  return drugIdentifiers.some((drugIdentifier) => {
    // Convert pattern to a regular expression
    const regexPattern = new RegExp(
      "^" + drugIdentifier.replace(/\*/g, "[A-Za-z0-9]") + "$"
    );
    return regexPattern.test(drugId);
  });
}

// Function to parse date string to Date object
function parseDate(dateStr) {
  return new Date(dateStr);
}

/* handler "The RD case cannot have a date and time that is before the CD decision date and time." */
function confirmDeniedRDIsAfterCD(formattedHistoryRecords) {
  // Filter and sort records
  const rdRecords = formattedHistoryRecords
    .filter(
      (record) =>
        record.case_typ_desc === "Redetermination" &&
        record.qstnr_case_stus_desc === "Denied"
    )
    .sort((a, b) => parseDate(b.case_dcsn_ts) - parseDate(a.case_dcsn_ts));

  const cdRecords = formattedHistoryRecords
    .filter(
      (record) =>
        record.case_typ_desc === "Coverage Determination" &&
        record.qstnr_case_stus_desc === "Denied"
    )
    .sort((a, b) => parseDate(b.case_dcsn_ts) - parseDate(a.case_dcsn_ts));

  // Check for The RD case cannot have a date and time that is before the CD decision date and time.
  let isValid = true;
  if (rdRecords.length > 0 && cdRecords.length > 0) {
    isValid =
      parseDate(cdRecords[0].case_dcsn_ts) <
      parseDate(rdRecords[0].case_dcsn_ts);
  }
  return isValid;
}

/**
 * Finds a denied case matching both requestReason and gpiCode.
 * If none found, returns the first record.
 * @param {Array} deniedCases - Array of denied case objects
 * @param {string} requestReason
 * @param {string} gpiCode
 * @returns {Object|null}
 */
function findMatchingDeniedCase(deniedCases, requestReason, gpiCode) {
  const exactMatch = deniedCases?.find(
    (deniedCase) =>
      deniedCase.rqst_rsn_desc === requestReason &&
      deniedCase.gpi_cd?.substring(0, 10) === gpiCode?.substring(0, 10)
  );
  if (exactMatch) return exactMatch;

  const reasonMatch = deniedCases?.find(
    (deniedCase) => deniedCase.rqst_rsn_desc === requestReason
  );
  return reasonMatch || deniedCases[0];
}

/* Helper to find out CD/RD grid responses */
function findoutCDRDGridAnswers(
  formattedHistoryRecords,
  caseDetails,
  lookBackTimestamp,
  isQ7Override   // boolean from gpi-override-level.js; replaces matcheDrugPattern
) {
  // Filter Records within Lookback period
  const filteredLookbackRecords = formattedHistoryRecords.filter((record) => {
    return new Date(record.case_dcsn_ts) > new Date(lookBackTimestamp);
  });

  // Current request's drug (GPI-12) and request reason — used to scope Q8 & Q9
  // to redeterminations that actually impact the drug being requested.
  const currentGpi12 = caseDetails?.gpiCode?.substring(0, 12);
  const currentRequestReason = caseDetails?.requestReason;

  // Q8: Approved Redetermination — option 4.
  // GPI-12 match + same request reason + Status "Approved" + Request Type
  // "Redetermination", with the decision date within 65 days of the current
  // request's received date (this 65-day window REPLACES the lookback period
  // for Q8, so it is applied against the full history set). Falls back to
  // today when receivedDate is absent.
  const q8AnchorDate = caseDetails?.receivedDate
    ? new Date(caseDetails.receivedDate)
    : new Date();
  const q8WindowStart = formattedDate(65, q8AnchorDate);
  const hasApprovedRedetermination = formattedHistoryRecords.some((record) => {
    return (
      record.qstnr_case_stus_desc === "Approved" &&
      record.case_typ_desc === "Redetermination" &&
      record.rqst_rsn_desc === currentRequestReason &&
      !!currentGpi12 &&
      record.gpi_cd?.substring(0, 12) === currentGpi12 &&
      new Date(record.case_dcsn_ts) > new Date(q8WindowStart)
    );
  });

  // Q9: Most recent denied case — option 3.
  // GPI-12 match + same request reason (Q9 keeps the lookback-period scope;
  // no 65-day change per spec), then check if the most recent one is an RD.
  const deniedCases = filteredLookbackRecords.filter((record) => {
    return (
      record.qstnr_case_stus_desc === "Denied" &&
      record.rqst_rsn_desc === currentRequestReason &&
      !!currentGpi12 &&
      record.gpi_cd?.substring(0, 12) === currentGpi12
    );
  });

  const mostRecentDeniedCase = deniedCases.reduce((latest, record) => {
    return new Date(record.case_dcsn_ts) > new Date(latest.case_dcsn_ts)
      ? record
      : latest;
  }, deniedCases[0]);

  const isMostRecentDeniedIsRedetermination =
    mostRecentDeniedCase &&
    mostRecentDeniedCase.case_typ_desc === "Redetermination";

  /* List of CDRD Grid Questions */
  /*
    Q1. Is there a denied case on the member's current line of eligibility in the past 65 days? The RD case cannot have a date and time that is before the CD decision date and time.
    Q1a. Is there a denied case on the Member's profile NOT within the past 65 days AND a good cause extension?
    Q2. Same request reason (Prior Authorization, Non-Formulary, Quantity Limit, Step Therapy, Tiering)?
    Q3. Same Drug? (Note: Brand vs Generic: If the CD was for a brand name and the new request is for a generic (or vice versa), do NOT mark as a RD)
    Q4. Is the request reason Quantity Limit?
    Q5. Is the request for the same strength (Quantity Limit only)?
    Q6. Same dosage form?
    Q7. If approved, is the override entered at a GPI of 10 or 8 per the Medication Specific Override Instructions section in the "Rework Queue: Override Reference Guide" Work Instruction?
    Q8. Is there an approved redetermination?
    Q9. Was the most recent denied case a Redetermination?
  */
  let cdrdGridAnswers = {
    Q1: "",
    Q1a: "",
    Q2: "",
    Q3: "",
    Q4: "",
    Q5: "",
    Q6: "",
    Q7: "",
    Q8: "",
    Q9: "",
    requestType: "",
  };

  /* Q1. Is there a denied case on the member's current line of eligibility in the past 65 days? The RD case cannot have a date and time that is before the CD decision date and time. */
  // Date and Time before 65 days
  const formattedDate65DaysAgo = formattedDate(65);
  const deniedCasesInLast65Days = formattedHistoryRecords.filter((record) => {
    return (
      new Date(record.case_dcsn_ts) > new Date(formattedDate65DaysAgo) &&
      record.qstnr_case_stus_desc === "Denied"
    );
  });

  const deniedCaseInLast65Days = findMatchingDeniedCase(
    deniedCasesInLast65Days,
    caseDetails?.requestReason,
    caseDetails?.gpiCode
  );

  const isDeniedRDAfterCD = confirmDeniedRDIsAfterCD(formattedHistoryRecords);

  if (deniedCaseInLast65Days) {
    cdrdGridAnswers["Q1"] = "Yes";
    const { rqst_rsn_desc, gpi_cd } = deniedCaseInLast65Days;

    /* Q2. Same request reason (Prior Authorization, Non-Formulary, Quantity Limit, Step Therapy, Tiering)? */
    if (rqst_rsn_desc === caseDetails?.requestReason) {
      cdrdGridAnswers["Q2"] = "Yes";

      const mhkGpiCode = caseDetails?.gpiCode;

      /*Q3. Same Drug? (If there is a 10 digit match for gpiCode from MHK and Teradata) */
      if (mhkGpiCode?.substring(0, 10) === gpi_cd?.substring(0, 10)) {
        cdrdGridAnswers["Q3"] = "Yes";

        /* Q4. Is the request reason Quantity Limit? */
        if (rqst_rsn_desc?.toLowerCase().startsWith(QUANTITY_LIMIT?.toLowerCase())) {
          cdrdGridAnswers["Q4"] = "Yes";

          /* Q5. Is the request for the same strength (Quantity Limit only)? (If there is a 14 digit match for gpiCode from MHK and Teradata) */
          if (mhkGpiCode?.substring(0, 14) === gpi_cd?.substring(0, 14)) {
            cdrdGridAnswers["Q5"] = "Yes";

            /* Q6. Same dosage form? (If there is a 12 digit match for gpiCode from MHK and Teradata) */
            if (mhkGpiCode?.substring(0, 12) === gpi_cd?.substring(0, 12)) {
              cdrdGridAnswers["Q6"] = "Yes";

              /* Q8. Is there an approved redetermination? (Consider Lookback period of 1/1 or past 365 days here) */
              if (hasApprovedRedetermination) {
                cdrdGridAnswers["Q8"] = "Yes";
                cdrdGridAnswers["requestType"] = COVERAGE_DETERMINATION;
                return cdrdGridAnswers;
              } else {
                cdrdGridAnswers["Q8"] = "No";

                /* Q9. Was the most recent denied case a Redetermination? (Consider Lookback Period here) */
                if (isMostRecentDeniedIsRedetermination) {
                  cdrdGridAnswers["Q9"] = "Yes";
                  cdrdGridAnswers["requestType"] =
                    REDETERMINATION_POSSIBLE_3RD_CASE;
                } else {
                  cdrdGridAnswers["Q9"] = "No";
                  cdrdGridAnswers["requestType"] = REDETERMINATION;
                }
                return cdrdGridAnswers;
              }
            } else {
              cdrdGridAnswers["Q6"] = "No";

              /* Q7. If approved, is the override entered at a GPI of 10 or 8 per the Medication Specific Override Instructions section in the "Rework Queue: Override Reference Guide" Work Instruction? */

              // matcheDrugPattern replaced by live BQ lookup — see gpi-override-level.js
              // const isOverrideEntered = matcheDrugPattern(caseDetails.gpiCode, drugIdentifiersData);
              const isOverrideEntered = isQ7Override;

              if (isOverrideEntered) {
                cdrdGridAnswers["Q7"] = "Yes";

                /* Q8. Is there an approved redetermination? (Consider Lookback period of 1/1 or past 365 days here) */
                if (hasApprovedRedetermination) {
                  cdrdGridAnswers["Q8"] = "Yes";
                  cdrdGridAnswers["requestType"] = COVERAGE_DETERMINATION;
                  return cdrdGridAnswers;
                } else {
                  cdrdGridAnswers["Q8"] = "No";

                  /* Q9. Was the most recent denied case a Redetermination? (Consider Lookback Period here) */
                  if (isMostRecentDeniedIsRedetermination) {
                    cdrdGridAnswers["Q9"] = "Yes";
                    cdrdGridAnswers["requestType"] =
                      REDETERMINATION_POSSIBLE_3RD_CASE;
                  } else {
                    cdrdGridAnswers["Q9"] = "No";
                    cdrdGridAnswers["requestType"] = REDETERMINATION;
                  }
                  return cdrdGridAnswers;
                }
              } else {
                cdrdGridAnswers["Q7"] = "No";
                cdrdGridAnswers["requestType"] = COVERAGE_DETERMINATION;
                return cdrdGridAnswers;
              }
            }
          } else {
            cdrdGridAnswers["Q5"] = "No";
            cdrdGridAnswers["requestType"] = COVERAGE_DETERMINATION;
            return cdrdGridAnswers;
          }
        } else {
          cdrdGridAnswers["Q4"] = "No";

          /* Q6. Same dosage form? (If there is a 12 digit match for gpiCode from MHK and Teradata) */
          if (mhkGpiCode?.substring(0, 12) === gpi_cd?.substring(0, 12)) {
            cdrdGridAnswers["Q6"] = "Yes";

            /* Q8. Is there an approved redetermination? (Consider Lookback period of 1/1 or past 365 days here) */
            if (hasApprovedRedetermination) {
              cdrdGridAnswers["Q8"] = "Yes";
              cdrdGridAnswers["requestType"] = COVERAGE_DETERMINATION;
              return cdrdGridAnswers;
            } else {
              cdrdGridAnswers["Q8"] = "No";

              /* Q9. Was the most recent denied case a Redetermination? (Consider Lookback Period here) */
              if (isMostRecentDeniedIsRedetermination) {
                cdrdGridAnswers["Q9"] = "Yes";
                cdrdGridAnswers["requestType"] =
                  REDETERMINATION_POSSIBLE_3RD_CASE;
              } else {
                cdrdGridAnswers["Q9"] = "No";
                cdrdGridAnswers["requestType"] = REDETERMINATION;
              }
              return cdrdGridAnswers;
            }
          } else {
            cdrdGridAnswers["Q6"] = "No";
            /* Q7. If approved, is the override entered at a GPI of 10 or 8 per the Medication Specific Override Instructions section in the "Rework Queue: Override Reference Guide" Work Instruction? */

            // matcheDrugPattern replaced by live BQ lookup — see gpi-override-level.js
            // const isOverrideEntered = matcheDrugPattern(caseDetails?.gpiCode, drugIdentifiersData);
            const isOverrideEntered = isQ7Override;

            if (isOverrideEntered) {
              cdrdGridAnswers["Q7"] = "Yes";

              /* Q8. Is there an approved redetermination? (Consider Lookback period of 1/1 or past 365 days here) */
              if (hasApprovedRedetermination) {
                cdrdGridAnswers["Q8"] = "Yes";
                cdrdGridAnswers["requestType"] = COVERAGE_DETERMINATION;
                return cdrdGridAnswers;
              } else {
                cdrdGridAnswers["Q8"] = "No";

                /* Q9. Was the most recent denied case a Redetermination? (Consider Lookback Period here) */
                if (isMostRecentDeniedIsRedetermination) {
                  cdrdGridAnswers["Q9"] = "Yes";
                  cdrdGridAnswers["requestType"] =
                    REDETERMINATION_POSSIBLE_3RD_CASE;
                } else {
                  cdrdGridAnswers["Q9"] = "No";
                  cdrdGridAnswers["requestType"] = REDETERMINATION;
                }
                return cdrdGridAnswers;
              }
            } else {
              cdrdGridAnswers["Q7"] = "No";
              cdrdGridAnswers["requestType"] = COVERAGE_DETERMINATION;
              return cdrdGridAnswers;
            }
          }
        }
      } else {
        cdrdGridAnswers["Q3"] = "No";
        cdrdGridAnswers["requestType"] = COVERAGE_DETERMINATION;
        return cdrdGridAnswers;
      }
    } else {
      cdrdGridAnswers["Q2"] = "No";
      cdrdGridAnswers["requestType"] = COVERAGE_DETERMINATION;
      return cdrdGridAnswers;
    }
  } else {
    cdrdGridAnswers["Q1"] = "No";
    cdrdGridAnswers["Q1a"] = "No";
    cdrdGridAnswers["requestType"] = COVERAGE_DETERMINATION;
    return cdrdGridAnswers;
  }
}

/* Format Teradata result */
function formatTeradataResult(result, teradataColumns) {
  return result.map((row) => {
    let historyRecord = {};
    teradataColumns.forEach((col, index) => {
      historyRecord[col] = row[index];
    });
    return historyRecord;
  }).sort((a, b) => parseDate(b.case_dcsn_ts) - parseDate(a.case_dcsn_ts));
}

const formatDate = (dateString) => {
  const date = new Date(dateString);
  return date.toISOString();
};

/* Format BQ result */
function formatBQResult(historyRecords) {
  return historyRecords.map((record) => {
    return {
      ...record,
      case_crte_ts: formatDate(record.case_crte_ts.value),
      case_dcsn_ts: formatDate(record.case_dcsn_ts.value),
    };
  }).sort((a, b) => parseDate(b.case_dcsn_ts) - parseDate(a.case_dcsn_ts));
}

/* Format BT result */
function formatBTResult(historyRecords) {
  return historyRecords.map((record) => {
    return {
      ...record,
      case_crte_ts: formatDate(record.case_crte_ts),
      case_dcsn_ts: formatDate(record.case_dcsn_ts),
    };
  }).sort((a, b) => parseDate(b.case_dcsn_ts) - parseDate(a.case_dcsn_ts));
}

/**
 * Safely parses a object string (single quotes) to a JS object.
 * Handles values with curly braces or quotes.
 */
function safeParseString(dataStr, caseId) {
  try {
    return JSON.parse(dataStr) || {}
  } catch(error) {
    logger.error(`Failed to parse data string for ${caseId}. Error: `, error);
    return;
  }
}

module.exports = {
  calculateLookBackTimeStamp,
  findoutCDRDGridAnswers,
  formatTeradataResult,
  formatBQResult,
  formatBTResult,
  safeParseString,
};
