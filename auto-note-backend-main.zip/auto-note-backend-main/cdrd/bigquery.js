var express = require("express");
const { BigQuery } = require("@google-cloud/bigquery");
var router = express.Router();
const {
  isDeployedEnv,
  PROJECT_ID,
  COMPUTE_PROJECT_ID,
  BQ_INSTANCE_ID,
  BQ_CASE_HISTORY_TABLE_ID,
  BQ_CASE_HISTORY_TABLE,
} = require("../parameters/parameterConfig");
const {
  calculateLookBackTimeStamp,
  findoutCDRDGridAnswers,
  formatBQResult,
} = require("./helper");
const { determineQ7GpiOverrideLevel } = require("./gpi-override-level");
// Encrypt/decrypt cloud function is not used in EDP 1.5 - data is stored as cleartext
// const { encryptDecryptData, formatEncryptedValue } = require("./encrypt");

const logger = require("../logger");

router.post("/", async (req, res) => {
  try {
    // Create a BigQuery client
    let bigquery;

    logger.info("Establishing connection with BigQuery...");

    if (isDeployedEnv()) {
      bigquery = new BigQuery({ projectId: COMPUTE_PROJECT_ID });
      logger.info(`BQ Client project has been set with to ${COMPUTE_PROJECT_ID}`);
    } else {
      bigquery = new BigQuery({ projectId: PROJECT_ID });
      logger.info(`BQ Client project has been set with to ${PROJECT_ID}`);
    }

    // Retrieve request parameters
    const caseId = req.body?.caseId;
    const memberAccountId = req.body?.memberAccountId; // example: GA2527380

    // Encrypt/decrypt cloud function is not used in EDP 1.5 - The data is stored as cleartext
    // const encryptedMemberAccountId = await encryptDecryptData(
    //   [[memberAccountId]],
    //   "us7ascii2",
    //   caseId,
    //   "encrypt",
    //   COMPUTE_PROJECT_ID
    // );
    // const formattedEncryptedMemberAccountId = formatEncryptedValue(encryptedMemberAccountId);

    const memberEligibilityTermDate = req.body?.memberEligibilityTermDate;
    const requestReason = req.body?.requestReason;
    const client = req.body?.client;
    const companyLob = req.body?.companyLob;
    const companyAccounts = req.body?.companyAccounts;
    const companyAccountGroup = req.body?.companyAccountGroup;
    const gpiCode = req.body?.gpiCode;
    const receivedDate = req.body?.receivedDate; // current request's received date (Q8 65-day window anchor)

    if (!memberAccountId) {
      res.status(404).json({
        message: "failed - memberAccountId is missing with the request.",
      });
      return;
    }

    // Encrypt/decrypt cloud function is not used in EDP 1.5 - using cleartext memberAccountId directly
    // if (!encryptedMemberAccountId) {
    //   res.status(404).json({
    //     message:
    //       "failed - encryptedMemberAccountId is missing with the request.",
    //   });
    //   return;
    // }

    logger.info("Connected to BigQuery for CD/RD Automation.");

    const caseDetails = {
      memberEligibilityTermDate,
      requestReason,
      client,
      gpiCode,
      receivedDate,
    };

    /* Lookback period logic */
    const lookBackTimestamp = calculateLookBackTimeStamp(caseDetails);

    const bqColumns = [
      "orgnl_case_typ_desc",
      "case_typ_desc",
      "orgnl_dcsn_nm",
      "qstnr_case_stus_desc",
      "case_crte_ts",
      "case_dcsn_ts",
      "orgnl_rqst_rsn_txt",
      "rqst_rsn_desc",
      "gpi_cd",
    ];

    // const query = `Select ${bqColumns.join(", ")} from ${PROJECT_ID}.${BQ_INSTANCE_ID}.${BQ_CASE_HISTORY_TABLE_ID} where mbr_acct_id = '${formattedEncryptedMemberAccountId}' and LVL1_ACCT_ID = '${companyLob}' and LVL2_ACCT_ID = '${companyAccounts}' and LVL3_ACCT_ID = '${companyAccountGroup}'`;

    const query = `Select ${bqColumns.join(", ")} from ${BQ_CASE_HISTORY_TABLE} where mbr_acct_id = ?  and LVL1_ACCT_ID = ? and LVL2_ACCT_ID = ? and LVL3_ACCT_ID = ?`;
    // const query = `Select ${bqColumns.join(", ")} from ${PROJECT_ID}.${BQ_INSTANCE_ID}.${BQ_CASE_HISTORY_TABLE_ID} where mbr_acct_id = @mbr_acct_id and LVL1_ACCT_ID = @lvl1_acct_id and LVL2_ACCT_ID = @lvl2_acct_id and LVL3_ACCT_ID = @lvl3_acct_id`;

    // const options = {
    //   query: query,
    //   params: {
    //     mbr_acct_id: formattedEncryptedMemberAccountId,
    //     lvl1_acct_id: companyLob,
    //     lvl2_acct_id: companyAccounts,
    //     lvl3_acct_id: companyAccountGroup,
    //   },
    // };

    logger.info(`Fetching Result to automated CD/RD automation for caseId: ${caseId}`);
    // const [historyRecords] = await bigquery.query(query);

    // Encrypt/decrypt cloud function is not used in EDP 1.5 - using cleartext memberAccountId directly
    const [historyRecords] = await bigquery.query({query, params: [memberAccountId, companyLob, companyAccounts, companyAccountGroup]});
    // const [historyRecords] = await bigquery.query(options);

    const formattedHistoryRecords = formatBQResult(historyRecords);

    const isQ7Override = await determineQ7GpiOverrideLevel({
      carrier:       companyLob,
      account:       companyAccounts,
      group:         companyAccountGroup,
      ndc:           req.body?.ndc || "",
      gpi:           gpiCode,
      requestReason,
      caseId,
    });

    const cdrdGridAnswers = findoutCDRDGridAnswers(
      formattedHistoryRecords,
      caseDetails,
      lookBackTimestamp,
      isQ7Override
    );

    return res.status(200).json({
      message: "success",
      cdrdGridAnswers,
      lookBackTimestamp,
      memberAccountId,
      formattedHistoryRecords
    });
  } catch (error) {
    logger.error("Error while automating CD_RD responses:", error);
    return res.status(400).json({ message: "failure", error });
  }
});

module.exports = router;
