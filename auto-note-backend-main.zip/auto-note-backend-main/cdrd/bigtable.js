const express = require("express");
const { Bigtable } = require("@google-cloud/bigtable");
const router = express.Router();
const {
  PROJECT_ID,
  COMPUTE_PROJECT_ID,
  BT_INSTANCE_ID,
  BT_CASE_HISTORY_TABLE_ID,
} = require("../parameters/parameterConfig");
const {
  calculateLookBackTimeStamp,
  findoutCDRDGridAnswers,
  formatBTResult,
  safeParseString,
} = require("./helper");
const { determineQ7GpiOverrideLevel } = require("./gpi-override-level");
// Encrypt/decrypt cloud function is not used in EDP 1.5 - data is stored as cleartext
// const { encryptDecryptData, formatEncryptedValue } = require("./encrypt");

const logger = require("../logger");

const SEP = "<sep>"; // separator used in your row key

router.post("/", async (req, res) => {
  let bigtable;
  try {
    bigtable = new Bigtable({ projectId: PROJECT_ID });
    const instance = bigtable.instance(BT_INSTANCE_ID);
    const table = instance.table(BT_CASE_HISTORY_TABLE_ID);

    // Retrieve request parameters
    const caseId = req.body?.caseId;
    const memberAccountId = req.body?.memberAccountId;

    // Encrypt/decrypt cloud function is not used in EDP 1.5 - data is stored as cleartext
    // const encryptedMemberAccountId = await encryptDecryptData(
    //   [[memberAccountId]],
    //   "us7ascii2",
    //   caseId,
    //   "encrypt",
    //   COMPUTE_PROJECT_ID
    // );
    // const formattedEncryptedMemberAccountId = formatEncryptedValue(
    //   encryptedMemberAccountId
    // );

    const memberEligibilityTermDate = req.body?.memberEligibilityTermDate;
    const requestReason = req.body?.requestReason;
    const client = req.body?.client;
    const companyLob = req.body?.companyLob;
    const companyAccounts = req.body?.companyAccounts;
    const companyAccountGroup = req.body?.companyAccountGroup;
    const gpiCode = req.body?.gpiCode;
    const ndc = req.body?.ndc;
    const receivedDate = req.body?.receivedDate; // current request's received date (Q8 65-day window anchor)
    // const caseCreateTs = req.body?.caseCreateTs; // optional, to filter by timestamp

    if (
      !memberAccountId ||
      !companyLob ||
      !companyAccounts ||
      !companyAccountGroup
    ) {
      res.status(404).json({
        message: "failed - required fields are missing with the request.",
      });
      return;
    }

    // Encrypt/decrypt cloud function is not used in EDP 1.5 - using cleartext memberAccountId directly
    // if (!encryptedMemberAccountId) {
    //   res.status(404).json({
    //     message:
    //       "failed - encryptedMemberAccountId is missing with the request.",
    //   });
    //   return;
    // }

    const caseDetails = {
      memberEligibilityTermDate,
      requestReason,
      client,
      gpiCode,
      receivedDate,
    };

    /* Lookback period logic */
    const lookBackTimestamp = calculateLookBackTimeStamp(caseDetails);

    // Construct the row key as in BT: LVL1_ACCT_ID<sep>LVL2_ACCT_ID<sep>LVL3_ACCT_ID<sep>MBR_ACCT_ID<sep>CASE_CRTE_TS
    // If you want to fetch all rows for a member, use a prefix filter up to MBR_ACCT_ID
    // Encrypt/decrypt cloud function is not used in EDP 1.5 - using cleartext memberAccountId directly
    let rowKeyPrefix = [
      companyLob,
      companyAccounts,
      companyAccountGroup,
      memberAccountId,
    ].join(SEP);

    // Specific case, add caseCreateTs to the key
    // let rowKey = rowKeyPrefix;
    // if (caseCreateTs) {
    //   rowKey = rowKeyPrefix + SEP + caseCreateTs;
    // }

    // Fetch rows with prefix (all cases for this member/account group)
    const [rows] = await table.getRows({
      prefix: rowKeyPrefix,
    });

    // Map Bigtable rows to the expected format
    let historyRecords = rows.map((row) => {
      // const data = row.data.autonote.data
      let dataStr = row.data.autonote?.data?.[0]?.value;
      // cleanup record string
      dataStr = dataStr
        ?.replace(/\\/g, "");
      dataStr = dataStr?.replace(/'/g, '"');
      dataStr = dataStr?.replace(/: None/g, ': ""'); // handle None from case_dcsn_ts column

      const data = dataStr && safeParseString(dataStr, caseId);
      if (data) {
        return {
          orgnl_case_typ_desc: data.ORGNL_CASE_TYP_DESC,
          case_typ_desc: data.CASE_TYP_DESC,
          orgnl_dcsn_nm: data.ORGNL_DCSN_NM,
          qstnr_case_stus_desc: data.QSTNR_CASE_STUS_DESC,
          case_crte_ts: data.CASE_CRTE_TS,
          case_dcsn_ts: data.CASE_DCSN_TS,
          orgnl_rqst_rsn_txt: data.ORGNL_RQST_RSN_TXT,
          rqst_rsn_desc: data.RQST_RSN_DESC,
          gpi_cd: data.GPI_CD,
        };
      }
    });

    // filter undefined values
    historyRecords = historyRecords.filter((record) => record);
    // filter history records with case_dcsn_ts as undefined or null
    historyRecords = historyRecords.filter(
      (record) => record.case_dcsn_ts !== undefined && record.case_dcsn_ts !== null && record.case_dcsn_ts !== "" && record.case_dcsn_ts !== "None"
    );

    let formattedHistoryRecords = formatBTResult(historyRecords);

    const isQ7Override = await determineQ7GpiOverrideLevel({
      carrier:       companyLob,
      account:       companyAccounts,
      group:         companyAccountGroup,
      ndc:           ndc,
      gpi:           gpiCode,
      requestReason,
      caseId,
    });

    const cdrdGridAnswers = findoutCDRDGridAnswers(
      formattedHistoryRecords,
      caseDetails,
      lookBackTimestamp,
      isQ7Override
    );

    return res.status(200).json({
      message: "success",
      cdrdGridAnswers,
      lookBackTimestamp,
      memberAccountId,
      formattedHistoryRecords,
    });
  } catch (error) {
    logger.error("Error while automating CD_RD responses:", error);
    return res.status(400).json({ message: "failure", error });
  } finally {
    if (bigtable) {
      await bigtable.close();
      logger.info("BigTable connection closed.");
    }
  }
});

module.exports = router;
