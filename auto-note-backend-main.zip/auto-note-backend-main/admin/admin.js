const express = require("express");
const router = express.Router();
const { reloadReferenceData } = require("../form_alts/utils");
const { reloadQ7Data } = require("../cdrd/gpi-override-level");
const { reloadReferenceData: reloadAetnaQuestions } = require("../aetna_questions/utils");
const logger = require("../logger");

// In-memory caches managed here.
// Add a new entry whenever a new stale-while-revalidate cache is introduced.
const CACHES = [
  { name: "form_alts",       reload: reloadReferenceData },
  { name: "cdrd_q7",         reload: reloadQ7Data },
  { name: "aetna_questions", reload: reloadAetnaQuestions },
];

// POST /admin/reload-all
// Reloads ALL in-memory caches from BigQuery in parallel.
// Use after an emergency data correction that can't wait for the 1h TTL.
// Routine monthly DAG refreshes and new deployments self-heal automatically.
router.post("/reload-all", async (req, res) => {
  logger.info("[Admin] /admin/reload-all requested..............");
  const start = Date.now();

  const results = await Promise.allSettled(
    CACHES.map(async ({ name, reload }) => {
      const t = Date.now();
      await reload();
      return { name, durationMs: Date.now() - t };
    })
  );

  const summary = results.map((r, i) =>
    r.status === "fulfilled"
      ? { name: CACHES[i].name, status: "ok",    durationMs: r.value.durationMs }
      : { name: CACHES[i].name, status: "error", error: r.reason?.message }
  );

  const allOk = summary.every(s => s.status === "ok");
  const totalMs = Date.now() - start;

  if (allOk) {
    logger.info("[Admin] /admin/reload-all succeeded", { totalMs, summary });
    return res.status(200).json({ status: "success", data: { totalMs, caches: summary } });
  }

  logger.error("[Admin] /admin/reload-all partial failure", { totalMs, summary });
  return res.status(207).json({ status: "partial", data: { totalMs, caches: summary } });
});

// POST /admin/reload-form-alts
// Reloads only the FormAlts reference tables (CAG crosswalk, GPI/drug, indications, ICD-10, drug notes).
router.post("/reload-form-alts", async (req, res) => {
  try {
    const start = Date.now();
    logger.info("[Admin] /admin/reload-form-alts requested");
    await reloadReferenceData();
    const durationMs = Date.now() - start;
    logger.info("[Admin] /admin/reload-form-alts succeeded", { durationMs });
    res.status(200).json({ status: "success", data: { message: "FormAlts reference data reloaded", durationMs } });
  } catch (err) {
    logger.error("[Admin] /admin/reload-form-alts failed", { error: err.message });
    res.status(400).json({ status: "error", message: "Failed to reload FormAlts data" });
  }
});

// POST /admin/reload-q7
// Reloads only the CDRD Q7 GPI override level tables.
router.post("/reload-q7", async (req, res) => {
  try {
    const start = Date.now();
    logger.info("[Admin] /admin/reload-q7 requested");
    await reloadQ7Data();
    const durationMs = Date.now() - start;
    logger.info("[Admin] /admin/reload-q7 succeeded", { durationMs });
    res.status(200).json({ status: "success", data: { message: "Q7 GPI override level data reloaded", durationMs } });
  } catch (err) {
    logger.error("[Admin] /admin/reload-q7 failed", { error: err.message });
    res.status(400).json({ status: "error", message: "Failed to reload Q7 data" });
  }
});

module.exports = router;
