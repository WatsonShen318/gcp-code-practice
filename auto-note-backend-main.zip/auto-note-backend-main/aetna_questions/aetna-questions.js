const express = require('express');
const logger = require('../logger');
const { fetchAetnaQuestions, reloadReferenceData } = require('./utils');

const router = express.Router();

// POST /aetna-questions/fetch
// Returns active questions matching the supplied gpi and/or ndc.
// Body:    { gpi, ndc }  — at least one must be non-empty
// Returns: { status: 'success', data: { questions: [{ index, question }] } }
//          questions is [] when no rows match (not an error)
router.post('/fetch', async (req, res) => {
  const { gpi, ndc } = req.body;

  if (!gpi && !ndc) {
    logger.warn('[AetnaQuestions] /fetch validation failed - missing params: gpi or ndc');
    return res.status(400).json({
      status: 'error',
      message: 'At least one of gpi or ndc is required',
    });
  }

  try {
    logger.debug('[AetnaQuestions] /fetch requested', { gpi, ndc });
    const questions = await fetchAetnaQuestions(gpi || '', ndc || '');
    logger.info('[AetnaQuestions] /fetch succeeded', { gpi, ndc, questionCount: questions.length });
    res.status(200).json({ status: 'success', data: { questions } });
  } catch (error) {
    logger.error('[AetnaQuestions] /fetch failed', { params: { gpi, ndc }, errorMessage: error.message, errorStack: error.stack });
    res.status(500).json({ status: 'error', message: 'Failed to fetch Aetna-specific questions', details: error.message });
  }
});

// POST /aetna-questions/reload
// Force-refreshes the in-memory cache from BQ (use after a DAG run for immediate effect).
router.post('/reload', async (req, res) => {
  try {
    logger.info('[AetnaQuestions] /reload requested');
    const start = Date.now();
    await reloadReferenceData();
    const durationMs = Date.now() - start;
    logger.info('[AetnaQuestions] /reload succeeded', { durationMs });
    res.status(200).json({ status: 'success', message: 'Aetna questions cache reloaded' });
  } catch (error) {
    logger.error('[AetnaQuestions] /reload failed', { errorMessage: error.message, errorStack: error.stack });
    res.status(500).json({ status: 'error', message: 'Failed to reload Aetna questions cache', details: error.message });
  }
});

module.exports = router;
