const { BigQuery } = require('@google-cloud/bigquery');
const logger = require('../logger');
const {
  COMPUTE_PROJECT_ID,
  AETNA_QUESTIONS_BQ_TABLE,
} = require('../parameters/parameterConfig');

// ── In-memory reference data (stale-while-revalidate) ────────────────
// Same pattern as form_alts/utils.js:
// First request loads Active='Y' rows from BQ and caches them.
// After REFRESH_TTL_MS the next request is served from stale cache while
// a background refresh fires silently — no request ever waits for a refresh.

const REFRESH_TTL_MS = 60 * 60 * 1000; // 1 hour
const BQ_LOCATION = 'US';
const BQ_TIMEOUT_MS = 60000;

let refData = null;
let loadPromise = null;

function _runLoad() {
  if (loadPromise) return loadPromise;

  loadPromise = (async () => {
    logger.info('[AetnaQuestions] Loading reference table from BigQuery...');
    const bq = new BigQuery({ projectId: COMPUTE_PROJECT_ID });

    const [rows] = await bq.query({
      query: `SELECT Id, Type, Question FROM \`${AETNA_QUESTIONS_BQ_TABLE}\` WHERE Active = 'Y'`,
      location: BQ_LOCATION,
      timeoutMs: BQ_TIMEOUT_MS,
    });

    logger.info(`[AetnaQuestions] Loaded ${rows.length} active question rows`);
    refData = { rows, loadedAt: Date.now() };
    loadPromise = null;
    return refData;
  })().catch(err => {
    loadPromise = null;
    logger.error('[AetnaQuestions] Reference data load failed:', err);
    throw err;
  });

  return loadPromise;
}

async function loadReferenceData() {
  if (refData && Date.now() - refData.loadedAt < REFRESH_TTL_MS) {
    return refData;
  }
  if (!refData) {
    return _runLoad();
  }
  if (!loadPromise) {
    logger.info('[AetnaQuestions] TTL expired - triggering background refresh (serving stale data)');
    _runLoad();
  }
  return refData;
}

async function reloadReferenceData() {
  refData = null;
  loadPromise = null;
  return _runLoad();
}

// Returns questions matching gpi or ndc, in BQ row order (= Excel row order = display order).
// Active='N' rows are excluded at load time — they never appear here.
async function fetchAetnaQuestions(gpi, ndc) {
  const { rows } = await loadReferenceData();

  const seen = new Set();
  const matched = rows.filter(row => {
    let matches = false;
    if (row.Type === 'GPI') matches = !!(gpi && row.Id === gpi);
    else if (row.Type === 'NDC') matches = !!(ndc && row.Id === ndc);
    if (!matches || seen.has(row.Question)) return false;
    seen.add(row.Question);
    return true;
  });

  return matched.map((row, index) => ({
    index,
    question: row.Question,
  }));
}

module.exports = { fetchAetnaQuestions, reloadReferenceData };
