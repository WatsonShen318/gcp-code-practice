# Auto Note Backend

## Description 
This repo holds backend codebase for Auto Note Tool with APIs for Authentication, Medhok, Auditing and also for performance testing

## Solutioning
- To have seperate codebase for backend intergrations and logic, auto-note-backend codebase is setup to expose APIs for Authentication, Medhok, Auditing for Auto Note Tool UI.
- This codebase can be updated to add any new APIs required for Auto Note Tool Front-end consumption.
- APIs are developed with Node.js express server

## URLs
1. Dev - https://paops-auto-note-backend.pss-dev.aig.aetna.com/
2. Test - https://paops-auto-note-backend.pss-test.aig.aetna.com/
3. Prod - https://paops-auto-note-backend.pss-prod.aig.aetna.com/

## Front Repo
https://github.aetna.com/paops/auto-note-tool

## APIs

### Authentication
Authentication APIs are developed with Azure AD (Active Directory)

List of Authentication APIs
  - /auth/sigin
  - /auth/signout
  - /auth/redirect
  - /auth/check
  
### Medhok/ESL
For prefilling in Auto Note Tool UI app, data is fetched from Medhok API (dev e.g., https://qa1.apigw-esl-pss.int.cvshealth.com/pbm/at/v3/rxpaservices/casedetails/retrieve) for the given caseId in the request payload. The response is being returned to the UI app for prefilling with /medhok API exposed to auto-note-tool UI

List of Medhok/ESL APIs
    - /medhok

### Bigtable
Audit data is being stored in Big Table to keep track of response time of generating notes, medhok api responses along with failures such as 404s, /bigtable API is used for saving data to Bigtable

List of Bigtable APIs
    - /bigtable

## Dependencies
- @azure/msal-node
- @google-cloud/bigtable
- @google-cloud/logging-winston
- @google-cloud/secret-manager
- express
- axios