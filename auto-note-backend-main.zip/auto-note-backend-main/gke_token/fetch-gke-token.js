/**
 * Helper function to fetch GKE token from the metadata server.
 */
async function fetchGKETokenHelper() {
    try {
        const response = await fetch(
            "http://metadata.google.internal/computeMetadata/v1/instance/service-accounts/default/token",
            {
                method: "GET",
                headers: {
                    "Metadata-Flavor": "Google",
                },
            }
        );

        if (!response.ok) {
            throw new Error(`Metadata server error: ${response.statusText}`);
        }

        const data = await response.json();
        return data;
    } catch (error) {
        console.error("Error fetching token:", error);
        throw error;
    }
}

/**
 * Express middleware to fetch the token and send the result to the client.
 */
async function expressTokenHandler(req, res) {
    try {
        const tokenData = await fetchGKETokenHelper();
        res.status(200).json(tokenData);
    } catch (error) {
        res.status(400).json({ error: error.message || "Unknown error" });
    }
}

module.exports = {
    fetchGKETokenHelper,
    expressTokenHandler,
};