var express = require("express");
const { fetchGKETokenHelper } = require("./fetch-gke-token");
var router = express.Router();

router.get("/", async (req, res) => {
  try {
    const tokenData = await fetchGKETokenHelper();
    res.status(200).json(tokenData);
  } catch (error) {
    res.status(400).json({ error: error.message || "Unknown error" });
  }
});

module.exports = router;
