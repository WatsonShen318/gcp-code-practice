var express = require("express");
const cors = require("cors");

const pingAuthProvider = require("./authProvider");
const { REDIRECT_URI, AUTONOTE_MAIN_URL } = require("../../parameters/parameterConfig");

const router = express.Router();

router.get(
  "/signin",
  pingAuthProvider.login({
    scopes: ["openid", "profile", "email"],
    redirectUri: REDIRECT_URI,
    successRedirect: AUTONOTE_MAIN_URL,
  })
);

router.get(
  "/acquireToken",
  pingAuthProvider.acquireToken({
    scopes: ["openid", "profile", "email"],
    redirectUri: REDIRECT_URI,
    successRedirect: "/users/profile",
  })
);

router.get(
  "/check",
  cors({
    origin: AUTONOTE_MAIN_URL,
    methods: "get",
    credentials: true,
    allowedHeaders: ["Content-Type", "Authorization"],
  }),
  pingAuthProvider.check()
);

router.post("/redirect", pingAuthProvider.handleRedirect());
router.get("/redirect", pingAuthProvider.handleRedirect());

router.get("/signout", pingAuthProvider.logout());

module.exports = router;
