const axios = require("axios");
const crypto = require("crypto");
const logger = require("../../logger");
const accessSecretVersion = require("../../parameters/getSecretParameters");
const { isBetaUser: checkIsBetaUser } = require("./betaUsers");
const {
  REDIRECT_URI,
  AUTONOTE_MAIN_URL,
  POST_LOGOUT_REDIRECT_URI,
  COMPUTE_PROJECT_ID,
  SECRET_MANAGER_SECRET_ID,
  SSO_PROVIDER,
  PING_OAUTH_AUTHORIZATION_ENDPOINT,
  PING_OAUTH_TOKEN_ENDPOINT,
  PING_CLIENT_ID,
  PING_CLIENT_SECRET,
  PING_OAUTH_SCOPES,
  PING_OAUTH_END_SESSION_ENDPOINT,
  PING_OAUTH_USERINFO_ENDPOINT,
  PING_CLIENT_SECRET_KEY,
  EXPRESS_SESSION_SECRET
} = require("../../parameters/parameterConfig");

function parseScopes(value) {
  if (!value || typeof value !== "string") {
    return ["openid", "profile", "email"];
  }

  return value
    .split(/[\s,]+/)
    .map((scope) => scope.trim())
    .filter(Boolean);
}

function base64UrlEncode(input) {
  return Buffer.from(input)
    .toString("base64")
    .replace(/\+/g, "-")
    .replace(/\//g, "_")
    .replace(/=+$/g, "");
}

function generateCodeVerifier() {
  return base64UrlEncode(crypto.randomBytes(32));
}

function generateCodeChallenge(codeVerifier) {
  return crypto
    .createHash("sha256")
    .update(codeVerifier)
    .digest("base64")
    .replace(/\+/g, "-")
    .replace(/\//g, "_")
    .replace(/=+$/g, "");
}

function generateAuthToken(userInfo) {
  const payload = base64UrlEncode(
    JSON.stringify({ ...userInfo, exp: Date.now() + 60 * 60 * 1000 })
  );
  const sig = crypto
    .createHmac("sha256", EXPRESS_SESSION_SECRET)
    .update(payload)
    .digest("hex");
  return `${payload}.${sig}`;
}

function validateAuthToken(token) {
  if (!token || typeof token !== "string") return null;
  const lastDot = token.lastIndexOf(".");
  if (lastDot < 0) return null;
  const payload = token.substring(0, lastDot);
  const sig = token.substring(lastDot + 1);
  const expected = Buffer.from(
    crypto.createHmac("sha256", EXPRESS_SESSION_SECRET).update(payload).digest("hex")
  );
  const actual = Buffer.from(sig);
  if (expected.length !== actual.length || !crypto.timingSafeEqual(expected, actual)) return null;
  try {
    const data = JSON.parse(
      Buffer.from(payload.replace(/-/g, "+").replace(/_/g, "/"), "base64").toString("utf8")
    );
    if (!data.exp || data.exp < Date.now()) return null;
    return data;
  } catch {
    return null;
  }
}

function decodeJwtPayload(jwtToken) {
  if (!jwtToken || typeof jwtToken !== "string") {
    return {};
  }

  const tokenParts = jwtToken.split(".");
  if (tokenParts.length < 2) {
    return {};
  }

  try {
    const payloadSegment = tokenParts[1].replace(/-/g, "+").replace(/_/g, "/");
    const paddedPayload = payloadSegment.padEnd(
      payloadSegment.length + ((4 - (payloadSegment.length % 4)) % 4),
      "="
    );
    const decoded = Buffer.from(paddedPayload, "base64").toString("utf8");
    return JSON.parse(decoded);
  } catch (error) {
    logger.error("Failed to decode id_token payload", error);
    return {};
  }
}

class PingAuthProvider {
  constructor() {
    this.authorizationEndpoint = PING_OAUTH_AUTHORIZATION_ENDPOINT || "";
    this.tokenEndpoint = PING_OAUTH_TOKEN_ENDPOINT || "";
    this.endSessionEndpoint = PING_OAUTH_END_SESSION_ENDPOINT || "";
    this.userInfoEndpoint = PING_OAUTH_USERINFO_ENDPOINT || "";
    this.clientId = PING_CLIENT_ID || "";
    this.clientSecret = PING_CLIENT_SECRET || "";
    this.scopes = parseScopes(PING_OAUTH_SCOPES || "");
  }

  async loadClientCredentials() {
    if (
      process.env.ENV_NAME?.includes("dev") ||
      process.env.ENV_NAME?.includes("qa") ||
      process.env.ENV_NAME?.includes("prod")
    ) {
      // fetch secret from secret manager in deployed environments
      const clientSecret = await accessSecretVersion(
        COMPUTE_PROJECT_ID,
        SECRET_MANAGER_SECRET_ID,
        PING_CLIENT_SECRET_KEY
      );
      this.clientSecret = clientSecret;
    }
  }

  login(options = {}) {
    return async (req, res, next) => {
      try {
        // Throttle rapid retries caused by a persistent PING token-endpoint error.
        // After 3 consecutive failures within 60 s, show a wait page so the browser
        // stops hammering PING and the user gets a chance to retry cleanly.
        const failCount = req.session?.authFailCount || 0;
        const lastFail = req.session?.lastAuthFail || 0;
        if (failCount >= 3 && (Date.now() - lastFail) < 60000) {
          logger.warn("Auth loop detected — throttling redirect to PING", {
            failCount,
            userAgent: req.headers["user-agent"],
            ip: req.headers["x-forwarded-for"] || req.socket?.remoteAddress,
          });
          if (req.session) {
            req.session.authFailCount = 0;
            req.session.lastAuthFail = null;
          }
          return res.status(200).type("text").send(
            "Authentication is taking longer than expected. Please open AutoNote tool again."
          );
        }

        const flowId = crypto.randomBytes(6).toString("hex");
        if (req.session) req.session.pingFlowId = flowId;

        logger.info("[PING signin] started", { flowId, ip: req.headers["x-forwarded-for"] || req.socket?.remoteAddress });

        if (!this.authorizationEndpoint) {
          throw new Error("PING authorization endpoint is not configured");
        }

        await this.loadClientCredentials();
        logger.info("[PING signin] credentials ready", { flowId });

        const successRedirect = options.successRedirect || AUTONOTE_MAIN_URL || "/";
        const nonce = base64UrlEncode(crypto.randomBytes(16));
        const codeVerifier = generateCodeVerifier();
        const codeChallenge = generateCodeChallenge(codeVerifier);

        // Encode PKCE data into the state parameter itself and sign it.
        // Primary path: session cookie carries the state (fast, no re-parsing).
        // Fallback path: if the session cookie is unavailable (blocked), the callback
        // decodes PKCE directly from the signed state parameter — no cookie required.
        const pkcePayload = base64UrlEncode(JSON.stringify({ nonce, codeVerifier, successRedirect }));
        const pkceHmac = crypto
          .createHmac("sha256", EXPRESS_SESSION_SECRET)
          .update(pkcePayload)
          .digest("hex");
        const state = `${pkcePayload}.${pkceHmac}`;

        if (req.session.pendingOAuth) {
          logger.warn("PING login restarted before previous OAuth flow completed", {
            userAgent: req.headers["user-agent"],
            ip: req.headers["x-forwarded-for"] || req.socket?.remoteAddress,
          });
        }

        req.session.pendingOAuth = { state, nonce, codeVerifier, successRedirect };

        logger.info("[PING signin] redirecting to PING", { flowId });

        const authParams = new URLSearchParams({
          response_type: "code",
          client_id: this.clientId,
          redirect_uri: REDIRECT_URI,
          scope: (options.scopes && options.scopes.length
            ? options.scopes
            : this.scopes
          ).join(" "),
          state,
          nonce,
          code_challenge: codeChallenge,
          code_challenge_method: "S256",
        });

        res.redirect(`${this.authorizationEndpoint}?${authParams.toString()}`);
      } catch (error) {
        const flowId = req.session?.pingFlowId || "unknown";
        logger.error("[PING signin] failed before reaching PING", { flowId, error: error.message });
        next(error);
      }
    };
  }

  handleRedirect() {
    return async (req, res, next) => {
      try {
        const flowId = req.session?.pingFlowId || "unknown";
        logger.info("[PING redirect] callback received", {
          flowId,
          hasCode: !!(req.body?.code || req.query?.code),
          hasState: !!(req.body?.state || req.query?.state),
          hasPendingOAuth: !!req.session?.pendingOAuth,
          hasSessionCookie: !!req.cookies?.session,
        });

        if (!this.tokenEndpoint) {
          throw new Error("PING token endpoint is not configured");
        }

        await this.loadClientCredentials();

        const authCode = req.body?.code || req.query?.code;
        const returnedState = req.body?.state || req.query?.state;

        if (!authCode || !returnedState) {
          throw new Error("Missing authorization code/state in callback");
        }

        // Primary: read PKCE state from session cookie.
        let pingAuth = req.session?.pendingOAuth;
        if (pingAuth && returnedState !== pingAuth.state) {
          pingAuth = null; // stale session (e.g. multiple tabs) — fall through to state decode
        }

        if (!pingAuth) {
          // Fallback: decode PKCE directly from the signed state parameter.
          // Used when the session cookie was blocked or lost (cookie blockers, proxy stripping).
          const lastDot = returnedState.lastIndexOf(".");
          if (lastDot < 0) throw new Error("Invalid OAuth state format");

          const payload = returnedState.substring(0, lastDot);
          const hmac = returnedState.substring(lastDot + 1);
          const expectedHmac = crypto
            .createHmac("sha256", EXPRESS_SESSION_SECRET)
            .update(payload)
            .digest("hex");

          if (expectedHmac !== hmac) throw new Error("Invalid OAuth state signature");

          try {
            pingAuth = JSON.parse(
              Buffer.from(payload.replace(/-/g, "+").replace(/_/g, "/"), "base64").toString("utf8")
            );
          } catch {
            throw new Error("Invalid OAuth state payload");
          }

          logger.warn("PING callback used state-parameter fallback — session cookie was unavailable", {
            userAgent: req.headers["user-agent"],
            ip: req.headers["x-forwarded-for"] || req.socket?.remoteAddress,
          });
        }

        req.session.pendingOAuth = null;
        logger.info("[PING redirect] state validated, attempting token exchange", { flowId });

        const tokenRequestBody = new URLSearchParams({
          grant_type: "authorization_code",
          code: authCode,
          redirect_uri: REDIRECT_URI,
          code_verifier: pingAuth.codeVerifier,
          client_id: this.clientId,
        });

        if (this.clientSecret) {
          tokenRequestBody.append("client_secret", this.clientSecret);
        }

        const tokenResponse = await axios.post(
          this.tokenEndpoint,
          tokenRequestBody.toString(),
          {
            headers: {
              "Content-Type": "application/x-www-form-urlencoded",
            },
          }
        );

        logger.info("[PING redirect] token exchange successful", { flowId });

        const tokens = tokenResponse.data || {};
        const idTokenPayload = decodeJwtPayload(tokens.id_token);

        if (
          pingAuth.nonce &&
          idTokenPayload.nonce &&
          pingAuth.nonce !== idTokenPayload.nonce
        ) {
          throw new Error("Invalid nonce in id_token");
        }

        let userInfo = {};
        if (this.userInfoEndpoint && tokens.access_token) {
          try {
            const userInfoResponse = await axios.get(this.userInfoEndpoint, {
              headers: {
                Authorization: `Bearer ${tokens.access_token}`,
              },
            });
            userInfo = userInfoResponse.data || {};
          } catch (error) {
            logger.info("PING userinfo endpoint call failed; falling back to id_token claims", error);
          }
        }

        const mergedClaims = {
          ...idTokenPayload,
          ...userInfo,
        };

        const username =
          mergedClaims.preferred_username ||
          mergedClaims.email ||
          mergedClaims.upn ||
          mergedClaims.sub ||
          "";

        logger.info("[PING redirect] authentication complete", { flowId, username });

        req.session.isAuthenticated = true;
        req.session.account = {
          username,
          name: mergedClaims.name || mergedClaims.given_name || "",
        };
        req.session.authFailCount = 0;
        req.session.lastAuthFail = null;

        // Store idToken in its own cookie — only needed for the PING logout hint.
        // Kept separate from the session cookie to avoid the 4KB session cookie size limit.
        // The id_token is already PING-signed JWT so no additional HMAC is needed.
        if (tokens.id_token) {
          res.cookie("_ping_idt", tokens.id_token, {
            httpOnly: true,
            secure: !!(process.env.ENV_NAME?.includes("prod") || process.env.ENV_NAME?.includes("qa")),
            maxAge: 60 * 60 * 1000,
            sameSite: (process.env.ENV_NAME?.includes("prod") || process.env.ENV_NAME?.includes("qa")) ? "none" : "lax",
            path: "/",
          });
        }

        const successRedirect = pingAuth.successRedirect || AUTONOTE_MAIN_URL || "/";

        const authToken = generateAuthToken({
          username,
          name: mergedClaims.name || mergedClaims.given_name || "",
        });
        res.redirect(`${successRedirect.split('#')[0]}#_authToken=${authToken}`);
      } catch (error) {
        console.log("PING auth callback error:", {
          message: error.message,
          pingStatus: error.response?.status,
          pingStatusText: error.response?.statusText,
          pingError: error.response?.data,
        });
        const flowId = req.session?.pingFlowId || "unknown";
        logger.warn("[PING redirect] failed", {
          flowId,
          error: error.message,
          pingStatus: error.response?.status,
          pingStatusText: error.response?.statusText,
          pingResponseBody: error.response?.data,
          hasPendingOAuth: !!req.session?.pendingOAuth,
          hasSessionCookie: !!req.cookies?.session,
        });
        if (req.session) {
          req.session.authFailCount = (req.session.authFailCount || 0) + 1;
          req.session.lastAuthFail = Date.now();
        }
        // Return an error page instead of redirecting back to the frontend.
        // A redirect to AUTONOTE_MAIN_URL causes an infinite loop because the
        // frontend immediately calls /auth/signin again on every unauthenticated load.
        res.status(200).type("text").send(
          "Sign-in failed. Please open AutoNote tool again to retry."
        );
      }
    };
  }

  acquireToken(options = {}) {
    return async (req, res) => {
      if (req.session?.isAuthenticated) {
        return res.redirect(options.successRedirect || AUTONOTE_MAIN_URL || "/");
      }

      return this.login(options)(req, res, () => {});
    };
  }

  logout() {
    return (req, res) => {
      // Read idToken from its dedicated cookie for the PING logout hint.
      const idTokenHint = req.cookies?._ping_idt || null;

      req.session = null;
      res.clearCookie("_ping_idt", { path: "/" });

      if (!this.endSessionEndpoint) {
        return res.redirect(POST_LOGOUT_REDIRECT_URI || AUTONOTE_MAIN_URL || "/");
      }

      const logoutParams = new URLSearchParams();
      if (POST_LOGOUT_REDIRECT_URI) {
        logoutParams.append("post_logout_redirect_uri", POST_LOGOUT_REDIRECT_URI);
      }
      if (idTokenHint) {
        logoutParams.append("id_token_hint", idTokenHint);
      }

      const query = logoutParams.toString();
      const logoutUri = query
        ? `${this.endSessionEndpoint}?${query}`
        : this.endSessionEndpoint;
      res.redirect(logoutUri);
    };
  }

  check() {
    return async (req, res) => {
      try {
        let isAuthenticated = req?.session?.isAuthenticated;
        let account = req?.session?.account;

        if (!isAuthenticated) {
          const authHeader = req.headers?.authorization;
          if (authHeader?.startsWith("Bearer ")) {
            const tokenData = validateAuthToken(authHeader.slice(7));
            if (tokenData) {
              isAuthenticated = true;
              account = { username: tokenData.username, name: tokenData.name };
            }
          }
        }

        const userId = account?.username;

        const isBeta = isAuthenticated ? await checkIsBetaUser(userId) : false;
        const userGroups = isBeta ? ["beta"] : [];
        let isHoldoutUser = false;

        res.set("Cache-Control", "no-store");
        res.status(200).json({
          isAuthenticated: isAuthenticated || false,
          ...(isAuthenticated
            ? {
                userInfo: {
                  userId,
                  userName: account?.name,
                  isHoldoutUser,
                  userGroups,
                  isBetaUser: isBeta,
                },
              }
            : {}),
        });
      } catch (error) {
        logger.error(error);
        res.status(401).json({
          isAuthenticated: false,
        });
      }
    };
  }
}

module.exports = new PingAuthProvider();
