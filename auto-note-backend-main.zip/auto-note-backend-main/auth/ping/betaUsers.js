const { Storage } = require("@google-cloud/storage");
const logger = require("../../logger");
const { DATA_BUCKET_NAME, BETA_USERS_LIST_FILE_NAME } = require("../../parameters/parameterConfig");

const CACHE_TTL_MS = 5 * 60 * 1000; // 5 minutes

const storage = new Storage();

let _cache = null;
let _cacheExpiry = 0;

/**
 * Returns a Set of lowercase userIds who are in the beta program.
 * Results are cached for 5 minutes to avoid GCS round-trips on every /auth/check.
 * On read failure returns an empty Set so the check degrades gracefully.
 */
async function getBetaUsers() {
  if (_cache && Date.now() < _cacheExpiry) {
    return _cache;
  }

  try {
    const bucket = storage.bucket(DATA_BUCKET_NAME);
    const file = bucket.file(BETA_USERS_LIST_FILE_NAME);

    const [exists] = await file.exists();
    if (!exists) {
      logger.warn(
        `[getBetaUsers] Beta users file not found: ${BETA_USERS_LIST_FILE_NAME} in bucket ${DATA_BUCKET_NAME}. Treating as empty list.`
      );
      _cache = new Set();
      _cacheExpiry = Date.now() + CACHE_TTL_MS;
      return _cache;
    }

    const [contents] = await file.download();
    const userIds = JSON.parse(contents.toString());
    _cache = new Set(userIds.map((id) => id.toLowerCase()));
    _cacheExpiry = Date.now() + CACHE_TTL_MS;

    logger.info(`[getBetaUsers] Loaded ${_cache.size} beta user(s) from GCS.`);
    return _cache;
  } catch (error) {
    logger.error("[getBetaUsers] Failed to read beta users list from GCS.", error);
    return new Set();
  }
}

/**
 * Returns true if the given userId (case-insensitive) is in the beta users list.
 */
async function isBetaUser(userId) {
  if (!userId) return false;
  const betaUsers = await getBetaUsers();
  return betaUsers.has(userId.toLowerCase());
}

module.exports = { getBetaUsers, isBetaUser };
