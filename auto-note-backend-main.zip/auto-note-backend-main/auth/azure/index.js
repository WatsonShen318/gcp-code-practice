/* We are currently using PING Federate for authentication in EDP1.5 */
var express = require("express");
const cors = require("cors");

const authProvider = require("./authProvider");
const {
  REDIRECT_URI,
  AUTONOTE_MAIN_URL,
} = require("../../parameters/parameterConfig");

const router = express.Router();

router.get(
  "/signin",
  authProvider.login({
    scopes: [],
    redirectUri: REDIRECT_URI,
    successRedirect: AUTONOTE_MAIN_URL,
  })
);

router.get(
  "/acquireToken",
  authProvider.acquireToken({
    scopes: ["User.Read"],
    redirectUri: REDIRECT_URI,
    successRedirect: "/users/profile",
  })
);

router.get(
  "/check",
  cors({
    origin: AUTONOTE_MAIN_URL,
    methods: "get",
    credentials: true,
    allowedHeaders: ["Content-Type", "Authorization"],
  }),
  authProvider.check({
    scopes: ["User.Read"],
  })
);

router.post("/redirect", authProvider.handleRedirect());

router.get("/signout", authProvider.logout());

module.exports = router;
