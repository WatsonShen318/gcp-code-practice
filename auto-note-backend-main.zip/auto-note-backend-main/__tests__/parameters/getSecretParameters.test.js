// getSecretParameters.js creates a SecretManagerServiceClient at module load time.
// The delegate pattern lets us reassign mockAccessSecretVersion per test without resetModules.
// console.log is suppressed because the source logs each secret access — expected noise.
jest.spyOn(console, 'log').mockImplementation(() => {});

var mockAccessSecretVersion;

jest.mock('@google-cloud/secret-manager', () => ({
  SecretManagerServiceClient: jest.fn().mockImplementation(() => ({
    accessSecretVersion: (...args) => mockAccessSecretVersion(...args),
  })),
}));

const accessSecretVersion = require('../../parameters/getSecretParameters');

const PROJECT_ID = 'my-project';
const SECRET_ID  = 'my-secret-id';
const SECRET_KEY = 'CLIENT_SECRET';

const PAYLOAD = { CLIENT_SECRET: 'super-secret-value', OTHER_KEY: 'other' };

beforeEach(() => {
  jest.clearAllMocks();
  mockAccessSecretVersion = jest.fn().mockResolvedValue([{
    payload: { data: Buffer.from(JSON.stringify(PAYLOAD)) },
  }]);
});

describe('accessSecretVersion', () => {
  test('returns the value for the requested secretKey from the secret payload', async () => {
    const result = await accessSecretVersion(PROJECT_ID, SECRET_ID, SECRET_KEY);
    expect(result).toBe('super-secret-value');
  });

  test('constructs the secret name with project/secret/versions/latest', async () => {
    await accessSecretVersion(PROJECT_ID, SECRET_ID, SECRET_KEY);
    const [{ name }] = mockAccessSecretVersion.mock.calls[0];
    expect(name).toBe(`projects/${PROJECT_ID}/secrets/${SECRET_ID}/versions/latest`);
  });

  test('returns a different key from the same payload when asked', async () => {
    const result = await accessSecretVersion(PROJECT_ID, SECRET_ID, 'OTHER_KEY');
    expect(result).toBe('other');
  });

  test('throws when the Secret Manager call rejects', async () => {
    mockAccessSecretVersion = jest.fn().mockRejectedValue(new Error('permission denied'));
    await expect(accessSecretVersion(PROJECT_ID, SECRET_ID, SECRET_KEY))
      .rejects.toThrow('permission denied');
  });

  test('returns undefined when secretKey does not exist in the payload', async () => {
    const result = await accessSecretVersion(PROJECT_ID, SECRET_ID, 'MISSING_KEY');
    expect(result).toBeUndefined();
  });
});
