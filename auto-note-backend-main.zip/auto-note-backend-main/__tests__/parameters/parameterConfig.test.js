// parameterConfig.js reads process.env at load time (dotenv) and at call time (isDeployedEnv).
// isDeployedEnv() reads process.env.ENV_NAME at call time, so we can test it by setting the
// env var before each call without needing jest.resetModules().
jest.mock('dotenv', () => ({ config: jest.fn() }));

const { isDeployedEnv } = require('../../parameters/parameterConfig');

describe('isDeployedEnv', () => {
  const original = process.env.ENV_NAME;

  afterEach(() => {
    if (original === undefined) {
      delete process.env.ENV_NAME;
    } else {
      process.env.ENV_NAME = original;
    }
  });

  test('returns false when ENV_NAME is not set', () => {
    delete process.env.ENV_NAME;
    expect(isDeployedEnv()).toBe(false);
  });

  test('returns false when ENV_NAME is "local"', () => {
    process.env.ENV_NAME = 'local';
    expect(isDeployedEnv()).toBe(false);
  });

  test('returns false when ENV_NAME is "development"', () => {
    process.env.ENV_NAME = 'development';
    expect(isDeployedEnv()).toBe(false);
  });

  test('returns true when ENV_NAME contains "pdev"', () => {
    process.env.ENV_NAME = 'pdev';
    expect(isDeployedEnv()).toBe(true);
  });

  test('returns true when ENV_NAME contains "pqa"', () => {
    process.env.ENV_NAME = 'pqa';
    expect(isDeployedEnv()).toBe(true);
  });

  test('returns true when ENV_NAME is "prod"', () => {
    process.env.ENV_NAME = 'prod';
    expect(isDeployedEnv()).toBe(true);
  });

  test('returns true for a full prod env name like "paops-prod"', () => {
    process.env.ENV_NAME = 'paops-prod';
    expect(isDeployedEnv()).toBe(true);
  });
});
