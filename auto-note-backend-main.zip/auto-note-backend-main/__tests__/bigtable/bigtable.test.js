jest.mock('../../logger', () => ({
  info: jest.fn(), error: jest.fn(), warn: jest.fn(), debug: jest.fn(),
}));

// Mock both exported functions — no cloud calls in router tests
jest.mock('../../bigtable/bigTableUtils', () => ({
  convertIntoDataToSend: jest.fn(),
  pushDataToBigData: jest.fn(),
}));

const request = require('supertest');
const express = require('express');
const { convertIntoDataToSend, pushDataToBigData } = require('../../bigtable/bigTableUtils');
const router = require('../../bigtable/bigtable');

function buildApp() {
  const app = express();
  app.use(express.json());
  app.use('/', router);
  return app;
}

beforeEach(() => {
  jest.clearAllMocks();
});

// ── POST / ─────────────────────────────────────────────────────────────────────
describe('POST /', () => {
  test('returns 200 with status:success on successful push', async () => {
    convertIntoDataToSend.mockReturnValue('serialized-payload');
    pushDataToBigData.mockResolvedValue();

    const res = await request(buildApp())
      .post('/')
      .send({ userId: 'user123', finalNote: '' });

    expect(res.status).toBe(200);
    expect(res.body).toEqual({ status: 'success' });
  });

  test('passes req.body to convertIntoDataToSend', async () => {
    const body = { userId: 'user123', finalNote: 'Request Reason: Prior Auth' };
    convertIntoDataToSend.mockReturnValue('serialized');
    pushDataToBigData.mockResolvedValue();

    await request(buildApp()).post('/').send(body);

    expect(convertIntoDataToSend).toHaveBeenCalledWith(body);
  });

  test('passes req.body and serialized data to pushDataToBigData', async () => {
    const body = { userId: 'user123', finalNote: '' };
    convertIntoDataToSend.mockReturnValue('the-serialized-data');
    pushDataToBigData.mockResolvedValue();

    await request(buildApp()).post('/').send(body);

    expect(pushDataToBigData).toHaveBeenCalledWith(body, 'the-serialized-data');
  });

  test('returns 400 text response when pushDataToBigData throws', async () => {
    convertIntoDataToSend.mockReturnValue('serialized');
    pushDataToBigData.mockRejectedValue(new Error('BT connection failed'));

    const res = await request(buildApp())
      .post('/')
      .send({ userId: 'user123' });

    expect(res.status).toBe(400);
    expect(res.text).toContain('An Error occured while pushing audit data');
  });

  test('returns 400 text response when convertIntoDataToSend throws', async () => {
    convertIntoDataToSend.mockImplementation(() => { throw new Error('parse error'); });

    const res = await request(buildApp())
      .post('/')
      .send({ userId: 'user123' });

    expect(res.status).toBe(400);
    expect(res.text).toContain('An Error occured while pushing audit data');
  });
});
