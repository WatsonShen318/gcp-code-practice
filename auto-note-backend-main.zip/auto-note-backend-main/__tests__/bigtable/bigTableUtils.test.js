// var-hoisted so the jest.mock factory delegate closures pick up reassignments in each test
var mockInsert;
var mockExists;
var mockCreate;
var mockClose;

jest.mock('../../logger', () => ({
  info: jest.fn(), error: jest.fn(), warn: jest.fn(), debug: jest.fn(),
}));
jest.mock('../../parameters/parameterConfig', () => ({
  TABLE_ID: 'test-table',
  COLUMN_FAMILY_ID: 'cf',
  INSTANCE_ID: 'test-instance',
  PROJECT_ID: 'test-project',
}));
// Delegate pattern: outer closure captures var by reference, so reassigning the var
// in beforeEach/each test is picked up without re-registering the mock.
jest.mock('@google-cloud/bigtable', () => ({
  Bigtable: jest.fn().mockImplementation(() => ({
    instance: jest.fn().mockReturnValue({
      table: jest.fn().mockReturnValue({
        exists: (...args) => mockExists(...args),
        create: (...args) => mockCreate(...args),
        insert: (...args) => mockInsert(...args),
      }),
    }),
    close: (...args) => mockClose(...args),
  })),
}));

// ── Helpers ───────────────────────────────────────────────────────────────────

// Returns a fresh module instance; resets module-level `tableEnsured = false`.
function loadBigTableUtils() {
  mockExists = jest.fn().mockResolvedValue([true]);
  mockCreate = jest.fn().mockResolvedValue([]);
  mockInsert = jest.fn().mockResolvedValue([]);
  mockClose = jest.fn();
  jest.resetModules();
  return require('../../bigtable/bigTableUtils');
}

// `convertIntoDataToSend` is pure — capture once at top level.
// jest.resetModules() calls inside loadBigTableUtils don't affect this reference.
const { convertIntoDataToSend } = require('../../bigtable/bigTableUtils');

function makeReqBody(overrides = {}) {
  return {
    userId: 'user123',
    userName: 'Test User',
    startTime: '2024-01-01T10:00:00.000Z',
    cdrdStartTime: '2024-01-01T10:00:00.000Z',
    cdrdEndTime: '2024-01-01T10:05:00.000Z',
    cdrdPredOutcome: 'approved',
    caseType: 'CD',
    medhokStatus: 'pending',
    medhokBackendResponse: null,
    caseIdInputTimeList: [],
    workFlow: 'standard',
    userGroups: ['group1'],
    finalNote: '',
    ...overrides,
  };
}

// ── convertIntoDataToSend ─────────────────────────────────────────────────────
describe('convertIntoDataToSend', () => {
  test('returns a valid JSON string', () => {
    const result = convertIntoDataToSend(makeReqBody());
    expect(() => JSON.parse(result)).not.toThrow();
  });

  test('maps core reqBody fields into the output object', () => {
    const body = makeReqBody();
    const out = JSON.parse(convertIntoDataToSend(body));
    expect(out.USER_ID).toBe('user123');
    expect(out.USER_NM).toBe('Test User');
    expect(out.CASE_TYPE).toBe('CD');
    expect(out.CASE_STRT_TS).toBe(body.startTime);
    expect(out.WORK_FLOW).toBe('standard');
  });

  test('CASE_END_TS is a valid ISO timestamp', () => {
    const out = JSON.parse(convertIntoDataToSend(makeReqBody()));
    expect(new Date(out.CASE_END_TS).toISOString()).toBe(out.CASE_END_TS);
  });

  test('optional fields default to empty string when missing', () => {
    const out = JSON.parse(convertIntoDataToSend(makeReqBody()));
    expect(out.DLT_GL_NM).toBe('');
    expect(out.RECOMMENDED_CASE_DCSN_ROUTING).toBe('');
    expect(out.RFI_REASON_SELECTED).toBe('');
  });

  test('optional null fields default to null when missing', () => {
    const out = JSON.parse(convertIntoDataToSend(makeReqBody()));
    expect(out.GL_FIELDS_AUTOMATED).toBeNull();
    expect(out.FORM_ALTS_AUDIT).toBeNull();
    expect(out.QL_AUDIT).toBeNull();
  });

  test('parses finalNote into key-value FINAL_NOTE dict', () => {
    const body = makeReqBody({ finalNote: 'Request Reason: Prior Auth\nCase Type: CD' });
    const out = JSON.parse(convertIntoDataToSend(body));
    expect(out.FINAL_NOTE['Request Reason']).toBe('Prior Auth');
    expect(out.REQ_RSN).toBe('Prior Auth');
  });

  test('extracts Drug name by trimming at Qty/DS', () => {
    const body = makeReqBody({ finalNote: 'Drug: Aspirin 81mg Qty/DS: 30/30' });
    const out = JSON.parse(convertIntoDataToSend(body));
    expect(out.FINAL_NOTE['Drug']).toBe('Aspirin 81mg');
  });

  test('extracts Qty/DS as a separate key via regex', () => {
    const body = makeReqBody({ finalNote: 'Drug: Aspirin 81mg Qty/DS: 30/30' });
    const out = JSON.parse(convertIntoDataToSend(body));
    expect(out.FINAL_NOTE['Qty/DS']).toBe('30/30');
  });

  test('injects newline before "Tier case created" so it parses as its own field', () => {
    const body = makeReqBody({ finalNote: 'Tiering: Yes Tier case created: Yes' });
    const out = JSON.parse(convertIntoDataToSend(body));
    expect(out.FINAL_NOTE['Tier case created']).toBe('Yes');
  });

  test('injects newline before "Current Tier" so it parses as its own field', () => {
    const body = makeReqBody({ finalNote: 'Tiering: Yes Current Tier: 2' });
    const out = JSON.parse(convertIntoDataToSend(body));
    expect(out.FINAL_NOTE['Current Tier']).toBe('2');
  });

  test('prepends field label to "This is Case" line', () => {
    const body = makeReqBody({ finalNote: 'This is Case 2 of 3' });
    const out = JSON.parse(convertIntoDataToSend(body));
    expect(out.FINAL_NOTE['Does this member have multiple drugs or requests?']).toBe('This is Case 2 of 3');
  });

  test('prepends field label to Prospective Review line with year', () => {
    const body = makeReqBody({ finalNote: 'This is a 2025 Prospective Review' });
    const out = JSON.parse(convertIntoDataToSend(body));
    expect(out.FINAL_NOTE['Is this for Prospective Review?']).toBe('This is a 2025 Prospective Review');
  });

  test('prepends PDP/MAPD label when finalNote starts with MAPD', () => {
    const body = makeReqBody({ finalNote: 'MAPD' });
    const out = JSON.parse(convertIntoDataToSend(body));
    expect(out.FINAL_NOTE['PDP/MAPD']).toBe('MAPD');
  });

  test('prepends PDP/MAPD label when finalNote starts with PDP', () => {
    const body = makeReqBody({ finalNote: 'PDP' });
    const out = JSON.parse(convertIntoDataToSend(body));
    expect(out.FINAL_NOTE['PDP/MAPD']).toBe('PDP');
  });

  test('injects newline before "CD/RD Grid Answers" so it parses as its own field', () => {
    const body = makeReqBody({ finalNote: 'Request Type: Standard CD/RD Grid Answers: Yes' });
    const out = JSON.parse(convertIntoDataToSend(body));
    expect(out.FINAL_NOTE['CD/RD Grid Answers']).toBe('Yes');
  });

  test('sets CASE_ID and ESL_RSPNS from eslRsp when present', () => {
    const body = makeReqBody({ eslRsp: { rxId: 'CASE-999', detail: 'x' } });
    const out = JSON.parse(convertIntoDataToSend(body));
    expect(out.CASE_ID).toBe('CASE-999');
    expect(out.ESL_RSPNS).toEqual({ rxId: 'CASE-999', detail: 'x' });
  });

  test('defaults CASE_ID to empty string and ESL_RSPNS to empty string when no eslRsp', () => {
    const out = JSON.parse(convertIntoDataToSend(makeReqBody()));
    expect(out.CASE_ID).toBe('');
    expect(out.ESL_RSPNS).toBe('');
  });

  // When eslRsp is an empty object the if-block fires but rxId is undefined,
  // causing CASE_ID to be stripped by JSON.stringify. Documents current behavior.
  test('CASE_ID is omitted from JSON when eslRsp is an empty object (no rxId)', () => {
    const body = makeReqBody({ eslRsp: {} });
    const out = JSON.parse(convertIntoDataToSend(body));
    expect(out.CASE_ID).toBeUndefined();
    expect(out.ESL_RSPNS).toEqual({});
  });

  test('handles missing or empty finalNote without throwing', () => {
    expect(() => convertIntoDataToSend(makeReqBody({ finalNote: '' }))).not.toThrow();
    expect(() => convertIntoDataToSend(makeReqBody({ finalNote: undefined }))).not.toThrow();
  });

  // Real-world sample — smoke test covering the full transformation pipeline
  test('correctly transforms a real production reqBody', () => {
    const body = {
      caseType: 'techQueue',
      userId: 'Jashwanth.Puligundla@aetna.com',
      userName: '',
      userGroups: [],
      startTime: '2026-09-18T18:15:28.394Z',
      workFlow: 'Automated',
      medhokStatus: ['M24R7FYPL9Z:200'],
      cdrdPredOutcome: 'CD',
      cdrdStartTime: '',
      cdrdEndTime: '',
      dltGuidelineStartTime: '',
      dltGuidelineEndTime: '',
      dltGuidelineName: '',
      caseIdInputTimeList: ['2026-09-18T18:15:31.844Z'],
      GL_FIELDS_AUTOMATED: {},
      GL_FIELDS_FINAL: {},
      eslRsp: {
        rxId: 'M24R7FYPL9Z',
        drugName: 'FORTEO Soln Pen-inj 600MCG/2.4ML',
        requestReason: 'Prior Authorization',
        status: 'Dismissed',
      },
      finalNote: [
        'Title: Tech',
        'Priority: Standard',
        'Client: SSI',
        'Drug: FORTEO Soln Pen-inj 600MCG/2.4ML    Qty/DS: 1/30',
        'Request Reason: Prior Authorization',
        'Tiering: No',
        'Request Type: CD CD/RD Grid Answers: Q1=No, Q1a=No',
        'Case Decision/Routing: Sent to RFI',
      ].join('\n'),
      FORM_ALTS_AUDIT: { drugLookupStatus: 'Supported - 1 option' },
      QL_AUDIT: null,
      RECOMMENDED_CASE_DCSN_ROUTING: '',
      FINAL_CASE_DCSN_ROUTING: 'Sent to RFI',
      RFI_REASON_SELECTED: 'RFI-Non Formulary Opioid',
      DENIAL_REASON_SELECTED: null,
      CASE_VERBIAGE_GENERATED: 'test verbiage',
    };

    const out = JSON.parse(convertIntoDataToSend(body));

    // Identity fields
    expect(out.CASE_ID).toBe('M24R7FYPL9Z');
    expect(out.USER_ID).toBe('Jashwanth.Puligundla@aetna.com');
    expect(out.WORK_FLOW).toBe('Automated');

    // Drug extraction
    expect(out.FINAL_NOTE['Drug']).toBe('FORTEO Soln Pen-inj 600MCG/2.4ML');
    expect(out.FINAL_NOTE['Qty/DS']).toBe('1/30');

    // CD/RD Grid Answers injection
    expect(out.FINAL_NOTE['CD/RD Grid Answers']).toBe('Q1=No, Q1a=No');
    expect(out.FINAL_NOTE['Request Type']).toBe('CD');

    // REQ_RSN derived from FINAL_NOTE
    expect(out.REQ_RSN).toBe('Prior Authorization');

    // Pass-through fields
    expect(out.FINAL_CASE_DCSN_ROUTING).toBe('Sent to RFI');
    expect(out.RFI_REASON_SELECTED).toBe('RFI-Non Formulary Opioid');
    expect(out.FORM_ALTS_AUDIT).toEqual({ drugLookupStatus: 'Supported - 1 option' });
    expect(out.QL_AUDIT).toBeNull();
  });

  // Manual IBC case: empty eslRsp, DLT guideline populated, GL_FIELDS_AUTOMATED/FINAL present
  test('correctly transforms a Manual/IBC reqBody with DLT guideline and empty eslRsp', () => {
    const body = {
      caseType: 'techIBC',
      userId: 'Jashwanth.Puligundla@aetna.com',
      userName: '',
      userGroups: [],
      startTime: '2026-09-18T18:19:41.906Z',
      workFlow: 'Manual',
      cdrdPredOutcome: '',
      cdrdStartTime: '2026-09-18T18:20:27.456Z',
      cdrdEndTime: '2026-09-18T18:20:29.236Z',
      dltGuidelineStartTime: '',
      dltGuidelineEndTime: '',
      dltGuidelineName: 'Standard Non-Formulary Exception Guideline',
      caseIdInputTimeList: [],
      GL_FIELDS_AUTOMATED: { dltAutomatedGuidelineForm: 'Standard Non-Formulary Exception Guideline' },
      GL_FIELDS_FINAL: { dltFinalGuidelineForm: 'Standard Non-Formulary Exception Guideline' },
      eslRsp: {},  // empty — CASE_ID will be undefined in output
      finalNote: [
        'Title: IBC Tech',
        'Priority: Standard',
        'Client: Aetna MAPD',
        'Drug: AMBIEN CR TABLET ER 12.5MG    Qty/DS: 1/2',
        'Request Reason: Non-formulary',
        'Request Type: CD CD/RD Grid Answers: Q1=No, Q1a=No',
        'Case Decision/Routing: Sent to RFI',
        'RFI Reason: RFI-Non Formulary Opioid',
      ].join('\n'),
      FORM_ALTS_AUDIT: { drugLookupStatus: 'Supported - 1 option' },
      QL_AUDIT: null,
      FINAL_CASE_DCSN_ROUTING: 'Sent to RFI',
      RFI_REASON_SELECTED: 'RFI-Non Formulary Opioid',
    };

    const out = JSON.parse(convertIntoDataToSend(body));

    // empty eslRsp → CASE_ID omitted from JSON
    expect(out.CASE_ID).toBeUndefined();
    expect(out.ESL_RSPNS).toEqual({});

    // DLT guideline name passed through
    expect(out.DLT_GL_NM).toBe('Standard Non-Formulary Exception Guideline');

    // GL_FIELDS round-tripped
    expect(out.GL_FIELDS_AUTOMATED).toEqual({ dltAutomatedGuidelineForm: 'Standard Non-Formulary Exception Guideline' });
    expect(out.GL_FIELDS_FINAL).toEqual({ dltFinalGuidelineForm: 'Standard Non-Formulary Exception Guideline' });

    // Drug extraction
    expect(out.FINAL_NOTE['Drug']).toBe('AMBIEN CR TABLET ER 12.5MG');
    expect(out.FINAL_NOTE['Qty/DS']).toBe('1/2');

    // CD/RD Grid Answers injection
    expect(out.FINAL_NOTE['CD/RD Grid Answers']).toBe('Q1=No, Q1a=No');

    // REQ_RSN
    expect(out.REQ_RSN).toBe('Non-formulary');

    // Client field is data — NOT the MAPD prefix trigger (finalNote doesn't start with MAPD)
    expect(out.FINAL_NOTE['PDP/MAPD']).toBeUndefined();
    expect(out.FINAL_NOTE['Client']).toBe('Aetna MAPD');
  });

  // Intakeform case: single-line non-standard finalNote, all MHK fields, FORM_ALTS_AUDIT null
  test('correctly transforms an intakeform reqBody with MHK fields and single-line finalNote', () => {
    const body = {
      caseType: 'intakeform',
      userId: 'Jashwanth.Puligundla@aetna.com',
      userName: '',
      userGroups: [],
      startTime: '2026-09-18T18:21:31.190Z',
      workFlow: 'Manual',
      cdrdPredOutcome: '',
      cdrdStartTime: '',
      cdrdEndTime: '',
      dltGuidelineStartTime: '',
      dltGuidelineEndTime: '',
      dltGuidelineName: '',
      caseIdInputTimeList: [],
      GL_FIELDS_AUTOMATED: {},
      GL_FIELDS_FINAL: {},
      eslRsp: {},
      // Single run-on line — no standard "Key: Value\n" structure, no Drug/Qty/DS
      finalNote: 'Forwarding to tech for review. Validated Member using 3 identifiers: No',
      FORM_ALTS_AUDIT: null,
      QL_AUDIT: null,
      RECOMMENDED_CASE_DCSN_ROUTING: '',
      FINAL_CASE_DCSN_ROUTING: '',
      RFI_REASON_SELECTED: null,
      DENIAL_REASON_SELECTED: null,
      CASE_VERBIAGE_GENERATED: null,
      MHK_OBC_CONTACT_TYPE: '',
      MHK_OBC_CONTACT_OUTCOME: '',
      MHK_OBC_CONTACT_NOTES: '',
      MHK_STATUS: '',
      MHK_STATUS_REASON: '',
      MHK_FINAL_NOTE: '',
      MHK_ADDL_INFO_REQUIRED: '',
      MHK_SUPP_STMT_REQUIRED: '',
      MHK_LETTER_TEMPLATE_DESC: '',
      MHK_EXTERNAL_TEMPLATE: '',
      MHK_EXTERNAL_TEMPLATE_DESC: '',
    };

    const out = JSON.parse(convertIntoDataToSend(body));

    // No eslRsp.rxId → CASE_ID omitted
    expect(out.CASE_ID).toBeUndefined();

    // No "Request Reason" line in finalNote → REQ_RSN is undefined
    expect(out.REQ_RSN).toBeUndefined();

    // FORM_ALTS_AUDIT explicitly null passes through
    expect(out.FORM_ALTS_AUDIT).toBeNull();

    // MHK fields default to empty string
    expect(out.MHK_STATUS).toBe('');
    expect(out.MHK_FINAL_NOTE).toBe('');
    expect(out.MHK_OBC_CONTACT_TYPE).toBe('');
    expect(out.MHK_LETTER_TEMPLATE_DESC).toBe('');

    // Does not crash on single-line non-KV finalNote
    expect(out.FINAL_NOTE).toBeDefined();

    // CASE_VERBIAGE_GENERATED null → defaults to empty string
    expect(out.CASE_VERBIAGE_GENERATED).toBe('');
  });
});

// ── pushDataToBigData — table lifecycle ───────────────────────────────────────
describe('pushDataToBigData — table lifecycle', () => {
  const REQ_BODY = makeReqBody();

  test('skips table.create() when table already exists', async () => {
    const { pushDataToBigData } = loadBigTableUtils(); // default: mockExists → [true]
    await pushDataToBigData(REQ_BODY, 'data');
    expect(mockCreate).not.toHaveBeenCalled();
    expect(mockInsert).toHaveBeenCalledTimes(1);
  });

  test('calls table.create() when table does not exist', async () => {
    const { pushDataToBigData } = loadBigTableUtils();
    mockExists = jest.fn().mockResolvedValue([false]); // override AFTER load
    await pushDataToBigData(REQ_BODY, 'data');
    expect(mockCreate).toHaveBeenCalledTimes(1);
    expect(mockInsert).toHaveBeenCalledTimes(1);
  });

  test('skips table.exists() on second call once tableEnsured is cached', async () => {
    const { pushDataToBigData } = loadBigTableUtils();
    await pushDataToBigData(REQ_BODY, 'data');   // first call: exists() runs
    await pushDataToBigData(REQ_BODY, 'data');   // second call: exists() skipped
    expect(mockExists).toHaveBeenCalledTimes(1);
    expect(mockInsert).toHaveBeenCalledTimes(2);
  });

  test('inserts row with key in format userId:isoTimestamp', async () => {
    const { pushDataToBigData } = loadBigTableUtils();
    await pushDataToBigData(REQ_BODY, 'data');
    const [rowArg] = mockInsert.mock.calls[0];
    expect(rowArg.key).toMatch(/^user123:\d{4}-\d{2}-\d{2}T/);
  });

  test('inserts row with data under the column family', async () => {
    const { pushDataToBigData } = loadBigTableUtils();
    await pushDataToBigData(REQ_BODY, 'payload');
    const [rowArg] = mockInsert.mock.calls[0];
    expect(rowArg.data['cf'].value).toBe('payload');
    expect(rowArg.data['cf'].timestamp).toBeDefined();
  });

  test('calls bigtableClient.close() after a successful insert', async () => {
    const { pushDataToBigData } = loadBigTableUtils();
    await pushDataToBigData(REQ_BODY, 'data');
    expect(mockClose).toHaveBeenCalledTimes(1);
  });

  test('calls bigtableClient.close() even when insert throws', async () => {
    const { pushDataToBigData } = loadBigTableUtils();
    mockInsert = jest.fn().mockRejectedValue(Object.assign(new Error('fail'), { code: 13 }));
    await expect(pushDataToBigData(REQ_BODY, 'data')).rejects.toThrow('fail');
    expect(mockClose).toHaveBeenCalledTimes(1);
  });

  test('re-throws the error so the caller can handle it', async () => {
    const { pushDataToBigData } = loadBigTableUtils();
    mockInsert = jest.fn().mockRejectedValue(Object.assign(new Error('bt error'), { code: 13 }));
    await expect(pushDataToBigData(REQ_BODY, 'data')).rejects.toThrow('bt error');
  });
});

// ── withBigtableRetry (via pushDataToBigData) ─────────────────────────────────
describe('withBigtableRetry', () => {
  const REQ_BODY = makeReqBody();

  beforeEach(() => jest.useFakeTimers());
  afterEach(() => jest.useRealTimers());

  test('does not retry on non-retryable gRPC code (e.g. 13 INTERNAL)', async () => {
    const { pushDataToBigData } = loadBigTableUtils();
    mockInsert = jest.fn().mockRejectedValue(Object.assign(new Error('internal error'), { code: 13 }));
    await expect(pushDataToBigData(REQ_BODY, 'data')).rejects.toThrow('internal error');
    expect(mockInsert).toHaveBeenCalledTimes(1);
  });

  test('does not retry on code 8 (RESOURCE_EXHAUSTED — intentionally excluded)', async () => {
    const { pushDataToBigData } = loadBigTableUtils();
    mockInsert = jest.fn().mockRejectedValue(Object.assign(new Error('quota exceeded'), { code: 8 }));
    await expect(pushDataToBigData(REQ_BODY, 'data')).rejects.toThrow('quota exceeded');
    expect(mockInsert).toHaveBeenCalledTimes(1);
  });

  test('retries on DEADLINE_EXCEEDED (code 4) and succeeds on second attempt', async () => {
    const { pushDataToBigData } = loadBigTableUtils();
    const err = Object.assign(new Error('deadline exceeded'), { code: 4 });
    mockInsert = jest.fn()
      .mockRejectedValueOnce(err)
      .mockResolvedValueOnce([]);

    const promise = pushDataToBigData(REQ_BODY, 'data');
    await jest.advanceTimersByTimeAsync(2000);
    await promise;

    expect(mockInsert).toHaveBeenCalledTimes(2);
  });

  test('retries on UNAVAILABLE (code 14) and succeeds on second attempt', async () => {
    const { pushDataToBigData } = loadBigTableUtils();
    const err = Object.assign(new Error('unavailable'), { code: 14 });
    mockInsert = jest.fn()
      .mockRejectedValueOnce(err)
      .mockResolvedValueOnce([]);

    const promise = pushDataToBigData(REQ_BODY, 'data');
    await jest.advanceTimersByTimeAsync(2000);
    await promise;

    expect(mockInsert).toHaveBeenCalledTimes(2);
  });

  test('throws after exhausting 2 retries (3 total attempts)', async () => {
    const { pushDataToBigData } = loadBigTableUtils();
    mockInsert = jest.fn().mockRejectedValue(Object.assign(new Error('always fails'), { code: 4 }));

    const promise = pushDataToBigData(REQ_BODY, 'data');
    // Attach the rejection handler BEFORE advancing timers so Node.js never
    // sees an unhandled rejection between advanceTimersByTimeAsync and the assert.
    const assertion = expect(promise).rejects.toThrow('always fails');
    await jest.advanceTimersByTimeAsync(5000); // covers both retry delays (max 899ms each)
    await assertion;

    expect(mockInsert).toHaveBeenCalledTimes(3); // initial + 2 retries
  });
});
