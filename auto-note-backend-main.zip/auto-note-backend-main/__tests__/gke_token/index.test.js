var mockFetchGKETokenHelper;

jest.mock('../../gke_token/fetch-gke-token', () => ({
  fetchGKETokenHelper: (...args) => mockFetchGKETokenHelper(...args),
}));

const request = require('supertest');
const express = require('express');
const router  = require('../../gke_token/index');

function buildApp() {
  const app = express();
  app.use(express.json());
  app.use('/', router);
  return app;
}

const TOKEN_DATA = { access_token: 'ya29.TOKEN', expires_in: 3599, token_type: 'Bearer' };

beforeEach(() => {
  jest.clearAllMocks();
  mockFetchGKETokenHelper = jest.fn().mockResolvedValue(TOKEN_DATA);
});

describe('GET /', () => {
  test('returns 200 with token data on success', async () => {
    const res = await request(buildApp()).get('/');
    expect(res.status).toBe(200);
    expect(res.body).toEqual(TOKEN_DATA);
  });

  test('calls fetchGKETokenHelper once', async () => {
    await request(buildApp()).get('/');
    expect(mockFetchGKETokenHelper).toHaveBeenCalledTimes(1);
  });

  test('returns 400 with error message when fetchGKETokenHelper throws', async () => {
    mockFetchGKETokenHelper = jest.fn().mockRejectedValue(new Error('metadata unavailable'));
    const res = await request(buildApp()).get('/');
    expect(res.status).toBe(400);
    expect(res.body.error).toBe('metadata unavailable');
  });

  test('returns 400 with "Unknown error" when thrown error has no message', async () => {
    mockFetchGKETokenHelper = jest.fn().mockRejectedValue({});
    const res = await request(buildApp()).get('/');
    expect(res.status).toBe(400);
    expect(res.body.error).toBe('Unknown error');
  });
});
