// fetch-gke-token.js uses the global fetch (Node 18 built-in).
// We replace global.fetch per test via beforeEach/afterEach.
// console.error is suppressed because the source catch block logs before re-throwing —
// those logs are expected on error-path tests and would otherwise clutter test output.
jest.spyOn(console, 'error').mockImplementation(() => {});

const { fetchGKETokenHelper, expressTokenHandler } = require('../../gke_token/fetch-gke-token');

const METADATA_URL =
  'http://metadata.google.internal/computeMetadata/v1/instance/service-accounts/default/token';

const TOKEN_DATA = { access_token: 'ya29.TOKEN', expires_in: 3599, token_type: 'Bearer' };

function makeFetchOk(data) {
  return jest.fn().mockResolvedValue({
    ok: true,
    json: jest.fn().mockResolvedValue(data),
  });
}

beforeEach(() => {
  global.fetch = makeFetchOk(TOKEN_DATA);
});
afterEach(() => {
  delete global.fetch;
});

// ── fetchGKETokenHelper ───────────────────────────────────────────────────────
describe('fetchGKETokenHelper', () => {
  test('returns token data from the metadata server on success', async () => {
    const result = await fetchGKETokenHelper();
    expect(result).toEqual(TOKEN_DATA);
  });

  test('calls the correct GKE metadata URL', async () => {
    await fetchGKETokenHelper();
    expect(global.fetch).toHaveBeenCalledWith(METADATA_URL, expect.any(Object));
  });

  test('sends Metadata-Flavor: Google header', async () => {
    await fetchGKETokenHelper();
    const [, options] = global.fetch.mock.calls[0];
    expect(options.headers['Metadata-Flavor']).toBe('Google');
  });

  test('uses GET method', async () => {
    await fetchGKETokenHelper();
    const [, options] = global.fetch.mock.calls[0];
    expect(options.method).toBe('GET');
  });

  test('throws when metadata server returns a non-ok response', async () => {
    global.fetch = jest.fn().mockResolvedValue({
      ok: false,
      statusText: 'Forbidden',
    });
    await expect(fetchGKETokenHelper()).rejects.toThrow('Metadata server error: Forbidden');
  });

  test('throws when fetch itself rejects (network error)', async () => {
    global.fetch = jest.fn().mockRejectedValue(new Error('ECONNREFUSED'));
    await expect(fetchGKETokenHelper()).rejects.toThrow('ECONNREFUSED');
  });
});

// ── expressTokenHandler ───────────────────────────────────────────────────────
describe('expressTokenHandler', () => {
  function makeRes() {
    const res = { status: jest.fn(), json: jest.fn() };
    res.status.mockReturnValue(res); // enable chaining: res.status(200).json(...)
    return res;
  }

  test('responds 200 with token data on success', async () => {
    const res = makeRes();
    await expressTokenHandler({}, res);
    expect(res.status).toHaveBeenCalledWith(200);
    expect(res.json).toHaveBeenCalledWith(TOKEN_DATA);
  });

  test('responds 400 with error message when fetchGKETokenHelper throws', async () => {
    global.fetch = jest.fn().mockRejectedValue(new Error('metadata down'));
    const res = makeRes();
    await expressTokenHandler({}, res);
    expect(res.status).toHaveBeenCalledWith(400);
    expect(res.json).toHaveBeenCalledWith({ error: 'metadata down' });
  });
});
