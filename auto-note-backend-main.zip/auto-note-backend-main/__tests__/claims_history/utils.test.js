// var-hoisted so the jest.mock factory delegate closure picks up per-test reassignments.
// _bq is a module-level singleton created at load time; no jest.resetModules() needed —
// the delegate reads mockQuery at call time, not at module-load time.
var mockQuery;

jest.mock('../../logger', () => ({
  info: jest.fn(), error: jest.fn(), warn: jest.fn(), debug: jest.fn(),
}));
jest.mock('../../parameters/parameterConfig', () => ({
  COMPUTE_PROJECT_ID: 'test-project',
  CLAIMS_DENORM_TABLE: 'test-project.ds.claims_denorm',
  MBR_EPH_LINKS_TABLE: 'test-project.ds.mbr_eph_links',
}));
jest.mock('@google-cloud/bigquery', () => ({
  BigQuery: jest.fn().mockImplementation(() => ({
    query: (...args) => mockQuery(...args),
  })),
}));

const logger = require('../../logger');
const { getNfCheckedGpi12s, getQualifyingClaimForGpi } = require('../../claims_history/utils');

beforeEach(() => {
  jest.clearAllMocks();
  mockQuery = jest.fn().mockResolvedValue([[]]); // default: BQ returns zero rows
});

// ── getNfCheckedGpi12s ────────────────────────────────────────────────────────
describe('getNfCheckedGpi12s', () => {
  const MEMBER  = 'MBR001';
  const PAIRS   = [{ gpi12: '123456789012', partialDrugName: 'ASPIRIN' }];
  const RCV_DT  = '2026-01-15';

  // ── Early-return guards ──────────────────────────────────────────────────────
  test('returns empty Set when memberId is falsy', async () => {
    const result = await getNfCheckedGpi12s(null, PAIRS, RCV_DT);
    expect(result).toEqual(new Set());
    expect(mockQuery).not.toHaveBeenCalled();
  });

  test('returns empty Set when gpi12Pairs is not an array', async () => {
    const result = await getNfCheckedGpi12s(MEMBER, 'not-an-array', RCV_DT);
    expect(result).toEqual(new Set());
    expect(mockQuery).not.toHaveBeenCalled();
  });

  test('returns empty Set when gpi12Pairs is empty', async () => {
    const result = await getNfCheckedGpi12s(MEMBER, [], RCV_DT);
    expect(result).toEqual(new Set());
    expect(mockQuery).not.toHaveBeenCalled();
  });

  test('returns empty Set and warns when receivedDate is falsy', async () => {
    const result = await getNfCheckedGpi12s(MEMBER, PAIRS, null);
    expect(result).toEqual(new Set());
    expect(logger.warn).toHaveBeenCalledWith(expect.stringContaining('receivedDate is null'));
    expect(mockQuery).not.toHaveBeenCalled();
  });

  test('returns empty Set and warns when receivedDate year cannot be parsed', async () => {
    const result = await getNfCheckedGpi12s(MEMBER, PAIRS, 'not-a-date');
    expect(result).toEqual(new Set());
    expect(logger.warn).toHaveBeenCalledWith(expect.stringContaining('receivedDate is invalid'));
    expect(mockQuery).not.toHaveBeenCalled();
  });

  // ── Happy path ───────────────────────────────────────────────────────────────
  test('returns empty Set when BQ returns no rows', async () => {
    const result = await getNfCheckedGpi12s(MEMBER, PAIRS, RCV_DT);
    expect(result).toEqual(new Set());
  });

  test('returns Set of gpi_cd_12 values from matching BQ rows', async () => {
    mockQuery = jest.fn().mockResolvedValue([[
      { gpi_cd_12: '123456789012', matched_partial_name: 'ASPIRIN' },
      { gpi_cd_12: '987654321098', matched_partial_name: 'IBUPROFEN' },
    ]]);
    const result = await getNfCheckedGpi12s(MEMBER, PAIRS, RCV_DT);
    expect(result).toEqual(new Set(['123456789012', '987654321098']));
  });

  test('filters out null or falsy gpi_cd_12 values', async () => {
    mockQuery = jest.fn().mockResolvedValue([[
      { gpi_cd_12: '123456789012' },
      { gpi_cd_12: null },
      { gpi_cd_12: undefined },
    ]]);
    const result = await getNfCheckedGpi12s(MEMBER, PAIRS, RCV_DT);
    expect(result).toEqual(new Set(['123456789012']));
  });

  test('computes claimsWindowStart as 2 years before receivedDate year', async () => {
    await getNfCheckedGpi12s(MEMBER, PAIRS, '2026-09-18');
    const callParams = mockQuery.mock.calls[0][0].params;
    expect(callParams.claimsWindowStart).toBe('2024-01-01');
    expect(callParams.receivedDate).toBe('2026-09-18');
  });

  test('passes memberId, gpi12List, partialNameList to BQ query params', async () => {
    const pairs = [
      { gpi12: '111111111111', partialDrugName: 'DRUG A' },
      { gpi12: '222222222222', partialDrugName: 'DRUG B' },
    ];
    await getNfCheckedGpi12s(MEMBER, pairs, RCV_DT);
    const callParams = mockQuery.mock.calls[0][0].params;
    expect(callParams.memberId).toBe(MEMBER);
    expect(callParams.gpi12List).toEqual(['111111111111', '222222222222']);
    expect(callParams.partialNameList).toEqual(['DRUG A', 'DRUG B']);
  });

  test('logs info with checked count and found count on success', async () => {
    mockQuery = jest.fn().mockResolvedValue([[
      { gpi_cd_12: '123456789012' },
    ]]);
    await getNfCheckedGpi12s(MEMBER, PAIRS, RCV_DT);
    expect(logger.info).toHaveBeenCalledWith(expect.stringContaining('checked=1 found=1'));
  });

  // ── Error handling ───────────────────────────────────────────────────────────
  test('returns empty Set (does not throw) when BQ throws', async () => {
    mockQuery = jest.fn().mockRejectedValue(new Error('BQ unavailable'));
    const result = await getNfCheckedGpi12s(MEMBER, PAIRS, RCV_DT);
    expect(result).toEqual(new Set());
  });

  test('logs error when BQ throws', async () => {
    mockQuery = jest.fn().mockRejectedValue(new Error('BQ unavailable'));
    await getNfCheckedGpi12s(MEMBER, PAIRS, RCV_DT);
    expect(logger.error).toHaveBeenCalledWith(expect.stringContaining('getNfCheckedGpi12s failed'));
  });
});

// ── getQualifyingClaimForGpi ──────────────────────────────────────────────────
describe('getQualifyingClaimForGpi', () => {
  const MEMBER  = 'MBR001';
  const GPI     = '12345678901234';
  const RCV_DT  = '2026-01-15';

  const BQ_ROW = {
    max_mdd:   '500',
    disp_qty:  '30',
    days_sply: '30',
    fill_dt:   '2025-06-01',
  };

  // ── Early-return guards ──────────────────────────────────────────────────────
  test('returns null when memberId is falsy', async () => {
    expect(await getQualifyingClaimForGpi(null, GPI, RCV_DT)).toBeNull();
    expect(mockQuery).not.toHaveBeenCalled();
  });

  test('returns null when gpi is falsy', async () => {
    expect(await getQualifyingClaimForGpi(MEMBER, '', RCV_DT)).toBeNull();
    expect(mockQuery).not.toHaveBeenCalled();
  });

  test('returns null and warns when receivedDate is falsy', async () => {
    expect(await getQualifyingClaimForGpi(MEMBER, GPI, null)).toBeNull();
    expect(logger.warn).toHaveBeenCalledWith(expect.stringContaining('receivedDate is null'));
    expect(mockQuery).not.toHaveBeenCalled();
  });

  test('returns null and warns when receivedDate year cannot be parsed', async () => {
    expect(await getQualifyingClaimForGpi(MEMBER, GPI, 'bad-date')).toBeNull();
    expect(logger.warn).toHaveBeenCalledWith(expect.stringContaining('receivedDate is invalid'));
    expect(mockQuery).not.toHaveBeenCalled();
  });

  // ── Happy path ───────────────────────────────────────────────────────────────
  test('returns null when BQ returns no rows', async () => {
    expect(await getQualifyingClaimForGpi(MEMBER, GPI, RCV_DT)).toBeNull();
  });

  test('returns null when max_mdd is null', async () => {
    mockQuery = jest.fn().mockResolvedValue([[{ ...BQ_ROW, max_mdd: null }]]);
    expect(await getQualifyingClaimForGpi(MEMBER, GPI, RCV_DT)).toBeNull();
  });

  test('returns null when max_mdd is not a valid number', async () => {
    mockQuery = jest.fn().mockResolvedValue([[{ ...BQ_ROW, max_mdd: 'NaN' }]]);
    expect(await getQualifyingClaimForGpi(MEMBER, GPI, RCV_DT)).toBeNull();
  });

  test('returns correct object with numeric fields when BQ returns a qualifying row', async () => {
    mockQuery = jest.fn().mockResolvedValue([[BQ_ROW]]);
    const result = await getQualifyingClaimForGpi(MEMBER, GPI, RCV_DT);
    expect(result).toEqual({
      maxMdd:   500,
      dispQty:  30,
      daysSply: 30,
      fillDt:   '2025-06-01',
    });
  });

  test('extracts fillDt from BigQuery Date .value property', async () => {
    mockQuery = jest.fn().mockResolvedValue([[{ ...BQ_ROW, fill_dt: { value: '2025-03-15' } }]]);
    const result = await getQualifyingClaimForGpi(MEMBER, GPI, RCV_DT);
    expect(result.fillDt).toBe('2025-03-15');
  });

  test('falls back to raw fill_dt when no .value property', async () => {
    mockQuery = jest.fn().mockResolvedValue([[{ ...BQ_ROW, fill_dt: '2025-03-15' }]]);
    const result = await getQualifyingClaimForGpi(MEMBER, GPI, RCV_DT);
    expect(result.fillDt).toBe('2025-03-15');
  });

  test('sets fillDt to null when fill_dt is null', async () => {
    mockQuery = jest.fn().mockResolvedValue([[{ ...BQ_ROW, fill_dt: null }]]);
    const result = await getQualifyingClaimForGpi(MEMBER, GPI, RCV_DT);
    expect(result.fillDt).toBeNull();
  });

  test('sets dispQty and daysSply to null when their fields are null', async () => {
    mockQuery = jest.fn().mockResolvedValue([[{ ...BQ_ROW, disp_qty: null, days_sply: null }]]);
    const result = await getQualifyingClaimForGpi(MEMBER, GPI, RCV_DT);
    expect(result.dispQty).toBeNull();
    expect(result.daysSply).toBeNull();
  });

  test('computes claimsWindowStart as 2 years before receivedDate year', async () => {
    mockQuery = jest.fn().mockResolvedValue([[BQ_ROW]]);
    await getQualifyingClaimForGpi(MEMBER, GPI, '2026-09-18');
    const callParams = mockQuery.mock.calls[0][0].params;
    expect(callParams.claimsWindowStart).toBe('2024-01-01');
  });

  test('passes memberId and gpi to BQ query params', async () => {
    mockQuery = jest.fn().mockResolvedValue([[BQ_ROW]]);
    await getQualifyingClaimForGpi(MEMBER, GPI, RCV_DT);
    const callParams = mockQuery.mock.calls[0][0].params;
    expect(callParams.memberId).toBe(MEMBER);
    expect(callParams.gpi).toBe(GPI);
  });

  test('logs info with maxMdd and date window on success', async () => {
    mockQuery = jest.fn().mockResolvedValue([[BQ_ROW]]);
    await getQualifyingClaimForGpi(MEMBER, GPI, RCV_DT);
    expect(logger.info).toHaveBeenCalledWith(expect.stringContaining('maxMdd=500'));
  });

  // ── Error handling ───────────────────────────────────────────────────────────
  test('returns null (does not throw) when BQ throws', async () => {
    mockQuery = jest.fn().mockRejectedValue(new Error('BQ down'));
    expect(await getQualifyingClaimForGpi(MEMBER, GPI, RCV_DT)).toBeNull();
  });

  test('logs error when BQ throws', async () => {
    mockQuery = jest.fn().mockRejectedValue(new Error('BQ down'));
    await getQualifyingClaimForGpi(MEMBER, GPI, RCV_DT);
    expect(logger.error).toHaveBeenCalledWith(expect.stringContaining('getQualifyingClaimForGpi failed'));
  });
});
