// Pure functions — no mocks needed.
const { createUniqueDictionary } = require('../../helpers/dict_helper');

describe('createUniqueDictionary', () => {
  test('builds an object from key-value entries', () => {
    const result = createUniqueDictionary([['name', 'Alice'], ['age', '30']]);
    expect(result).toEqual({ name: 'Alice', age: '30' });
  });

  test('returns empty object for empty entries array', () => {
    expect(createUniqueDictionary([])).toEqual({});
  });

  test('coerces non-string values to empty string', () => {
    const result = createUniqueDictionary([
      ['num', 42],
      ['bool', true],
      ['nil', null],
      ['obj', { a: 1 }],
    ]);
    expect(result.num).toBe('');
    expect(result.bool).toBe('');
    expect(result.nil).toBe('');
    expect(result.obj).toBe('');
  });

  test('preserves string values unchanged', () => {
    const result = createUniqueDictionary([['key', 'hello world']]);
    expect(result.key).toBe('hello world');
  });

  test('renames first duplicate to key_1', () => {
    const result = createUniqueDictionary([['drug', 'ASPIRIN'], ['drug', 'IBUPROFEN']]);
    expect(result.drug).toBe('ASPIRIN');
    expect(result.drug_1).toBe('IBUPROFEN');
  });

  test('renames second duplicate to key_2', () => {
    const result = createUniqueDictionary([
      ['drug', 'A'],
      ['drug', 'B'],
      ['drug', 'C'],
    ]);
    expect(result.drug).toBe('A');
    expect(result.drug_1).toBe('B');
    expect(result.drug_2).toBe('C');
  });

  test('blocks __proto__ key (prototype pollution guard)', () => {
    const result = createUniqueDictionary([['__proto__', 'evil'], ['safe', 'ok']]);
    expect(Object.keys(result)).not.toContain('__proto__');
    expect(result.safe).toBe('ok');
  });

  test('blocks constructor key', () => {
    const result = createUniqueDictionary([['constructor', 'evil'], ['key', 'val']]);
    expect(Object.keys(result)).not.toContain('constructor');
  });

  test('blocks prototype key', () => {
    const result = createUniqueDictionary([['prototype', 'evil'], ['key', 'val']]);
    expect(Object.keys(result)).not.toContain('prototype');
  });

  test('handles mixed safe and unsafe keys in same input', () => {
    const result = createUniqueDictionary([
      ['__proto__', 'bad'],
      ['name', 'Alice'],
      ['constructor', 'bad'],
      ['age', '25'],
    ]);
    expect(result).toEqual({ name: 'Alice', age: '25' });
  });
});
