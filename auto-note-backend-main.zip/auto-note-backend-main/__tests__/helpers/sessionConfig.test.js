const { createExpressSessionConfig } = require('../../helpers/sessionConfig');

describe('createExpressSessionConfig', () => {
  const savedSecret  = process.env.EXPRESS_SESSION_SECRET;
  const savedEnvName = process.env.ENV_NAME;

  afterEach(() => {
    // Restore env vars and clean up the side-effect key
    if (savedSecret === undefined) delete process.env.EXPRESS_SESSION_SECRET;
    else process.env.EXPRESS_SESSION_SECRET = savedSecret;

    if (savedEnvName === undefined) delete process.env.ENV_NAME;
    else process.env.ENV_NAME = savedEnvName;

    delete process.env.EXPRESS_SESSION_PARAMS;
  });

  test('writes EXPRESS_SESSION_PARAMS as a valid JSON string', () => {
    createExpressSessionConfig();
    expect(process.env.EXPRESS_SESSION_PARAMS).toBeDefined();
    expect(() => JSON.parse(process.env.EXPRESS_SESSION_PARAMS)).not.toThrow();
  });

  test('uses EXPRESS_SESSION_SECRET from env as the session key', () => {
    process.env.EXPRESS_SESSION_SECRET = 'my-strong-secret';
    createExpressSessionConfig();
    const config = JSON.parse(process.env.EXPRESS_SESSION_PARAMS);
    expect(config.keys).toContain('my-strong-secret');
  });

  test('falls back to placeholder secret when EXPRESS_SESSION_SECRET is not set', () => {
    delete process.env.EXPRESS_SESSION_SECRET;
    createExpressSessionConfig();
    const config = JSON.parse(process.env.EXPRESS_SESSION_PARAMS);
    expect(config.keys[0]).toBe('Enter_the_Express_Session_Secret_Here');
  });

  test('sets httpOnly:true regardless of environment', () => {
    createExpressSessionConfig();
    const config = JSON.parse(process.env.EXPRESS_SESSION_PARAMS);
    expect(config.httpOnly).toBe(true);
  });

  test('sets secure:true and sameSite:"none" for prod environment (cross-site)', () => {
    process.env.ENV_NAME = 'prod';
    createExpressSessionConfig();
    const config = JSON.parse(process.env.EXPRESS_SESSION_PARAMS);
    expect(config.secure).toBe(true);
    expect(config.sameSite).toBe('none');
  });

  test('sets secure:true and sameSite:"none" for qa environment (cross-site)', () => {
    process.env.ENV_NAME = 'paops-pqa';
    createExpressSessionConfig();
    const config = JSON.parse(process.env.EXPRESS_SESSION_PARAMS);
    expect(config.secure).toBe(true);
    expect(config.sameSite).toBe('none');
  });

  test('sets secure:false and sameSite:"lax" for local environment', () => {
    process.env.ENV_NAME = 'local';
    createExpressSessionConfig();
    const config = JSON.parse(process.env.EXPRESS_SESSION_PARAMS);
    expect(config.secure).toBe(false);
    expect(config.sameSite).toBe('lax');
  });

  test('sets secure:false and sameSite:"lax" when ENV_NAME is not set', () => {
    delete process.env.ENV_NAME;
    createExpressSessionConfig();
    const config = JSON.parse(process.env.EXPRESS_SESSION_PARAMS);
    expect(config.secure).toBe(false);
    expect(config.sameSite).toBe('lax');
  });

  test('sets maxAge to 1 hour in milliseconds', () => {
    createExpressSessionConfig();
    const config = JSON.parse(process.env.EXPRESS_SESSION_PARAMS);
    expect(config.maxAge).toBe(60 * 60 * 1000);
  });

  test('sets session name to "session"', () => {
    createExpressSessionConfig();
    const config = JSON.parse(process.env.EXPRESS_SESSION_PARAMS);
    expect(config.name).toBe('session');
  });
});
