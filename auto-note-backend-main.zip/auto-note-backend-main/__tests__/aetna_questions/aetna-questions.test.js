jest.mock('../../logger', () => ({ info: jest.fn(), error: jest.fn(), warn: jest.fn(), debug: jest.fn() }));

// Mock utils — no BQ calls, no network
jest.mock('../../aetna_questions/utils', () => ({
  fetchAetnaQuestions: jest.fn(),
  reloadReferenceData: jest.fn(),
}));

const request = require('supertest');
const express = require('express');
const { fetchAetnaQuestions, reloadReferenceData } = require('../../aetna_questions/utils');
const router = require('../../aetna_questions/aetna-questions');

// Minimal Express app — just the router under test
function buildApp() {
  const app = express();
  app.use(express.json());
  app.use('/', router);
  return app;
}

beforeEach(() => {
  jest.clearAllMocks();
});

// ── POST /fetch ───────────────────────────────────────────────────────────────
describe('POST /fetch', () => {
  test('returns 200 with questions array on GPI match', async () => {
    const questions = [{ index: 0, question: 'Can the patient take each drug component separately?' }];
    fetchAetnaQuestions.mockResolvedValue(questions);

    const res = await request(buildApp())
      .post('/fetch')
      .send({ gpi: '66109902320340', ndc: '' });

    expect(res.status).toBe(200);
    expect(res.body.status).toBe('success');
    expect(res.body.data.questions).toEqual(questions);
    expect(fetchAetnaQuestions).toHaveBeenCalledWith('66109902320340', '');
  });

  test('returns 200 with questions array on NDC match', async () => {
    const questions = [{ index: 0, question: 'Has the patient experienced an intolerance?' }];
    fetchAetnaQuestions.mockResolvedValue(questions);

    const res = await request(buildApp())
      .post('/fetch')
      .send({ gpi: '', ndc: '71085008130' });

    expect(res.status).toBe(200);
    expect(res.body.data.questions).toEqual(questions);
    expect(fetchAetnaQuestions).toHaveBeenCalledWith('', '71085008130');
  });

  test('returns 200 with empty array when no questions match', async () => {
    fetchAetnaQuestions.mockResolvedValue([]);

    const res = await request(buildApp())
      .post('/fetch')
      .send({ gpi: '99999999999999', ndc: '' });

    expect(res.status).toBe(200);
    expect(res.body.data.questions).toEqual([]);
  });

  test('returns 400 when both gpi and ndc are missing', async () => {
    const res = await request(buildApp())
      .post('/fetch')
      .send({});

    expect(res.status).toBe(400);
    expect(res.body.status).toBe('error');
    expect(fetchAetnaQuestions).not.toHaveBeenCalled();
  });

  test('returns 400 when gpi is empty string and ndc is missing', async () => {
    const res = await request(buildApp())
      .post('/fetch')
      .send({ gpi: '' });

    expect(res.status).toBe(400);
    expect(res.body.status).toBe('error');
    expect(fetchAetnaQuestions).not.toHaveBeenCalled();
  });

  test('returns 500 when fetchAetnaQuestions throws (server-side failure)', async () => {
    fetchAetnaQuestions.mockRejectedValue(new Error('BQ unavailable'));

    const res = await request(buildApp())
      .post('/fetch')
      .send({ gpi: '66109902320340', ndc: '' });

    expect(res.status).toBe(500);
    expect(res.body.status).toBe('error');
    expect(res.body.message).toContain('Failed to fetch');
    expect(res.body.details).toBe('BQ unavailable');
  });

  test('passes gpi as empty string when only ndc is supplied', async () => {
    fetchAetnaQuestions.mockResolvedValue([]);

    await request(buildApp())
      .post('/fetch')
      .send({ ndc: '71085008130' });

    expect(fetchAetnaQuestions).toHaveBeenCalledWith('', '71085008130');
  });

  test('passes ndc as empty string when only gpi is supplied', async () => {
    fetchAetnaQuestions.mockResolvedValue([]);

    await request(buildApp())
      .post('/fetch')
      .send({ gpi: '66109902320340' });

    expect(fetchAetnaQuestions).toHaveBeenCalledWith('66109902320340', '');
  });
});

// ── POST /reload ──────────────────────────────────────────────────────────────
describe('POST /reload', () => {
  test('returns 200 on successful cache reload', async () => {
    reloadReferenceData.mockResolvedValue();

    const res = await request(buildApp()).post('/reload');

    expect(res.status).toBe(200);
    expect(res.body.status).toBe('success');
    expect(reloadReferenceData).toHaveBeenCalledTimes(1);
  });

  test('returns 500 when reloadReferenceData throws (server-side failure)', async () => {
    reloadReferenceData.mockRejectedValue(new Error('BQ connection failed'));

    const res = await request(buildApp()).post('/reload');

    expect(res.status).toBe(500);
    expect(res.body.status).toBe('error');
    expect(res.body.details).toBe('BQ connection failed');
  });
});
