jest.mock('../../logger', () => ({ info: jest.fn(), error: jest.fn(), warn: jest.fn(), debug: jest.fn() }));

jest.mock('../../parameters/parameterConfig', () => ({
  COMPUTE_PROJECT_ID: 'test-compute-project',
  AETNA_QUESTIONS_BQ_TABLE: 'test.aetna_questions',
}));

var mockQuery;
jest.mock('@google-cloud/bigquery', () => ({
  BigQuery: jest.fn().mockImplementation(() => ({
    query: (...args) => mockQuery(...args),
  })),
}));

// BQ rows loaded by _runLoad(): simulates the reference table content
const GPI_ROW = { Type: 'GPI', Id: '75100090100140', Question: 'Has the patient experienced an intolerance, caused by an inactive ingredient, to other formulary products with the same active ingredient?' };
const NDC_ROW_SAME_Q = { Type: 'NDC', Id: '71085008230', Question: GPI_ROW.Question };        // same question as GPI_ROW
const NDC_ROW_DIFF_Q = { Type: 'NDC', Id: '71085008230', Question: 'Is a different question?' }; // different question
const GPI_ROW_2 = { Type: 'GPI', Id: '66109902320340', Question: 'Can the patient take each drug component separately?' };

// loadModule() resets module-level state (refData, loadPromise) by re-requiring after resetModules.
// mockQuery must be configured BEFORE the first fetchAetnaQuestions call triggers _runLoad().
function loadModule(rows) {
  jest.resetModules();
  mockQuery = jest.fn().mockResolvedValue([rows]);
  return require('../../aetna_questions/utils');
}

// ── fetchAetnaQuestions ───────────────────────────────────────────────────────
describe('fetchAetnaQuestions', () => {
  test('returns matching GPI question when only gpi is supplied', async () => {
    const { fetchAetnaQuestions } = loadModule([GPI_ROW, NDC_ROW_SAME_Q]);

    const result = await fetchAetnaQuestions('75100090100140', '');

    expect(result).toHaveLength(1);
    expect(result[0].question).toBe(GPI_ROW.Question);
    expect(result[0].index).toBe(0);
  });

  test('returns matching NDC question when only ndc is supplied', async () => {
    const { fetchAetnaQuestions } = loadModule([GPI_ROW, NDC_ROW_SAME_Q]);

    const result = await fetchAetnaQuestions('', '71085008230');

    expect(result).toHaveLength(1);
    expect(result[0].question).toBe(NDC_ROW_SAME_Q.Question);
  });

  test('deduplicates when GPI and NDC rows share the same question text', async () => {
    const { fetchAetnaQuestions } = loadModule([GPI_ROW, NDC_ROW_SAME_Q]);

    const result = await fetchAetnaQuestions('75100090100140', '71085008230');

    expect(result).toHaveLength(1);
    expect(result[0].question).toBe(GPI_ROW.Question);
  });

  test('returns both questions when GPI and NDC rows have different question text', async () => {
    const { fetchAetnaQuestions } = loadModule([GPI_ROW, NDC_ROW_DIFF_Q]);

    const result = await fetchAetnaQuestions('75100090100140', '71085008230');

    expect(result).toHaveLength(2);
    expect(result[0].question).toBe(GPI_ROW.Question);
    expect(result[1].question).toBe(NDC_ROW_DIFF_Q.Question);
    expect(result[0].index).toBe(0);
    expect(result[1].index).toBe(1);
  });

  test('returns empty array when neither gpi nor ndc matches any row', async () => {
    const { fetchAetnaQuestions } = loadModule([GPI_ROW, NDC_ROW_SAME_Q]);

    const result = await fetchAetnaQuestions('99999999999999', '00000000000');

    expect(result).toEqual([]);
  });

  test('does not match GPI rows when gpi is empty string', async () => {
    const { fetchAetnaQuestions } = loadModule([GPI_ROW, NDC_ROW_SAME_Q]);

    const result = await fetchAetnaQuestions('', '71085008230');

    expect(result).toHaveLength(1);
    expect(result[0].question).toBe(NDC_ROW_SAME_Q.Question);
  });

  test('does not match NDC rows when ndc is empty string', async () => {
    const { fetchAetnaQuestions } = loadModule([GPI_ROW, NDC_ROW_SAME_Q]);

    const result = await fetchAetnaQuestions('75100090100140', '');

    expect(result).toHaveLength(1);
    expect(result[0].question).toBe(GPI_ROW.Question);
  });

  test('returns multiple distinct GPI questions when multiple GPI rows match', async () => {
    const GPI_ROW_SAME_ID_2 = { Type: 'GPI', Id: '75100090100140', Question: 'Second question for same GPI?' };
    const { fetchAetnaQuestions } = loadModule([GPI_ROW, GPI_ROW_SAME_ID_2]);

    const result = await fetchAetnaQuestions('75100090100140', '');

    expect(result).toHaveLength(2);
  });

  test('throws when BigQuery query rejects', async () => {
    jest.resetModules();
    mockQuery = jest.fn().mockRejectedValue(new Error('BQ unavailable'));
    const { fetchAetnaQuestions } = require('../../aetna_questions/utils');

    await expect(fetchAetnaQuestions('75100090100140', '')).rejects.toThrow('BQ unavailable');
  });
});

// ── cache behaviour ───────────────────────────────────────────────────────────
describe('loadReferenceData cache', () => {
  test('second call uses cached data without re-querying BQ', async () => {
    const { fetchAetnaQuestions } = loadModule([GPI_ROW]);

    await fetchAetnaQuestions('75100090100140', '');
    mockQuery = jest.fn().mockRejectedValue(new Error('should not call BQ again'));
    await fetchAetnaQuestions('75100090100140', '');

    expect(mockQuery).not.toHaveBeenCalled();
  });
});

// ── reloadReferenceData ───────────────────────────────────────────────────────
describe('reloadReferenceData', () => {
  test('forces a fresh BQ load and returns updated data', async () => {
    const { fetchAetnaQuestions, reloadReferenceData } = loadModule([GPI_ROW]);

    // Warm the cache
    await fetchAetnaQuestions('75100090100140', '');

    // Swap BQ to return different rows
    mockQuery = jest.fn().mockResolvedValue([[GPI_ROW_2]]);
    await reloadReferenceData();

    const result = await fetchAetnaQuestions('66109902320340', '');
    expect(result).toHaveLength(1);
    expect(result[0].question).toBe(GPI_ROW_2.Question);
  });
});
