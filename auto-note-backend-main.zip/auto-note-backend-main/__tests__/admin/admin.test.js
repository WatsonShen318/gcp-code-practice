jest.mock('../../logger', () => ({
  info: jest.fn(), error: jest.fn(), warn: jest.fn(), debug: jest.fn(),
}));
jest.mock('../../form_alts/utils', () => ({
  reloadReferenceData: jest.fn(),
}));
jest.mock('../../cdrd/gpi-override-level', () => ({
  reloadQ7Data: jest.fn(),
}));
jest.mock('../../aetna_questions/utils', () => ({
  reloadReferenceData: jest.fn(),
}));

const request   = require('supertest');
const express   = require('express');
const { reloadReferenceData: reloadFormAlts } = require('../../form_alts/utils');
const { reloadQ7Data }                         = require('../../cdrd/gpi-override-level');
const { reloadReferenceData: reloadAetna }     = require('../../aetna_questions/utils');
const router = require('../../admin/admin');

function buildApp() {
  const app = express();
  app.use(express.json());
  app.use('/', router);
  return app;
}

beforeEach(() => {
  jest.clearAllMocks();
  reloadFormAlts.mockResolvedValue();
  reloadQ7Data.mockResolvedValue();
  reloadAetna.mockResolvedValue();
});

// ── POST /reload-all ──────────────────────────────────────────────────────────
describe('POST /reload-all', () => {
  test('returns 200 with status:success when all caches reload successfully', async () => {
    const res = await request(buildApp()).post('/reload-all');

    expect(res.status).toBe(200);
    expect(res.body.status).toBe('success');
  });

  test('calls all three reload functions', async () => {
    await request(buildApp()).post('/reload-all');

    expect(reloadFormAlts).toHaveBeenCalledTimes(1);
    expect(reloadQ7Data).toHaveBeenCalledTimes(1);
    expect(reloadAetna).toHaveBeenCalledTimes(1);
  });

  test('response caches array has one entry per cache with name, status:ok, and durationMs', async () => {
    const res = await request(buildApp()).post('/reload-all');

    const caches = res.body.data.caches;
    expect(caches).toHaveLength(3);
    expect(caches[0]).toMatchObject({ name: 'form_alts',       status: 'ok', durationMs: expect.any(Number) });
    expect(caches[1]).toMatchObject({ name: 'cdrd_q7',         status: 'ok', durationMs: expect.any(Number) });
    expect(caches[2]).toMatchObject({ name: 'aetna_questions', status: 'ok', durationMs: expect.any(Number) });
  });

  test('response includes totalMs as a number', async () => {
    const res = await request(buildApp()).post('/reload-all');
    expect(res.body.data.totalMs).toEqual(expect.any(Number));
  });

  test('returns 207 with status:partial when one cache fails', async () => {
    reloadFormAlts.mockRejectedValue(new Error('form_alts BQ down'));

    const res = await request(buildApp()).post('/reload-all');

    expect(res.status).toBe(207);
    expect(res.body.status).toBe('partial');
  });

  test('failed cache entry has status:error and error message; successful entries still have status:ok', async () => {
    reloadFormAlts.mockRejectedValue(new Error('form_alts BQ down'));

    const res = await request(buildApp()).post('/reload-all');
    const caches = res.body.data.caches;

    expect(caches[0]).toMatchObject({ name: 'form_alts', status: 'error', error: 'form_alts BQ down' });
    expect(caches[1]).toMatchObject({ name: 'cdrd_q7',   status: 'ok' });
    expect(caches[2]).toMatchObject({ name: 'aetna_questions', status: 'ok' });
  });

  test('returns 207 when all three caches fail', async () => {
    reloadFormAlts.mockRejectedValue(new Error('err1'));
    reloadQ7Data.mockRejectedValue(new Error('err2'));
    reloadAetna.mockRejectedValue(new Error('err3'));

    const res = await request(buildApp()).post('/reload-all');

    expect(res.status).toBe(207);
    expect(res.body.status).toBe('partial');
    expect(res.body.data.caches.every(c => c.status === 'error')).toBe(true);
  });

  test('still reloads remaining caches when one fails (Promise.allSettled — no short-circuit)', async () => {
    reloadFormAlts.mockRejectedValue(new Error('err'));

    await request(buildApp()).post('/reload-all');

    // Other two must still have been called despite form_alts failing
    expect(reloadQ7Data).toHaveBeenCalledTimes(1);
    expect(reloadAetna).toHaveBeenCalledTimes(1);
  });
});

// ── POST /reload-form-alts ────────────────────────────────────────────────────
describe('POST /reload-form-alts', () => {
  test('returns 200 with status:success on successful reload', async () => {
    const res = await request(buildApp()).post('/reload-form-alts');

    expect(res.status).toBe(200);
    expect(res.body.status).toBe('success');
    expect(res.body.data.message).toMatch(/FormAlts/);
    expect(res.body.data.durationMs).toEqual(expect.any(Number));
  });

  test('calls reloadReferenceData from form_alts/utils', async () => {
    await request(buildApp()).post('/reload-form-alts');
    expect(reloadFormAlts).toHaveBeenCalledTimes(1);
  });

  test('returns 400 with status:error when reload throws', async () => {
    reloadFormAlts.mockRejectedValue(new Error('BQ unavailable'));

    const res = await request(buildApp()).post('/reload-form-alts');

    expect(res.status).toBe(400);
    expect(res.body.status).toBe('error');
    expect(res.body.message).toContain('Failed to reload FormAlts');
  });
});

// ── POST /reload-q7 ───────────────────────────────────────────────────────────
describe('POST /reload-q7', () => {
  test('returns 200 with status:success on successful reload', async () => {
    const res = await request(buildApp()).post('/reload-q7');

    expect(res.status).toBe(200);
    expect(res.body.status).toBe('success');
    expect(res.body.data.message).toMatch(/Q7/);
    expect(res.body.data.durationMs).toEqual(expect.any(Number));
  });

  test('calls reloadQ7Data from cdrd/gpi-override-level', async () => {
    await request(buildApp()).post('/reload-q7');
    expect(reloadQ7Data).toHaveBeenCalledTimes(1);
  });

  test('returns 400 with status:error when reload throws', async () => {
    reloadQ7Data.mockRejectedValue(new Error('BQ unavailable'));

    const res = await request(buildApp()).post('/reload-q7');

    expect(res.status).toBe(400);
    expect(res.body.status).toBe('error');
    expect(res.body.message).toContain('Failed to reload Q7');
  });
});
