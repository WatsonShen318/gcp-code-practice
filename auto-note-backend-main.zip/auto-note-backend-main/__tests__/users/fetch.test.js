var mockAxiosGet;

jest.mock('axios', () => ({
  get: (...args) => mockAxiosGet(...args),
}));
jest.mock('../../logger', () => ({
  info: jest.fn(), error: jest.fn(), warn: jest.fn(),
}));

const logger = require('../../logger');
const fetch  = require('../../users/fetch');

beforeEach(() => {
  jest.clearAllMocks();
  mockAxiosGet = jest.fn().mockResolvedValue({ data: { displayName: 'Test User' } });
});

describe('fetch', () => {
  const ENDPOINT = 'https://graph.microsoft.com/v1.0/me';
  const TOKEN    = 'access-token-abc';

  test('returns response.data on success', async () => {
    const result = await fetch(ENDPOINT, TOKEN);
    expect(result).toEqual({ displayName: 'Test User' });
  });

  test('sends Bearer token in Authorization header', async () => {
    await fetch(ENDPOINT, TOKEN);
    const [, options] = mockAxiosGet.mock.calls[0];
    expect(options.headers.Authorization).toBe(`Bearer ${TOKEN}`);
  });

  test('calls the correct endpoint URL', async () => {
    await fetch(ENDPOINT, TOKEN);
    expect(mockAxiosGet).toHaveBeenCalledWith(ENDPOINT, expect.any(Object));
  });

  test('logs the request with endpoint and timestamp', async () => {
    await fetch(ENDPOINT, TOKEN);
    expect(logger.info).toHaveBeenCalledWith(expect.stringContaining(ENDPOINT));
  });

  test('throws an Error when axios.get rejects', async () => {
    mockAxiosGet = jest.fn().mockRejectedValue(new Error('network failure'));
    await expect(fetch(ENDPOINT, TOKEN)).rejects.toThrow('network failure');
  });

  test('logs the error when axios.get rejects', async () => {
    const err = new Error('network failure');
    mockAxiosGet = jest.fn().mockRejectedValue(err);
    await fetch(ENDPOINT, TOKEN).catch(() => {});
    expect(logger.error).toHaveBeenCalledWith(err);
  });
});
