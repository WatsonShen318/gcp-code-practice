var mockFetch;

jest.mock('../../users/fetch', () => (...args) => mockFetch(...args));
jest.mock('../../parameters/parameterConfig', () => ({
  GRAPH_ME_ENDPOINT: 'https://graph.microsoft.com/v1.0/me',
}));
jest.mock('../../logger', () => ({
  info: jest.fn(), error: jest.fn(), warn: jest.fn(),
}));

const request = require('supertest');
const express = require('express');
const router  = require('../../users/users');

// Injects a fake req.session so the isAuthenticated middleware can be exercised
function buildApp(sessionData = {}) {
  const app = express();
  app.use(express.json());
  app.use((req, res, next) => { req.session = sessionData; next(); });
  app.use('/', router);
  return app;
}

beforeEach(() => {
  jest.clearAllMocks();
  mockFetch = jest.fn().mockResolvedValue({ displayName: 'Test User', mail: 'test@example.com' });
});

// ── GET /details ──────────────────────────────────────────────────────────────
describe('GET /details', () => {
  test('returns 200 with a text body', async () => {
    const res = await request(buildApp()).get('/details');
    expect(res.status).toBe(200);
    expect(res.text).toContain('Session value set');
  });
});

// ── POST /profile ─────────────────────────────────────────────────────────────
describe('POST /profile', () => {
  test('redirects to /auth/signin when session is not authenticated', async () => {
    const res = await request(buildApp({ isAuthenticated: false })).post('/profile');
    expect(res.status).toBe(302);
    expect(res.headers.location).toBe('/auth/signin');
  });

  test('redirects when session has no isAuthenticated property', async () => {
    const res = await request(buildApp({})).post('/profile');
    expect(res.status).toBe(302);
  });

  test('returns 200 with graph response when authenticated', async () => {
    const res = await request(buildApp({ isAuthenticated: true, accessToken: 'tok123' }))
      .post('/profile');
    expect(res.status).toBe(200);
    expect(res.body).toEqual({ displayName: 'Test User', mail: 'test@example.com' });
  });

  test('calls fetch with GRAPH_ME_ENDPOINT and session accessToken', async () => {
    await request(buildApp({ isAuthenticated: true, accessToken: 'tok123' }))
      .post('/profile');
    expect(mockFetch).toHaveBeenCalledWith(
      'https://graph.microsoft.com/v1.0/me',
      'tok123'
    );
  });

  test('calls next(error) when fetch throws', async () => {
    mockFetch = jest.fn().mockRejectedValue(new Error('graph API down'));
    const res = await request(buildApp({ isAuthenticated: true, accessToken: 'tok' }))
      .post('/profile');
    // Express default error handler returns 500
    expect(res.status).toBe(500);
  });
});
