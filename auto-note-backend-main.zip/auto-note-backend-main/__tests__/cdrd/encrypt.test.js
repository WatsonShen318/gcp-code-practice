var mockGetIdTokenClient;
var mockAxiosPost;

jest.mock('google-auth-library', () => ({
  GoogleAuth: jest.fn().mockImplementation(() => ({
    getIdTokenClient: (...args) => mockGetIdTokenClient(...args),
  })),
}));
jest.mock('axios', () => ({
  post: (...args) => mockAxiosPost(...args),
}));
jest.mock('../../logger', () => ({ info: jest.fn(), error: jest.fn() }));

const logger = require('../../logger');
const { formatEncryptedValue, encryptDecryptData } = require('../../cdrd/encrypt');

// Helper: builds the axios response shape the function expects
function makeAxiosResponse(replyValue) {
  return { data: [{ replies: [replyValue] }] };
}

// Helper: wires getIdTokenClient to return a mock client with a given token
function mockIdentityToken(token) {
  mockGetIdTokenClient = jest.fn().mockResolvedValue({
    getRequestHeaders: jest.fn().mockResolvedValue({ Authorization: `Bearer ${token}` }),
  });
}

beforeEach(() => {
  jest.clearAllMocks();
  mockIdentityToken('test-id-token');
  mockAxiosPost = jest.fn().mockResolvedValue(makeAxiosResponse('ENCRYPTED_VALUE'));
});

describe('formatEncryptedValue', () => {
  test('escapes backslashes', () => {
    expect(formatEncryptedValue('hello\\world')).toBe('hello\\\\world');
  });

  test('escapes single quotes', () => {
    expect(formatEncryptedValue("it's a test")).toBe("it\\'s a test");
  });

  test('escapes double quotes', () => {
    expect(formatEncryptedValue('"quoted"')).toBe('\\"quoted\\"');
  });

  test('handles empty string', () => {
    expect(formatEncryptedValue('')).toBe('');
  });

  test('returns undefined for undefined input', () => {
    expect(formatEncryptedValue(undefined)).toBeUndefined();
  });

  test('leaves plain strings unchanged', () => {
    expect(formatEncryptedValue('plaintext')).toBe('plaintext');
  });
});

// ── encryptDecryptData ────────────────────────────────────────────────────────
describe('encryptDecryptData', () => {
  const DATA     = [['GA1234567']];
  const ALIAS    = 'us7ascii2';
  const PA_NBR   = 'PA001';
  const MODE     = 'encrypt';
  const PROJECT  = 'test-project';

  test('returns the first reply value on success', async () => {
    const result = await encryptDecryptData(DATA, ALIAS, PA_NBR, MODE, PROJECT);
    expect(result).toBe('ENCRYPTED_VALUE');
  });

  test('calls axios.post with the correct cloud function URL', async () => {
    await encryptDecryptData(DATA, ALIAS, PA_NBR, MODE, PROJECT);
    const [url] = mockAxiosPost.mock.calls[0];
    expect(url).toBe(`https://us-east4-${PROJECT}.cloudfunctions.net/paops_encrypt-decrypt-pss`);
  });

  test('calls axios.post with correct payload fields', async () => {
    await encryptDecryptData(DATA, ALIAS, PA_NBR, MODE, PROJECT);
    const [, payload] = mockAxiosPost.mock.calls[0];
    expect(payload).toEqual({
      data_to_encrypt: DATA,
      alias: ALIAS,
      prior_athzn_nbr: PA_NBR,
      mode: MODE,
    });
  });

  test('sends Bearer token in Authorization header', async () => {
    await encryptDecryptData(DATA, ALIAS, PA_NBR, MODE, PROJECT);
    const [, , { headers }] = mockAxiosPost.mock.calls[0];
    expect(headers['Authorization']).toBe('Bearer test-id-token');
  });

  test('returns undefined and logs error when axios.post throws', async () => {
    mockAxiosPost = jest.fn().mockRejectedValue(new Error('network error'));
    const result = await encryptDecryptData(DATA, ALIAS, PA_NBR, MODE, PROJECT);
    expect(result).toBeUndefined();
    expect(logger.error).toHaveBeenCalledWith(expect.stringContaining('Error while encrypting'));
  });

  test('returns undefined when replies array is empty', async () => {
    mockAxiosPost = jest.fn().mockResolvedValue({ data: [{ replies: [] }] });
    const result = await encryptDecryptData(DATA, ALIAS, PA_NBR, MODE, PROJECT);
    expect(result).toBeUndefined();
  });

  test('returns undefined and logs error when identity token fetch fails', async () => {
    mockGetIdTokenClient = jest.fn().mockRejectedValue(new Error('auth failed'));
    const result = await encryptDecryptData(DATA, ALIAS, PA_NBR, MODE, PROJECT);
    expect(result).toBeUndefined();
    expect(logger.error).toHaveBeenCalledWith(expect.stringContaining('Error getting identity token'));
  });

  test('returns undefined and logs when identity token is falsy', async () => {
    mockGetIdTokenClient = jest.fn().mockResolvedValue({
      getRequestHeaders: jest.fn().mockResolvedValue({ Authorization: 'Bearer ' }),
    });
    // token = '' (empty string after split) — falsy
    const result = await encryptDecryptData(DATA, ALIAS, PA_NBR, MODE, PROJECT);
    expect(result).toBeUndefined();
    expect(mockAxiosPost).not.toHaveBeenCalled();
    expect(logger.error).toHaveBeenCalledWith('Failed to fetch ID token, no request made');
  });
});
