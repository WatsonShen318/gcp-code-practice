// Tests for cdrd/bigquery.js Express router.
// All helper/Q7/BQ dependencies are mocked so this file focuses on HTTP contract.
var mockBqQuery;

jest.mock('@google-cloud/bigquery', () => ({
  BigQuery: jest.fn().mockImplementation(() => ({
    query: (...args) => mockBqQuery(...args),
  })),
}));
jest.mock('../../parameters/parameterConfig', () => ({
  isDeployedEnv: jest.fn().mockReturnValue(false),
  PROJECT_ID: 'test-project',
  COMPUTE_PROJECT_ID: 'test-compute-project',
  BQ_INSTANCE_ID: 'test-instance',
  BQ_CASE_HISTORY_TABLE_ID: 'test-table',
  BQ_CASE_HISTORY_TABLE: 'test-project.test-instance.test-table',
}));
jest.mock('../../cdrd/helper', () => ({
  calculateLookBackTimeStamp: jest.fn().mockReturnValue('2025-01-01T00:00:00Z'),
  formatBQResult: jest.fn().mockReturnValue([]),
  findoutCDRDGridAnswers: jest.fn().mockReturnValue({ Q1: 'No', requestType: 'CD' }),
}));
jest.mock('../../cdrd/gpi-override-level', () => ({
  determineQ7GpiOverrideLevel: jest.fn().mockResolvedValue(false),
}));
jest.mock('../../logger', () => ({
  info: jest.fn(), error: jest.fn(), warn: jest.fn(), debug: jest.fn(),
}));

const request  = require('supertest');
const express  = require('express');
const { formatBQResult, findoutCDRDGridAnswers } = require('../../cdrd/helper');
const { determineQ7GpiOverrideLevel } = require('../../cdrd/gpi-override-level');
const router = require('../../cdrd/bigquery');

function buildApp() {
  const app = express();
  app.use(express.json());
  app.use('/', router);
  return app;
}

const VALID_BODY = {
  memberAccountId: 'GA2527380',
  memberEligibilityTermDate: '9999-12-31T23:59:59Z',
  requestReason: 'Prior Authorization',
  client: 'Aetna',
  companyLob: 'LOB001',
  companyAccounts: 'ACCT001',
  companyAccountGroup: 'GRP001',
  gpiCode: '12345678901234',
  receivedDate: new Date().toISOString(),
  caseId: 'CASE001',
};

beforeEach(() => {
  jest.clearAllMocks();
  mockBqQuery = jest.fn().mockResolvedValue([[]]); // BQ returns no history rows
});

// ── POST / ────────────────────────────────────────────────────────────────────
describe('POST /', () => {
  test('returns 404 when memberAccountId is missing', async () => {
    const { memberAccountId: _omit, ...body } = VALID_BODY;
    const res = await request(buildApp()).post('/').send(body);
    expect(res.status).toBe(404);
    expect(res.body.message).toMatch(/memberAccountId/);
  });

  test('returns 200 with success message and expected shape on valid request', async () => {
    const res = await request(buildApp()).post('/').send(VALID_BODY);
    expect(res.status).toBe(200);
    expect(res.body.message).toBe('success');
    expect(res.body).toHaveProperty('cdrdGridAnswers');
    expect(res.body).toHaveProperty('lookBackTimestamp');
    expect(res.body).toHaveProperty('memberAccountId', VALID_BODY.memberAccountId);
    expect(res.body).toHaveProperty('formattedHistoryRecords');
  });

  test('passes memberAccountId and company fields to BigQuery query as positional params', async () => {
    await request(buildApp()).post('/').send(VALID_BODY);
    expect(mockBqQuery).toHaveBeenCalledTimes(1);
    const callArgs = mockBqQuery.mock.calls[0][0];
    expect(callArgs.params).toEqual([
      VALID_BODY.memberAccountId,
      VALID_BODY.companyLob,
      VALID_BODY.companyAccounts,
      VALID_BODY.companyAccountGroup,
    ]);
  });

  test('passes BQ result rows through formatBQResult', async () => {
    const rawRows = [{ case_typ_desc: 'CD', case_crte_ts: { value: '2024-01-01Z' }, case_dcsn_ts: { value: '2024-01-01Z' } }];
    mockBqQuery = jest.fn().mockResolvedValue([rawRows]);
    await request(buildApp()).post('/').send(VALID_BODY);
    expect(formatBQResult).toHaveBeenCalledWith(rawRows);
  });

  test('calls determineQ7GpiOverrideLevel with carrier/account/group/gpi', async () => {
    await request(buildApp()).post('/').send(VALID_BODY);
    expect(determineQ7GpiOverrideLevel).toHaveBeenCalledWith(expect.objectContaining({
      carrier: VALID_BODY.companyLob,
      account: VALID_BODY.companyAccounts,
      group:   VALID_BODY.companyAccountGroup,
      gpi:     VALID_BODY.gpiCode,
    }));
  });

  test('calls findoutCDRDGridAnswers with formatted records, caseDetails, and Q7 result', async () => {
    determineQ7GpiOverrideLevel.mockResolvedValue(true);
    await request(buildApp()).post('/').send(VALID_BODY);
    expect(findoutCDRDGridAnswers).toHaveBeenCalledWith(
      expect.any(Array),    // formattedHistoryRecords
      expect.objectContaining({ memberEligibilityTermDate: VALID_BODY.memberEligibilityTermDate }),
      '2025-01-01T00:00:00Z',
      true                  // isQ7Override
    );
  });

  test('returns 400 when BigQuery query throws', async () => {
    mockBqQuery = jest.fn().mockRejectedValue(new Error('BQ connection failed'));
    const res = await request(buildApp()).post('/').send(VALID_BODY);
    expect(res.status).toBe(400);
    expect(res.body.message).toBe('failure');
  });
});
