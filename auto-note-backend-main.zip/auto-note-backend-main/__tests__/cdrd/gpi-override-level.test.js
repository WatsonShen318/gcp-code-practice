// var-hoisted so the jest.mock factory delegate closure picks up per-test reassignments.
// gpi-override-level.js has module-level q7Data/loadPromise — jest.resetModules() in
// loadModule() gives each test a clean slate.
var mockQuery;

jest.mock('@google-cloud/bigquery', () => ({
  BigQuery: jest.fn().mockImplementation(() => ({
    query: (...args) => mockQuery(...args),
  })),
}));
jest.mock('../../parameters/parameterConfig', () => ({
  isDeployedEnv: jest.fn().mockReturnValue(false),
  PROJECT_ID: 'test-project',
  COMPUTE_PROJECT_ID: 'test-compute-project',
  GPI_OVERRIDE_LEVEL_CAG_TABLE: 'test.cag',
  GPI_OVERRIDE_LEVEL_DRUG_TABLE: 'test.drug',
  GPI_OVERRIDE_LEVEL_OVERRIDE_TABLE: 'test.override',
  GPI_OVERRIDE_LEVEL_HIERARCHY_TABLE: 'test.hierarchy',
}));
jest.mock('../../logger', () => ({
  info: jest.fn(), error: jest.fn(), warn: jest.fn(), debug: jest.fn(),
}));

// ── Shared BQ fixture data ────────────────────────────────────────────────────
const PAST   = '2020-01-01';
const FUTURE = '9999-12-31';

const CAG_ROW = {
  CagClusterName: 'cag-cluster-1',
  CagClusterType: 'Specific',
  EffectiveDate: PAST,
  ThruDate: FUTURE,
  Carrier: 'CARRIER001',
  Account: 'ACCOUNT001',
  Group: 'GROUP001',
};

const DRUG_ROW_GPI = {
  DrugClusterName: 'drug-cluster-gpi',
  DrugClusterType: 'GPI-14',
  EffectiveDate: PAST,
  ThruDate: FUTURE,
  DrugIdentifier: '12345678901234',
};

const DRUG_ROW_NDC = {
  DrugClusterName: 'drug-cluster-ndc',
  DrugClusterType: 'NDC-11',
  EffectiveDate: PAST,
  ThruDate: FUTURE,
  DrugIdentifier: '12345678901',
};

const OVERRIDE_ROW_8 = {
  CagCluster: 'cag-cluster-1',
  DrugCluster: 'drug-cluster-gpi',
  EffectiveDate: PAST,
  ThruDate: FUTURE,
  OverrideType: 'Prior Authorization',
  GpiOf: 8,
};

const HIERARCHY_ROWS = [
  { ClusterColumnName: 'CagClusterType',  ClusterType: 'Specific', HierarchyLevel: '1' },
  { ClusterColumnName: 'DrugClusterType', ClusterType: 'GPI-14',   HierarchyLevel: '1' },
  { ClusterColumnName: 'DrugClusterType', ClusterType: 'NDC-11',   HierarchyLevel: '2' },
];

// Standard params that produce a full match with the fixtures above
const MATCH_PARAMS = {
  carrier: 'CARRIER001',
  account: 'ACCOUNT001',
  group: 'GROUP001',
  ndc: '',
  gpi: '12345678901234',
  requestReason: 'Prior Authorization',
  caseId: 'CASE001',
};

// Loads a fresh module (resets q7Data / loadPromise) and wires the default
// 4-query BQ sequence.  Always call this first in each test.
function loadModule(cagRows, drugRows, overrideRows, hierarchyRows) {
  jest.resetModules();
  const mod = require('../../cdrd/gpi-override-level');
  mockQuery = jest.fn()
    .mockResolvedValueOnce([cagRows   ?? [CAG_ROW]])
    .mockResolvedValueOnce([drugRows  ?? [DRUG_ROW_GPI]])
    .mockResolvedValueOnce([overrideRows ?? [OVERRIDE_ROW_8]])
    .mockResolvedValueOnce([hierarchyRows ?? HIERARCHY_ROWS]);
  return mod;
}

// ── determineQ7GpiOverrideLevel ───────────────────────────────────────────────
describe('determineQ7GpiOverrideLevel', () => {
  test('returns true when GpiOf is 8', async () => {
    const { determineQ7GpiOverrideLevel } = loadModule();
    const result = await determineQ7GpiOverrideLevel(MATCH_PARAMS);
    expect(result).toBe(true);
  });

  test('returns true when GpiOf is 10', async () => {
    const { determineQ7GpiOverrideLevel } = loadModule(
      [CAG_ROW],
      [DRUG_ROW_GPI],
      [{ ...OVERRIDE_ROW_8, GpiOf: 10 }],
      HIERARCHY_ROWS
    );
    const result = await determineQ7GpiOverrideLevel(MATCH_PARAMS);
    expect(result).toBe(true);
  });

  test('returns false when GpiOf is not 8 or 10', async () => {
    const { determineQ7GpiOverrideLevel } = loadModule(
      [CAG_ROW],
      [DRUG_ROW_GPI],
      [{ ...OVERRIDE_ROW_8, GpiOf: 6 }],
      HIERARCHY_ROWS
    );
    const result = await determineQ7GpiOverrideLevel(MATCH_PARAMS);
    expect(result).toBe(false);
  });

  test('returns false when no CAG row matches the carrier/account/group', async () => {
    const { determineQ7GpiOverrideLevel } = loadModule(
      [{ ...CAG_ROW, Carrier: 'OTHER_CARRIER' }]
    );
    const result = await determineQ7GpiOverrideLevel(MATCH_PARAMS);
    expect(result).toBe(false);
  });

  test('returns false when no Drug row matches the GPI', async () => {
    const { determineQ7GpiOverrideLevel } = loadModule(
      [CAG_ROW],
      [{ ...DRUG_ROW_GPI, DrugIdentifier: '99999999999999' }]
    );
    const result = await determineQ7GpiOverrideLevel(MATCH_PARAMS);
    expect(result).toBe(false);
  });

  test('returns false when no Override row matches the requestReason', async () => {
    const { determineQ7GpiOverrideLevel } = loadModule(
      [CAG_ROW],
      [DRUG_ROW_GPI],
      [{ ...OVERRIDE_ROW_8, OverrideType: 'Non-Formulary' }]
    );
    const result = await determineQ7GpiOverrideLevel(MATCH_PARAMS);
    expect(result).toBe(false);
  });

  test('returns false (does not throw) when BQ query fails', async () => {
    jest.resetModules();
    const mod = require('../../cdrd/gpi-override-level');
    mockQuery = jest.fn().mockRejectedValue(new Error('BQ unavailable'));
    const result = await mod.determineQ7GpiOverrideLevel(MATCH_PARAMS);
    expect(result).toBe(false);
  });

  test('CAG wildcard (*All) matches any carrier/account/group value', async () => {
    const wildcardCag = { ...CAG_ROW, Carrier: '*All', Account: '*All', Group: '*All' };
    const { determineQ7GpiOverrideLevel } = loadModule([wildcardCag]);
    const result = await determineQ7GpiOverrideLevel({
      ...MATCH_PARAMS,
      carrier: 'ANY_CARRIER',
      account: 'ANY_ACCOUNT',
      group: 'ANY_GROUP',
    });
    expect(result).toBe(true);
  });

  test('NDC-11 drug type is matched against the ndc param, not gpi', async () => {
    const ndcOverride = { ...OVERRIDE_ROW_8, DrugCluster: 'drug-cluster-ndc' };
    const { determineQ7GpiOverrideLevel } = loadModule(
      [CAG_ROW],
      [DRUG_ROW_NDC],
      [ndcOverride]
    );
    // gpi doesn't match NDC-11 type; ndc does
    const result = await determineQ7GpiOverrideLevel({
      ...MATCH_PARAMS,
      gpi: 'NOMATCH',
      ndc: '12345678901',
    });
    expect(result).toBe(true);
  });

  test('expired row (ThruDate in past) is not matched', async () => {
    const expiredCag = { ...CAG_ROW, ThruDate: '2020-06-01' }; // past date
    const { determineQ7GpiOverrideLevel } = loadModule([expiredCag]);
    const result = await determineQ7GpiOverrideLevel(MATCH_PARAMS);
    expect(result).toBe(false);
  });

  test('picks most specific override rule when multiple match (lowest CAG+Drug hierarchy level sum)', async () => {
    // Two CAG clusters; one is more specific (level 1), one is less (level 99 = unknown type)
    const cag1 = { ...CAG_ROW, CagClusterName: 'cag-specific', CagClusterType: 'Specific' };
    const cag2 = { ...CAG_ROW, CagClusterName: 'cag-broad',    CagClusterType: 'Broad' };

    const override_specific = { ...OVERRIDE_ROW_8, CagCluster: 'cag-specific', GpiOf: 8  };
    const override_broad    = { ...OVERRIDE_ROW_8, CagCluster: 'cag-broad',    GpiOf: 6  };

    const { determineQ7GpiOverrideLevel } = loadModule(
      [cag1, cag2],
      [DRUG_ROW_GPI],
      [override_specific, override_broad]
    );
    // 'Specific' has HierarchyLevel 1, 'Broad' has no entry → level 99.
    // Most specific (sum=2) is override_specific → GpiOf=8 → true
    const result = await determineQ7GpiOverrideLevel(MATCH_PARAMS);
    expect(result).toBe(true);
  });

  test('parses MM/DD/YYYY EffectiveDate format as active when valid', async () => {
    const mmddCag = { ...CAG_ROW, EffectiveDate: '01/01/2020', ThruDate: '12/31/9999' };
    const { determineQ7GpiOverrideLevel } = loadModule([mmddCag]);
    const result = await determineQ7GpiOverrideLevel(MATCH_PARAMS);
    expect(result).toBe(true);
  });

  // ── Cache behaviour ──────────────────────────────────────────────────────────
  test('second call returns cached data without re-querying BQ', async () => {
    const { determineQ7GpiOverrideLevel } = loadModule();

    await determineQ7GpiOverrideLevel(MATCH_PARAMS);
    const callsAfterFirst = mockQuery.mock.calls.length; // should be 4

    // Replace mockQuery with a function that always fails — a cache bypass would error
    mockQuery = jest.fn().mockRejectedValue(new Error('should not call BQ again'));

    const result = await determineQ7GpiOverrideLevel(MATCH_PARAMS);
    expect(result).toBe(true);
    expect(mockQuery).not.toHaveBeenCalled(); // BQ not called again
    expect(callsAfterFirst).toBe(4); // confirm first load used 4 BQ queries
  });
});

// ── reloadQ7Data ──────────────────────────────────────────────────────────────
describe('reloadQ7Data', () => {
  test('forces a fresh BQ load even when data is already cached', async () => {
    const { determineQ7GpiOverrideLevel, reloadQ7Data } = loadModule();

    // Populate cache
    await determineQ7GpiOverrideLevel(MATCH_PARAMS);
    expect(mockQuery).toHaveBeenCalledTimes(4);

    // Wire second load
    mockQuery = jest.fn()
      .mockResolvedValueOnce([[CAG_ROW]])
      .mockResolvedValueOnce([[DRUG_ROW_GPI]])
      .mockResolvedValueOnce([[OVERRIDE_ROW_8]])
      .mockResolvedValueOnce([HIERARCHY_ROWS]);

    await reloadQ7Data();
    expect(mockQuery).toHaveBeenCalledTimes(4); // 4 new BQ queries for the reload
  });
});
