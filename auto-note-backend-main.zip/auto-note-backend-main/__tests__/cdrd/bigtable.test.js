// Tests for cdrd/bigtable.js Express router.
// Helper/Q7 are mocked; safeParseString runs real so row-parsing/filtering logic is exercised.
var mockGetRows;
var mockClose;

jest.mock('@google-cloud/bigtable', () => ({
  Bigtable: jest.fn().mockImplementation(() => ({
    instance: jest.fn().mockReturnValue({
      table: jest.fn().mockReturnValue({
        getRows: (...args) => mockGetRows(...args),
      }),
    }),
    close: (...args) => mockClose(...args),
  })),
}));
jest.mock('../../parameters/parameterConfig', () => ({
  PROJECT_ID: 'test-project',
  COMPUTE_PROJECT_ID: 'test-compute-project',
  BT_INSTANCE_ID: 'test-bt-instance',
  BT_CASE_HISTORY_TABLE_ID: 'test-bt-table',
}));
jest.mock('../../cdrd/helper', () => {
  // Run real safeParseString so the row-parsing/filtering logic in the router is exercised.
  const { safeParseString } = jest.requireActual('../../cdrd/helper');
  return {
    calculateLookBackTimeStamp: jest.fn().mockReturnValue('2025-01-01T00:00:00Z'),
    formatBTResult: jest.fn(records => records),
    findoutCDRDGridAnswers: jest.fn().mockReturnValue({ Q1: 'No', requestType: 'CD' }),
    safeParseString,
  };
});
jest.mock('../../cdrd/gpi-override-level', () => ({
  determineQ7GpiOverrideLevel: jest.fn().mockResolvedValue(false),
}));
jest.mock('../../logger', () => ({
  info: jest.fn(), error: jest.fn(), warn: jest.fn(), debug: jest.fn(),
}));

const request = require('supertest');
const express = require('express');
const router  = require('../../cdrd/bigtable');

function buildApp() {
  const app = express();
  app.use(express.json());
  app.use('/', router);
  return app;
}

const VALID_BODY = {
  memberAccountId:         'GA2527380',
  companyLob:              'LOB001',
  companyAccounts:         'ACCT001',
  companyAccountGroup:     'GRP001',
  memberEligibilityTermDate: '9999-12-31T23:59:59Z',
  requestReason:           'Prior Authorization',
  client:                  'Aetna',
  gpiCode:                 '12345678901234',
  receivedDate:            new Date().toISOString(),
  caseId:                  'CASE001',
};

// Builds a Bigtable row with the given JSON-serialisable fields as its autonote data.
function makeBtRow(fields = {}) {
  const defaults = {
    CASE_TYP_DESC:         'Coverage Determination',
    ORGNL_CASE_TYP_DESC:   'Coverage Determination',
    QSTNR_CASE_STUS_DESC:  'Denied',
    ORGNL_DCSN_NM:         'Denied',
    RQST_RSN_DESC:         'Prior Authorization',
    ORGNL_RQST_RSN_TXT:    'Prior Authorization',
    GPI_CD:                '12345678901234',
    CASE_CRTE_TS:          '2024-01-01T00:00:00Z',
    CASE_DCSN_TS:          '2024-01-01T00:00:00Z',
  };
  return {
    data: {
      autonote: {
        data: [{ value: JSON.stringify({ ...defaults, ...fields }) }],
      },
    },
  };
}

beforeEach(() => {
  jest.clearAllMocks();
  mockGetRows = jest.fn().mockResolvedValue([[]]); // no rows by default
  mockClose   = jest.fn().mockResolvedValue();
});

// ── POST / ────────────────────────────────────────────────────────────────────
describe('POST /', () => {
  test('returns 404 when memberAccountId is missing', async () => {
    const { memberAccountId: _omit, ...body } = VALID_BODY;
    const res = await request(buildApp()).post('/').send(body);
    expect(res.status).toBe(404);
    expect(res.body.message).toMatch(/required fields/);
  });

  test('returns 404 when companyLob is missing', async () => {
    const { companyLob: _omit, ...body } = VALID_BODY;
    const res = await request(buildApp()).post('/').send(body);
    expect(res.status).toBe(404);
  });

  test('returns 404 when companyAccounts is missing', async () => {
    const { companyAccounts: _omit, ...body } = VALID_BODY;
    const res = await request(buildApp()).post('/').send(body);
    expect(res.status).toBe(404);
  });

  test('returns 404 when companyAccountGroup is missing', async () => {
    const { companyAccountGroup: _omit, ...body } = VALID_BODY;
    const res = await request(buildApp()).post('/').send(body);
    expect(res.status).toBe(404);
  });

  test('returns 200 with success message and expected shape', async () => {
    mockGetRows = jest.fn().mockResolvedValue([[makeBtRow()]]);
    const res = await request(buildApp()).post('/').send(VALID_BODY);
    expect(res.status).toBe(200);
    expect(res.body.message).toBe('success');
    expect(res.body).toHaveProperty('cdrdGridAnswers');
    expect(res.body).toHaveProperty('memberAccountId', VALID_BODY.memberAccountId);
    expect(res.body).toHaveProperty('formattedHistoryRecords');
  });

  test('constructs row key prefix as LOB<sep>ACCT<sep>GRP<sep>MBR', async () => {
    await request(buildApp()).post('/').send(VALID_BODY);
    const callArgs = mockGetRows.mock.calls[0][0];
    expect(callArgs.prefix).toBe('LOB001<sep>ACCT001<sep>GRP001<sep>GA2527380');
  });

  test('rows with null/missing autonote data value are filtered out', async () => {
    const nullRow = { data: { autonote: { data: [{ value: null }] } } };
    mockGetRows = jest.fn().mockResolvedValue([[nullRow, makeBtRow()]]);
    const res = await request(buildApp()).post('/').send(VALID_BODY);
    expect(res.status).toBe(200);
    // Only the valid row survives filtering
    expect(res.body.formattedHistoryRecords).toHaveLength(1);
  });

  test('rows with CASE_DCSN_TS equal to "None" are filtered out', async () => {
    // "None" value is normalised to "" by the router's replace logic, then filtered
    const noneRow = makeBtRow({ CASE_DCSN_TS: 'None' });
    mockGetRows = jest.fn().mockResolvedValue([[noneRow, makeBtRow()]]);
    const res = await request(buildApp()).post('/').send(VALID_BODY);
    expect(res.body.formattedHistoryRecords).toHaveLength(1);
  });

  test('rows with empty string CASE_DCSN_TS are filtered out', async () => {
    const emptyRow = makeBtRow({ CASE_DCSN_TS: '' });
    mockGetRows = jest.fn().mockResolvedValue([[emptyRow, makeBtRow()]]);
    const res = await request(buildApp()).post('/').send(VALID_BODY);
    expect(res.body.formattedHistoryRecords).toHaveLength(1);
  });

  test('bigtable.close() is called on success', async () => {
    await request(buildApp()).post('/').send(VALID_BODY);
    expect(mockClose).toHaveBeenCalledTimes(1);
  });

  test('bigtable.close() is called even when getRows throws', async () => {
    mockGetRows = jest.fn().mockRejectedValue(new Error('BT unavailable'));
    await request(buildApp()).post('/').send(VALID_BODY);
    expect(mockClose).toHaveBeenCalledTimes(1);
  });

  test('returns 400 when getRows throws', async () => {
    mockGetRows = jest.fn().mockRejectedValue(new Error('BT unavailable'));
    const res = await request(buildApp()).post('/').send(VALID_BODY);
    expect(res.status).toBe(400);
    expect(res.body.message).toBe('failure');
  });
});
