jest.mock('../../logger', () => ({ info: jest.fn(), error: jest.fn(), warn: jest.fn() }));

const {
  safeParseString,
  formatTeradataResult,
  formatBTResult,
  calculateLookBackTimeStamp,
  formatBQResult,
  findoutCDRDGridAnswers,
} = require('../../cdrd/helper');

describe('safeParseString', () => {
  test('parses valid JSON string', () => {
    expect(safeParseString('{"key":"value"}', 'CASE001')).toEqual({ key: 'value' });
  });

  test('returns undefined for invalid JSON', () => {
    expect(safeParseString('{invalid json}', 'CASE001')).toBeUndefined();
  });

  test('returns empty object when JSON is null', () => {
    expect(safeParseString('null', 'CASE001')).toEqual({});
  });

  test('parses nested JSON', () => {
    expect(safeParseString('{"a":{"b":1}}', 'CASE001')).toEqual({ a: { b: 1 } });
  });
});

describe('formatTeradataResult', () => {
  const columns = ['case_typ_desc', 'qstnr_case_stus_desc', 'case_dcsn_ts'];

  test('maps array rows to named objects', () => {
    const rows = [['Coverage Determination', 'Denied', '2024-01-01T00:00:00Z']];
    const result = formatTeradataResult(rows, columns);
    expect(result[0].case_typ_desc).toBe('Coverage Determination');
    expect(result[0].qstnr_case_stus_desc).toBe('Denied');
  });

  test('sorts by case_dcsn_ts descending', () => {
    const rows = [
      ['Coverage Determination', 'Denied', '2024-01-01T00:00:00Z'],
      ['Redetermination', 'Denied', '2024-03-01T00:00:00Z'],
    ];
    const result = formatTeradataResult(rows, columns);
    expect(result[0].case_typ_desc).toBe('Redetermination');
  });

  test('returns empty array for empty input', () => {
    expect(formatTeradataResult([], columns)).toEqual([]);
  });
});

describe('formatBTResult', () => {
  test('converts case_dcsn_ts and case_crte_ts to ISO strings', () => {
    const records = [{
      case_typ_desc: 'CD',
      case_dcsn_ts: '2024-01-15T10:00:00Z',
      case_crte_ts: '2024-01-14T08:00:00Z',
    }];
    const result = formatBTResult(records);
    expect(result[0].case_dcsn_ts).toBe('2024-01-15T10:00:00.000Z');
    expect(result[0].case_crte_ts).toBe('2024-01-14T08:00:00.000Z');
  });
});

// ── calculateLookBackTimeStamp ────────────────────────────────────────────────
describe('calculateLookBackTimeStamp', () => {
  test('returns start-of-year timestamp when eligibility active + exception client + exception requestReason', () => {
    const result = calculateLookBackTimeStamp({
      memberEligibilityTermDate: '9999-12-31T23:59:59Z',
      requestReason: 'Non-Formulary',
      client: 'Aetna',
    });
    const currentYear = new Date().getFullYear();
    expect(result).toBe(`${currentYear}-01-01T00:00:00Z`);
  });

  test('returns 365-days-ago timestamp when eligibility active but requestReason not in exception list', () => {
    const result = calculateLookBackTimeStamp({
      memberEligibilityTermDate: '9999-12-31T23:59:59Z',
      requestReason: 'Prior Authorization',
      client: 'Aetna',
    });
    const currentYear = new Date().getFullYear();
    expect(result).toMatch(/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z$/);
    expect(result).not.toBe(`${currentYear}-01-01T00:00:00Z`);
  });

  test('returns start-of-year timestamp when eligibility term date is in the past', () => {
    const result = calculateLookBackTimeStamp({
      memberEligibilityTermDate: '2020-01-01T00:00:00Z',
      requestReason: 'Prior Authorization',
      client: 'Aetna',
    });
    const currentYear = new Date().getFullYear();
    expect(result).toBe(`${currentYear}-01-01T00:00:00Z`);
  });
});

// ── formatBQResult ────────────────────────────────────────────────────────────
describe('formatBQResult', () => {
  test('converts case_crte_ts.value and case_dcsn_ts.value BigQuery objects to ISO strings', () => {
    const records = [{
      case_typ_desc: 'Coverage Determination',
      case_crte_ts: { value: '2024-01-14T08:00:00Z' },
      case_dcsn_ts: { value: '2024-01-15T10:00:00Z' },
    }];
    const result = formatBQResult(records);
    expect(result[0].case_dcsn_ts).toBe('2024-01-15T10:00:00.000Z');
    expect(result[0].case_crte_ts).toBe('2024-01-14T08:00:00.000Z');
  });

  test('preserves all other fields on the record', () => {
    const records = [{
      case_typ_desc: 'Coverage Determination',
      qstnr_case_stus_desc: 'Denied',
      rqst_rsn_desc: 'Prior Authorization',
      gpi_cd: '12345678901234',
      case_crte_ts: { value: '2024-01-14T00:00:00Z' },
      case_dcsn_ts: { value: '2024-01-15T00:00:00Z' },
    }];
    const result = formatBQResult(records);
    expect(result[0].case_typ_desc).toBe('Coverage Determination');
    expect(result[0].gpi_cd).toBe('12345678901234');
  });

  test('sorts records by case_dcsn_ts descending', () => {
    const records = [
      { case_typ_desc: 'A', case_crte_ts: { value: '2024-01-01Z' }, case_dcsn_ts: { value: '2024-01-01T00:00:00Z' } },
      { case_typ_desc: 'B', case_crte_ts: { value: '2024-03-01Z' }, case_dcsn_ts: { value: '2024-03-01T00:00:00Z' } },
    ];
    const result = formatBQResult(records);
    expect(result[0].case_typ_desc).toBe('B');
    expect(result[1].case_typ_desc).toBe('A');
  });
});

// ── findoutCDRDGridAnswers ────────────────────────────────────────────────────
describe('findoutCDRDGridAnswers', () => {
  // far-past lookback so all recent records fall within lookback window
  const LOOKBACK = '2000-01-01T00:00:00Z';
  const CASE_DETAILS = {
    memberEligibilityTermDate: '9999-12-31T23:59:59Z',
    requestReason: 'Prior Authorization',
    client: 'Aetna',
    gpiCode: '12345678901234',
    receivedDate: new Date().toISOString(),
  };

  function daysAgoIso(n) {
    const d = new Date();
    d.setDate(d.getDate() - n);
    return d.toISOString();
  }

  // Base denied CD record within 65 days
  function denied(overrides = {}) {
    return {
      case_typ_desc: 'Coverage Determination',
      qstnr_case_stus_desc: 'Denied',
      rqst_rsn_desc: 'Prior Authorization',
      gpi_cd: '12345678901234',
      case_crte_ts: daysAgoIso(30),
      case_dcsn_ts: daysAgoIso(30),
      ...overrides,
    };
  }

  // Approved RD within 65 days — triggers Q8=Yes
  function approvedRD(overrides = {}) {
    return {
      case_typ_desc: 'Redetermination',
      qstnr_case_stus_desc: 'Approved',
      rqst_rsn_desc: 'Prior Authorization',
      gpi_cd: '12345678901234',
      case_crte_ts: daysAgoIso(10),
      case_dcsn_ts: daysAgoIso(10),
      ...overrides,
    };
  }

  test('Q1=No when there are no denied cases in the last 65 days', () => {
    const result = findoutCDRDGridAnswers([], CASE_DETAILS, LOOKBACK, false);
    expect(result.Q1).toBe('No');
    expect(result.Q1a).toBe('No');
    expect(result.requestType).toBe('CD');
  });

  test('Q1=No when denied case exists but is older than 65 days', () => {
    const oldRecord = denied({ case_dcsn_ts: daysAgoIso(90) });
    const result = findoutCDRDGridAnswers([oldRecord], CASE_DETAILS, LOOKBACK, false);
    expect(result.Q1).toBe('No');
  });

  test('Q1=Yes Q2=No when request reasons differ', () => {
    const record = denied({ rqst_rsn_desc: 'Non-Formulary' });
    const result = findoutCDRDGridAnswers([record], CASE_DETAILS, LOOKBACK, false);
    expect(result.Q1).toBe('Yes');
    expect(result.Q2).toBe('No');
    expect(result.requestType).toBe('CD');
  });

  test('Q1=Yes Q2=Yes Q3=No when GPI first 10 digits differ', () => {
    const record = denied({ gpi_cd: '99999999991234' }); // different first 10
    const result = findoutCDRDGridAnswers([record], CASE_DETAILS, LOOKBACK, false);
    expect(result.Q2).toBe('Yes');
    expect(result.Q3).toBe('No');
    expect(result.requestType).toBe('CD');
  });

  test('Q4=No Q6=Yes Q8=No Q9=No → requestType=RD', () => {
    const records = [denied()]; // same reason, same GPI-12
    const result = findoutCDRDGridAnswers(records, CASE_DETAILS, LOOKBACK, false);
    expect(result.Q3).toBe('Yes');
    expect(result.Q4).toBe('No');
    expect(result.Q6).toBe('Yes');
    expect(result.Q8).toBe('No');
    expect(result.Q9).toBe('No');
    expect(result.requestType).toBe('RD');
  });

  test('Q4=No Q6=Yes Q8=No Q9=Yes → requestType=RD (Possible 3rd Case)', () => {
    const deniedRD = denied({ case_typ_desc: 'Redetermination', case_dcsn_ts: daysAgoIso(30) });
    const result = findoutCDRDGridAnswers([deniedRD], CASE_DETAILS, LOOKBACK, false);
    expect(result.Q9).toBe('Yes');
    expect(result.requestType).toBe('RD (Possible 3rd Case)');
  });

  test('Q4=No Q6=Yes Q8=Yes → requestType=CD (approved redetermination exists)', () => {
    const records = [denied(), approvedRD()];
    const result = findoutCDRDGridAnswers(records, CASE_DETAILS, LOOKBACK, false);
    expect(result.Q8).toBe('Yes');
    expect(result.requestType).toBe('CD');
  });

  test('Q4=No Q6=No Q7=No → requestType=CD', () => {
    // GPI first 10 same but 12-digit differs → Q6=No
    const record = denied({ gpi_cd: '12345678901199' }); // substr(0,10)='1234567890' ✓, substr(0,12)='123456789011' ≠ '123456789012'
    const result = findoutCDRDGridAnswers([record], CASE_DETAILS, LOOKBACK, false);
    expect(result.Q6).toBe('No');
    expect(result.Q7).toBe('No');
    expect(result.requestType).toBe('CD');
  });

  test('Q4=No Q6=No Q7=Yes Q8=No Q9=No → requestType=RD', () => {
    const record = denied({ gpi_cd: '12345678901199' });
    const result = findoutCDRDGridAnswers([record], CASE_DETAILS, LOOKBACK, true);
    expect(result.Q7).toBe('Yes');
    expect(result.Q8).toBe('No');
    expect(result.Q9).toBe('No');
    expect(result.requestType).toBe('RD');
  });

  test('Q4=Yes Q5=No → requestType=CD (Quantity Limit, different 14-digit GPI)', () => {
    const qlDetails = { ...CASE_DETAILS, requestReason: 'Quantity Limit' };
    const record = denied({ rqst_rsn_desc: 'Quantity Limit', gpi_cd: '12345678901200' }); // last 2 digits differ
    const result = findoutCDRDGridAnswers([record], qlDetails, LOOKBACK, false);
    expect(result.Q4).toBe('Yes');
    expect(result.Q5).toBe('No');
    expect(result.requestType).toBe('CD');
  });

  test('Q4=Yes Q5=Yes Q6=Yes Q8=No Q9=No → requestType=RD', () => {
    const qlDetails = { ...CASE_DETAILS, requestReason: 'Quantity Limit' };
    const record = denied({ rqst_rsn_desc: 'Quantity Limit' }); // full 14-digit match
    const result = findoutCDRDGridAnswers([record], qlDetails, LOOKBACK, false);
    expect(result.Q5).toBe('Yes');
    expect(result.Q6).toBe('Yes');
    expect(result.Q8).toBe('No');
    expect(result.requestType).toBe('RD');
  });
});
