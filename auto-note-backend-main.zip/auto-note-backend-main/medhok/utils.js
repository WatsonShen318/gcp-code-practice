const axios = require("axios");
const qs = require("qs");
const logger = require("../logger");
const accessSecretVersion = require("../parameters/getSecretParameters");
const {
  isDeployedEnv,
  MEDHOK_TOKEN_URL,
  MEDHOK_CLIENT_ID,
  MEDHOK_CLIENT_SECRET,
  COMPUTE_PROJECT_ID,
  SECRET_MANAGER_SECRET_ID,
  ESL_ENV_NAME,
} = require("../parameters/parameterConfig");

// Expected terminal states from Medhok — logged at WARN, not ERROR.
// Examples:
//   "{application}100050 : Case is Decisioned"
//   "{application}100051 : Case is Completed"
function isCaseAlreadyDecisionedError(error) {
  const info = error?.response?.data?.moreInformation ?? "";
  return /\{application\}10005[01]\s*:/.test(info);
}

function getErrorLogContext(error) {
  return {
    errorCode: error?.code,
    upstreamStatus: error?.response?.status,
    upstreamStatusText: error?.response?.statusText,
    // Force the key to persist even when the body is empty, so an empty-body
    // upstream rejection is distinguishable from "not captured".
    upstreamResponseData: error?.response?.data ?? null,
    // Upstream often carries the rejection reason / correlation id in a header
    // even when the response body is empty.
    upstreamResponseHeaders: error?.response?.headers,
    errorStatus: error?.status,
    errorMessage: error?.message,
  };
}

// Transport / connection-level codes that indicate the request most likely
// never produced an HTTP response upstream.
const TRANSIENT_ERROR_CODES = new Set([
  "ECONNRESET",
  "ECONNABORTED", // axios timeout ("timeout of Nms exceeded")
  "ETIMEDOUT",
  "EAI_AGAIN",
  "ENOTFOUND",
  "EPIPE",
  "ERR_SOCKET_CONNECTION_TIMEOUT",
]);

/**
 * Transport-level failure: the request never received an HTTP response.
 * Safe to retry even for write calls — the request almost certainly never
 * landed upstream, so there is no duplicate-write risk.
 */
function isTransientTransportError(error) {
  if (error?.response) return false; // got an HTTP response -> not a transport blip
  return (
    TRANSIENT_ERROR_CODES.has(error?.code) ||
    /socket hang up|network socket disconnected|timeout/i.test(
      error?.message || ""
    )
  );
}

/**
 * Retryable for idempotent calls (reads / token generation): transport blips
 * plus upstream 5xx. NOT used for writes, where a 5xx may mean the write landed.
 */
function isRetryableError(error) {
  const status = error?.response?.status;
  return isTransientTransportError(error) || (status >= 500 && status <= 599);
}

/**
 * Runs `fn` and retries it on transient failures with exponential backoff.
 * Intermediate attempts are logged at WARN (not ERROR), so a call that
 * ultimately succeeds produces no ERROR-level noise. The caller is responsible
 * for logging the final failure once retries are exhausted.
 *
 * A `deadlineMs` wall-clock ceiling caps total time spent across attempts, so
 * retries stay within the caller's (and the frontend's) request budget. Once
 * the elapsed time reaches the deadline, no further retry is attempted even if
 * `retries` remain. This means fast-failing errors (e.g. ECONNRESET, <1s) get
 * retried, while slow timeouts that already consumed the budget do not.
 *
 * @param {(attempt: number) => Promise<any>} fn
 * @param {Object} [opts]
 * @param {number} [opts.retries=2]        Retries after the first attempt (total tries = retries + 1).
 * @param {number} [opts.baseDelayMs=200]  Base backoff; doubles each attempt (capped), plus small jitter.
 * @param {number} [opts.deadlineMs]       Optional wall-clock ceiling across all attempts.
 * @param {(error: any) => boolean} [opts.isRetryable=isRetryableError]
 * @param {string} [opts.label=""]         Label for retry log lines.
 */
async function withRetry(
  fn,
  {
    retries = 2,
    baseDelayMs = 200,
    deadlineMs,
    isRetryable = isRetryableError,
    label = "",
  } = {}
) {
  const start = Date.now();
  let attempt = 0;
  // eslint-disable-next-line no-constant-condition
  while (true) {
    try {
      return await fn(attempt);
    } catch (error) {
      const outOfTime = deadlineMs && Date.now() - start >= deadlineMs;
      if (attempt >= retries || outOfTime || !isRetryable(error)) {
        throw error;
      }
      const delay =
        Math.min(baseDelayMs * 2 ** attempt, 800) + Math.floor(Math.random() * 100);
      logger.warn(`[medhok] ${label} transient failure, retrying`, {
        attempt: attempt + 1,
        maxAttempts: retries + 1,
        delayMs: delay,
        ...getErrorLogContext(error),
      });
      await new Promise((resolve) => setTimeout(resolve, delay));
      attempt += 1;
    }
  }
}

function logApiSuccess(action, context) {
  logger.info(`[medhok] ${action} succeeded`, context);
}

function logApiError(action, error, context) {
  logger.error(`[medhok] ${action} failed`, {
    ...context,
    ...getErrorLogContext(error),
  });
}

// For transient/retryable failures that are NOT the final outcome (a backend or
// frontend retry may still fix them). Kept at WARN so they don't add ERROR-level
// noise; only genuinely final, non-retried failures are logged via logApiError.
function logApiWarn(action, error, context) {
  logger.warn(`[medhok] ${action} failed (retryable)`, {
    ...context,
    ...getErrorLogContext(error),
  });
}

async function getAccessToken(userId) {
  let auth = "";
  if (isDeployedEnv()) {
    const medhokClientFromSecrets = await accessSecretVersion(
      COMPUTE_PROJECT_ID,
      SECRET_MANAGER_SECRET_ID,
      `esl_secret_${ESL_ENV_NAME}`
    );
    auth = Buffer.from(
      `${MEDHOK_CLIENT_ID}:${medhokClientFromSecrets}`
    ).toString("base64");
  } else {
    auth = Buffer.from(`${MEDHOK_CLIENT_ID}:${MEDHOK_CLIENT_SECRET}`).toString(
      "base64"
    );
  }

  try {
    const response = await withRetry(
      () =>
        axios.post(
          MEDHOK_TOKEN_URL,
          qs.stringify({
            grant_type: "client_credentials",
          }),
          {
            headers: {
              Authorization: `Basic ${auth}`,
              "Content-Type": "application/x-www-form-urlencoded",
            },
            // Short per-attempt timeout so 2-3 attempts fit within the frontend's
            // ~10s request budget (token generation is normally sub-second).
            timeout: 2500,
          }
        ),
      {
        label: "token-generation",
        isRetryable: isRetryableError,
        retries: 2,
        deadlineMs: 5000,
      }
    );
    logApiSuccess("token-generation", {
      userId,
    });
    return response.data.access_token;
  } catch (error) {
    // Logged at WARN (not ERROR): token generation is retryable — the caller
    // maps this to a 555 that the frontend retries, so it is not the final
    // outcome. The route decides ERROR (deterministic 400) vs WARN (retryable
    // 555). Propagate so callers never proceed with an undefined token (which
    // would send "Bearer undefined" and surface as a misleading upstream 401).
    logApiWarn("token-generation", error, {
      userId,
    });
    throw error;
  }
}

function getRequestTokenContext(req) {
  let currentToken = "";
  let tokenStartTime = "";
  let diffMinutes = "";

  if (req.body.tokenStartTime && req.body.tokenStartTime !== "") {
    const now = new Date();
    const startDateObject = new Date(req.body.tokenStartTime);
    const diffMilliSec = Math.abs(now - startDateObject);
    tokenStartTime = startDateObject;
    diffMinutes = Math.floor(diffMilliSec / 60000);
  }

  if (req.body.currentToken && req.body.currentToken !== "") {
    currentToken = req.body.currentToken;
  }

  return { currentToken, tokenStartTime, diffMinutes };
}

async function getOrRefreshToken(req, userId) {
  let { currentToken, tokenStartTime, diffMinutes } = getRequestTokenContext(req);

  if (currentToken === "" || tokenStartTime === "" || diffMinutes > 55) {
    logApiSuccess("token-refresh-triggered", {
      userId,
      hasCurrentToken: currentToken !== "",
      hasTokenStartTime: tokenStartTime !== "",
      tokenAgeMinutes: diffMinutes || 0,
    });
    currentToken = await getAccessToken(userId);
    tokenStartTime = new Date();
  }

  return { currentToken, tokenStartTime };
}



/**
 * Builds a request body object, omitting any fields that are undefined or empty string.
 * @param {Object} fields - Key/value pairs to include conditionally.
 * @returns {Object}
 */
function sanitizeRequestBody(fields) {
  return Object.fromEntries(
    Object.entries(fields).filter(([_, v]) => v !== undefined && v !== "")
  );
}

/**
 * Format date as ISO 8601 with timezone offset (e.g., 2025-02-14T00:19:44-0500)
 */
function formatDateWithTimezone(date = new Date()) {
  const d = new Date(date);
  const tzOffset = -d.getTimezoneOffset();
  const sign = tzOffset >= 0 ? "+" : "-";
  const hours = String(Math.abs(Math.floor(tzOffset / 60))).padStart(2, "0");
  const minutes = String(Math.abs(tzOffset % 60)).padStart(2, "0");
  
  const iso = d.toISOString().split(".")[0]; // Remove milliseconds
  return `${iso}${sign}${hours}${minutes}`;
}

module.exports = {
  getAccessToken,
  getOrRefreshToken,
  getRequestTokenContext,
  logApiSuccess,
  logApiError,
  logApiWarn,
  sanitizeRequestBody,
  formatDateWithTimezone,
  withRetry,
  isRetryableError,
  isTransientTransportError,
  isCaseAlreadyDecisionedError,
  getErrorLogContext,
};
