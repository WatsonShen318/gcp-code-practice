var axios = require("axios");
var express = require("express");
var router = express.Router();
const {
  MEDHOK_ESL_API_CASE_DETAILS_RETRIEVE,
  MEDHOK_ESL_API_ADD_OUTBOUND_CONTACT,
  MEDHOK_ESL_API_UPDATE_RX_CASE_ATTRIBUTE,
} = require("../parameters/parameterConfig");
const {
  getAccessToken,
  getOrRefreshToken,
  logApiSuccess,
  logApiError,
  logApiWarn,
  sanitizeRequestBody,
  formatDateWithTimezone,
  withRetry,
  isRetryableError,
  isCaseAlreadyDecisionedError,
  getErrorLogContext,
} = require("./utils");
const logger = require("../logger");

/* Retrieve Rx Case details from Medhok ESL API by providing valid RxPA case number. Rx Case details include patient information, prescriber information, drug information and other relevant information related to the Rx case. */
router.post("/retrieve-casedetails", async (req, res) => {
  const caseId = req.body["caseId"];
  const userId = req.body["userId"];
  let reqBody;
  try {
    const { currentToken, tokenStartTime } = await getOrRefreshToken(
      req,
      userId,
    );

    reqBody = sanitizeRequestBody({
      rxId: caseId,
    });

    const makeCall = (token) =>
      withRetry(
        () =>
          axios.post(MEDHOK_ESL_API_CASE_DETAILS_RETRIEVE, reqBody, {
            headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json" },
            timeout: 3000,
          }),
        {
          label: "retrieve-casedetails",
          isRetryable: isRetryableError,
          retries: 2,
          deadlineMs: 10000,
        }
      );

    let activeToken = currentToken;
    let activeTokenStartTime = tokenStartTime;
    let response;

    try {
      response = await makeCall(activeToken);
    } catch (firstErr) {
      if (firstErr?.response?.status === 401) {
        logger.warn("[medhok] retrieve-casedetails: 401 received, refreshing token and retrying", { userId, caseId });
        activeToken = await getAccessToken(userId);
        activeTokenStartTime = new Date();
        response = await makeCall(activeToken);
      } else {
        throw firstErr;
      }
    }

    logApiSuccess("retrieve-casedetails", {
      userId, caseId, responseStatus: response.status,
    });
    res.status(200).json({
      medhokData: response.data,
      currentToken: activeToken,
      tokenStartTime: activeTokenStartTime,
    });
  } catch (error) {
    // Transient failures (upstream 5xx, or connection/timeout errors with no
    // response) are signalled with 555 so the frontend can safely retry them.
    // Deterministic failures (4xx: bad request, wrong case id, auth) stay 400
    // and are NOT retried by the frontend.
    if (isRetryableError(error)) {
      logApiWarn("retrieve-casedetails-upstream-unavailable", error, {
        userId,
        caseId,
        reqBody,
        mappedStatus: 555,
      });
      res.status(555).json({ error: "Upstream ESL unavailable. Please retry.", userId, caseId, errorCode: error?.code, upstreamStatus: error?.response?.status });
    } else {
      logApiError("retrieve-casedetails-error", error, {
        userId,
        caseId,
        reqBody,
        mappedStatus: 400,
      });
      res.status(400).json({ error: "Failed to fetch Medhok response..", userId, caseId, errorCode: error?.code, upstreamStatus: error?.response?.status });
    }
  }
});

/* Create Outbound contact entries for a Rx Case. Valid RxPA case number must be provided to create outboundcall. Multiple entries of outbound calls can be created for the Rx case. */
router.post("/add-outboundcontact", async (req, res) => {
  const rxPAId = req.body["rxPAId"];
  const outboundContactInput = req.body["outboundContact"] || {};
  const userId = req.body["userId"];
  let reqBody;
  let writeAttempted = false;
  try {
    const { currentToken, tokenStartTime } = await getOrRefreshToken(
      req,
      userId,
    );

    const { callType, firstName, lastName, title, notes, outcome } = 
    outboundContactInput;

    const outboundContact = sanitizeRequestBody({
      callType, // mandatory field
      firstName, // optional field
      lastName, // optional field
      title, // optional field
      notes, // optional field
      outcome, // mandatory field
      timeOfContact: formatDateWithTimezone(), // mandatory field
    });

    reqBody = {
      rxPAId: String(rxPAId), // mandatory field
      outboundContact: [outboundContact], // mandatory field
    };

    const makeCall = (token) =>
      withRetry(
        () =>
          axios.post(MEDHOK_ESL_API_ADD_OUTBOUND_CONTACT, reqBody, {
            headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json" },
            timeout: 3000,
          }),
        {
          // Retry the write ONCE on transient failures (timeout / connection / 5xx).
          // NOTE: outbound is NOT idempotent (it creates a contact entry per call),
          // so a retry after a first attempt that actually landed can create a
          // DUPLICATE entry — this is an accepted trade-off. Each retry is logged at
          // WARN by withRetry; a genuine 401 is still handled by the refresh path.
          label: "add-outboundcontact",
          isRetryable: isRetryableError,
          retries: 1,
          deadlineMs: 6500,
        }
      );

    let activeToken = currentToken;
    let activeTokenStartTime = tokenStartTime;
    let response;

    // Marks the point past which the create has actually been sent upstream, so
    // the catch can tell a token-stage failure (nothing created) from a
    // create-stage failure.
    writeAttempted = true;
    try {
      response = await makeCall(activeToken);
    } catch (firstErr) {
      if (firstErr?.response?.status === 401) {
        logger.warn("[medhok] add-outboundcontact: 401 received, refreshing token and retrying", { userId, rxPAId });
        activeToken = await getAccessToken(userId);
        activeTokenStartTime = new Date();
        response = await makeCall(activeToken);
      } else {
        throw firstErr;
      }
    }

    logApiSuccess("add-outboundcontact", {
      userId, rxPAId, responseStatus: response.status,
    });
    res.status(response.status).json({
      medhokData: response.data,
      currentToken: activeToken,
      tokenStartTime: activeTokenStartTime,
    });
  } catch (error) {
    // Signal 555 (retryable) ONLY when the failure happened before the create was
    // ever attempted — i.e. the token stage failed transiently, so no contact was
    // created. Any failure once the create was attempted stays 400 and is NOT
    // retried by the frontend (the backend already retried the create once).
    if (!writeAttempted && isRetryableError(error)) {
      logApiWarn("add-outboundcontact-upstream-unavailable", error, {
        userId,
        rxPAId,
        reqBody,
        mappedStatus: 555,
      });
      res.status(555).json({ error: "Upstream ESL unavailable (token stage). Please retry.", userId, rxPAId, errorCode: error?.code, upstreamStatus: error?.response?.status });
    } else {
      logApiError("add-outboundcontact-error", error, {
        userId,
        rxPAId,
        reqBody,
        mappedStatus: 400,
      });
      res.status(400).json({ error: "Failed to add outbound contact.", userId, rxPAId, errorCode: error?.code, upstreamStatus: error?.response?.status });
    }
  }
});

/* Update Rx Case attributes in Medhok for a given Rx case id. */
router.post("/update-rxcaseattribute", async (req, res) => {
  const {
    userId,
    medhokId,
    rxId,
    status,
    statusReason,
    yesOrNoByAddlInfoRequired,
    yesOrNoBySupportingStatementRequired,
    internal,
    externalTemplate,
    externalTemplateDescription,
    letterTemplateDescription,
  } = req.body;

  let reqBody;
  let writeAttempted = false;
  try {
    const { currentToken, tokenStartTime } = await getOrRefreshToken(
      req,
      userId,
    );

    reqBody = sanitizeRequestBody({
      rxId, // mandatory field
      medhokId: Number(medhokId), // optional field
      status, // optional field but should be in the dropdown values defined in MHK UI
      statusReason, // optional field but should be in the dropdown values defined in MHK UI
      internal, // optional field
      yesOrNoByAddlInfoRequired,
      yesOrNoBySupportingStatementRequired,
      externalTemplate,
      externalTemplateDescription,
      letterTemplateDescription,
    });

    const makeCall = (token) =>
      withRetry(
        () =>
          axios.post(MEDHOK_ESL_API_UPDATE_RX_CASE_ATTRIBUTE, reqBody, {
            headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json" },
            timeout: 3000,
          }),
        {
          // Retry the write ONCE on transient failures (timeout / connection / 5xx).
          // Safe because update is idempotent (it sets absolute attribute values, so
          // re-applying the same payload converges to the same state). Each retry is
          // logged at WARN by withRetry; a genuine 401 is still handled by the
          // refresh path. Token-stage failures (write never sent) map to a 555 below.
          label: "update-rx-case-attribute",
          isRetryable: isRetryableError,
          retries: 1,
          deadlineMs: 6500,
        }
      );

    let activeToken = currentToken;
    let activeTokenStartTime = tokenStartTime;
    let response;

    // Marks the point past which the write has actually been sent upstream.
    // Used below to decide whether a transient failure is safe to retry: only
    // failures that occur BEFORE the write is attempted (i.e. token stage) can
    // be safely retried without risking a duplicate/double-applied update.
    writeAttempted = true;
    try {
      response = await makeCall(activeToken);
    } catch (firstErr) {
      if (firstErr?.response?.status === 401) {
        logger.warn("[medhok] update-rx-case-attribute: 401 received, refreshing token and retrying", { userId, rxId, medhokId });
        activeToken = await getAccessToken(userId);
        activeTokenStartTime = new Date();
        response = await makeCall(activeToken);
      } else {
        throw firstErr;
      }
    }

    logApiSuccess("update-rx-case-attribute", {
      userId, rxId, medhokId, responseStatus: response.status, reqBody,
    });
    res.status(response.status).json({
      medhokData: response.data,
      currentToken: activeToken,
      tokenStartTime: activeTokenStartTime,
    });
  } catch (error) {
    // Signal 555 (retryable) ONLY when the failure happened before the write was
    // ever attempted — i.e. the token stage failed transiently, so the update
    // definitely never reached Medhok. Any failure once the write was attempted
    // stays 400 and is NOT retried, to avoid double-applying the update.
    if (!writeAttempted && isRetryableError(error)) {
      logApiWarn("update-rx-case-attribute-upstream-unavailable", error, {
        userId,
        rxId,
        medhokId,
        reqBody,
        mappedStatus: 555,
      });
      res.status(555).json({ error: "Upstream ESL unavailable (token stage). Please retry.", userId, rxId, medhokId, errorCode: error?.code, upstreamStatus: error?.response?.status });
    } else {
      const context = { userId, rxId, medhokId, reqBody, mappedStatus: 400 };
      if (isCaseAlreadyDecisionedError(error)) {
        logger.warn("[medhok] update-rx-case-attribute-error failed", {
          ...context,
          ...getErrorLogContext(error),
        });
      } else {
        logApiError("update-rx-case-attribute-error", error, context);
      }
      res.status(400).json({ error: "Failed to update Rx case attribute.", userId, rxId, medhokId, errorCode: error?.code, upstreamStatus: error?.response?.status });
    }
  }
});

module.exports = router;
