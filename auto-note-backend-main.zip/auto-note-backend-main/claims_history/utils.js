const { BigQuery } = require('@google-cloud/bigquery');
const logger = require('../logger');
const { COMPUTE_PROJECT_ID, CLAIMS_DENORM_TABLE, MBR_EPH_LINKS_TABLE } = require('../parameters/parameterConfig');

const BQ_LOCATION = 'US';
const BQ_TIMEOUT_MS = 60000;

// Set to true to re-enable paid claims automation
const CLAIMS_ENABLED = true;

// Module-level singleton — reuses auth token cache and underlying HTTP/gRPC connections
// across all claims history queries, avoiding per-call TLS handshake overhead.
const _bq = new BigQuery({ projectId: COMPUTE_PROJECT_ID });

// EPH CTE: finds all mbr_acct_ids linked to the given member using the
// pre-materialized auto_note_mbr_eph_links table (cluster-pruned by mbr_acct_id).
// UNION DISTINCT @memberId is the fallback for members with no EPH link
// (EPH_LINK_ID = 0 / NULL — not present in the links table).
const ephCte = (memberIdParam = '@memberId') => `
  all_mbr_ids AS (
    SELECT linked_mbr_acct_id AS mbr_acct_id
    FROM \`${MBR_EPH_LINKS_TABLE}\`
    WHERE mbr_acct_id = ${memberIdParam}

    UNION DISTINCT

    SELECT ${memberIdParam}
  )
`;

// Returns the Set of gpi_cd_12 values (from the provided pairs) that the member
// (or any EPH-linked account) has paid claims for within 2 full plan years of receivedDate.
// Window: Jan 1 of (year(receivedDate) - 2) through receivedDate exclusive.
// gpi12Pairs: [{ gpi12: string, partialDrugName: string }]
// Matches drug_brnd_nm LIKE '%partialDrugName%' alongside gpi_cd_12 (mirrors NF_claims_history.sql).
// Returns empty Set when memberId, gpi12Pairs, or receivedDate is absent.
async function getNfCheckedGpi12s(memberId, gpi12Pairs, receivedDate) {
  if (!CLAIMS_ENABLED) return new Set();
  if (!memberId || !Array.isArray(gpi12Pairs) || gpi12Pairs.length === 0) return new Set();
  if (!receivedDate) {
    logger.warn('[Claims] getNfCheckedGpi12s: receivedDate is null — skipping claims check');
    return new Set();
  }
  const receivedYear = parseInt(String(receivedDate).slice(0, 4), 10);
  if (!receivedYear || isNaN(receivedYear)) {
    logger.warn(`[Claims] getNfCheckedGpi12s: receivedDate is invalid (${receivedDate}) — skipping claims check`);
    return new Set();
  }
  const claimsWindowStart = `${receivedYear - 2}-01-01`;
  const gpi12List        = gpi12Pairs.map(p => p.gpi12);
  const partialNameList  = gpi12Pairs.map(p => p.partialDrugName);
  try {
    const [rows] = await _bq.query({
      query: `
        WITH ${ephCte()},
        filter_pairs AS (
          SELECT gpi12, partialName
          FROM UNNEST(@gpi12List)       AS gpi12       WITH OFFSET pos1
          JOIN UNNEST(@partialNameList) AS partialName WITH OFFSET pos2
            ON pos1 = pos2
        )
        SELECT DISTINCT C.gpi_cd_12, F.partialName AS matched_partial_name
        FROM \`${CLAIMS_DENORM_TABLE}\` C
        INNER JOIN all_mbr_ids A ON C.mbr_acct_id = A.mbr_acct_id
        INNER JOIN filter_pairs F
          ON C.gpi_cd_12 = F.gpi12
         AND (F.partialName = '' OR UPPER(C.drug_brnd_nm) LIKE '%' || F.partialName || '%')
        WHERE C.fill_dt >= DATE(@claimsWindowStart)
          AND C.fill_dt  < DATE(@receivedDate)
      `,
      params: { memberId, gpi12List, partialNameList, receivedDate, claimsWindowStart },
      types: {
        memberId: 'STRING',
        gpi12List: ['STRING'],
        partialNameList: ['STRING'],
        receivedDate: 'STRING',
        claimsWindowStart: 'STRING',
      },
      location: BQ_LOCATION,
      timeoutMs: BQ_TIMEOUT_MS,
    });
    logger.info(`[Claims] getNfCheckedGpi12s: checked=${gpi12List.length} found=${rows.length} receivedDate=${receivedDate} claimsWindowStart=${claimsWindowStart}`);
    // TODO: Enable composite key below instead when enabling partialDrugName autoCheck in form_alts/utils.js.
    // return new Set((rows || []).map(r => r?.gpi_cd_12 && `${r.gpi_cd_12}|${r.matched_partial_name}`).filter(Boolean));
    return new Set((rows || []).map(r => r?.gpi_cd_12).filter(Boolean));
  } catch (err) {
    logger.error(`[Claims] getNfCheckedGpi12s failed — returning empty set so form alts can continue: ${err?.message}`);
    return new Set();
  }
}

// Returns the claim with the highest mdd for the member + GPI within 2 full plan years
// of receivedDate, or null when no qualifying claims exist or inputs are absent.
// Window: Jan 1 of (year(receivedDate) - 2) through receivedDate exclusive.
// { maxMdd, dispQty, daysSply, fillDt } — all fields needed to display the qualifying claim detail.
// gpi_cd_12 = LEFT(@gpi, 12) is explicit to enable cluster pruning on (mbr_acct_id, gpi_cd_12).
async function getQualifyingClaimForGpi(memberId, gpi, receivedDate) {
  if (!CLAIMS_ENABLED) return null;
  if (!memberId || !gpi) return null;
  if (!receivedDate) {
    logger.warn('[Claims] getQualifyingClaimForGpi: receivedDate is null — skipping claims check');
    return null;
  }
  const receivedYear = parseInt(String(receivedDate).slice(0, 4), 10);
  if (!receivedYear || isNaN(receivedYear)) {
    logger.warn(`[Claims] getQualifyingClaimForGpi: receivedDate is invalid (${receivedDate}) — skipping claims check`);
    return null;
  }
  const claimsWindowStart = `${receivedYear - 2}-01-01`;
  try {
    const [rows] = await _bq.query({
      query: `
        WITH ${ephCte()}
        SELECT C.mdd AS max_mdd, C.disp_qty, C.days_sply, C.fill_dt
        FROM \`${CLAIMS_DENORM_TABLE}\` C
        INNER JOIN all_mbr_ids A ON C.mbr_acct_id = A.mbr_acct_id
        WHERE C.gpi_cd_12 = LEFT(@gpi, 12)
          AND C.gpi_cd    = @gpi
          AND C.fill_dt  >= DATE(@claimsWindowStart)
          AND C.fill_dt   < DATE(@receivedDate)
        ORDER BY C.mdd DESC, C.fill_dt DESC
        LIMIT 1
      `,
      params: { memberId, gpi, receivedDate, claimsWindowStart },
      types: { memberId: 'STRING', gpi: 'STRING', receivedDate: 'STRING', claimsWindowStart: 'STRING' },
      location: BQ_LOCATION,
      timeoutMs: BQ_TIMEOUT_MS,
    });
    if (!rows?.[0]) return null;
    const maxMdd = (rows[0].max_mdd != null && !isNaN(Number(rows[0].max_mdd))) ? Number(rows[0].max_mdd) : null;
    if (maxMdd === null) return null;
    const fillDt = rows[0].fill_dt?.value ?? rows[0].fill_dt ?? null;
    const dispQty  = rows[0].disp_qty  != null ? Number(rows[0].disp_qty)  : null;
    const daysSply = rows[0].days_sply != null ? Number(rows[0].days_sply) : null;
    logger.info(`[Claims] getQualifyingClaimForGpi: maxMdd=${maxMdd} dispQty=${dispQty} daysSply=${daysSply} fillDt=${fillDt} receivedDate=${receivedDate} claimsWindowStart=${claimsWindowStart}`);
    return { maxMdd, dispQty, daysSply, fillDt };
  } catch (err) {
    logger.error(`[Claims] getQualifyingClaimForGpi failed — returning null so quantity limit can continue: ${err?.message}`);
    return null;
  }
}

module.exports = { getNfCheckedGpi12s, getQualifyingClaimForGpi };
