const logger = require("../logger");
const {
  TABLE_ID,
  COLUMN_FAMILY_ID,
  INSTANCE_ID,
  PROJECT_ID,
} = require("../parameters/parameterConfig");
const { Bigtable } = require("@google-cloud/bigtable");
const { createUniqueDictionary } = require("../helpers/dict_helper");

// gRPC codes that indicate a transient failure safe to retry on insert.
// Code 8 (RESOURCE_EXHAUSTED) is intentionally excluded — retrying quota
// exhaustion errors burns more quota without recovering.
const RETRYABLE_GRPC_CODES = new Set([
  4,  // DEADLINE_EXCEEDED
  14, // UNAVAILABLE
]);

// Cached after the first successful check so table.exists() is not called
// on every request (admin API quota: "Table metadata read requests per minute").
let tableEnsured = false;

async function withBigtableRetry(fn, { retries = 2, label = "" } = {}) {
  let attempt = 0;
  while (true) {
    try {
      return await fn();
    } catch (error) {
      if (attempt >= retries || !RETRYABLE_GRPC_CODES.has(error?.code)) throw error;
      const delay = Math.min(200 * 2 ** attempt, 800) + Math.floor(Math.random() * 100);
      logger.warn(`[bigtable] ${label} transient failure, retrying`, {
        attempt: attempt + 1,
        maxAttempts: retries + 1,
        delayMs: delay,
        errorCode: error?.code,
        errorMessage: error?.message,
      });
      await new Promise((resolve) => setTimeout(resolve, delay));
      attempt += 1;
    }
  }
}

if (!INSTANCE_ID) {
  throw new Error("Environment variables for INSTANCE_ID must be set!");
}

async function pushDataToBigData(reqBody, dataToSend) {
  const bigtableClient = new Bigtable({
    projectId: PROJECT_ID,
  });

  try {
    const instance = bigtableClient.instance(INSTANCE_ID);

    const table = instance.table(TABLE_ID);
    if (!tableEnsured) {
      logger.info(`[bigtable] Checking if table ${TABLE_ID} exists.`);
      const [tableExists] = await table.exists();
      if (!tableExists) {
        logger.info(`[bigtable] Table ${TABLE_ID} not found, creating.`);
        await table.create({
          families: [{ name: COLUMN_FAMILY_ID, rule: { versions: 1 } }],
        });
        logger.info(`[bigtable] Table ${TABLE_ID} created successfully.`);
      }
      tableEnsured = true;
      logger.info(`[bigtable] Table ${TABLE_ID} confirmed, skipping existence check on future requests.`);
    }

    const USER_ID = reqBody.userId;
    const currentDate = new Date().toISOString();
    const rowKey = `${USER_ID}:${currentDate}`;
    const rowToInsert = {
      key: rowKey,
      data: {
        [COLUMN_FAMILY_ID]: {
          timestamp: currentDate,
          value: dataToSend,
        },
      },
    };
    logger.info(`Writing in the BigTable with rowKey: ${rowKey}`);
    await withBigtableRetry(() => table.insert(rowToInsert), { label: "table.insert", retries: 2 });
    logger.info(`Successful audit data push to BT with rowKey: ${rowKey}`);
    return;
  } catch (error) {
    logger.error(`Big Table Push Error: `, error);
    throw error;
  } finally {
    logger.info('Closing Big Table Connection.');
    bigtableClient.close();
  }
}

function convertIntoDataToSend(reqBody) {
  let finalNoteInReqBody = reqBody?.finalNote || "";
  /* Handle Exceptions */
  // Tier Case Created in the same line as Tiering. E.g., in final notes - Tiering: Yes Tier case created: Yes Current Tier
  finalNoteInReqBody = finalNoteInReqBody
    .replace("Tier case created", "\nTier case created")
    .replace("Current Tier", "\nCurrent Tier");
  // Handle Field - Does this member have multiple drugs or requests? Yes to show field in the BT
  finalNoteInReqBody = finalNoteInReqBody.replace(
    "This is Case ",
    "Does this member have multiple drugs or requests?: This is Case "
  );
  // Handle Field - Is this for Prospective Review? This is a 2025 Prospective Review.
  const prospectiveRegex = /This is a (\d{4}) Prospective Review/;
  if (prospectiveRegex.test(finalNoteInReqBody)) {
    let year = finalNoteInReqBody.match(prospectiveRegex)[1];
    finalNoteInReqBody = finalNoteInReqBody.replace(
      `This is a ${year} Prospective Review`,
      `Is this for Prospective Review?: This is a ${year} Prospective Review`
    );
  }
  // when PDP/MAPD is selected in Send to MD template of RPH flows
  if (finalNoteInReqBody?.startsWith("MAPD")) {
    finalNoteInReqBody = finalNoteInReqBody.replace("MAPD", "PDP/MAPD: MAPD");
  } else if (finalNoteInReqBody?.startsWith("PDP")) {
    finalNoteInReqBody = finalNoteInReqBody.replace("PDP", "PDP/MAPD: PDP");
  }
  // Request Type and CD/RD Grid Answers present in the same line in final notes
  finalNoteInReqBody = finalNoteInReqBody.replace(
    "CD/RD Grid Answers",
    "\nCD/RD Grid Answers"
  );

  const finalNoteSplit = finalNoteInReqBody.split("\n");
  const finalNoteKVs = finalNoteSplit
    .map((item) => {
      const [key, value] = item.split(":").map((str) => str.trim());
      return [key, value];
    })
    .filter(([key, value]) => {
      return key && value;
    });

  const finalNoteDict = createUniqueDictionary(finalNoteKVs);

  if (finalNoteDict["Drug"]) {
    finalNoteDict["Drug"] =
      finalNoteDict["Drug"]?.split("Qty/DS")[0]?.trim() || "";
  }
  const drugRegex = /Qty\/DS:\s*(\d+)\/(\d+)/i;
  const drugMatch = drugRegex.exec(finalNoteInReqBody);

  if (drugMatch?.length >= 2) {
    finalNoteDict["Qty/DS"] = `${drugMatch[1]}/${drugMatch[2]}`;
  }

  let caseId = "";
  let btEslRsp = "";
  if (reqBody?.eslRsp) {
    caseId = reqBody.eslRsp.rxId;
    btEslRsp = reqBody.eslRsp;
  }

  const END_TS = new Date().toISOString();

  const dataToSend = {
    CASE_ID: caseId,
    CASE_STRT_TS: reqBody.startTime,
    CASE_END_TS: END_TS,
    CDRD_STRT_TS: reqBody.cdrdStartTime,
    CDRD_END_TS: reqBody.cdrdEndTime,
    CDRD_pred_outcome: reqBody.cdrdPredOutcome,
    DLT_GL_STRT_TS: reqBody.dltGuidelineStartTime || "",
    DLT_GL_END_TS: reqBody.dltGuidelineEndTime || "",
    DLT_GL_NM: reqBody.dltGuidelineName || "",
    GL_FIELDS_AUTOMATED: reqBody.GL_FIELDS_AUTOMATED || null,
    GL_FIELDS_FINAL: reqBody.GL_FIELDS_FINAL || null,
    USER_ID: reqBody.userId,
    USER_NM: reqBody.userName,
    CASE_TYPE: reqBody.caseType,
    MEDHOK_STATUS: reqBody.medhokStatus,
    MEDHOK_RESPONSE: reqBody.medhokBackendResponse,
    CASE_SUBMIT_TS: reqBody.caseIdInputTimeList,
    ESL_RSPNS: btEslRsp,
    REQ_RSN: finalNoteDict["Request Reason"],
    WORK_FLOW: reqBody.workFlow,
    USER_GROUP: reqBody.userGroups,
    FINAL_NOTE: finalNoteDict,
    RECOMMENDED_CASE_DCSN_ROUTING: reqBody.RECOMMENDED_CASE_DCSN_ROUTING || "",
    FINAL_CASE_DCSN_ROUTING: reqBody.FINAL_CASE_DCSN_ROUTING || "",
    MHK_OBC_CONTACT_TYPE: reqBody.MHK_OBC_CONTACT_TYPE || "",
    MHK_OBC_CONTACT_OUTCOME: reqBody.MHK_OBC_CONTACT_OUTCOME || "",
    MHK_OBC_CONTACT_NOTES: reqBody.MHK_OBC_CONTACT_NOTES || "",
    MHK_STATUS: reqBody.MHK_STATUS || "",
    MHK_STATUS_REASON: reqBody.MHK_STATUS_REASON || "",
    MHK_FINAL_NOTE: reqBody.MHK_FINAL_NOTE || "",
    MHK_ADDL_INFO_REQUIRED: reqBody.MHK_ADDL_INFO_REQUIRED || "",
    MHK_SUPP_STMT_REQUIRED: reqBody.MHK_SUPP_STMT_REQUIRED || "",
    MHK_LETTER_TEMPLATE_DESC: reqBody.MHK_LETTER_TEMPLATE_DESC || "",
    MHK_EXTERNAL_TEMPLATE: reqBody.MHK_EXTERNAL_TEMPLATE || "",
    MHK_EXTERNAL_TEMPLATE_DESC: reqBody.MHK_EXTERNAL_TEMPLATE_DESC || "",
    FORM_ALTS_AUDIT: reqBody.FORM_ALTS_AUDIT || null,
    QL_AUDIT: reqBody.QL_AUDIT || null,
    RFI_REASON_SELECTED: reqBody.RFI_REASON_SELECTED || "",
    DENIAL_REASON_SELECTED: reqBody.DENIAL_REASON_SELECTED || "",
    CASE_VERBIAGE_GENERATED: reqBody.CASE_VERBIAGE_GENERATED || ""
  };

  return JSON.stringify(dataToSend);
}

module.exports = { pushDataToBigData, convertIntoDataToSend };
