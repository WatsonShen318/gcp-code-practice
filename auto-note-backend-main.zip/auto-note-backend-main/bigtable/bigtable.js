var express = require("express");
const logger = require("../logger");
var router = express.Router();

const { pushDataToBigData, convertIntoDataToSend } = require("./bigTableUtils");

router.post("/", async (req, res) => {
  try {
    const dataToSend = convertIntoDataToSend(req.body);
    await pushDataToBigData(req.body, dataToSend);

    res.status(200).json({
      status: "success",
    });
  } catch (error) {
    logger.error("Error while pushing audit data to the BT table", error);
    res
      .status(400)
      .send(
        `An Error occured while pushing audit data to the BT table, error: ${error}..`
      );
  }
});

module.exports = router;
