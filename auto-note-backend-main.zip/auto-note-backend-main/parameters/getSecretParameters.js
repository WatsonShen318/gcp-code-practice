const { SecretManagerServiceClient } = require("@google-cloud/secret-manager");

const client = new SecretManagerServiceClient();

async function accessSecretVersion(projectId, secretId, secretKey) {
  console.log(`Accessing secret version for secretId: ${secretId}, secretKey: ${secretKey} in project ${projectId}`);
  const secretName = `projects/${projectId}/secrets/${secretId}/versions/latest`;
  const [version] = await client.accessSecretVersion({
    name: secretName,
  });

  const payload = JSON.parse(version.payload.data.toString());
  return payload[secretKey];
}

module.exports = accessSecretVersion;
