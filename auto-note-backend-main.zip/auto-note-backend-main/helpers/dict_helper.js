/**
 * Checks if a value is a string and return valid string or empty string
 * @param {any} value - The value to check
 * @returns {boolean} - Returns the value if it is a string, otherwise returns an empty string
 */
function validString(value) {
  if (typeof value === 'string') {
    return value;
  }
  return '';
}

function isSafeKey(key) {
  const unsafeKeys = ['__proto__', 'constructor', 'prototype'];
  if (unsafeKeys.includes(key)) {
    return false;
  }
  return true;
}

function createUniqueDictionary(entries) {
  const uniqueDict = new Map();
  const keyCount = new Map();
  
  for (const [key, value] of entries) {
    if (!isSafeKey(key)) continue;
    
    if (uniqueDict.has(key)) {
      const count = (keyCount.get(key) || 0) + 1;
      keyCount.set(key, count);
      const newKey = `${key}_${count}`;
      if (isSafeKey(newKey)) {
        uniqueDict.set(newKey, validString(value));
      }
    } else {
      uniqueDict.set(key, validString(value));
      keyCount.set(key, 0);
    }
  }
  
  return Object.fromEntries(uniqueDict);
}

module.exports = { createUniqueDictionary };
