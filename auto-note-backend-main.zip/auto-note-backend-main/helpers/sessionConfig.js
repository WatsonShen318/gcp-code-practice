function createExpressSessionConfig() {
  const secret = process.env.EXPRESS_SESSION_SECRET || "Enter_the_Express_Session_Secret_Here";
  const envName = process.env.ENV_NAME || "";
  // When the frontend is on a different eTLD+1 (e.g. .aetna.com) from the backend
  // (.cvshealth.com), sameSite:"lax" blocks the session cookie on cross-site fetch.
  // sameSite:"none" + secure:true allows the browser to send it cross-site.
  const crossSite = envName.includes("prod") || envName.includes("qa");

  process.env.EXPRESS_SESSION_PARAMS = JSON.stringify({
    name: "session",
    keys: [secret],
    maxAge: 60 * 60 * 1000,
    httpOnly: true,
    secure: crossSite,
    sameSite: crossSite ? "none" : "lax",
  });
}

module.exports = { createExpressSessionConfig };
