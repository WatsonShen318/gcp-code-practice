"""Unit tests for src/config.py.

Config reads environment variables at import time (class-body scope), so we
reload the module under a controlled environment to exercise the defaults and
the env-driven parsing branches (allowed_groups / page_allowed_groups).
"""
import importlib


def test_defaults(monkeypatch):
    monkeypatch.delenv("ALLOWED_GROUPS", raising=False)
    monkeypatch.delenv("PAGE_ALLOWED_GROUPS", raising=False)
    monkeypatch.delenv("TOKEN_EXPIRATION_TIME", raising=False)
    import src.config as config
    importlib.reload(config)

    assert config.Config.grant_type == "authorization_code"
    assert config.Config.secret_version == "latest"
    assert config.Config.allowed_groups == []
    # page_allowed_groups has a non-empty default.
    assert config.Config.page_allowed_groups == ["app-pa-pulse-pdev-user"]
    assert isinstance(config.Config.token_expiration_time, int)
    assert isinstance(config.Config.streamlit_port, int)


def test_group_lists_parsed_and_stripped(monkeypatch):
    monkeypatch.setenv("ALLOWED_GROUPS", "grp-a, grp-b ,, grp-c ")
    monkeypatch.setenv("PAGE_ALLOWED_GROUPS", "page-x ,page-y")
    monkeypatch.setenv("TOKEN_EXPIRATION_TIME", "3600")
    import src.config as config
    importlib.reload(config)

    assert config.Config.allowed_groups == ["grp-a", "grp-b", "grp-c"]
    assert config.Config.page_allowed_groups == ["page-x", "page-y"]
    assert config.Config.token_expiration_time == 3600


def test_env_overrides_endpoints(monkeypatch):
    monkeypatch.setenv("REDIRECT_URI", "https://example.test/token")
    monkeypatch.setenv("STREAMLIT_PORT", "9000")
    import src.config as config
    importlib.reload(config)

    assert config.Config.redirect_uri == "https://example.test/token"
    assert config.Config.streamlit_port == 9000
