"""Unit tests for the pure helpers in src/auth.py.

These functions do no network I/O and are the testable core of the OIDC flow:
group-name normalisation, group-access checks, claim extraction, credential
encoding, session-id generation, and the denied-page HTML escaping.
"""
import base64

from src.auth import (
    _claim_values,
    _denied_html,
    _encode_credentials,
    _extract_groups,
    _group_cn,
    _has_group_access,
    _make_session_id,
)


# --------------------------------------------------------------------------
# _group_cn
# --------------------------------------------------------------------------

def test_group_cn_strips_dn_and_casefolds():
    assert _group_cn(
        "CN=APP-PA-PULSE-PDEV-USER,OU=Groups,DC=example,DC=com"
    ) == "app-pa-pulse-pdev-user"


def test_group_cn_plain_value_casefolded_and_trimmed():
    assert _group_cn("  MyGroup  ") == "mygroup"


# --------------------------------------------------------------------------
# _has_group_access
# --------------------------------------------------------------------------

def test_has_group_access_matches_short_name_and_dn():
    assert _has_group_access(["app-x"], ["app-x"])
    assert _has_group_access(["CN=APP-X,OU=Groups,DC=example,DC=com"], ["app-x"])


def test_has_group_access_rejects_non_member():
    assert not _has_group_access(["other-group"], ["app-x"])


def test_has_group_access_open_when_no_required_groups():
    # Empty required list => access is open to any authenticated user.
    assert _has_group_access(["anything"], [])


# --------------------------------------------------------------------------
# _claim_values
# --------------------------------------------------------------------------

def test_claim_values_handles_none_str_and_list():
    assert _claim_values(None) == []
    assert _claim_values("") == []
    assert _claim_values("solo") == ["solo"]
    assert _claim_values(["a", "b", None, "", 0]) == ["a", "b"]
    assert _claim_values([1, 2]) == ["1", "2"]


# --------------------------------------------------------------------------
# _extract_groups
# --------------------------------------------------------------------------

def test_extract_groups_combines_and_dedupes():
    groups, source = _extract_groups({"groups_cn": "a", "groups": ["b", "a"]})
    assert groups == ["a", "b"]
    assert source == "groups_cn+groups"


def test_extract_groups_single_source():
    groups, source = _extract_groups({"groups_cn": ["only"]})
    assert groups == ["only"]
    assert source == "groups_cn"


def test_extract_groups_none_source_when_empty():
    groups, source = _extract_groups({})
    assert groups == []
    assert source == "none"


# --------------------------------------------------------------------------
# _encode_credentials
# --------------------------------------------------------------------------

def test_encode_credentials_roundtrips(monkeypatch):
    from src import auth
    monkeypatch.setenv("sso_client_secret", "top-secret")
    encoded = _encode_credentials()
    decoded = base64.b64decode(encoded).decode()
    assert decoded == f"{auth._client_id}:top-secret"


# --------------------------------------------------------------------------
# _make_session_id
# --------------------------------------------------------------------------

def test_make_session_id_is_unique_and_nonempty():
    a, b = _make_session_id(), _make_session_id()
    assert a and b
    assert a != b


# --------------------------------------------------------------------------
# _denied_html
# --------------------------------------------------------------------------

def test_denied_html_escapes_email():
    html_out = _denied_html("<script>alert(1)</script>@x.com")
    assert "<script>alert(1)</script>" not in html_out
    assert "&lt;script&gt;" in html_out
    assert "<!DOCTYPE html>" in html_out


def test_denied_html_handles_missing_email():
    assert "unknown" in _denied_html("")
