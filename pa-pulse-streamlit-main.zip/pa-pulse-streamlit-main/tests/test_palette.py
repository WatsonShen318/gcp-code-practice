"""Unit tests for src/apps/pa_pulse/theme/cvs_palette.py.

Pure module: a colour palette (plain dicts) plus a Plotly template registrar.
No streamlit, no I/O — imports only `copy` and `plotly.io`.
"""
import plotly.io as pio

from src.apps.pa_pulse.theme.cvs_palette import (
    COLOR_SEQ,
    CVS,
    FUNNEL_SEG,
    MODEL_COLORS,
    apply_cvs_template,
)


def test_palette_has_core_keys_and_hex_values():
    for key in ("red", "teal", "gold", "charcoal", "white"):
        assert key in CVS
        assert CVS[key].startswith("#") and len(CVS[key]) == 7


def test_color_sequence_is_nonempty_and_from_palette():
    assert len(COLOR_SEQ) == 8
    assert set(COLOR_SEQ) <= set(CVS.values())


def test_funnel_segments_share_the_same_keys_per_source():
    # A key present under CSO but missing under GSO (or vice versa) is a bug.
    assert set(FUNNEL_SEG["CSO"]) == set(FUNNEL_SEG["GSO"])


def test_model_colors_are_valid_hex():
    for value in MODEL_COLORS.values():
        assert value.startswith("#") and len(value) == 7


def test_apply_cvs_template_registers_and_activates():
    apply_cvs_template()
    assert "cvs" in pio.templates
    assert pio.templates.default == "cvs"
    assert list(pio.templates["cvs"].layout.colorway) == list(COLOR_SEQ)
