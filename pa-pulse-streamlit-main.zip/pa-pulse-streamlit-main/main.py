"""PA Pulse Streamlit — FastAPI gateway with OIDC SSO.

Startup sequence
----------------
1. Uvicorn starts this FastAPI application on port 8080 (public-facing).
2. On startup, FastAPI launches Streamlit as a subprocess on port 8501
   (internal only — never exposed directly to users).
3. Every inbound HTTP/WebSocket request is validated against the JWT session
   cookie set by /token.  Unauthenticated requests are redirected to /login.
4. Authenticated requests are reverse-proxied to the Streamlit process.

Run locally
-----------
    uvicorn main:app --host 0.0.0.0 --port 8080 --reload
"""

import asyncio
import os
import subprocess
import sys
import time
import urllib.request

import httpx
import jwt
import websockets
from dotenv import load_dotenv
from fastapi import FastAPI, Request, WebSocket, WebSocketDisconnect
from fastapi.responses import RedirectResponse, Response

load_dotenv()

from src.credential_setup import extract_credentials
from src.auth import router as auth_router

extract_credentials()
from src.config import Config

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

_STREAMLIT_PORT = Config.streamlit_port
_STREAMLIT_HTTP = f"http://localhost:{_STREAMLIT_PORT}"
_STREAMLIT_WS = f"ws://localhost:{_STREAMLIT_PORT}"
_COOKIE_KEY = Config.sso_cookie_key
_SECRET = Config.shared_secret_key

# Paths that bypass authentication (the SSO flow itself + k8s health probes)
_AUTH_FREE = {"/login", "/token", "/logout", "/health", "/_stcore/health", "/debug/login"}

# ---------------------------------------------------------------------------
# App
# ---------------------------------------------------------------------------

app = FastAPI(docs_url=None, redoc_url=None)
app.include_router(auth_router)

_streamlit_proc: subprocess.Popen | None = None


# ---------------------------------------------------------------------------
# Lifecycle: start / stop the embedded Streamlit process
# ---------------------------------------------------------------------------

def _wait_for_streamlit(timeout: int = 60) -> None:
    deadline = time.time() + timeout
    while time.time() < deadline:
        try:
            urllib.request.urlopen(f"{_STREAMLIT_HTTP}/_stcore/health", timeout=2)
            return
        except Exception:
            time.sleep(1)
    raise RuntimeError("Streamlit did not become ready within the allotted time.")


@app.on_event("startup")
async def _start_streamlit() -> None:
    global _streamlit_proc
    _streamlit_proc = subprocess.Popen(
        [
            sys.executable,
            "-m",
            "streamlit",
            "run",
            "src/Home.py",
            "--server.port",
            str(_STREAMLIT_PORT),
            "--server.headless",
            "true",
            "--server.enableCORS",
            "false",
            "--server.enableXsrfProtection",
            "false",
        ]
    )
    loop = asyncio.get_running_loop()
    await loop.run_in_executor(None, _wait_for_streamlit)


@app.on_event("shutdown")
async def _stop_streamlit() -> None:
    if _streamlit_proc and _streamlit_proc.poll() is None:
        _streamlit_proc.terminate()


# ---------------------------------------------------------------------------
# Auth helper
# ---------------------------------------------------------------------------

def _is_authenticated(token: str | None, require_authorized: bool = True) -> bool:
    if not token:
        return False
    try:
        payload = jwt.decode(token, _SECRET, algorithms=["HS256"])
        return not require_authorized or payload.get("authorized", True)
    except jwt.PyJWTError:
        return False


# ---------------------------------------------------------------------------
# Middleware — enforce authentication on every HTTP request
# ---------------------------------------------------------------------------

@app.middleware("http")
async def _auth_gate(request: Request, call_next):
    if request.url.path in _AUTH_FREE:
        return await call_next(request)

    token = request.cookies.get(_COOKIE_KEY)
    if request.url.path == "/debug/userinfo":
        if not _is_authenticated(token, require_authorized=False):
            return RedirectResponse("/login")
        return await call_next(request)

    if not _is_authenticated(token):
        return RedirectResponse("/login")

    return await call_next(request)


# ---------------------------------------------------------------------------
# WebSocket proxy (Streamlit uses WS for all interactive communication)
# ---------------------------------------------------------------------------

@app.websocket("/{path:path}")
async def _ws_proxy(websocket: WebSocket, path: str) -> None:
    if not _is_authenticated(websocket.cookies.get(_COOKIE_KEY)):
        await websocket.close(code=1008, reason="Unauthorized")
        return

    qs = websocket.scope.get("query_string", b"").decode()
    target = f"{_STREAMLIT_WS}/{path}" + (f"?{qs}" if qs else "")

    # Forward subprotocols from browser so Streamlit can negotiate correctly.
    # Connect to upstream first, then accept the browser with the negotiated protocol.
    raw_proto = websocket.headers.get("sec-websocket-protocol", "")
    subprotocols = [s.strip() for s in raw_proto.split(",") if s.strip()]

    # Forward the browser's Cookie header so st.context.cookies is populated in Streamlit
    cookie_header = websocket.headers.get("cookie", "")

    try:
        async with websockets.connect(
            target,
            ping_interval=None,
            subprotocols=subprotocols or None,
            additional_headers={"cookie": cookie_header} if cookie_header else {},
        ) as upstream:
            await websocket.accept(subprotocol=upstream.subprotocol or None)

            async def _client_to_upstream() -> None:
                try:
                    while True:
                        msg = await websocket.receive()
                        if msg["type"] == "websocket.disconnect":
                            break
                        if msg.get("bytes"):
                            await upstream.send(msg["bytes"])
                        elif msg.get("text"):
                            await upstream.send(msg["text"])
                except (WebSocketDisconnect, Exception):
                    pass

            async def _upstream_to_client() -> None:
                try:
                    async for msg in upstream:
                        if isinstance(msg, bytes):
                            await websocket.send_bytes(msg)
                        else:
                            await websocket.send_text(msg)
                except (websockets.ConnectionClosed, Exception):
                    pass

            await asyncio.gather(_client_to_upstream(), _upstream_to_client())

    except Exception as e:
        print(f"WS proxy error: {type(e).__name__}: {e}")
    finally:
        try:
            await websocket.close()
        except Exception:
            pass


# ---------------------------------------------------------------------------
# HTTP reverse proxy — forward all other requests to Streamlit
# ---------------------------------------------------------------------------

_SKIP_PROXY_HEADERS = frozenset(
    {"host", "transfer-encoding", "content-encoding", "content-length"}
)


@app.api_route(
    "/{path:path}",
    methods=["GET", "POST", "PUT", "DELETE", "PATCH", "HEAD", "OPTIONS"],
)
async def _http_proxy(request: Request, path: str = "") -> Response:
    url = f"{_STREAMLIT_HTTP}/{path}"
    headers = {
        k: v
        for k, v in request.headers.items()
        if k.lower() not in _SKIP_PROXY_HEADERS
    }

    async with httpx.AsyncClient(timeout=120.0) as client:
        upstream = await client.request(
            method=request.method,
            url=url,
            headers=headers,
            content=await request.body(),
            params=request.query_params,
            follow_redirects=False,
        )

    resp_headers = {
        k: v
        for k, v in upstream.headers.items()
        if k.lower() not in _SKIP_PROXY_HEADERS
    }
    return Response(
        content=upstream.content,
        status_code=upstream.status_code,
        headers=resp_headers,
    )

