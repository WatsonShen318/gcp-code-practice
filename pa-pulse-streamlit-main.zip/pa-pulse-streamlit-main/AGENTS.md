# AGENTS.md

This file provides guidance to AI coding assistants when working in this repository.

<!-- Add project-specific instructions here -->
