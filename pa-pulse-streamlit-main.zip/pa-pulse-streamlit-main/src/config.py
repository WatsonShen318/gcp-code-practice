import os


class Config:
    # OIDC / PingFederate endpoints
    auth_url: str = os.environ.get("AUTH_URL", "https://authsvc.cvshealth.com/as/authorization.oauth2")
    sso_client_id: str = os.environ.get("SSO_CLIENT_ID", "APM0015442")
    redirect_uri: str = os.environ.get("REDIRECT_URI", "https://pa-pulse.pdev.cvshealth.com/token")
    token_endpoint: str = os.environ.get("TOKEN_ENDPOINT", "https://authsvc.cvshealth.com/as/token.oauth2")
    userinfo_endpoint: str = os.environ.get("USERINFO_ENDPOINT", "https://authsvc.cvshealth.com/idp/userinfo.openid")
    revoke_endpoint: str = os.environ.get("REVOKE_ENDPOINT", "https://authsvc.cvshealth.com/as/revoke_token.oauth2")
    grant_type: str = "authorization_code"

    # AD groups allowed to access the app (comma-separated in env var).
    # If empty, all authenticated users are granted access.
    allowed_groups: list = [
        g.strip() for g in os.environ.get("ALLOWED_GROUPS", "").split(",") if g.strip()
    ]
    page_allowed_groups: list = [
        g.strip()
        for g in os.environ.get(
            "PAGE_ALLOWED_GROUPS", "app-pa-pulse-pdev-user"
        ).split(",")
        if g.strip()
    ]

    # JWT / session settings
    sso_cookie_key: str = os.environ.get("SSO_COOKIE_KEY", "paops-sso")
    shared_secret_key: str = os.environ.get("SHARED_SECRET_KEY", "change-me-in-production")
    token_expiration_time: int = int(os.environ.get("TOKEN_EXPIRATION_TIME", "7200"))

    # Secret Manager
    secret_id: str = os.environ.get("SECRET_ID", "paops-streamlit-pdev")
    secret_version: str = "latest"

    # Internal Streamlit port (not exposed to users — FastAPI proxies to it)
    streamlit_port: int = int(os.environ.get("STREAMLIT_PORT", "8501"))
