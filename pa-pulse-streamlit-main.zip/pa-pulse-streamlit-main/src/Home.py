"""PA Pulse Streamlit — entrypoint."""

import streamlit as st

st.set_page_config(
    page_title="PA Pulse",
    page_icon=None,
    layout="wide",
)

nav = st.navigation([
    st.Page("apps/pa_pulse/main.py", title="PA Pulse", url_path="pa-pulse"),
])
nav.run()
