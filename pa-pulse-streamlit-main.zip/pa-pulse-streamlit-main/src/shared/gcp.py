"""Shared GCP utilities for all pages."""

import re
import google.auth
from google.cloud import bigquery

TENANT = "paops"

_EDP_PAOPS_PATTERN = re.compile(r"^edp-\w+-restrict-paops$")
try:
    _, _auth_project = google.auth.default()
    if not _EDP_PAOPS_PATTERN.match(_auth_project or ""):
        _auth_project = None
except Exception:
    _auth_project = None

# EDP 1.5 compute project: edp-{ENV}-restrict-paops
COMPUTE_PROJECT_ID = _auth_project or "edp-pdev-restrict-paops"
ENV = COMPUTE_PROJECT_ID.split("-")[1]        # pdev | pqa | prod
_restrict = COMPUTE_PROJECT_ID.split("-")[2]  # restrict

# Storage project where tables live: edp-{ENV}-restrict-pbmstorage
STORAGE_PROJECT_ID = f"edp-{ENV}-{_restrict}-pbmstorage"
BQ_DATASET = "edp_paops_cnsv"

# BigQuery connection
def connect_bigquery():
    credentials, _ = google.auth.default()
    return bigquery.Client(project=COMPUTE_PROJECT_ID, credentials=credentials)
