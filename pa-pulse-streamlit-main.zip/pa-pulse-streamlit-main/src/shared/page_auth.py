"""Per-page AD group access control for Streamlit pages.

Usage at the top of any page's main.py:

    from shared.page_auth import require_groups
    require_groups("app-paops-streamlit-pdev-user")

If the user's session does not include any of the required groups, an
access-denied message is rendered and st.stop() is called so nothing
below the check is executed.

Skipped entirely when DEBUG_AUTH=1 (local dev without SSO).
"""

import os
import pathlib

import jwt
import streamlit as st
from dotenv import load_dotenv

load_dotenv()

_ACCESS_REQUEST_FORM = pathlib.Path(__file__).resolve().parents[2] / "Streamlit AD Group Access.docx"


def _cn(group: str) -> str:
    """Return a normalized short name from an AD group value."""
    group = str(group).strip()
    if group.upper().startswith("CN="):
        group = group.split(",", 1)[0][3:]
    return group.casefold()


def require_groups(*required_groups: str) -> None:
    if not required_groups:
        return

    # Local dev bypass — DEBUG_AUTH=1 skips group enforcement
    if os.environ.get("DEBUG_AUTH") == "1":
        return

    cookie_key = os.environ.get("SSO_COOKIE_KEY", "paops-sso")
    secret = os.environ.get("SHARED_SECRET_KEY", "change-me-in-production")

    token = st.context.cookies.get(cookie_key)
    if not token:
        _show_denied(required_groups=required_groups)

    try:
        payload = jwt.decode(token, secret, algorithms=["HS256"])
    except jwt.PyJWTError:
        _show_denied(required_groups=required_groups)

    # Normalise to short CN names regardless of whether the JWT stores full DNs or short names
    raw_groups = payload.get("groups", [])
    if isinstance(raw_groups, str):
        raw_groups = [raw_groups]
    user_groups = {_cn(group) for group in raw_groups}
    normalized_required_groups = {_cn(group) for group in required_groups}
    if not user_groups.intersection(normalized_required_groups):
        _show_denied(
            email=payload.get("email", ""),
            firstname=payload.get("firstname", ""),
            required_groups=required_groups,
        )


def _show_denied(
    email: str = "",
    firstname: str = "",
    required_groups: tuple = (),
) -> None:
    st.markdown("<h3 style='color:#CC0000;'>Access Denied</h3>", unsafe_allow_html=True)

    if email:
        st.markdown(f"Logged in as **{email}**")

    st.markdown("You do not have permission to view this page.")

    if required_groups:
        st.markdown("**Required AD group(s):**")
        for g in required_groups:
            st.markdown(f"- `{g}`")

    if _ACCESS_REQUEST_FORM.is_file():
        st.download_button(
            "Download AD group access request form",
            data=_ACCESS_REQUEST_FORM.read_bytes(),
            file_name=_ACCESS_REQUEST_FORM.name,
            mime="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
            key="download_ad_group_access_form",
        )
    else:
        st.caption("Contact your administrator to request access.")
    st.stop()
