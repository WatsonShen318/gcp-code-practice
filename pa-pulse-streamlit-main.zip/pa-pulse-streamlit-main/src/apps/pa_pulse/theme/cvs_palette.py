import copy
import plotly.io as pio

# ── Core palette ──────────────────────────────────────────────────────────────
CVS = {
    "red":         "#CC0000",
    "dark_red":    "#8B0000",
    "bright_red":  "#E53935",
    "light_red":   "#EF9A9A",
    "pale_red":    "#FFCDD2",
    "charcoal":    "#231F20",
    "gold":        "#F8AE2D",
    "gold_dark":   "#E09000",
    "light_gray":  "#F2F2F2",
    "bg":          "#F7F7F7",
    "white":       "#FFFFFF",
    "mid_gray":    "#9E9E9E",
    "dark_gray":   "#424242",
    # GSO teal family
    "teal":        "#00897B",
    "dark_teal":   "#004D40",
    "mid_teal":    "#26A69A",
    "light_teal":  "#80CBC4",
    "pale_teal":   "#B2DFDB",
    # extra
    "blue_gray":   "#546E7A",
}

# Plotly color sequence
COLOR_SEQ = [
    CVS["red"], CVS["teal"], CVS["gold"], CVS["charcoal"],
    CVS["dark_red"], CVS["mid_teal"], CVS["light_red"], CVS["mid_gray"],
]

# Source brand colors
SRC_COLORS = {"CSO": CVS["red"], "GSO": CVS["teal"]}

# Per-source segment colors for the PAIT OG View funnel
FUNNEL_SEG = {
    "CSO": {
        "epa":           "#8B0000",
        "non_epa":       "#EF9A9A",
        "rules_auto":    "#CC0000",
        "model_auto":    "#E53935",
        "human":         "#FFCDD2",
        "approval":      "#4E342E",
        "denial":        "#231F20",
        "admin":         "#9E9E9E",
        "appeal_apr":    "#F8AE2D",
        "appeal_other":  "#BDBDBD",
        "cost":          "#CC0000",
        "aht":           "#E53935",
    },
    "GSO": {
        "epa":           "#004D40",
        "non_epa":       "#80CBC4",
        "rules_auto":    "#00897B",
        "model_auto":    "#26A69A",
        "human":         "#B2DFDB",
        "approval":      "#1B5E20",
        "denial":        "#37474F",
        "admin":         "#90A4AE",
        "appeal_apr":    "#F8AE2D",
        "appeal_other":  "#BDBDBD",
        "cost":          "#00897B",
        "aht":           "#26A69A",
    },
}

# Model colors — no "General GenAI" (combined into GLP GenAI)
MODEL_COLORS = {
    "GLP GenAI":             CVS["dark_red"],
    "Predictive":            CVS["gold"],
    "Override":              CVS["charcoal"],
    "DLT":                   CVS["teal"],
    "Attachment Automation": CVS["mid_teal"],
    "Rules / System Only":   CVS["mid_gray"],
}


def apply_cvs_template():
    tmpl = copy.deepcopy(pio.templates["plotly_white"])
    tmpl.layout.font = dict(
        family="'Inter', 'Helvetica Neue', Arial, sans-serif",
        color=CVS["charcoal"],
    )
    tmpl.layout.colorway     = COLOR_SEQ
    tmpl.layout.paper_bgcolor = CVS["white"]
    tmpl.layout.plot_bgcolor  = CVS["white"]
    pio.templates["cvs"]      = tmpl
    pio.templates.default     = "cvs"


# ── CSS ───────────────────────────────────────────────────────────────────────
CSS = """
<style>
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&display=swap');

/* Base font */
html, body, [class*="css"], .stApp {
    font-family: 'Inter', 'Helvetica Neue', Arial, sans-serif !important;
}

/* ── Expand main content to full browser width ── */
.block-container {
    max-width: 100% !important;
    padding-left: 1.5rem !important;
    padding-right: 1.5rem !important;
}

/* ── Tighten column gap for chart rows ── */
div[data-testid="stHorizontalBlock"] {
    gap: 0.3rem !important;
}
div[data-testid="stColumn"] {
    min-width: 0 !important;
    padding-left: 0 !important;
    padding-right: 0 !important;
}

/* ── App header ── */
.pa-header {
    background: linear-gradient(130deg, #CC0000 0%, #8B0000 60%, #231F20 100%);
    border-radius: 12px;
    padding: 26px 32px 22px 32px;
    margin-bottom: 18px;
    box-shadow: 0 4px 24px rgba(204,0,0,0.30);
}
.pa-header h1 {
    color: #fff !important;
    margin: 0 0 4px 0;
    font-size: 48px;
    font-weight: 900;
    letter-spacing: -1px;
    line-height: 1.05;
    font-family: 'CVS Health Sans', 'Inter', 'Helvetica Neue', Arial, sans-serif !important;
}
.pa-header .punch {
    color: rgba(255,255,255,0.92);
    margin: 4px 0 10px 0;
    font-size: 15px;
    font-weight: 600;
    letter-spacing: 0.01em;
}
.pa-header .dev-credit {
    color: rgba(255,255,255,0.85);
    margin: 0;
    font-size: 13px;
    font-weight: 700;
    letter-spacing: 0.03em;
}
.pa-header .meta-row {
    color: rgba(255,255,255,0.65);
    margin: 0;
    font-size: 12px;
    font-weight: 500;
}

/* ── Tab styling ── */
button[data-baseweb="tab"] {
    font-family: 'Inter', sans-serif !important;
    font-size: 13px;
    font-weight: 600;
    letter-spacing: 0.02em;
    color: #666 !important;
}
button[data-baseweb="tab"][aria-selected="true"] {
    border-bottom: 3px solid #CC0000 !important;
    color: #CC0000 !important;
}

/* ── Primary button ── */
div[data-testid="stButton"] > button[kind="primary"] {
    background: linear-gradient(135deg, #CC0000, #8B0000);
    border: none;
    color: white;
    font-family: 'Inter', sans-serif;
    font-weight: 700;
    font-size: 14px;
    padding: 0.55rem 1.5rem;
    border-radius: 8px;
    transition: all 0.18s ease;
    box-shadow: 0 2px 8px rgba(204,0,0,0.22);
}
div[data-testid="stButton"] > button[kind="primary"]:hover {
    background: linear-gradient(135deg, #E00000, #AA0000);
    transform: translateY(-1px);
    box-shadow: 0 5px 16px rgba(204,0,0,0.35);
}

/* ── Metric card ── */
.cvs-metric {
    background: #ffffff;
    border-left: 4px solid #CC0000;
    border-radius: 10px;
    padding: 14px 16px 12px 16px;
    box-shadow: 0 2px 10px rgba(0,0,0,0.07);
    margin-bottom: 10px;
    transition: box-shadow 0.15s;
}
.cvs-metric:hover { box-shadow: 0 4px 18px rgba(0,0,0,0.12); }
.cvs-metric-gold  { border-left-color: #F8AE2D !important; }
.cvs-metric-teal  { border-left-color: #00897B !important; }
.cvs-metric-gray  { border-left-color: #9E9E9E !important; }
.cvs-metric-label {
    font-size: 16px;
    font-weight: 700;
    color: #6B6B6B;
    text-transform: uppercase;
    letter-spacing: 0.06em;
}
.cvs-metric-value {
    font-size: 34px;
    font-weight: 800;
    color: #231F20;
    line-height: 1.1;
    margin-top: 4px;
}
.cvs-metric-sub {
    font-size: 13px;
    color: #9E9E9E;
    margin-top: 4px;
    font-weight: 500;
}

/* ── Section header ── */
.cvs-section {
    display: flex;
    align-items: center;
    gap: 10px;
    margin: 18px 0 10px 0;
}
.cvs-section-bar {
    width: 4px;
    height: 22px;
    background: #CC0000;
    border-radius: 2px;
    flex-shrink: 0;
}
.cvs-section-title {
    font-size: 20px;
    font-weight: 700;
    color: #231F20;
}

/* ── OG chart column wrapper ── */
.og-col {
    background: #fff;
    border-radius: 10px;
    box-shadow: 0 2px 10px rgba(0,0,0,0.06);
    overflow: hidden;
}

/* ── Sidebar ── */
[data-testid="stSidebar"] {
    background: #FAFAFA !important;
    border-right: 1px solid #EBEBEB;
}
[data-testid="stSidebar"] [data-testid="stMarkdownContainer"] p {
    font-size: 13px;
}

/* ── Sidebar filter labels — uniform font size + CVS sans-serif ── */
[data-testid="stSidebar"] label,
[data-testid="stSidebar"] .stSelectbox label,
[data-testid="stSidebar"] .stMultiSelect label,
[data-testid="stSidebar"] .stDateInput label,
[data-testid="stSidebar"] small,
[data-testid="stSidebar"] p {
    font-size: 12px !important;
    font-family: 'Inter', 'Helvetica Neue', Arial, sans-serif !important;
}
</style>
"""
