import os
import pathlib
import sys
import time as _time
import datetime
from concurrent.futures import ThreadPoolExecutor

import google.auth
import pandas as pd
from shared.gcp import COMPUTE_PROJECT_ID
import plotly.graph_objects as go
import plotly.io as _pio
import streamlit as st
import streamlit.components.v1 as _components
from google.cloud import bigquery
from src.config import Config

# Make `theme/` (sibling folder) importable without turning this app into a package.
sys.path.insert(0, str(pathlib.Path(__file__).parent))

from theme.cvs_palette import (
    CSS, CVS, FUNNEL_SEG, MODEL_COLORS, SRC_COLORS, apply_cvs_template
)
from shared.page_auth import require_groups

require_groups(*Config.page_allowed_groups)

# Page chrome (st.set_page_config is owned by Home.py for the whole hub).
st.markdown(CSS, unsafe_allow_html=True)
apply_cvs_template()

_HERE = pathlib.Path(__file__).parent

# ── BQ client ─────────────────────────────────────────────────────────────────
@st.cache_resource
def _bq_client():
    try:
        creds, _ = google.auth.default()
        return bigquery.Client(project=COMPUTE_PROJECT_ID, credentials=creds), None
    except Exception as exc:
        return None, str(exc)

_BENCH_ENABLED = os.environ.get("PAPULSE_BENCH") == "1"


def _bench_emit(**fields) -> None:
    if not _BENCH_ENABLED:
        return
    import json as _json
    print("[BENCH] " + _json.dumps(fields, default=str), flush=True)


@st.cache_data(ttl=3600, persist="disk")
def run_query(sql: str, _tag: str = "") -> pd.DataFrame:
    client, err = _bq_client()
    if err:
        raise RuntimeError(err)
    _t0 = _time.perf_counter()
    job = client.query(sql)
    df = job.to_dataframe()
    _dt_ms = int((_time.perf_counter() - _t0) * 1000)
    _bq_ms = None
    try:
        if job.started and job.ended:
            _bq_ms = int((job.ended - job.started).total_seconds() * 1000)
    except Exception:
        pass
    _bench_emit(
        event="query",
        tag=_tag or "ad-hoc",
        total_ms=_dt_ms,
        bq_ms=_bq_ms,
        rows=len(df),
        cols=len(df.columns),
        bytes_processed=getattr(job, "total_bytes_processed", None),
    )
    return df

@st.cache_data(ttl=86400, persist="disk")
def load_filter_options() -> dict:
    client, err = _bq_client()
    if err:
        return {}
    try:
        sql = (_HERE / "queries" / "filter_options.sql").read_text()
        df = client.query(sql).to_dataframe()
        return {
            col: sorted(grp["col_value"].dropna().astype(str).tolist())
            for col, grp in df.groupby("col_name")
        }
    except Exception:
        return {}

# ── SQL templates ─────────────────────────────────────────────────────────────
_PAIT_OG_SQL      = (_HERE / "queries" / "pait_og_view.sql").read_text()
_PAIT_FALLOUT_SQL = (_HERE / "queries" / "pait_og_fallout.sql").read_text()
_PAIT_RAW_SQL     = (_HERE / "queries" / "pait_og_raw.sql").read_text()
_TRENDS_SQL       = (_HERE / "queries" / "trends.sql").read_text()
_SIZING_SQL        = (_HERE / "queries" / "sizing_view.sql").read_text()
_SIZING_DETAIL_SQL = (_HERE / "queries" / "sizing_detail.sql").read_text()
_WALKAWAY_SQL      = (_HERE / "queries" / "walkaway.sql").read_text()

# The join CTE block is identical across all 5 kc_pa_data queries.
# When no MACRO_TYPE filter is active we can skip both LEFT JOINs entirely
# because MACRO_TYPE never appears in the outer SELECT and won't be in extra_filters.
_KC_CTE_WITH_JOINS = (
    "  LEFT JOIN `edp-prod-restrict-pbmstorage.edp_customer_pbmedh_cnsv.V_PRIOR_ATHZN_MAIN` pa_main\n"
    "    ON kc.CASE_ID = pa_main.PRIOR_ATHZN_NBR\n"
    "  LEFT JOIN `edp-prod-restrict-pbmstorage.edp_customer_pbmedh_cnsv.V_CAS_PAORXCLAIM` config_macro_dtl\n"
    "    ON REPLACE(pa_main.APPLD_MACROS_TXT, \"'\", \"\") = config_macro_dtl.PRIOR_ATHZN_OVRD_ID\n"
    "   AND TRIM(UPPER(config_macro_dtl.RSLTN_TYP_CD)) = 'APPROVED'"
)
_KC_CTE_NO_JOINS = (
    "  -- joins skipped: MACRO_TYPE filter not active"
)

# The CASE expression and kc.* EXCEPT(MACRO_TYPE) are also unneeded without joins.
_KC_SELECT_WITH_JOINS = (
    "  SELECT\n"
    "    kc.* EXCEPT(MACRO_TYPE),\n"
    "    CASE\n"
    "      WHEN kc.PA_SOURCE = 'GSO' THEN 'GSO-MHK'\n"
    "      WHEN config_macro_dtl.PARTL_IND = 1 THEN 'PARTIAL'\n"
    "      WHEN ARRAY_LENGTH(SPLIT(REPLACE(TRIM(pa_main.APPLD_MACROS_TXT), \"'\", \"\"), ',')) > 1\n"
    "        THEN 'MULTIPLE MACROS'\n"
    "      WHEN pa_main.APPLD_MACROS_TXT IS NOT NULL\n"
    "       AND TRIM(pa_main.APPLD_MACROS_TXT) <> '' THEN 'FULL'\n"
    "      ELSE NULL\n"
    "    END AS MACRO_TYPE\n"
    "  FROM `edp-pdev-restrict-pbmstorage.edp_paops_enr.kc_pa_data` kc"
)
_KC_SELECT_NO_JOINS = (
    "  SELECT *\n"
    "  FROM `edp-pdev-restrict-pbmstorage.edp_paops_enr.kc_pa_data` kc"
)

def _strip_joins(sql: str) -> str:
    """Return sql with the two expensive LEFT JOINs removed from the kc_pa_data CTE."""
    return sql.replace(_KC_SELECT_WITH_JOINS, _KC_SELECT_NO_JOINS, 1) \
              .replace(_KC_CTE_WITH_JOINS,    _KC_CTE_NO_JOINS,    1)

# ── Helpers ───────────────────────────────────────────────────────────────────
def fmt(n, currency=False, pct=False):
    if n is None or (isinstance(n, float) and pd.isna(n)):
        return "-"
    if pct:
        return f"{n:.1f}%"
    prefix = "$" if currency else ""
    abs_n = abs(n)
    if abs_n >= 1_000_000_000:
        return f"{prefix}{n/1_000_000_000:.1f}B"
    if abs_n >= 1_000_000:
        return f"{prefix}{n/1_000_000:.1f}M"
    if abs_n >= 1_000:
        return f"{prefix}{n/1_000:.0f}K"
    return f"{prefix}{n:,.0f}"

def metric_card(col, label, value, sub=None, accent=None):
    ac = f" cvs-metric-{accent}" if accent else ""
    sub_html = f'<div class="cvs-metric-sub">{sub}</div>' if sub else ""
    col.markdown(
        f'<div class="cvs-metric{ac}">'
        f'<div class="cvs-metric-label">{label}</div>'
        f'<div class="cvs-metric-value">{value}</div>'
        f'{sub_html}</div>',
        unsafe_allow_html=True,
    )

def section_header(title, color=None):
    c = color or CVS["red"]
    st.markdown(
        f'<div class="cvs-section">'
        f'<div class="cvs-section-bar" style="background:{c}"></div>'
        f'<div class="cvs-section-title">{title}</div>'
        f'</div>',
        unsafe_allow_html=True,
    )

def _flow_section(label, color=None):
    c = color or CVS["red"]
    st.markdown(
        f'<div style="display:flex;align-items:center;gap:8px;margin:16px 0 8px 0;">'
        f'<div style="width:3px;height:18px;background:{c};border-radius:2px;flex-shrink:0;"></div>'
        f'<span style="font-size:16px;font-weight:700;color:{CVS["charcoal"]};">{label}</span>'
        f'</div>',
        unsafe_allow_html=True,
    )

def _gv(row, col):
    v = row.get(col, 0)
    if v is None or (isinstance(v, float) and pd.isna(v)):
        return 0
    return int(v)

def _gf(row, col):
    v = row.get(col, 0.0)
    if v is None or (isinstance(v, float) and pd.isna(v)):
        return 0.0
    return float(v)

# ── Filter builder ────────────────────────────────────────────────────────────
def build_filters(f: dict, include_appeal_filter: bool = True) -> str:
    clauses = []

    def _in(col, vals):
        if vals:
            v = ", ".join(f"'{x}'" for x in vals)
            clauses.append(f"AND {col} IN ({v})")

    # Source / Origin
    _in("PA_SOURCE",              f.get("pa_sources"))
    _in("LINE_OF_BUSINESS",       f.get("lobs"))
    _in("PA_ORIGIN_CD",           f.get("origins"))
    _in("EPA_NON_EPA_SPLIT",      f.get("epa_split"))

    # Resolution / Decision
    _in("ORGNL_RSLTN_CD",           f.get("orgnl_resolutions"))
    _in("FNL_RSLTN_CD",             f.get("fnl_resolutions"))
    _in("REVIEW_TYPE",              f.get("review_types"))
    _in("INITIAL_DECISION",         f.get("initial_decisions"))
    _in("AUTO_SCORE_RESULT_STATUS", f.get("auto_score_results"))
    _in("APPEAL_TYPE",              f.get("appeal_types"))
    _in("INITIAL_APPROVAL_PATH",    f.get("initial_approval_paths"))
    _in("FINAL_APPROVAL_PATH",      f.get("final_approval_paths"))

    # Drug
    _in("DRUG_TYPE",   f.get("drug_types"))
    _in("DRUG_NAME",   f.get("drug_names"))
    _in("GPI_CLS_NM",  f.get("gpi_cls_nms"))
    _in("GPI_4_CD",    f.get("gpi_4_cds"))
    _in("GPI_10_CD",   f.get("gpi_10_cds"))

    # ePA & Criteria
    _in("EPA_FALLOUT_STEP",     f.get("epa_fallout_steps"))
    _in("EPA_FALLOUT_REASON",   f.get("epa_fallout_reasons"))
    _in("PAC_CD",               f.get("pac_cds"))
    _in("PAC_CD_DESC",          f.get("pac_cd_descs"))
    _in("QSET_NBR",             f.get("qset_nbrs"))
    _in("QSET_NBR_DESC",        f.get("qset_nbr_descs"))
    _in("RFRNC_NBR",            f.get("rfrnc_nbrs"))
    _in("RFRNC_NBR_CRTRA_NM",   f.get("rfrnc_nbr_crtra_nms"))
    _in("MACRO_TYPE",           f.get("macro_types"))

    # Formulary & Fill Type
    _in("PA_FILL_TYPE",     f.get("pa_fill_types"))
    _in("UM_TYP_CD",        f.get("um_typ_cds"))
    _in("FORMULARY_NAME",   f.get("formulary_names"))
    _in("FORMULARY_STATUS", f.get("formulary_statuses"))
    _in("BNFT_PLAN_NM",     f.get("bnft_plan_nms"))

    formulary_pa_flg = f.get("formulary_pa_flg", "All")
    if formulary_pa_flg == "Yes":
        clauses.append("AND CAST(FORMULARY_PA_FLG AS STRING) IN ('true','True','1','Y')")
    elif formulary_pa_flg == "No":
        clauses.append("AND CAST(FORMULARY_PA_FLG AS STRING) IN ('false','False','0','N')")

    # Case Attributes
    _in("STD_CSTM_CRTRA_CD", f.get("std_cstm_criteria"))

    sgm = f.get("sgm_crtra_ind", "All")
    if sgm == "Y only":
        clauses.append("AND SGM_CRTRA_IND = 'Y'")
    elif sgm == "N only":
        clauses.append("AND SGM_CRTRA_IND = 'N'")

    att = f.get("has_attachment", "All")
    if att == "Y only":
        clauses.append("AND HAS_ATTACHMENT_IND = 'Y'")
    elif att == "N only":
        clauses.append("AND HAS_ATTACHMENT_IND = 'N'")

    req_att = f.get("requires_attachment", "All")
    if req_att == "Y only":
        clauses.append("AND REQUIRES_ATTACHMENT_IND = 'Y'")
    elif req_att == "N only":
        clauses.append("AND REQUIRES_ATTACHMENT_IND = 'N'")

    re_auth = f.get("re_auth", "All")
    if re_auth == "Re-auth Only":
        clauses.append("AND RE_AUTHORIZED_PA_FLAG = 'Y'")
    elif re_auth == "New PAs Only":
        clauses.append("AND RE_AUTHORIZED_PA_FLAG = 'N'")

    # Account
    _in("LVL0_ACCT_NM",  f.get("lvl0_acct_nms"))
    _in("LVL1_ACCT_NM",  f.get("lvl1_acct_nms"))
    _in("LVL1_ACCT_ID",  f.get("lvl1_acct_ids"))
    _in("PAG_CD",        f.get("pag_cds"))
    _in("PAG_CD_DESC",   f.get("pag_cd_descs"))

    aetna_flg = f.get("aetna_only", "All")
    if aetna_flg == "Aetna Only":
        clauses.append("AND AETNA_FLAG = 'Y'")
    elif aetna_flg == "Non-Aetna Only":
        clauses.append("AND AETNA_FLAG = 'N'")

    # Appeals scope
    if include_appeal_filter:
        appeal_scope = f.get("appeal_scope", "Original PAs Only")
        if appeal_scope == "Original PAs Only":
            clauses.append("AND APPEAL_IND = 0")
        elif appeal_scope == "Appeals Only":
            clauses.append("AND APPEAL_IND > 0")

    # Auto Approval indicator
    aa = f.get("auto_approval_ind", "All")
    if aa == "Y only (Auto-Approved)":
        clauses.append("AND AUTO_APPROVAL = 'Y'")
    elif aa == "N only (Human-Reviewed)":
        clauses.append("AND AUTO_APPROVAL = 'N'")

    return "\n".join(clauses)

# ── Session state ─────────────────────────────────────────────────────────────
# Per-tab query mapping used by the Evaluate block to fetch only what's needed
# for the currently-visible view (Phase 1 lazy loading).
_VIEW_QUERIES = {
    "PAIT OG View": ("pait_og_df", "pait_fallout_df", "walkaway_df"),
    "Sizing View":  ("sizing_df", "sizing_detail_df"),
    "Trends":       ("trends_df",),
}
_ALL_QUERY_KEYS = tuple(k for keys in _VIEW_QUERIES.values() for k in keys)

for _k, _v in {
    "pait_og_df": None, "pait_fallout_df": None,
    "trends_df": None, "pait_raw_df": None, "sizing_df": None,
    "sizing_detail_df": None, "walkaway_df": None, "has_run": False,
    "_last_filter_key": None,
    # Per-query filter-key: tracks which _filter_key each df was fetched under.
    # Enables lazy re-fetch when a view is displayed but its dfs are stale.
    **{f"_qk_{k}": None for k in _ALL_QUERY_KEYS},
}.items():
    if _k not in st.session_state:
        st.session_state[_k] = _v

# ── Load dynamic filter options (cached 24h) ──────────────────────────────────
_opts = load_filter_options()

def _opt(key):
    return _opts.get(key, [])

# ── SIDEBAR ────────────────────────────────────────────────────────────────────
ALL_LOBS = [
    "CSO - Commercial", "CSO - Specialty", "CSO - Medicaid", "CSO - Data Entry",
    "GSO - PDP", "GSO - MAPD", "GSO - OD",
]

with st.sidebar:
    st.markdown(
        f'<div style="padding:18px 4px 12px 4px;">'
        f'<div style="font-size:32px;font-weight:900;color:{CVS["red"]};'
        f'letter-spacing:-0.5px;line-height:1.1;'
        f'font-family:\'CVS Health Sans\',\'Inter\',\'Helvetica Neue\',sans-serif;">'
        f'PA Pulse</div>'
        f'<div style="font-size:12px;font-weight:600;color:{CVS["charcoal"]};'
        f'margin-top:6px;line-height:1.4;">'
        f'Unified CGSO Prior Authorization Intelligence &mdash; '
        f'Real-time insights for smarter PA decisions'
        f'</div>'
        f'<div style="font-size:11px;font-weight:500;color:{CVS["mid_gray"]};margin-top:8px;">'
        f'CSO &nbsp;&middot;&nbsp; GSO &nbsp;&middot;&nbsp; 2025-01-01 to present'
        f'</div>'
        f'<div style="font-size:11px;font-weight:700;color:{CVS["dark_gray"]};margin-top:6px;">'
        f'Developed by Mike &amp; Mehul\'s Team &nbsp;&middot;&nbsp; PAIT Analytics'
        f'</div>'
        f'</div>',
        unsafe_allow_html=True,
    )

    with st.expander("About this dashboard", expanded=False):
        st.markdown(
            """
**What is PA Pulse?**
PA Pulse is a unified prior authorization analytics dashboard for CSO and GSO operations.
It mirrors the PAIT dashboard with live data for both CAS (CSO) and MHK (GSO) sources.

**Coverage**
- **CSO** — CommercialRx / CAS prior auth cases
- **GSO** — MHK prior auth cases (PDP, MAPD, Part B)
- Date scope: 2025-01-01 to present

**Filters**
All sidebar filters apply to every tab. Empty multiselect = **all values** (no filter applied).
""",
        )

    st.divider()

    st.markdown(
        f'<div style="border-left:3px solid {CVS["red"]};background:{CVS["pale_red"]}22;'
        f'border-radius:0 4px 4px 0;padding:7px 10px;margin-bottom:10px;">'
        f'<span style="font-size:11px;font-weight:600;color:{CVS["charcoal"]};">'
        f'Select filters below, then click '
        f'<b style="color:{CVS["red"]};">Evaluate</b> to apply</span>'
        f'</div>',
        unsafe_allow_html=True,
    )
    evaluate = st.button("Evaluate", type="primary", use_container_width=True)

    _, bq_err = _bq_client()
    if bq_err:
        st.error("BigQuery auth failed")
        st.code("gcloud auth application-default login")

    st.markdown("<div style='margin-top:20px'></div>", unsafe_allow_html=True)

    # Date Range
    st.markdown(
        f'<p style="font-size:11px;font-weight:700;text-transform:uppercase;'
        f'letter-spacing:0.07em;color:{CVS["red"]};margin-bottom:4px;">Date Range</p>',
        unsafe_allow_html=True,
    )
    # Default end-date = last day of previous full month
    _today          = datetime.date.today()
    _prev_month_end = _today.replace(day=1) - datetime.timedelta(days=1)

    _min_date = datetime.date(2024, 1, 1)
    start_date = st.date_input(
        "Start date", value=_min_date,
        min_value=_min_date, max_value=_today,
        label_visibility="collapsed",
    )
    end_date = st.date_input(
        "End date", value=_prev_month_end,
        min_value=_min_date, max_value=_today,
        label_visibility="collapsed",
    )
    st.caption(f"{start_date}  →  {end_date}")
    st.caption("Data available from 2024 onwards only.")

    # ── Source & Origin ────────────────────────────────────────────────────────
    with st.expander("Source & Origin", expanded=True):
        pa_sources = st.multiselect("PA Source", ["CSO", "GSO"], default=[], placeholder="All")
        lobs       = st.multiselect("Line of Business", ALL_LOBS, default=[], placeholder="All")
        origins    = st.multiselect("PA Origin", ["EPA", "NON EPA"], default=[], placeholder="All")
        aetna_only = st.selectbox(
            "Aetna Flag", ["All", "Aetna Only", "Non-Aetna Only"],
        )
    # ePA Entry Channel filter removed per request
    epa_split = []

    # ── Resolution & Decision ──────────────────────────────────────────────────
    with st.expander("Resolution & Decision", expanded=False):
        appeal_scope = st.selectbox(
            "Cases to Include",
            ["All Cases (incl. Appeals)", "Original PAs Only", "Appeals Only"],
        )
        auto_approval_ind = st.selectbox(
            "Auto Approval",
            ["All", "Y only (Auto-Approved)", "N only (Human-Reviewed)"],
        )
        orgnl_resolutions = st.multiselect(
            "Original Resolution",
            ["APPROVAL", "DENIAL", "ADMIN DENIAL", "DISMISS"],
            default=[], placeholder="All",
        )
        fnl_resolutions = st.multiselect(
            "Final Resolution",
            ["APPROVAL", "DENIAL", "ADMIN DENIAL", "DISMISS"],
            default=[], placeholder="All",
        )
        review_types = st.multiselect(
            "Review Type",
            ["AUTO_APPROVAL", "EPA_HUMAN_REVIEW", "NON_EPA_HUMAN_REVIEW", "OTHER"],
            default=[], placeholder="All",
        )
        initial_decisions = st.multiselect(
            "Initial Decision",
            ["AUTO_APPROVAL", "EPA_HUMAN_APPROVAL", "EPA_HUMAN_DENIAL",
             "EPA_HUMAN_ADMIN_DENIAL", "NON_EPA_HUMAN_APPROVAL", "NON_EPA_HUMAN_DENIAL",
             "NON_EPA_HUMAN_ADMIN_DENIAL", "OTHER"],
            default=[], placeholder="All",
        )
        appeal_types = st.multiselect(
            "Appeal Type",
            ["DENIAL_NO_APPEAL", "OTHER_NO_APPEAL", "DURABLE_DENIAL",
             "APPROVE_ON_APPEAL", "APPEAL_ON_ORGNL_APPROVE", "OTHER"],
            default=[], placeholder="All",
        )
        initial_approval_paths = st.multiselect(
            "Initial Approval Path", _opt("initial_approval_path"),
            default=[], placeholder="All",
        )
        final_approval_paths = st.multiselect(
            "Final Approval Path", _opt("final_approval_path"),
            default=[], placeholder="All",
        )

    # ── ePA & Criteria ─────────────────────────────────────────────────────────
    with st.expander("ePA & Criteria", expanded=False):
        _ePA_RESULTS = ["APPROVAL", "DENIAL", "Unscored"]
        auto_score_results = st.multiselect(
            "ePA Scoring Result", _ePA_RESULTS, default=[], placeholder="All",
        )
        epa_fallout_steps   = st.multiselect("ePA Loop 2 Fallout Step",   _opt("epa_fallout_step"),   default=[], placeholder="All")
        epa_fallout_reasons = st.multiselect("ePA Loop 2 Fallout Reason", _opt("epa_fallout_reason"), default=[], placeholder="All")
        pac_cds        = st.multiselect("PAC Code",             _opt("pac_cd"),         default=[], placeholder="All")
        pac_cd_descs   = st.multiselect("PAC Code Description", _opt("pac_cd_desc"),    default=[], placeholder="All")
        qset_nbrs      = st.multiselect("QSET Number",          _opt("qset_nbr"),       default=[], placeholder="All")
        qset_nbr_descs = st.multiselect("QSET Description",     _opt("qset_nbr_desc"),  default=[], placeholder="All")
        rfrnc_nbrs          = st.multiselect("Criteria Code (Reference #)",         _opt("rfrnc_nbr"),          default=[], placeholder="All")
        rfrnc_nbr_crtra_nms = st.multiselect("Criteria Name (Reference Code Desc)", _opt("rfrnc_nbr_crtra_nm"), default=[], placeholder="All")
        macro_types = st.multiselect("Macro Type", _opt("macro_type"), default=[], placeholder="All")

    # ── Drug ───────────────────────────────────────────────────────────────────
    with st.expander("Drug", expanded=False):
        drug_types   = st.multiselect("Drug Type", ["SPECIALTY", "NON SPECIALTY"], default=[], placeholder="All")
        drug_names   = st.multiselect("Drug Name", _opt("drug_name"), default=[], placeholder="All")
        gpi_cls_nms  = st.multiselect("GPI Class Name", _opt("gpi_cls_nm"), default=[], placeholder="All")
        gpi_4_cds    = st.multiselect("GPI 4 Code",     _opt("gpi_4_cd"),   default=[], placeholder="All")
        gpi_10_cds   = st.multiselect("GPI 10 Code",    _opt("gpi_10_cd"),  default=[], placeholder="All")

    # ── Formulary & Fill Type ──────────────────────────────────────────────────
    with st.expander("Formulary & Fill Type", expanded=False):
        pa_fill_types      = st.multiselect("Fill Type (Target/No/Alt)", _opt("pa_fill_type"),     default=[], placeholder="All")
        um_typ_cds         = st.multiselect("UM Type Code",              _opt("um_typ_cd"),        default=[], placeholder="All")
        formulary_pa_flg   = st.selectbox("Formulary PA Flag", ["All", "Yes", "No"])
        formulary_names    = st.multiselect("Formulary Name",   _opt("formulary_name"),   default=[], placeholder="All")
        formulary_statuses = st.multiselect("Formulary Status", _opt("formulary_status"), default=[], placeholder="All")

    # ── Case Attributes ────────────────────────────────────────────────────────
    with st.expander("Case Attributes", expanded=False):
        _CRT_OPTS = ["CUSTOM", "STANDARD", "UNKNOWN", "OTHER"]
        std_cstm_criteria = st.multiselect(
            "Criteria Type", _CRT_OPTS, default=[], placeholder="All",
        )
        sgm_crtra_ind    = st.selectbox("SGM Criteria Indicator", ["All", "Y only", "N only"])
        has_attachment   = st.selectbox("Has Attachment",         ["All", "Y only", "N only"])
        requires_attachment = st.selectbox("Requires Attachment", ["All", "Y only", "N only"])
        re_auth          = st.selectbox("Re-authorized",  ["All", "Re-auth Only", "New PAs Only"])

    # ── Client Account Details ────────────────────────────────────────────────
    with st.expander("Client Account Details", expanded=False):
        lvl0_acct_nms = st.multiselect(
            "Lvl0 Account Name", _opt("lvl0_acct_nm"), default=[],
            placeholder="All", help="Enterprise / top-level account name",
        )
        lvl1_acct_nms = st.multiselect(
            "Lvl1 Account Name", _opt("lvl1_acct_nm"), default=[],
            placeholder="All", help="Carrier / plan-sponsor account name",
        )
        lvl1_acct_ids = st.multiselect(
            "Lvl1 Account ID", _opt("lvl1_acct_id"), default=[],
            placeholder="All", help="Numeric carrier / plan-sponsor ID",
        )
        bnft_plan_nms = st.multiselect(
            "Benefit Plan", _opt("bnft_plan_nm"), default=[], placeholder="All",
        )
        pag_cds      = st.multiselect("PAG Code",             _opt("pag_cd"),      default=[], placeholder="All")
        pag_cd_descs = st.multiselect("PAG Code Description", _opt("pag_cd_desc"), default=[], placeholder="All")

# ── Shared filter dict ────────────────────────────────────────────────────────
_FILT = dict(
    pa_sources=pa_sources, lobs=lobs, origins=origins, epa_split=epa_split,
    appeal_scope=appeal_scope, auto_approval_ind=auto_approval_ind,
    orgnl_resolutions=orgnl_resolutions, fnl_resolutions=fnl_resolutions,
    review_types=review_types, initial_decisions=initial_decisions,
    auto_score_results=auto_score_results, appeal_types=appeal_types,
    initial_approval_paths=initial_approval_paths, final_approval_paths=final_approval_paths,
    drug_types=drug_types, drug_names=drug_names,
    gpi_cls_nms=gpi_cls_nms, gpi_4_cds=gpi_4_cds, gpi_10_cds=gpi_10_cds,
    epa_fallout_steps=epa_fallout_steps, epa_fallout_reasons=epa_fallout_reasons,
    pac_cds=pac_cds, pac_cd_descs=pac_cd_descs,
    qset_nbrs=qset_nbrs, qset_nbr_descs=qset_nbr_descs,
    rfrnc_nbrs=rfrnc_nbrs, rfrnc_nbr_crtra_nms=rfrnc_nbr_crtra_nms,
    macro_types=macro_types,
    pa_fill_types=pa_fill_types, um_typ_cds=um_typ_cds,
    formulary_pa_flg=formulary_pa_flg,
    formulary_names=formulary_names, formulary_statuses=formulary_statuses,
    std_cstm_criteria=std_cstm_criteria, sgm_crtra_ind=sgm_crtra_ind,
    has_attachment=has_attachment, requires_attachment=requires_attachment,
    re_auth=re_auth,
    lvl0_acct_nms=lvl0_acct_nms, lvl1_acct_nms=lvl1_acct_nms,
    lvl1_acct_ids=lvl1_acct_ids,
    bnft_plan_nms=bnft_plan_nms,
    pag_cds=pag_cds, pag_cd_descs=pag_cd_descs,
    aetna_only=aetna_only,
)

# ── Filter key + per-tab lazy loader ──────────────────────────────────────────
extra     = build_filters(_FILT, include_appeal_filter=True)
extra_raw = build_filters(_FILT, include_appeal_filter=False)
_src_filter = ""
if _FILT.get("pa_sources"):
    _sv = ", ".join(f"'{x}'" for x in _FILT["pa_sources"])
    _src_filter = f"AND PA_SOURCE IN ({_sv})"

_filter_key = (start_date, end_date, extra, extra_raw, _src_filter)

# Skip the two expensive LEFT JOINs when no MACRO_TYPE filter is active —
# the joins exist solely to compute MACRO_TYPE, which is unused in that case.
_maybe_strip = _strip_joins if not _FILT.get("macro_types") else (lambda s: s)


def _sql_for(key: str) -> str:
    """Return the parameterized SQL for a query key, using the current filter set."""
    if key == "pait_og_df":
        return _maybe_strip(_PAIT_OG_SQL).format(start_date=start_date, end_date=end_date, extra_filters=extra)
    if key == "pait_fallout_df":
        return _maybe_strip(_PAIT_FALLOUT_SQL).format(start_date=start_date, end_date=end_date, extra_filters=extra)
    if key == "trends_df":
        return _maybe_strip(_TRENDS_SQL).format(start_date=start_date, end_date=end_date, extra_filters=extra)
    if key == "sizing_df":
        return _maybe_strip(_SIZING_SQL).format(start_date=start_date, end_date=end_date, extra_filters=extra_raw)
    if key == "sizing_detail_df":
        return _maybe_strip(_SIZING_DETAIL_SQL).format(start_date=start_date, end_date=end_date, extra_filters=extra_raw)
    if key == "walkaway_df":
        return _WALKAWAY_SQL.format(start_date=start_date, end_date=end_date, source_filter=_src_filter)
    raise KeyError(key)


def _ensure_loaded(view_keys: tuple[str, ...], force: bool = False, view_name: str = "") -> bool:
    """Load any queries in `view_keys` whose cached filter-key differs from _filter_key.
    Returns True if at least one query was already fresh (or successfully loaded)."""
    stale = [k for k in view_keys
             if force or st.session_state.get(f"_qk_{k}") != _filter_key
             or st.session_state.get(k) is None]
    if not stale:
        return True
    _jobs = {k: _sql_for(k) for k in stale}
    try:
        with st.spinner("Loading data from BigQuery…"):
            _bench_wall_t0 = _time.perf_counter()
            with ThreadPoolExecutor(max_workers=len(_jobs)) as _ex:
                _futures = {k: _ex.submit(run_query, sql, k) for k, sql in _jobs.items()}
                for k, fut in _futures.items():
                    st.session_state[k] = fut.result()
                    st.session_state[f"_qk_{k}"] = _filter_key
        _bench_emit(
            event="evaluate",
            tag=f"VIEW_WALL:{view_name or ','.join(view_keys)}",
            total_ms=int((_time.perf_counter() - _bench_wall_t0) * 1000),
            keys=list(stale),
            start_date=str(start_date),
            end_date=str(end_date),
        )
        st.session_state.has_run = True
        st.session_state._last_filter_key = _filter_key
        return True
    except Exception as exc:
        st.error(f"Query failed: {exc}")
        return False


# ── Active-view selector (replaces top-level st.tabs) ─────────────────────────
# st.segmented_control persists the choice in st.session_state["active_view"],
# so Python knows which view is displayed and only fetches its queries.
# Pre-seed the state key BEFORE the widget renders — passing `default=` triggers
# a first-render state-persist rerun, which briefly destabilizes the DOM and
# makes Playwright's stability detector wait ~10s longer than the real render.
if "active_view" not in st.session_state:
    st.session_state["active_view"] = "PAIT OG View"
active_view = st.segmented_control(
    "View",
    options=list(_VIEW_QUERIES.keys()),
    key="active_view",
    label_visibility="collapsed",
)
if active_view is None:  # segmented_control returns None if all deselected
    active_view = "PAIT OG View"

# Load only the queries needed for the active view. Trigger rules:
#  - Evaluate with same filters → no-op (toast).
#  - Evaluate with new filters → reload the active view's queries.
#  - First load → run the active view's queries with default filters.
#  - View switch to a view whose queries have never been loaded → auto-load.
# Silent filter widget changes (no Evaluate press) do NOT trigger loading,
# to match prior UX where Evaluate is the commit gesture.
_view_dfs_missing = any(st.session_state.get(k) is None for k in _VIEW_QUERIES[active_view])

if evaluate and _filter_key == st.session_state._last_filter_key:
    st.toast("Filters unchanged — showing cached results.", icon="ℹ️")
elif evaluate or not st.session_state.has_run or _view_dfs_missing:
    _ensure_loaded(_VIEW_QUERIES[active_view], force=bool(evaluate), view_name=active_view)

# ── Background prefetch for other views ───────────────────────────────────────
# After the active view is loaded, warm the other views' queries in a daemon
# thread so a tab switch hits @st.cache_data instantly instead of blocking on
# BigQuery. Zero user-visible cost — the current page render is already done
# by the time this thread starts.
def _prefetch_other_views(filter_key, current_view: str) -> None:
    import threading

    def _work():
        try:
            for view, keys in _VIEW_QUERIES.items():
                if view == current_view:
                    continue
                for k in keys:
                    try:
                        # run_query is @st.cache_data-decorated — the result
                        # lands in the process-wide cache. We can't touch
                        # session_state from a bg thread, so we don't bother.
                        run_query(_sql_for(k), k)
                    except Exception:
                        # Never let a prefetch error surface to the user.
                        pass
        except Exception:
            pass

    threading.Thread(target=_work, daemon=True, name="papulse-prefetch").start()


# Only spawn a prefetch when we just successfully loaded the active view.
# Guarded by _last_filter_key match to avoid re-firing on plain reruns.
if (st.session_state.has_run
        and st.session_state._last_filter_key == _filter_key
        and not st.session_state.get("_prefetched_key") == _filter_key):
    st.session_state._prefetched_key = _filter_key
    _prefetch_other_views(_filter_key, active_view)

# ── Header ────────────────────────────────────────────────────────────────────
st.markdown(
    f'<div style="border-left:4px solid {CVS["red"]};padding:6px 12px;'
    f'margin-bottom:12px;background:#fff;border-radius:0 6px 6px 0;">'
    f'<span style="font-size:13px;font-weight:600;color:{CVS["charcoal"]};">'
    f'Adjust sidebar filters and click <b style="color:{CVS["red"]};">Evaluate</b> to refresh data.</span>'
    f'</div>',
    unsafe_allow_html=True,
)

# ── Views ─────────────────────────────────────────────────────────────────────
# active_view (from st.segmented_control above) drives conditional rendering —
# each of the three view blocks below runs only when its view is selected,
# which is what makes per-view lazy query loading possible.

_NOT_RUN_MSG = (
    f'<p style="color:{CVS["mid_gray"]};font-size:15px;margin-top:30px;text-align:center;">'
    f'Adjust filters in the sidebar and click <b>Evaluate</b> to refresh.</p>'
)


# ═══════════════════════════════════════════════════════════════════════════════
# TAB 1 — PAIT OG VIEW
# ═══════════════════════════════════════════════════════════════════════════════
def single_bar(title, segments, height=620, cost=False, annotation_text=None, xlabel=""):
    """Single stacked bar. xlabel is rendered bold via annotation below the chart."""
    fig = go.Figure()
    total_val = sum(max(float(seg.get("value", 0) or 0), 0) for seg in segments)
    for seg in segments:
        v = max(float(seg.get("value", 0) or 0), 0)
        t = fmt(v, currency=cost) if v else ""
        fig.add_trace(go.Bar(
            name=seg["label"],
            x=[""],
            y=[v],
            marker_color=seg["color"],
            text=t,
            textposition="inside",
            insidetextanchor="middle",
            textfont=dict(size=13, color="white",
                          family="Inter, 'Helvetica Neue', sans-serif"),
            hovertemplate=f"<b>{seg['label']}</b>: "
                          f"{'$' if cost else ''}%{{y:,.0f}}<extra></extra>",
            width=0.85,
        ))
    total_label = (annotation_text if annotation_text is not None
                   else (fmt(total_val, currency=cost) if total_val else "0"))
    all_annots = []
    if total_val:
        all_annots.append(dict(
            x=0, y=total_val,
            text=f"<b>{total_label}</b>",
            showarrow=False,
            font=dict(size=15, color=CVS["red"],
                      family="Inter, 'Helvetica Neue', sans-serif"),
            yanchor="bottom", xanchor="center",
            yref="y", xref="x",
        ))
    if xlabel:
        all_annots.append(dict(
            x=0.5, y=0,
            text=f"<b>{xlabel}</b>",
            showarrow=False,
            font=dict(size=14, family="Inter, 'Helvetica Neue', sans-serif",
                      color=CVS["charcoal"]),
            xref="paper", yref="paper",
            xanchor="center", yanchor="top",
        ))
    fig.update_layout(
        barmode="stack", height=height,
        showlegend=False,
        yaxis=dict(visible=False, range=[0, total_val * 1.35] if total_val else None),
        xaxis=dict(showticklabels=False),
        margin=dict(t=24, l=8, r=8, b=44 if xlabel else 12),
        paper_bgcolor="#ffffff", plot_bgcolor="#ffffff",
        bargap=0.10,
        annotations=all_annots,
    )
    return fig


# ─── ePA Loop 2 Fallout helpers ──────────────────────────────────────────────
# Step → category mapping (CSO fallout steps)
_STEP_CATEGORY = {
    "1120": "Duplicate PA Checks",
    "1125": "Duplicate PA Checks",
    "1130": "Duplicate PA Checks",
    "1135": "Default Fallout",
    "1140": "Default Fallout",
    "1145": "Client Blocks",
    "1150": "Outcome / Adjudication Failures",
    "1155": "Macro Failures",
    "1160": "Macro Failures",
    "1165": "Mock Claim Failures",
    "2100": "Attachment Failures",
}

# (Step, reason-keyword) → cleaned reason label
_REASON_OVERRIDES = [
    ("1120", "duplicate", "Duplicate Approved PA for this Member/PAG/PAC"),
    ("1125", "duplicate", "Duplicate Pending PA — Non-ePA Requested & Locked"),
    ("1130", "duplicate", "Duplicate Denied PA"),
    ("1135", None,        None),  # use default
    ("1140", None,        None),  # use default
    ("1145", "block",     "Auto Approval Not Allowed (Client Blocks)"),
    ("1145", "client",    "Auto Approval Not Allowed (Client Blocks)"),
    ("1150", "outcome",   "Could Not Validate Outcome Code"),
    ("1150", "approval term", "Could Not Determine Approval Term"),
    ("1150", "attachment", "PA Has No Attachment / Auto Approval With Attachment Not Allowed"),
    ("1150", "requeue",   "Requeue From Utility"),
    ("1150", "duplicate pending", "Duplicate Pending PA — Auto Approval ePA Duplicate Not Allowed"),
    ("1155", "partial",   "Partial Macro Exists for This PA"),
    ("1155", "no macro",  "No Macros Exist for This PA"),
    ("1155", "requeue",   "Requeue From Utility"),
    ("1160", "override",  "PA Override Macro Failure"),
    ("1160", "macro",     "PA Override Macro Failure"),
    ("1165", "mock",      "Second Mock Claim Adjudication Failure"),
    ("2100", "attachment","Attachments Exist & Auto Approval With Attachments Not Allowed"),
]

def _categorize_step(step_val):
    """Given a step value, return the category label (or 'Other' if unknown)."""
    if step_val is None:
        return "Other"
    s = str(step_val).strip()
    # Extract leading digits (e.g. "1150 Outcome..." → "1150")
    import re
    m = re.match(r"^(\d{3,4})", s)
    if m and m.group(1) in _STEP_CATEGORY:
        return _STEP_CATEGORY[m.group(1)]
    return "Other"

def _step_code(step_val):
    if step_val is None:
        return None
    import re
    m = re.match(r"^(\d{3,4})", str(step_val).strip())
    return m.group(1) if m else None

def _clean_reason(step_val, reason_val):
    """Apply step-specific reason overrides (case-insensitive substring match)."""
    if reason_val is None:
        return reason_val
    code = _step_code(step_val)
    rsn_lc = str(reason_val).lower()
    for s, kw, replacement in _REASON_OVERRIDES:
        if s != code:
            continue
        if kw is None or replacement is None:
            continue
        if kw.lower() in rsn_lc:
            return replacement
    return reason_val

# MHK fallout reason naming standards
_MHK_REASON_MAP = {
    "Fallout_Attachment_Configuration":             "Attachment Configuration",
    "Fallout_Drug_Cluster_Configuration":           "Drug Cluster Configuration",
    "Fallout_Reject_Code_A5":                       "Reject Code A5",
    "Fallout_Diagnosis_Populated":                  "Diagnosis Populated",
    "Fallout_Notes_Configuration":                  "Notes Configuration",
    "Fallout_Reject_Message_Hierarchy":             "Reject Message Hierarchy",
    "Fallout_Company_Carrier_Configuration":        "Carrier Configuration",
    "Fallout_Free_Dependent_Text_Configuration":    "Free Dependent Text Configuration",
    "Fallout_Required_Fields_are_Blank":            "Required Fields Are Blank",
    "Fallout_MSUME_Reject":                         "MSUME Reject",
}

def _clean_mhk_reason(rsn):
    if rsn is None:
        return rsn
    return _MHK_REASON_MAP.get(str(rsn).strip(), str(rsn).strip())


def fallout_hbar(title, df_sub, color, height=380):
    """Horizontal bar for top-N ePA fallout items."""
    if df_sub.empty:
        return None
    top = df_sub.nlargest(15, "cnt").sort_values("cnt")
    fig = go.Figure(go.Bar(
        x=top["cnt"], y=top["fallout_value"],
        orientation="h",
        marker_color=color,
        text=[fmt(v) for v in top["cnt"]],
        textposition="outside",
        textfont=dict(size=9, family="Inter, sans-serif", color=CVS["charcoal"]),
    ))
    fig.update_layout(
        height=height,
        title=dict(
            text=f"<b>{title}</b>",
            font=dict(size=10, family="Inter, 'Helvetica Neue', sans-serif",
                      color=CVS["charcoal"]),
            x=0, xanchor="left",
        ),
        xaxis=dict(visible=False),
        yaxis=dict(tickfont=dict(size=9, family="Inter, sans-serif")),
        margin=dict(t=32, l=4, r=60, b=8),
        paper_bgcolor="#ffffff", plot_bgcolor="#ffffff",
    )
    return fig


if active_view == "PAIT OG View":
    og_sub_funnel, og_sub_raw = st.tabs(["Funnel View", "Raw Data"])

    # ── FUNNEL VIEW ────────────────────────────────────────────────────────────
    with og_sub_funnel:
        if not st.session_state.has_run:
            st.markdown(_NOT_RUN_MSG, unsafe_allow_html=True)
        else:
            og = st.session_state.pait_og_df
            if og is None or og.empty:
                st.warning("No data returned for the selected filters.")
            else:
                # ── Aggregate across all sources (respects sidebar PA Source filter) ─
                def _col(col):
                    return og[col].sum() if col in og.columns else 0
                def _avgcol(col):
                    v = og[col] if col in og.columns else pd.Series(dtype=float)
                    return v[v > 0].mean() if len(v[v > 0]) > 0 else 0.0

                total_pas    = int(_col("total_pas"))
                _wdf = st.session_state.get("walkaway_df")
                if _wdf is not None and not _wdf.empty and _wdf["walkaway_cnt"].sum() > 0:
                    walkaway_cnt = int(_wdf["walkaway_cnt"].sum())
                    walkaway_sav = float(_wdf["walkaway_savings"].sum())
                else:
                    walkaway_cnt = int(_col("walkaway_cnt"))
                    walkaway_sav = 0.0
                total_cost   = float(_col("total_ops_cost"))
                pa_sav       = float(_col("total_savings"))
                total_sav    = pa_sav + walkaway_sav        # UM Program Savings = PA + Walkaway
                roi          = total_sav / total_cost if total_cost else 0
                pa_roi       = pa_sav    / total_cost if total_cost else 0
                avg_aht      = float(_avgcol("avg_aht_seconds"))
                total_handle = float(_col("total_handle_sec"))
                appeal_total = int(_col("appeal_total"))

                # Headline volume = all cases incl. appeals (matches PAIT)
                all_pas_incl_appeals = int(_col("all_pas_incl_appeals")) \
                    if "all_pas_incl_appeals" in og.columns else (total_pas + appeal_total)

                # Additional KPIs per request
                epa_pas_total = int(_col("epa_pas"))
                rules_auto    = int(_col("epa_rules_auto"))
                model_auto    = int(_col("model_auto"))
                raw_auto      = rules_auto + model_auto

                # Per-model auto-approval breakdown (counts can overlap)
                m_genai      = int(_col("auto_genai_cnt"))
                m_predictive = int(_col("auto_predictive_cnt"))
                m_ofu        = int(_col("auto_ofu_cnt"))
                m_dlt        = int(_col("auto_dlt_cnt"))
                m_attach     = int(_col("auto_attachment_cnt"))
                # Approvals = original PA approvals (auto + human)
                total_apr     = int(_col("approvals"))
                # AHT = SUM(total handle seconds) / COUNT(all cases incl. appeals)
                # Compute across sources from raw sums to avoid weighting math.
                _sum_handle = float(og["total_handle_sec"].sum()) if "total_handle_sec" in og.columns else 0.0
                _all_cases  = float(all_pas_incl_appeals)
                aht_avg_seconds = (_sum_handle / _all_cases) if _all_cases else 0.0
                # Median TAT — use weighted median across sources by case count
                if "median_tat_mins" in og.columns and not og["median_tat_mins"].dropna().empty:
                    _w = og["total_pas"].astype(float)
                    _v = og["median_tat_mins"].astype(float)
                    _mask = _v.notna() & (_w > 0)
                    median_tat = float((_v[_mask] * _w[_mask]).sum() / _w[_mask].sum()) \
                                 if _mask.any() else 0.0
                else:
                    median_tat = 0.0

                epa_rate = (epa_pas_total / total_pas * 100) if total_pas else 0
                raw_auto_rate = (raw_auto / total_apr * 100) if total_apr else 0
                cost_per_pa = (total_cost / total_pas) if total_pas else 0

                # KPI cards — 12 cards in 4 rows of 3
                k1, k2, k3 = st.columns(3)
                k4, k5, k6 = st.columns(3)
                k7, k8, k9 = st.columns(3)
                k10, k11, k12 = st.columns(3)
                metric_card(k1, "Total PA Cases",          fmt(all_pas_incl_appeals),
                            "All cases incl. appeals")
                metric_card(k2, "Overall ePA Rate",        f"{epa_rate:.1f}%",
                            "ePAs ÷ Total PAs", accent="teal")
                metric_card(k3, "Raw Auto Approval Rate",  f"{raw_auto_rate:.1f}%",
                            "Auto ÷ All Approvals · Original Review only (excl. appeals)",
                            accent="gold")
                metric_card(k4, "Auto Approvals",          fmt(raw_auto),
                            "Rules + Model auto-approvals · Original Review only",
                            accent="gold")
                _model_sub = (
                    f"{fmt(m_genai)} from Gen AI · "
                    f"{fmt(m_predictive)} from Predictive · "
                    f"{fmt(m_ofu)} from OFU · "
                    f"{fmt(m_dlt)} from DLT · "
                    f"{fmt(m_attach)} from Attachment"
                )
                metric_card(k5, "Model Auto Approvals",    fmt(model_auto),
                            _model_sub,
                            accent="gold")
                metric_card(k6, "Total Ops Cost",          fmt(total_cost, currency=True))
                metric_card(k7, "Ops Cost per PA",
                            fmt(cost_per_pa, currency=True) if cost_per_pa else "-",
                            "Total Ops Cost ÷ Total PAs")
                metric_card(k8, "AHT",
                            f"{aht_avg_seconds:.0f} sec" if aht_avg_seconds else "-",
                            "Total handle time ÷ Total PA cases", accent="gray")
                metric_card(k9, "Median TAT",
                            f"{median_tat/60:.1f} hrs" if median_tat else "-",
                            "Median Resolution − Receipt · Originals only · Approval/Denial only (excl. appeals, admin denials, dismissals)",
                            accent="gray")
                metric_card(k10, "UM Program Savings",     fmt(total_sav, currency=True),
                            accent="gold")
                metric_card(k11, "Overall ROI",
                            f"{roi:.2f}x" if roi else "-",
                            "(PA + Walkaway $) ÷ Ops Cost", accent="gold")
                metric_card(k12, "PA ROI",
                            f"{pa_roi:.2f}x" if pa_roi else "-",
                            "PA Savings ÷ Ops Cost (excl. walkaways)", accent="gold")

                st.markdown("<div style='height:6px'></div>", unsafe_allow_html=True)

                # ── Helper for segment dict ───────────────────────────────────
                def seg(label, col, color):
                    return {"label": label, "value": float(_col(col)), "color": color}

                # ── All 13 charts in a single row (funnel + financial) ───────
                section_header("PA Lifecycle Funnel & Financial Summary")
                sav_target = float(_col("savings_target_fill"))
                sav_no     = float(_col("savings_no_fill"))
                sav_alt    = float(_col("savings_alt_fill"))
                sav_other  = max(0.0, pa_sav - sav_target - sav_no - sav_alt)
                epa_c      = float(_col("orig_epa_cnt"))
                fax_c      = float(_col("orig_fax_cnt"))
                call_c     = float(_col("orig_call_cnt"))
                other_c    = float(_col("orig_other_cnt"))
                aoa        = float(_col("appeal_aoa"))
                dur_den    = float(_col("appeal_dur_den"))
                apl_oth    = float(_col("appeal_other"))

                _cfg = {"displayModeBar": False}

                # Build all 13 figures, then place them inside a horizontally
                # scrollable container so the bars and fonts can be larger.
                # ── Consistent palette ────────────────────────────────────
                # Approvals  → red family   (red, dark_red, mid_red)
                # Denials    → charcoal/gray family
                # Admin/Adj  → blue_gray
                # Appeals    → gold family
                # Savings    → teal family
                C_APR_AUTO_MDL = CVS["dark_red"]
                C_APR_AUTO_RUL = CVS["red"]
                C_APR_EPA_HUM  = CVS["dark_red"]
                C_APR_NON_EPA  = CVS["red"]
                C_DEN_EPA      = CVS["charcoal"]
                C_DEN_NON_EPA  = CVS["mid_gray"]
                C_ADM          = CVS["blue_gray"]
                C_APL_AOA      = CVS["gold"]
                C_APL_DEN      = CVS["charcoal"]
                C_APL_OTH      = CVS["mid_gray"]
                C_FILL_T       = CVS["teal"]
                C_FILL_N       = CVS["charcoal"]
                C_FILL_A       = CVS["gold"]
                C_FILL_O       = CVS["mid_gray"]

                _bar_specs = [
                    # 1. Volume
                    ("Volume", False, [
                        {"label": "PA Cases",   "value": all_pas_incl_appeals, "color": CVS["red"]},
                        {"label": "Walkaways",  "value": walkaway_cnt,         "color": CVS["gold_dark"]},
                    ]),
                    # 2. Case Origin
                    ("Case Origin", False, [
                        {"label": "ePAs",  "value": epa_c,   "color": CVS["dark_red"]},
                        {"label": "Fax",   "value": fax_c,   "color": CVS["red"]},
                        {"label": "Call",  "value": call_c,  "color": CVS["gold_dark"]},
                        {"label": "Other", "value": other_c, "color": CVS["mid_gray"]},
                    ]),
                    # 3. Initial Decision
                    ("Initial Decision", False, [
                        {"label": "Auto — Model",  "value": float(_col("init_model_auto")),  "color": C_APR_AUTO_MDL},
                        {"label": "Auto — Rules",  "value": float(_col("init_system_auto")), "color": C_APR_AUTO_RUL},
                        {"label": "ePA Hum Appr",  "value": float(_col("init_epa_hum_apr")), "color": C_APR_EPA_HUM},
                        {"label": "ePA Hum Den",   "value": float(_col("init_epa_hum_den")), "color": C_DEN_EPA},
                        {"label": "ePA Hum Adm",   "value": float(_col("init_epa_hum_adm")), "color": C_ADM},
                        {"label": "Non-ePA Appr",  "value": float(_col("init_non_epa_apr")), "color": C_APR_NON_EPA},
                        {"label": "Non-ePA Den",   "value": float(_col("init_non_epa_den")), "color": C_DEN_NON_EPA},
                        {"label": "Non-ePA Adm",   "value": float(_col("init_non_epa_adm")), "color": C_ADM},
                    ]),
                    # 3b. Auto Approvals — model breakdown (after Initial Decision)
                    ("Auto Approvals", False, [
                        {"label": "Auto Rules", "value": float(_col("init_system_auto")),     "color": C_APR_AUTO_RUL},
                        {"label": "Gen AI",     "value": float(_col("auto_genai_cnt")),       "color": MODEL_COLORS.get("GLP GenAI", CVS["dark_red"])},
                        {"label": "Predictive", "value": float(_col("auto_predictive_cnt")),  "color": MODEL_COLORS.get("Predictive", CVS["red"])},
                        {"label": "OFU",        "value": float(_col("auto_ofu_cnt")),         "color": MODEL_COLORS.get("Override", CVS["charcoal"])},
                        {"label": "DLT",        "value": float(_col("auto_dlt_cnt")),         "color": MODEL_COLORS.get("DLT", CVS["gold_dark"])},
                        {"label": "Attachment", "value": float(_col("auto_attachment_cnt")),  "color": MODEL_COLORS.get("Attachment Automation", CVS["gold"])},
                    ]),
                    # 4. Final Decision
                    ("Final Decision", False, [
                        {"label": "Auto Appr",     "value": float(_col("fin_auto_cnt")),    "color": C_APR_AUTO_MDL},
                        {"label": "ePA Hum Appr",  "value": float(_col("fin_epa_hum_apr")), "color": C_APR_EPA_HUM},
                        {"label": "ePA Hum Den",   "value": float(_col("fin_epa_hum_den")), "color": C_DEN_EPA},
                        {"label": "ePA Hum Adm",   "value": float(_col("fin_epa_hum_adm")), "color": C_ADM},
                        {"label": "Non-ePA Appr",  "value": float(_col("fin_non_epa_apr")), "color": C_APR_NON_EPA},
                        {"label": "Non-ePA Den",   "value": float(_col("fin_non_epa_den")), "color": C_DEN_NON_EPA},
                        {"label": "Non-ePA Adm",   "value": float(_col("fin_non_epa_adm")), "color": C_ADM},
                    ]),
                    # 5. Fill Type
                    ("Fill Type", False, [
                        {"label": "Target Fill", "value": float(_col("fill_target_cnt")), "color": C_FILL_T},
                        {"label": "No Fill",     "value": float(_col("fill_no_cnt")),     "color": C_FILL_N},
                        {"label": "Alt Fill",    "value": float(_col("fill_alt_cnt")),    "color": C_FILL_A},
                        {"label": "Other",       "value": float(_col("fill_other_cnt")),  "color": C_FILL_O},
                    ]),
                    # 6. Appeals (after Fill Type per request)
                    ("Appeals", False, [
                        {"label": "Appr on Appeal", "value": aoa,     "color": C_APL_AOA},
                        {"label": "Durable Denial", "value": dur_den, "color": C_APL_DEN},
                        {"label": "Other",          "value": apl_oth, "color": C_APL_OTH},
                    ], fmt(appeal_total) if appeal_total else "0"),
                    # 7. Handle Time
                    ("Handle Time", False, [
                        {"label": "Total Handle (s)", "value": total_handle, "color": CVS["red"]},
                    ]),
                    # 8. AHT by Final Decision (sec per case = SUM(handle)/SUM(count))
                    ("AHT (sec)", False, [
                        {"label": "Auto Appr",     "value": (float(_col("aht_num_fin_auto"))        / float(_col("fin_auto_cnt")))    if _col("fin_auto_cnt")    else 0.0, "color": C_APR_AUTO_MDL},
                        {"label": "ePA Hum Appr",  "value": (float(_col("aht_num_fin_epa_apr"))     / float(_col("fin_epa_hum_apr"))) if _col("fin_epa_hum_apr") else 0.0, "color": C_APR_EPA_HUM},
                        {"label": "ePA Hum Den",   "value": (float(_col("aht_num_fin_epa_den"))     / float(_col("fin_epa_hum_den"))) if _col("fin_epa_hum_den") else 0.0, "color": C_DEN_EPA},
                        {"label": "ePA Hum Adm",   "value": (float(_col("aht_num_fin_epa_adm"))     / float(_col("fin_epa_hum_adm"))) if _col("fin_epa_hum_adm") else 0.0, "color": C_ADM},
                        {"label": "Non-ePA Appr",  "value": (float(_col("aht_num_fin_non_epa_apr")) / float(_col("fin_non_epa_apr"))) if _col("fin_non_epa_apr") else 0.0, "color": C_APR_NON_EPA},
                        {"label": "Non-ePA Den",   "value": (float(_col("aht_num_fin_non_epa_den")) / float(_col("fin_non_epa_den"))) if _col("fin_non_epa_den") else 0.0, "color": C_DEN_NON_EPA},
                        {"label": "Non-ePA Adm",   "value": (float(_col("aht_num_fin_non_epa_adm")) / float(_col("fin_non_epa_adm"))) if _col("fin_non_epa_adm") else 0.0, "color": C_ADM},
                    ], f"{aht_avg_seconds:.0f} sec"),
                    # 9. Orig/Appeal $
                    ("Orig/Appeal $", True, [
                        {"label": "Original", "value": float(_col("orig_ops_cost")),   "color": CVS["red"]},
                        {"label": "Appeals",  "value": float(_col("appeal_ops_cost")), "color": CVS["gold_dark"]},
                    ]),
                    # 10. Original Cost by Type (after Orig/Appeal $)
                    ("Original Cost by Type", True, [
                        {"label": "Auto Model",    "value": float(_col("cost_model_auto")),  "color": C_APR_AUTO_MDL},
                        {"label": "Auto Rules",    "value": float(_col("cost_system_auto")), "color": C_APR_AUTO_RUL},
                        {"label": "ePA Hum Appr",  "value": float(_col("cost_epa_hum_apr")), "color": C_APR_EPA_HUM},
                        {"label": "ePA Hum Den",   "value": float(_col("cost_epa_hum_den")), "color": C_DEN_EPA},
                        {"label": "ePA Hum Adm",   "value": float(_col("cost_epa_hum_adm")), "color": C_ADM},
                        {"label": "Non-ePA Appr",  "value": float(_col("cost_non_epa_apr")), "color": C_APR_NON_EPA},
                        {"label": "Non-ePA Den",   "value": float(_col("cost_non_epa_den")), "color": C_DEN_NON_EPA},
                        {"label": "Non-ePA Adm",   "value": float(_col("cost_non_epa_adm")), "color": C_ADM},
                    ]),
                    # 11. UM Savings
                    ("UM Savings", True, [
                        {"label": "PA Savings",       "value": max(pa_sav, 0),       "color": CVS["gold_dark"]},
                        {"label": "Walkaway Savings", "value": max(walkaway_sav, 0), "color": CVS["gold"]},
                    ]),
                    # 12. Savings by Fill
                    ("Sav by Fill", True, [
                        {"label": "Target Fill", "value": sav_target, "color": C_FILL_T},
                        {"label": "No Fill",     "value": sav_no,     "color": C_FILL_N},
                        {"label": "Alt Fill",    "value": sav_alt,    "color": C_FILL_A},
                        {"label": "Other",       "value": sav_other,  "color": C_FILL_O},
                    ]),
                    # 13. ROI — Overall (PA + Walkaway savings ÷ Cost)
                    ("Overall ROI", False, [
                        {"label": "ROI", "value": max(roi, 0), "color": CVS["gold"]},
                    ], f"{roi:.2f}×" if roi else "—"),
                    # 14. ROI — PA only (excl. walkaways)
                    ("PA ROI", False, [
                        {"label": "PA ROI", "value": max(pa_roi, 0), "color": CVS["gold_dark"]},
                    ], f"{pa_roi:.2f}×" if pa_roi else "—"),
                ]

                _bar_html = []
                for _spec in _bar_specs:
                    if len(_spec) == 4:
                        _xlabel, _is_cost, _segs, _ann = _spec
                    else:
                        _xlabel, _is_cost, _segs = _spec
                        _ann = None
                    _fig = single_bar("", _segs, height=620, cost=_is_cost,
                                       annotation_text=_ann, xlabel=_xlabel)
                    _bar_html.append(
                        f'<div style="display:inline-block;width:280px;'
                        f'vertical-align:top;margin-right:8px;">'
                        + _pio.to_html(_fig, include_plotlyjs="cdn",
                                        full_html=False, config=_cfg)
                        + '</div>'
                    )
                _scroll_html = (
                    f'<div style="overflow-x:auto;overflow-y:hidden;white-space:nowrap;'
                    f'padding-bottom:6px;width:100%;">' + "".join(_bar_html) + '</div>'
                )
                _components.html(_scroll_html, height=660, scrolling=True)

                if total_cost > 0:
                    st.markdown(
                        f'<p style="text-align:right;font-size:11px;color:{CVS["gold_dark"]};">'
                        f'ROI: every $1 ops cost returned <b>{roi:.2f}x</b> in UM savings</p>',
                        unsafe_allow_html=True,
                    )

                # ────────────────────────────────────────────────────────────────
                # ROW 3: ePA Loop2 Fallout — CSO donut (steps) | MHK donut (reasons)
                # ────────────────────────────────────────────────────────────────
                section_header("ePA Loop2 Fallout Analysis")
                fo = st.session_state.pait_fallout_df

                _fo_cfg = {"displayModeBar": False}

                def _donut(labels, values, colors, customdata=None, hovertemplate=None,
                            title="", height=560):
                    # Build per-slice text: blank when share < 1%, else "X.X%"
                    _total = float(sum(v or 0 for v in values)) or 1.0
                    _slice_text = [
                        ("" if (float(v or 0) / _total) < 0.01 else f"{(float(v) / _total) * 100:.1f}%")
                        for v in values
                    ]
                    fig = go.Figure(go.Pie(
                        labels=labels,
                        values=values,
                        hole=0.52,
                        marker=dict(colors=colors, line=dict(color="#fff", width=1.5)),
                        text=_slice_text,
                        textinfo="text",
                        textfont=dict(size=12, family="Inter, sans-serif"),
                        customdata=customdata,
                        hovertemplate=hovertemplate or "<b>%{label}</b><br>%{value:,} cases (%{percent})<extra></extra>",
                        sort=True,
                        direction="clockwise",
                    ))
                    fig.update_layout(
                        height=height,
                        showlegend=True,
                        legend=dict(
                            font=dict(size=12, family="Inter, sans-serif"),
                            orientation="v",
                            x=1.02, y=0.5,
                        ),
                        margin=dict(t=20, l=0, r=0, b=10),
                        paper_bgcolor="#ffffff", plot_bgcolor="#ffffff",
                        annotations=[dict(
                            text=f"<b>{title}</b>",
                            x=0.5, y=0.5, font=dict(size=14, family="Inter, sans-serif",
                                                      color=CVS["charcoal"]),
                            showarrow=False,
                        )],
                    )
                    return fig

                if fo is not None and not fo.empty:
                    steps_raw    = fo[(fo["fallout_type"] == "step")        & (fo["PA_SOURCE"] == "CSO")]
                    step_rsn_all = fo[(fo["fallout_type"] == "step_reason") & (fo["PA_SOURCE"] == "CSO")]
                    reasons_cso  = fo[(fo["fallout_type"] == "reason")      & (fo["PA_SOURCE"] == "CSO")]
                    reasons_mhk  = fo[(fo["fallout_type"] == "reason")      & (fo["PA_SOURCE"] == "GSO")]

                    fo_lhs, fo_rhs = st.columns(2)

                    # ── LHS: CSO donut (steps) + step→reason table ────────────
                    with fo_lhs:
                        _flow_section("CSO ePA Loop 2 Fallout — Steps", color=CVS["red"])
                        if not steps_raw.empty:
                            cso_total = int(steps_raw["cnt"].sum())
                            st.markdown(
                                f'<div style="font-size:14px;font-weight:600;color:{CVS["charcoal"]};'
                                f'margin-bottom:6px;">Grand Total (All Steps · Human-reviewed): '
                                f'<span style="color:{CVS["red"]};font-weight:800;">{fmt(cso_total)}</span></div>',
                                unsafe_allow_html=True,
                            )
                            top_steps = steps_raw.sort_values("cnt", ascending=False).reset_index(drop=True)
                            _base_red = [
                                "#8B0000", "#CC0000", "#E53935", "#EF9A9A",
                                "#FFCDD2", "#B71C1C", "#D32F2F", "#F44336",
                                "#E57373", "#FFAB91", "#FF7043", "#BF360C",
                                "#A1887F", "#795548",
                            ]
                            step_colors = []
                            _ri = 0
                            for _lbl in top_steps["fallout_value"]:
                                if str(_lbl).startswith("No fallout"):
                                    step_colors.append("#BDBDBD")  # neutral gray
                                else:
                                    step_colors.append(_base_red[_ri % len(_base_red)])
                                    _ri += 1
                            # Pre-compute cleaned reason rollup for each step (apply override map,
                            # aggregate after cleaning) — used for donut hover.
                            _sr_clean = step_rsn_all[["fallout_step", "fallout_value", "cnt"]].copy()
                            _sr_clean["Reason"] = _sr_clean.apply(
                                lambda r: _clean_reason(r["fallout_step"], r["fallout_value"]),
                                axis=1,
                            )
                            _sr_rollup = (
                                _sr_clean.groupby(["fallout_step", "Reason"], as_index=False)["cnt"]
                                          .sum()
                                          .sort_values(["fallout_step", "cnt"], ascending=[True, False])
                            )
                            cdata = []
                            for _, sr in top_steps.iterrows():
                                sname = sr["fallout_value"]
                                rsns  = _sr_rollup[_sr_rollup["fallout_step"] == sname]
                                if not rsns.empty:
                                    rsn_lines = "<br>".join(
                                        f"&nbsp;&nbsp;• {r['Reason']}: {fmt(int(r['cnt']))}"
                                        for _, r in rsns.iterrows()
                                    )
                                else:
                                    rsn_lines = "&nbsp;&nbsp;No reason breakdown"
                                cdata.append([rsn_lines])
                            htmpl = (
                                "<b>%{label}</b><br>"
                                "%{value:,} cases (%{percent})<br>"
                                "<i>All reasons:</i><br>%{customdata[0]}"
                                "<extra></extra>"
                            )
                            fig_cso = _donut(
                                labels=top_steps["fallout_value"].tolist(),
                                values=top_steps["cnt"].tolist(),
                                colors=step_colors,
                                customdata=cdata,
                                hovertemplate=htmpl,
                                title="Steps",
                                height=560,
                            )
                            st.plotly_chart(fig_cso, use_container_width=True, config=_fo_cfg)

                            # Table: Step, Reason, Count — sorted desc by count
                            if not step_rsn_all.empty:
                                _tbl = step_rsn_all[["fallout_step", "fallout_value", "cnt"]].copy()
                                _tbl["Reason"]   = _tbl.apply(
                                    lambda r: _clean_reason(r["fallout_step"], r["fallout_value"]),
                                    axis=1,
                                )
                                tbl_cso = (
                                    _tbl.groupby(["fallout_step", "Reason"], as_index=False)["cnt"]
                                        .sum()
                                        .rename(columns={"fallout_step": "Step", "cnt": "Count"})
                                        .sort_values("Count", ascending=False)
                                        .reset_index(drop=True)
                                )[["Step", "Reason", "Count"]]
                                # Append 'No fallout category found' row from steps_raw bucket
                                _no_fo = steps_raw[
                                    steps_raw["fallout_value"].astype(str)
                                        .str.startswith("No fallout")
                                ]
                                if not _no_fo.empty:
                                    _no_fo_cnt = int(_no_fo["cnt"].sum())
                                    tbl_cso = pd.concat([
                                        tbl_cso,
                                        pd.DataFrame([{
                                            "Step":   "No fallout category found",
                                            "Reason": "—",
                                            "Count":  _no_fo_cnt,
                                        }]),
                                    ], ignore_index=True)
                                _grand_total = int(tbl_cso["Count"].sum())
                                tbl_cso["Count"] = tbl_cso["Count"].apply(lambda x: f"{int(x):,}")
                                # Prepend Grand Total row at the top
                                tbl_cso = pd.concat([
                                    pd.DataFrame([{"Step": "GRAND TOTAL", "Reason": "",
                                                    "Count": f"{_grand_total:,}"}]),
                                    tbl_cso,
                                ], ignore_index=True)
                                st.dataframe(tbl_cso, hide_index=True, use_container_width=True,
                                             height=320)
                        else:
                            st.caption("No CSO ePA Loop 2 fallout step data for the selected filters.")

                    # ── RHS: MHK donut (reasons) + reason table ───────────────
                    with fo_rhs:
                        _flow_section("GSO ePA Loop 2 Fallout Reasons", color=CVS["teal"])
                        if not reasons_mhk.empty:
                            reasons_mhk = reasons_mhk.copy()
                            reasons_mhk["fallout_value"] = reasons_mhk["fallout_value"].apply(_clean_mhk_reason)
                            reasons_mhk = (
                                reasons_mhk.groupby("fallout_value", as_index=False)["cnt"].sum()
                                            .sort_values("cnt", ascending=False)
                            )
                            gso_total = int(reasons_mhk["cnt"].sum())
                            st.markdown(
                                f'<div style="font-size:14px;font-weight:600;color:{CVS["charcoal"]};'
                                f'margin-bottom:6px;">Grand Total (All Reasons · Human-reviewed): '
                                f'<span style="color:{CVS["teal"]};font-weight:800;">{fmt(gso_total)}</span></div>',
                                unsafe_allow_html=True,
                            )
                            top_rsn = reasons_mhk.sort_values("cnt", ascending=False).reset_index(drop=True)
                            _base_teal = [
                                "#004D40", "#00897B", "#26A69A", "#80CBC4",
                                "#B2DFDB", "#1B5E20", "#2E7D32", "#388E3C",
                                "#43A047", "#66BB6A", "#A5D6A7", "#00BFA5",
                                "#1DE9B6", "#64FFDA", "#A7FFEB",
                            ]
                            rsn_colors = []
                            _ti = 0
                            for _lbl in top_rsn["fallout_value"]:
                                s = str(_lbl)
                                if s.startswith("Auto-scored result"):
                                    rsn_colors.append("#616161")  # dark gray
                                elif s.startswith("Fallout unknown") or s.startswith("No fallout"):
                                    rsn_colors.append("#BDBDBD")  # light gray
                                else:
                                    rsn_colors.append(_base_teal[_ti % len(_base_teal)])
                                    _ti += 1
                            fig_mhk = _donut(
                                labels=top_rsn["fallout_value"].tolist(),
                                values=top_rsn["cnt"].tolist(),
                                colors=rsn_colors,
                                title="Reasons",
                                height=560,
                            )
                            st.plotly_chart(fig_mhk, use_container_width=True, config=_fo_cfg)

                            tbl_mhk = (
                                top_rsn[["fallout_value", "cnt"]]
                                .rename(columns={"fallout_value": "Reason", "cnt": "Count"})
                                .sort_values("Count", ascending=False)
                                .reset_index(drop=True)
                            )
                            _gso_grand = int(tbl_mhk["Count"].sum())
                            tbl_mhk["Count"] = tbl_mhk["Count"].apply(lambda x: f"{int(x):,}")
                            tbl_mhk = pd.concat([
                                pd.DataFrame([{"Reason": "GRAND TOTAL",
                                                "Count": f"{_gso_grand:,}"}]),
                                tbl_mhk,
                            ], ignore_index=True)
                            st.dataframe(tbl_mhk, hide_index=True, use_container_width=True,
                                         height=280)
                        else:
                            st.caption("No GSO ePA Loop 2 fallout reason data for the selected filters.")
                else:
                    st.caption("No ePA Loop 2 fallout data for the selected filters.")

                st.divider()
                with st.expander("Source summary table", expanded=False):
                    tbl = og.copy()
                    tbl["Auto Rate"] = (
                        (tbl["epa_rules_auto"] + tbl["model_auto"])
                        / tbl["total_pas"].replace(0, float("nan")) * 100
                    ).round(1).astype(str) + "%"
                    tbl["Appeal Rate"] = (
                        tbl["appeal_total"]
                        / tbl["total_pas"].replace(0, float("nan")) * 100
                    ).round(1).astype(str) + "%"
                    tbl["Avg AHT"] = (tbl["avg_aht_seconds"].fillna(0)).round(0).astype(str) + "s"
                    disp_cols = ["PA_SOURCE", "total_pas", "epa_pas", "init_model_auto",
                                 "init_system_auto", "human_reviewed", "approvals", "denials",
                                 "admin_denials", "appeal_total", "Auto Rate", "Appeal Rate", "Avg AHT"]
                    rename = {
                        "PA_SOURCE": "Source", "total_pas": "Total PAs", "epa_pas": "ePA",
                        "init_model_auto": "Model Auto", "init_system_auto": "System Auto",
                        "human_reviewed": "Human", "approvals": "Approvals",
                        "denials": "Denials", "admin_denials": "Admin/Dismiss",
                        "appeal_total": "Appeals",
                    }
                    out = tbl[[c for c in disp_cols if c in tbl.columns]].rename(columns=rename)
                    for c in ["Total PAs", "ePA", "Model Auto", "System Auto",
                               "Human", "Approvals", "Denials", "Admin/Dismiss", "Appeals"]:
                        if c in out.columns:
                            out[c] = out[c].apply(fmt)
                    st.dataframe(out, hide_index=True, use_container_width=True)

    # ── RAW DATA VIEW ──────────────────────────────────────────────────────────
    with og_sub_raw:
        st.info(
            "Select a grouping dimension to break down the full PA lifecycle. "
            "Summary cards show aggregate totals across all selected groups. "
            "The detailed table breaks down by each group. "
            "All sidebar filters apply. Both original and appeal cases are always included so you can see the complete flow."
        )

        RAW_DIM_OPTIONS = {
            "Month-Year":            "FORMAT_DATE('%Y-%m', CRTE_DT)",
            "PA Source":             "PA_SOURCE",
            "Line of Business":      "LINE_OF_BUSINESS",
            "PA Origin":             "PA_ORIGIN_CD",
            "Original Resolution":   "ORGNL_RSLTN_CD",
            "Final Resolution":      "FNL_RSLTN_CD",
            "Review Type":           "REVIEW_TYPE",
            "Initial Decision":      "INITIAL_DECISION",
            "Auto Score Result":     "AUTO_SCORE_RESULT_STATUS",
            "Appeal Type":           "APPEAL_TYPE",
            "Drug Type":             "DRUG_TYPE",
            "Drug Name":             "DRUG_NAME",
            "Drug Class":            "EPSD_DRUG_CLS",
            "GPI Class Name":        "GPI_CLS_NM",
            "Criteria Type":         "STD_CSTM_CRTRA_CD",
            "Criteria Code":         "RFRNC_NBR",
            "Criteria Name (Reference Code Desc)": "RFRNC_NBR_CRTRA_NM",
            "PAC Code":              "PAC_CD",
            "PAC Description":       "PAC_CD_DESC",
            "QSET Number":           "QSET_NBR",
            "QSET Description":      "QSET_NBR_DESC",
            "PA Fill Type":          "PA_FILL_TYPE",
            "UM Type Code":          "UM_TYP_CD",
            "Formulary Name":        "FORMULARY_NAME",
            "Formulary Status":      "FORMULARY_STATUS",
            "Benefit Plan":          "BNFT_PLAN_NM",
            "Initial Approval Path": "INITIAL_APPROVAL_PATH",
            "Final Approval Path":   "FINAL_APPROVAL_PATH",
            "Has Attachment":        "HAS_ATTACHMENT_IND",
            "Requires Attachment":   "REQUIRES_ATTACHMENT_IND",
            "Re-Authorized":         "RE_AUTHORIZED_PA_FLAG",
            "PAG Code":              "PAG_CD",
            "PAG Code Description":  "PAG_CD_DESC",
            "Macro Type":            "MACRO_TYPE",
            "Aetna Flag":            "AETNA_FLAG",
        }

        rc1, rc2 = st.columns([2, 1])
        with rc1:
            raw_dims = st.multiselect(
                "Group by (select one or more)",
                list(RAW_DIM_OPTIONS.keys()),
                default=["PA Source"],
                key="raw_dims",
            )
        with rc2:
            st.markdown("<br>", unsafe_allow_html=True)
            load_raw = st.button("Load Raw Data", key="load_raw_data")

        if load_raw and not raw_dims:
            st.info("Select at least one dimension above, then click Load Raw Data.")

        if load_raw and raw_dims:
            cols_sql = [RAW_DIM_OPTIONS[d] for d in raw_dims]
            col_sql  = ", ".join(cols_sql)
            grp_sql  = ", ".join(str(i + 1) for i in range(len(cols_sql)))
            extra_raw = build_filters(_FILT, include_appeal_filter=False)
            sql = _PAIT_RAW_SQL.format(
                group_by_cols=col_sql, group_by_list=grp_sql,
                start_date=max(start_date, datetime.date(2024, 1, 1)),
                end_date=end_date,
                extra_filters=extra_raw,
            )
            with st.spinner("Loading raw data…"):
                try:
                    st.session_state.pait_raw_df = run_query(sql)
                except Exception as exc:
                    st.error(f"Raw data query failed: {exc}")

        rdf = st.session_state.pait_raw_df
        if rdf is not None and not rdf.empty:
            T = rdf

            def _sum(col):
                return T[col].sum() if col in T.columns else 0

            def _wavg(col):
                v = T[col] if col in T.columns else pd.Series([], dtype=float)
                return v[v > 0].mean() if len(v[v > 0]) > 0 else 0.0

            total_cases   = int(_sum("total_cases"))
            orig_pas      = int(_sum("original_pas"))
            epa_pas       = int(_sum("epa_pas"))
            non_epa_pas   = int(_sum("non_epa_pas"))
            appeal_pas    = int(_sum("appeal_pas"))
            total_sav     = float(_sum("total_savings"))
            total_cost    = float(_sum("total_ops_cost"))
            walkaway_cnt  = int(_sum("walkaway_cnt"))
            walkaway_sav  = float(_sum("walkaway_savings"))
            avg_aht_sec   = float(_wavg("avg_aht_sec"))
            rules_auto    = int(_sum("rules_auto"))
            model_auto    = int(_sum("model_auto"))
            human_rev     = int(_sum("human_reviewed"))
            orig_apr      = int(_sum("orig_approvals"))
            orig_den      = int(_sum("orig_denials"))
            orig_adm      = int(_sum("orig_admin"))
            orig_cost     = float(_sum("orig_ops_cost"))
            orig_aht_sec  = float(_wavg("orig_aht_sec"))
            epa_sc_apr    = int(_sum("epa_scored_apr"))
            epa_sc_den    = int(_sum("epa_scored_den"))
            epa_unscored  = int(_sum("epa_unscored"))
            apl_aprd      = int(_sum("appeal_approved"))
            aoa           = int(_sum("approve_on_appeal"))
            dur_den       = int(_sum("durable_denial"))
            apl_cost      = float(_sum("appeal_ops_cost"))

            roi      = total_sav / total_cost if total_cost else 0
            auto_pct = (rules_auto + model_auto) / orig_pas * 100 if orig_pas else 0

            # KPI cards removed — table's Grand Total row covers totals.
            section_header("Breakdown by " + ", ".join(raw_dims))

            dim_cols_sql = [RAW_DIM_OPTIONS[d] for d in raw_dims]

            # All base columns emitted by pait_og_raw.sql (positional order!)
            _BASE_SQL_COLS = dim_cols_sql + [
                # Volume / top-line
                "overall_cases", "walkaway_cnt", "pa_savings", "total_ops_cost", "total_handle_sec",
                # All PAs
                "all_pas", "all_pa_auto", "all_pa_apr", "all_pa_den", "all_pa_adm",
                # All ePAs
                "all_epa", "all_epa_auto", "all_epa_auto_model",
                "all_epa_human", "all_epa_human_apr", "all_epa_human_den", "all_epa_human_adm",
                "all_epa_human_ops_cost", "all_epa_human_handle_sec", "all_epa_human_savings",
                # All Non-ePAs
                "all_non_epa", "all_non_epa_apr", "all_non_epa_den", "all_non_epa_adm",
                "all_non_epa_ops_cost", "all_non_epa_handle_sec", "all_non_epa_savings",
                # Original Review
                "orig_pas", "orig_pa_apr", "orig_pa_den", "orig_pa_adm",
                # Original ePAs
                "orig_epa", "orig_epa_auto", "orig_epa_auto_model",
                "orig_epa_human", "orig_epa_human_apr", "orig_epa_human_den", "orig_epa_human_adm",
                "orig_epa_human_ops_cost", "orig_epa_human_handle_sec", "orig_epa_human_savings",
                # Original Non-ePAs
                "orig_non_epa", "orig_non_epa_apr", "orig_non_epa_den", "orig_non_epa_adm",
                "orig_non_epa_ops_cost", "orig_non_epa_handle_sec", "orig_non_epa_savings",
                # Appeals
                "appeal_pas", "appeal_apr", "appeal_den", "appeal_adm",
                "appeal_aoa", "appeal_durable_denial",
                "appeal_ops_cost", "appeal_handle_sec", "appeal_savings",
            ]

            display_df = rdf.copy()
            if len(display_df.columns) == len(_BASE_SQL_COLS):
                display_df.columns = _BASE_SQL_COLS
            else:
                st.error(
                    f"Schema mismatch: query returned {len(display_df.columns)} columns "
                    f"but {len(_BASE_SQL_COLS)} were expected. "
                    "Metric values will be blank — contact the data team."
                )
                st.stop()

            # ── Column dictionary ─────────────────────────────────────────
            # Each label maps to a dict:
            #   {"kind": "count|currency|seconds|rate", "expr": <fn(row)->float>}
            # Rates are derived in Python so we can divide cleanly.
            # Vectorized helpers — operate on a DataFrame column, returning a Series.
            # Replacing row-by-row dict lambdas eliminates O(rows×cols) Python overhead.
            def _s(df, c):
                return pd.to_numeric(df[c], errors="coerce").fillna(0)
            def _spct(n, d):
                return n.div(d.where(d != 0, other=float("nan"))).fillna(0) * 100
            def _sdiv(n, d):
                return n.div(d.where(d != 0, other=float("nan"))).fillna(0)

            COL_DICT = {
                # ── All PA Cases / All PAs ──
                "All PA Cases":                  ("count",    lambda df: _s(df, "all_pas")),
                "All PAs, Auto Approvals":       ("count",    lambda df: _s(df, "all_pa_auto")),
                "All PAs, Auto Approval Rate":   ("rate",     lambda df: _spct(_s(df, "all_pa_auto"), _s(df, "all_pa_apr"))),
                "All PAs, Approvals":            ("count",    lambda df: _s(df, "all_pa_apr")),
                "All PAs, Approval Rate":        ("rate",     lambda df: _spct(_s(df, "all_pa_apr"), _s(df, "all_pas"))),
                "All PAs, Denials":              ("count",    lambda df: _s(df, "all_pa_den")),
                "All PAs, Admin Denials":        ("count",    lambda df: _s(df, "all_pa_adm")),
                "All PAs, Total Ops Cost":       ("currency", lambda df: _s(df, "total_ops_cost")),
                "All PAs, Total Ops Cost per PA":("currency", lambda df: _sdiv(_s(df, "total_ops_cost"), _s(df, "all_pas"))),
                "All PAs, Total Handle Time":    ("seconds",  lambda df: _s(df, "total_handle_sec")),
                "All PAs, AHT":                  ("seconds",  lambda df: _sdiv(_s(df, "total_handle_sec"), _s(df, "all_pas"))),
                "All PAs, UM Savings":           ("currency", lambda df: _s(df, "pa_savings")),
                "All PAs, RoI":                  ("ratio",    lambda df: _sdiv(_s(df, "pa_savings"), _s(df, "total_ops_cost"))),

                # ── All, ePAs ──
                "All, ePAs":                                                ("count",    lambda df: _s(df, "all_epa")),
                "All, ePAs, Auto Approvals":                                ("count",    lambda df: _s(df, "all_epa_auto")),
                "All, ePAs, Auto Approvals, Model":                         ("count",    lambda df: _s(df, "all_epa_auto_model")),
                "All, ePAs, Auto Approval Rate (of All ePA Approvals)":     ("rate",
                    lambda df: _spct(_s(df, "all_epa_auto"), _s(df, "all_epa_auto") + _s(df, "all_epa_human_apr"))),
                "All, ePAs, Human Reviewed":                                ("count",    lambda df: _s(df, "all_epa_human")),
                "All, ePAs, Human Reviewed, Approvals":                     ("count",    lambda df: _s(df, "all_epa_human_apr")),
                "All, ePAs, Human Reviewed, Approval Rate":                 ("rate",     lambda df: _spct(_s(df, "all_epa_human_apr"), _s(df, "all_epa_human"))),
                "All, ePAs, Human Reviewed, Denials":                       ("count",    lambda df: _s(df, "all_epa_human_den")),
                "All, ePAs, Human Reviewed, Admin Denials":                 ("count",    lambda df: _s(df, "all_epa_human_adm")),
                "All, ePAs, Human Reviewed, Ops Cost":                      ("currency", lambda df: _s(df, "all_epa_human_ops_cost")),
                "All, ePAs, Human Reviewed, Ops Cost per PA":               ("currency", lambda df: _sdiv(_s(df, "all_epa_human_ops_cost"), _s(df, "all_epa_human"))),
                "All, ePAs, Human Reviewed, Handle Time":                   ("seconds",  lambda df: _s(df, "all_epa_human_handle_sec")),
                "All, ePAs, Human Reviewed, AHT":                           ("seconds",  lambda df: _sdiv(_s(df, "all_epa_human_handle_sec"), _s(df, "all_epa_human"))),
                "All, ePAs, Human Reviewed, UM Savings":                    ("currency", lambda df: _s(df, "all_epa_human_savings")),
                "All, ePAs, Human Reviewed, RoI":                           ("ratio",    lambda df: _sdiv(_s(df, "all_epa_human_savings"), _s(df, "all_epa_human_ops_cost"))),

                # ── All, Non-ePAs ──
                "All, Non ePAs":                          ("count",    lambda df: _s(df, "all_non_epa")),
                "All, Non ePAs, Approvals":               ("count",    lambda df: _s(df, "all_non_epa_apr")),
                "All, Non ePAs, Approval Rate":           ("rate",     lambda df: _spct(_s(df, "all_non_epa_apr"), _s(df, "all_non_epa"))),
                "All, Non ePAs, Denials":                 ("count",    lambda df: _s(df, "all_non_epa_den")),
                "All, Non ePAs, Admin Denials":           ("count",    lambda df: _s(df, "all_non_epa_adm")),
                "All, Non ePAs, Ops Cost":                ("currency", lambda df: _s(df, "all_non_epa_ops_cost")),
                "All, Non ePAs, Ops Cost per PA":         ("currency", lambda df: _sdiv(_s(df, "all_non_epa_ops_cost"), _s(df, "all_non_epa"))),
                "All, Non ePAs, Handle Time":             ("seconds",  lambda df: _s(df, "all_non_epa_handle_sec")),
                "All, Non ePAs, AHT":                     ("seconds",  lambda df: _sdiv(_s(df, "all_non_epa_handle_sec"), _s(df, "all_non_epa"))),
                "All, Non ePAs, UM Savings":              ("currency", lambda df: _s(df, "all_non_epa_savings")),
                "All, Non ePAs, RoI":                     ("ratio",    lambda df: _sdiv(_s(df, "all_non_epa_savings"), _s(df, "all_non_epa_ops_cost"))),

                # ── All Original Review PAs ──
                "All Original Review PAs":                ("count",    lambda df: _s(df, "orig_pas")),
                "All Original Review PAs, Approvals":     ("count",    lambda df: _s(df, "orig_pa_apr")),
                "All Original Review PAs, Approval Rate": ("rate",     lambda df: _spct(_s(df, "orig_pa_apr"), _s(df, "orig_pas"))),
                "All Original Review PAs, Denials":       ("count",    lambda df: _s(df, "orig_pa_den")),
                "All Original Review PAs, Admin Denials": ("count",    lambda df: _s(df, "orig_pa_adm")),

                # ── All Original Review, ePAs ──
                "All Original Review, ePAs":                                                        ("count",    lambda df: _s(df, "orig_epa")),
                "All Original Review, ePAs, Auto Approvals":                                        ("count",    lambda df: _s(df, "orig_epa_auto")),
                "All Original Review, ePAs, Auto Approvals, Model":                                 ("count",    lambda df: _s(df, "orig_epa_auto_model")),
                "All Original Review, ePAs, Auto Approval Rate (of Original Review All Approvals)": ("rate",     lambda df: _spct(_s(df, "orig_epa_auto"), _s(df, "orig_pa_apr"))),
                "All Original Review, ePAs, Human Reviewed":                                        ("count",    lambda df: _s(df, "orig_epa_human")),
                "All Original Review, ePAs, Human Reviewed, Approvals":                             ("count",    lambda df: _s(df, "orig_epa_human_apr")),
                "All Original Review, ePAs, Human Reviewed, Approval Rate":                         ("rate",     lambda df: _spct(_s(df, "orig_epa_human_apr"), _s(df, "orig_epa_human"))),
                "All Original Review, ePAs, Human Reviewed, Denials":                               ("count",    lambda df: _s(df, "orig_epa_human_den")),
                "All Original Review, ePAs, Human Reviewed, Admin Denials":                         ("count",    lambda df: _s(df, "orig_epa_human_adm")),
                "All Original Review, ePAs, Human Reviewed, Ops Cost":                              ("currency", lambda df: _s(df, "orig_epa_human_ops_cost")),
                "All Original Review, ePAs, Human Reviewed, Ops Cost per PA":                       ("currency", lambda df: _sdiv(_s(df, "orig_epa_human_ops_cost"), _s(df, "orig_epa_human"))),
                "All Original Review, ePAs, Human Reviewed, Handle Time":                           ("seconds",  lambda df: _s(df, "orig_epa_human_handle_sec")),
                "All Original Review, ePAs, Human Reviewed, AHT":                                   ("seconds",  lambda df: _sdiv(_s(df, "orig_epa_human_handle_sec"), _s(df, "orig_epa_human"))),
                "All Original Review, ePAs, Human Reviewed, UM Savings":                            ("currency", lambda df: _s(df, "orig_epa_human_savings")),
                "All Original Review, ePAs, Human Reviewed, RoI":                                   ("ratio",    lambda df: _sdiv(_s(df, "orig_epa_human_savings"), _s(df, "orig_epa_human_ops_cost"))),

                # ── All Original Review, Non-ePAs ──
                "All Original Review, Non ePAs":                ("count",    lambda df: _s(df, "orig_non_epa")),
                "All Original Review, Non ePAs, Approvals":     ("count",    lambda df: _s(df, "orig_non_epa_apr")),
                "All Original Review, Non ePAs, Approval Rate": ("rate",     lambda df: _spct(_s(df, "orig_non_epa_apr"), _s(df, "orig_non_epa"))),
                "All Original Review, Non ePAs, Denials":       ("count",    lambda df: _s(df, "orig_non_epa_den")),
                "All Original Review, Non ePAs, Admin Denials": ("count",    lambda df: _s(df, "orig_non_epa_adm")),
                "All Original Review, Non ePAs, Ops Cost":      ("currency", lambda df: _s(df, "orig_non_epa_ops_cost")),
                "All Original Review, Non ePAs, Ops Cost per PA": ("currency", lambda df: _sdiv(_s(df, "orig_non_epa_ops_cost"), _s(df, "orig_non_epa"))),
                "All Original Review, Non ePAs, Handle Time":   ("seconds",  lambda df: _s(df, "orig_non_epa_handle_sec")),
                "All Original Review, Non ePAs, AHT":           ("seconds",  lambda df: _sdiv(_s(df, "orig_non_epa_handle_sec"), _s(df, "orig_non_epa"))),
                "All Original Review, Non ePAs, UM Savings":    ("currency", lambda df: _s(df, "orig_non_epa_savings")),
                "All Original Review, Non ePAs, RoI":           ("ratio",    lambda df: _sdiv(_s(df, "orig_non_epa_savings"), _s(df, "orig_non_epa_ops_cost"))),

                # ── Appeals ──
                # Appeal counts use ORGNL_RSLTN_CD (decision the appeal was filed against)
                "All Appeals, PAs":                           ("count",    lambda df: _s(df, "appeal_pas")),
                "All Appeal PAs, Approvals":                  ("count",    lambda df: _s(df, "appeal_apr")),
                "All Appeal PAs, Approval Rate":              ("rate",     lambda df: _spct(_s(df, "appeal_apr"), _s(df, "appeal_pas"))),
                "All Appeal PAs, Denials":                    ("count",    lambda df: _s(df, "appeal_den")),
                "All Appeal PAs, Admin Denials":              ("count",    lambda df: _s(df, "appeal_adm")),
                # Appeal outcomes (use FNL_RSLTN_CD vs ORGNL_RSLTN_CD)
                "All Appeal PAs, Approve on Appeal":          ("count",    lambda df: _s(df, "appeal_aoa")),
                "All Appeal PAs, Approve on Appeal Rate":     ("rate",     lambda df: _spct(_s(df, "appeal_aoa"), _s(df, "appeal_den"))),
                "All Appeal PAs, Durable Denial":             ("count",    lambda df: _s(df, "appeal_durable_denial")),
                "All Appeal PAs, Durable Denial Rate":        ("rate",     lambda df: _spct(_s(df, "appeal_durable_denial"), _s(df, "appeal_den"))),
                "All Appeals, Ops Cost":                      ("currency", lambda df: _s(df, "appeal_ops_cost")),
                "All Appeals, Ops Cost per PA":               ("currency", lambda df: _sdiv(_s(df, "appeal_ops_cost"), _s(df, "appeal_pas"))),
                "All Appeal PAs, Human Reviewed, Handle Time":("seconds",  lambda df: _s(df, "appeal_handle_sec")),
                "All Appeal PAs, AHT":                        ("seconds",  lambda df: _sdiv(_s(df, "appeal_handle_sec"), _s(df, "appeal_pas"))),
                "All Appeal PAs, UM Savings":                 ("currency", lambda df: _s(df, "appeal_savings")),
                "All Appeal PAs, RoI":                        ("ratio",    lambda df: _sdiv(_s(df, "appeal_savings"), _s(df, "appeal_ops_cost"))),
            }

            _DEFAULT_PICKED = list(COL_DICT.keys())
            _all_keys = list(COL_DICT.keys())
            _picked_count = len(st.session_state.get("raw_agg_picker", _DEFAULT_PICKED))
            with st.expander(
                f"Choose columns ({_picked_count} of {len(_all_keys)} selected)",
                expanded=False,
            ):
                _b1, _b2, _ = st.columns([1, 1, 6])
                with _b1:
                    if st.button("Select all", key="raw_select_all"):
                        st.session_state["raw_agg_picker"] = _all_keys
                        st.rerun()
                with _b2:
                    if st.button("Clear all", key="raw_clear_all"):
                        st.session_state["raw_agg_picker"] = []
                        st.rerun()
                if "raw_agg_picker" in st.session_state:
                    st.session_state["raw_agg_picker"] = [k for k in st.session_state["raw_agg_picker"] if k in COL_DICT]
                _selected_aggs = st.multiselect(
                    "Columns",
                    _all_keys,
                    default=_DEFAULT_PICKED,
                    key="raw_agg_picker",
                    placeholder="Select metrics to display",
                    label_visibility="collapsed",
                )

            if not _selected_aggs:
                st.info("Pick one or more columns above to view the breakdown.")
            else:
                # Grand-total row uses the FULL (unclamped) dataset so totals stay accurate
                # no matter what row cap the user sets below.
                _grand_row = {c: float(display_df[c].sum()) if c in display_df.columns and pd.api.types.is_numeric_dtype(display_df[c]) else "" for c in display_df.columns}

                # Row cap — st.dataframe hangs when it has to send >100k cells to the
                # browser (85 metrics × 8k rows = 700k cells). The SQL already sorts
                # by overall_cases DESC, so trimming keeps the biggest groups.
                _total_rows = len(display_df)
                _min_rows = 10
                _max_rows = max(10, _total_rows)
                # Apply any pending override BEFORE the widget is instantiated —
                # session_state widget keys cannot be written after the widget renders.
                _pending_cap = st.session_state.pop("_raw_row_cap_pending", None)
                if _pending_cap is not None:
                    st.session_state["raw_row_cap"] = max(_min_rows, min(_max_rows, _pending_cap))
                elif "raw_row_cap" in st.session_state:
                    st.session_state["raw_row_cap"] = max(_min_rows, min(_max_rows, st.session_state["raw_row_cap"]))
                _cap_col1, _cap_col2 = st.columns([1, 1])
                with _cap_col1:
                    _row_cap = st.number_input(
                        "Max rows",
                        min_value=_min_rows,
                        max_value=_max_rows,
                        value=st.session_state.get("raw_row_cap", min(500, _max_rows)),
                        step=10,
                        key="raw_row_cap",
                        help=(
                            "Cap on displayed rows (sorted by overall cases desc). "
                            "Grand Total row always reflects the full unclamped dataset. "
                            "Increase carefully — very wide tables can freeze the browser."
                        ),
                    )
                    if _row_cap < _total_rows:
                        st.caption(
                            f"Showing top **{_row_cap:,}** of **{_total_rows:,}** groups "
                            f"(by overall cases). Grand Total covers all {_total_rows:,}."
                        )
                    else:
                        st.caption(f"Showing all **{_total_rows:,}** groups. Grand Total covers all {_total_rows:,}.")
                with _cap_col2:
                    st.markdown("<br>", unsafe_allow_html=True)
                    if _row_cap < _total_rows:
                        if st.button("Show all", key="raw_show_all", help=f"Load all {_total_rows:,} groups"):
                            st.session_state["_raw_row_cap_pending"] = _total_rows
                            st.rerun()
                    else:
                        if st.button("Reset to 500", key="raw_show_all", help="Show top 500 groups only"):
                            st.session_state["_raw_row_cap_pending"] = 500
                            st.rerun()

                # Trim BEFORE the expensive metric compute — this is the actual perf win.
                _capped_df = display_df.head(int(_row_cap))

                # Build display dataframe: dim cols + selected metric cols (vectorized)
                show = pd.DataFrame()
                for d, dlabel in zip(dim_cols_sql, raw_dims):
                    show[dlabel] = _capped_df[d].values

                for label in _selected_aggs:
                    kind, fn = COL_DICT[label]
                    show[label] = fn(_capped_df).values

                # Grand-total row — pass a 1-row DataFrame so the same vectorized
                # lambdas work without a separate row-dict path.
                _grand_df = pd.DataFrame([_grand_row])
                gt = {dlabel: ("GRAND TOTAL" if i == 0 else "")
                      for i, dlabel in enumerate(raw_dims)}
                for label in _selected_aggs:
                    kind, fn = COL_DICT[label]
                    gt[label] = fn(_grand_df).iloc[0]
                show = pd.concat([pd.DataFrame([gt]), show], ignore_index=True)

                # Format each column by kind
                # Format each metric column in one vectorized pass per column
                # (avoids per-cell Python dispatch that was O(rows × cols)).
                _fmt_fns = {
                    "count":    lambda col: col.map(fmt),
                    "currency": lambda col: col.map(lambda v: fmt(v, currency=True) if v != 0 else "—"),
                    "seconds":  lambda col: col.map(lambda v: f"{v:,.0f}s" if v > 0 else "—"),
                    "rate":     lambda col: col.map(lambda v: f"{v:.1f}%" if v != 0 else "0.0%"),
                    "ratio":    lambda col: col.map(lambda v: f"{v:.2f}x" if v != 0 else "—"),
                }
                for label in _selected_aggs:
                    kind, _ = COL_DICT[label]
                    show[label] = _fmt_fns[kind](pd.to_numeric(show[label], errors="coerce").fillna(0))

                st.dataframe(show, hide_index=True, use_container_width=True)

                # Full-data CSV export — always visible so users can get all rows offline.
                _csv_show = pd.DataFrame()
                for d, dlabel in zip(dim_cols_sql, raw_dims):
                    _csv_show[dlabel] = display_df[d].values
                for label in _selected_aggs:
                    kind, fn = COL_DICT[label]
                    _csv_show[label] = fn(display_df).values
                _csv_bytes = _csv_show.to_csv(index=False).encode("utf-8")
                st.download_button(
                    "Download full table as CSV",
                    data=_csv_bytes,
                    file_name=f"pait_raw_breakdown_{start_date}_{end_date}.csv",
                    mime="text/csv",
                    key="raw_full_csv",
                )


# ═══════════════════════════════════════════════════════════════════════════════
# TAB 2 — SIZING VIEW
# ═══════════════════════════════════════════════════════════════════════════════
def _wf_texts(y_vals, measures):
    texts, running = [], 0
    for y, m in zip(y_vals, measures):
        if m == "absolute":
            running = y
            texts.append(fmt(running))
        elif m == "relative":
            running += y
            texts.append(fmt(abs(y)) if y != 0 else "")
        else:
            texts.append(fmt(running))
    return texts


def sizing_waterfall(row, source, bucket_costs=None):
    base_color = CVS["red"]    if source == "CSO" else CVS["teal"]
    dec_color  = CVS["light_red"]  if source == "CSO" else CVS["light_teal"]
    inc_color  = CVS["pale_red"]   if source == "CSO" else CVS["pale_teal"]

    # Break out the ePA auto-approved bucket into Model Auto + Rules Auto.
    # Approximation: total_auto = model_auto + rules_only (overlap is rare).
    _epa_auto    = _gv(row, "epa_scored_apr_auto")
    _rules_only  = _gv(row, "auto_rules_only")
    # Cap rules at the auto count so the residual model bucket cannot go negative.
    _wf_rules    = min(_rules_only, _epa_auto)
    _wf_model    = max(_epa_auto - _wf_rules, 0)

    if source == "CSO":
        x = [
            "Total PAs", "— Appeals", "— Data Entry", "— Medicaid",
            "— IBRs", "— Non-ePA", "ePA Total",
            "— ePA Unscored", "— ePA Scored Denied", "ePA Scored Approval",
            "— Rules Auto", "— Model Auto", "ePA Human Reviewed",
        ]
        measure = [
            "absolute", "relative", "relative", "relative", "relative", "relative",
            "total", "relative", "relative", "total",
            "relative", "relative", "total",
        ]
        y = [
            _gv(row, "total_pas"),
            -_gv(row, "appeals_cnt"),
            -_gv(row, "data_entry_cnt"),
            -_gv(row, "medicaid_cnt"),
            -_gv(row, "ibr_cnt"),
            -_gv(row, "cso_non_epa_remaining"),
            0,
            -_gv(row, "epa_unscored"),
            -_gv(row, "epa_scored_den"),
            0,
            -_wf_rules,
            -_wf_model,
            0,
        ]
    else:
        x = [
            "Total PAs", "— Med B (OD)", "— Appeals", "— Non-ePA",
            "ePA Total", "— ePA Unscored", "— ePA Scored Denied",
            "ePA Scored Approval", "— Rules Auto", "— Model Auto",
            "ePA Human Reviewed",
        ]
        measure = [
            "absolute", "relative", "relative", "relative",
            "total", "relative", "relative", "total",
            "relative", "relative", "total",
        ]
        y = [
            _gv(row, "total_pas"),
            -_gv(row, "med_b_cnt"),
            -_gv(row, "appeals_cnt"),
            -_gv(row, "gso_non_epa_remaining"),
            0,
            -_gv(row, "epa_unscored"),
            -_gv(row, "epa_scored_den"),
            0,
            -_wf_rules,
            -_wf_model,
            0,
        ]

    texts = _wf_texts(y, measure)

    fig = go.Figure(go.Waterfall(
        orientation="v", measure=measure, x=x, y=y,
        text=texts, textposition="inside", insidetextanchor="middle",
        textfont=dict(size=12, color="white",
                      family="Inter, 'Helvetica Neue', sans-serif"),
        decreasing={"marker": {"color": dec_color}},
        increasing={"marker": {"color": inc_color}},
        totals={"marker": {"color": base_color}},
        connector=dict(line=dict(color="#cfcfcf", width=1, dash="dot")),
    ))
    fig.update_traces(width=0.6)

    # ── Ops Cost annotations on top of each bar ─────────────────────────────
    # Map waterfall x-label → detail-table bucket key for cost lookup.
    _LABEL_TO_BUCKET = {
        "Total PAs":            "Total PAs",
        "— Appeals":            "Appeals",
        "— Data Entry":         "Data Entry",
        "— Medicaid":           "Medicaid",
        "— IBRs":               "IBRs",
        "— Non-ePA":            "Non-ePA Remaining",
        "— Med B (OD)":         "Med B (OD)",
        "ePA Total":            "ePA Total",
        "— ePA Unscored":       "ePA Unscored",
        "— ePA Scored Denied":  "ePA Scored Denial",
        "ePA Scored Approval":  "ePA Scored Approval",
        "— Rules Auto":         "ePA Scored Appr — Rules Auto",
        "— Model Auto":         "ePA Scored Appr — Model Auto",
        "ePA Human Reviewed":   "ePA Scored Appr — Human",
    }
    # Compute bar-top y-coordinate per step so annotations sit above each bar.
    running = 0
    bar_tops = []
    for yi, mi in zip(y, measure):
        if mi == "absolute":
            running = yi
            bar_tops.append(running)
        elif mi == "relative":
            new_running = running + yi
            bar_tops.append(max(running, new_running))
            running = new_running
        else:  # total
            bar_tops.append(running)

    if bucket_costs:
        y_max = max(bar_tops) if bar_tops else 0
        y_shift = y_max * 0.04 if y_max else 0
        for label, top in zip(x, bar_tops):
            bkey = _LABEL_TO_BUCKET.get(label)
            if not bkey:
                continue
            cost = bucket_costs.get(bkey)
            if cost is None or cost <= 0:
                continue
            # Aggregated bucket "ePA Scored Approval" not present in detail; skip.
            fig.add_annotation(
                x=label, y=top + y_shift,
                text=f"<b>{fmt(float(cost), currency=True)}</b>",
                showarrow=False,
                font=dict(size=11, color=CVS.get("charcoal", "#333"),
                          family="Inter, 'Helvetica Neue', sans-serif"),
                yanchor="bottom",
            )

    fig.update_layout(
        height=580, showlegend=False,
        yaxis=dict(visible=False),
        xaxis=dict(
            tickfont=dict(size=11, family="Inter, 'Helvetica Neue', sans-serif"),
            tickangle=-30,
        ),
        margin=dict(t=50, l=10, r=10, b=110),
    )
    return fig


if active_view == "Sizing View":
    st.info(
        "**Sizing View** — waterfall breakdown showing how the total PA population is allocated "
        "from intake through ePA scoring for each source. "
        "Select CSO or GSO from the dropdown below."
    )

    if not st.session_state.has_run:
        st.markdown(_NOT_RUN_MSG, unsafe_allow_html=True)
    else:
        sz_df = st.session_state.sizing_df
        if sz_df is None or sz_df.empty:
            st.warning("No data returned for the selected filters.")
        else:
            def _sz_row(src):
                sub = sz_df[sz_df["PA_SOURCE"] == src]
                return sub.iloc[0].to_dict() if not sub.empty else {}

            sv_col1, sv_col2 = st.columns([1, 4])
            with sv_col1:
                sv_source = st.selectbox(
                    "Select Source", ["CSO", "GSO"], key="sz_source",
                )

            sz_r = _sz_row(sv_source)
            sz_color = CVS["red"] if sv_source == "CSO" else CVS["teal"]
            sz_accent = None if sv_source == "CSO" else "teal"

            if not sz_r:
                st.warning(f"No data available for {sv_source}.")
            else:
                total_pas    = _gv(sz_r, "total_pas")
                total_cost   = _gf(sz_r, "total_ops_cost")
                avg_aht_sec  = _gf(sz_r, "avg_aht_seconds")
                epa_scored   = _gv(sz_r, "epa_scored_apr")
                epa_auto     = _gv(sz_r, "epa_scored_apr_auto")
                epa_human    = _gv(sz_r, "epa_scored_apr_human")
                epa_unscored = _gv(sz_r, "epa_unscored")
                epa_den      = _gv(sz_r, "epa_scored_den")

                k1, k2, k3, k4, k5 = st.columns(5)
                metric_card(k1, f"{sv_source} Total PAs", fmt(total_pas),
                            accent=sz_accent)
                metric_card(k2, "ePA Scored Approval", fmt(epa_scored),
                            f"{epa_scored/total_pas*100:.1f}% of total" if total_pas else "",
                            accent=sz_accent)
                metric_card(k3, "ePA Auto Approved", fmt(epa_auto),
                            f"{epa_auto/epa_scored*100:.1f}% of scored appr" if epa_scored else "",
                            accent=sz_accent)
                metric_card(k4, "Ops Cost",
                            fmt(total_cost, currency=True) if total_cost else "-",
                            "Total operations cost", accent=sz_accent)
                metric_card(k5, "Avg AHT (Human)",
                            f"{avg_aht_sec/60:.1f} min" if avg_aht_sec else "-",
                            "Human-reviewed original PAs", accent="gray")

                st.markdown("<div style='height:12px'></div>", unsafe_allow_html=True)
                section_header(f"{sv_source} PA Population Waterfall", color=sz_color)

                # Build per-bucket Ops Cost map for waterfall bar annotations
                _bucket_costs = {}
                _sd_for_chart = st.session_state.get("sizing_detail_df")
                if _sd_for_chart is not None and not _sd_for_chart.empty:
                    _sd_src_chart = _sd_for_chart[
                        _sd_for_chart["PA_SOURCE"] == sv_source
                    ]
                    for _, _r in _sd_src_chart.iterrows():
                        _bucket_costs[_r["bucket"]] = _r.get("total_cost")

                st.plotly_chart(
                    sizing_waterfall(sz_r, sv_source, bucket_costs=_bucket_costs),
                    use_container_width=True,
                    config={"displayModeBar": False},
                )

                # ── Waterfall detail table ─────────────────────────────────────
                sd_df = st.session_state.get("sizing_detail_df")
                if sd_df is not None and not sd_df.empty:
                    st.markdown("<div style='height:8px'></div>", unsafe_allow_html=True)
                    section_header("Waterfall Detail Table", color=sz_color)

                    # Bucket display order per source
                    _BUCKET_ORDER = {
                        "CSO": [
                            "Total PAs", "Appeals", "Data Entry", "Medicaid", "IBRs",
                            "Non-ePA Remaining", "ePA Total", "ePA Unscored",
                            "ePA Scored Denial",
                            "ePA Scored Approval",
                            "ePA Scored Appr — Rules Auto",
                            "ePA Scored Appr — Model Auto",
                            "ePA Scored Appr — Human",
                        ],
                        "GSO": [
                            "Total PAs", "Med B (OD)", "Appeals", "Non-ePA Remaining",
                            "ePA Total", "ePA Unscored", "ePA Scored Denial",
                            "ePA Scored Approval",
                            "ePA Scored Appr — Rules Auto",
                            "ePA Scored Appr — Model Auto",
                            "ePA Scored Appr — Human",
                        ],
                    }

                    sd_src = sd_df[sd_df["PA_SOURCE"] == sv_source].copy()
                    if not sd_src.empty:
                        order = _BUCKET_ORDER.get(sv_source, [])
                        order_idx = {b: i for i, b in enumerate(order)}
                        sd_src["_sort"] = sd_src["bucket"].map(
                            lambda b: order_idx.get(b, 999))
                        sd_src = sd_src.sort_values("_sort").drop(columns=["_sort", "PA_SOURCE"])

                        sd_disp = pd.DataFrame()
                        sd_disp["Bucket"]           = sd_src["bucket"]
                        sd_disp["PA Volume"]        = sd_src["pa_cnt"].apply(fmt)
                        sd_disp["Approvals"]        = sd_src["appr_cnt"].apply(fmt)
                        sd_disp["Approval Rate"]    = sd_src["appr_pct"].apply(
                            lambda x: f"{x:.1f}%" if pd.notna(x) else "-")
                        sd_disp["Total Cost"]       = sd_src["total_cost"].apply(
                            lambda x: fmt(float(x), currency=True) if pd.notna(x) else "-")
                        sd_disp["Cost per PA"]      = sd_src["cost_per_pa"].apply(
                            lambda x: fmt(float(x), currency=True) if pd.notna(x) else "-")
                        sd_disp["UM Savings"]       = sd_src["savings"].apply(
                            lambda x: fmt(float(x), currency=True) if pd.notna(x) else "-")
                        sd_disp["Handle Time"]      = sd_src["handle_hrs"].apply(
                            lambda x: f"{x:.1f} hrs" if pd.notna(x) and x > 0 else "-")
                        sd_disp["AHT"]              = sd_src["aht_sec"].apply(
                            lambda x: f"{x:.0f}s" if pd.notna(x) and x > 0 else "-")

                        st.dataframe(sd_disp, hide_index=True, use_container_width=True)

                        _csv = sd_src.to_csv(index=False).encode("utf-8")
                        st.download_button(
                            label="Download detail table as CSV",
                            data=_csv,
                            file_name=f"sizing_detail_{sv_source}_{start_date}_{end_date}.csv",
                            mime="text/csv",
                        )

                with st.expander("Full sizing table (both sources)", expanded=False):
                    tbl = sz_df.copy()
                    rename = {
                        "PA_SOURCE": "Source",
                        "total_pas": "Total PAs", "appeals_cnt": "Appeals",
                        "data_entry_cnt": "Data Entry", "medicaid_cnt": "Medicaid",
                        "ibr_cnt": "IBRs", "cso_non_epa_remaining": "CSO Non-ePA",
                        "med_b_cnt": "Med B (OD)", "gso_non_epa_remaining": "GSO Non-ePA",
                        "epa_unscored": "ePA Unscored", "epa_scored_den": "ePA Scrd Denied",
                        "epa_scored_apr": "ePA Scrd Appr",
                        "epa_scored_apr_auto": "ePA Auto Appr",
                        "epa_scored_apr_human": "ePA Human Appr",
                        "total_ops_cost": "Ops Cost",
                    }
                    disp = tbl.rename(columns=rename)
                    for c in list(rename.values())[1:-1]:
                        if c in disp.columns:
                            disp[c] = disp[c].apply(fmt)
                    if "Ops Cost" in disp.columns:
                        disp["Ops Cost"] = disp["Ops Cost"].apply(
                            lambda x: fmt(float(x) if x else 0, currency=True))
                    st.dataframe(disp, hide_index=True, use_container_width=True)


# ═══════════════════════════════════════════════════════════════════════════════
# TAB 3 — TRENDS
# ═══════════════════════════════════════════════════════════════════════════════
if active_view == "Trends":
    st.info(
        "**Trends** — monthly view of all PA cases volume, automation rate, model contribution, "
        "and average handle time (seconds). Each line is split by PA Source (CSO / GSO). "
        "Handle time reflects human-reviewed original cases only. "
        "All sidebar filters apply."
    )

    if not st.session_state.has_run or st.session_state.trends_df is None:
        st.markdown(_NOT_RUN_MSG, unsafe_allow_html=True)
    else:
        df = st.session_state.trends_df
        if df is None or df.empty:
            st.warning("No data returned for the selected filters.")
        else:
            df = df.copy()
            df["auto_pct"]  = (df["epa_rules_auto"] + df["model_auto"]) \
                              / df["original_pas"].replace(0, float("nan")) * 100
            df["model_pct"] = df["model_auto"] \
                              / df["original_pas"].replace(0, float("nan")) * 100
            df["aht_sec"]   = df["avg_aht_seconds"]

            # Map each "YYYY-MM" bucket to a real date x-value: 1st of the month,
            # except the terminal bucket which is pinned to the filter's end_date
            # so the last data point renders at the actual end of the range.
            _e_ts    = pd.Timestamp(end_date)
            _end_ym  = f"{_e_ts.year:04d}-{_e_ts.month:02d}"
            _ed_str  = str(end_date)
            df["_x_date"] = df["month_year"].apply(
                lambda ym: _ed_str if ym == _end_ym else f"{ym}-01"
            )

            sources = df["PA_SOURCE"].unique().tolist()

            # Build quarterly x-axis ticks with the actual end_date as the last label.
            _s_ts = pd.Timestamp(start_date)
            _qticks = pd.date_range(_s_ts, _e_ts, freq="3MS")
            _tickvals = [str(t.date()) for t in _qticks]
            _ticktext = [t.strftime("%b '%y") for t in _qticks]
            if not _tickvals or _tickvals[-1] != _ed_str:
                if _tickvals and pd.Timestamp(_tickvals[-1]).month == _e_ts.month \
                              and pd.Timestamp(_tickvals[-1]).year == _e_ts.year:
                    _tickvals[-1] = _ed_str
                    _ticktext[-1] = end_date.strftime("%b %d, %Y")
                else:
                    _tickvals.append(_ed_str)
                    _ticktext.append(end_date.strftime("%b %d, %Y"))
            # Pad the axis range by ~1.5% on each side so the terminal markers
            # (last data point + first data point) don't render clipped on the
            # axis boundary. Without padding the last dot sits on the frame.
            _span_days = max((_e_ts - _s_ts).days, 1)
            _pad_days  = max(int(round(_span_days * 0.015)), 3)
            _range_lo  = (_s_ts - pd.Timedelta(days=_pad_days)).date().isoformat()
            _range_hi  = (_e_ts + pd.Timedelta(days=_pad_days)).date().isoformat()
            _trend_xaxis = dict(
                tickangle=-30,
                tickmode="array",
                tickvals=_tickvals,
                ticktext=_ticktext,
                range=[_range_lo, _range_hi],
            )

            def trend_line(metric_col, title, y_label, pct=False):
                fig = go.Figure()
                for src in sources:
                    sub = df[df["PA_SOURCE"] == src].sort_values("_x_date")
                    fig.add_trace(go.Scatter(
                        x=sub["_x_date"], y=sub[metric_col],
                        name=src, mode="lines+markers",
                        line=dict(color=SRC_COLORS.get(src, CVS["mid_gray"]), width=2),
                        marker=dict(size=6),
                        hovertemplate=(
                            f"<b>{src}</b><br>%{{x|%b %d, %Y}}<br>{y_label}: "
                            f"%{{y:.{'1f' if pct else '0f'}}}{'%' if pct else ''}"
                            f"<extra></extra>"
                        ),
                    ))
                fig.update_layout(
                    title=dict(text=title,
                               font=dict(size=14,
                                         family="Inter, 'Helvetica Neue', sans-serif")),
                    height=300, margin=dict(t=40, l=10, r=10, b=30),
                    legend=dict(orientation="h", y=-0.28),
                    xaxis=_trend_xaxis,
                )
                if pct:
                    fig.update_yaxes(ticksuffix="%")
                return fig

            r1c1, r1c2 = st.columns(2)
            with r1c1:
                st.plotly_chart(
                    trend_line("all_pas", "Monthly All PA Cases Volume", "PAs"),
                    use_container_width=True, config={"displayModeBar": False},
                )
            with r1c2:
                st.plotly_chart(
                    trend_line("auto_pct", "Total Auto-Approval Rate", "Auto %", pct=True),
                    use_container_width=True, config={"displayModeBar": False},
                )

            r2c1, r2c2 = st.columns(2)
            with r2c1:
                st.plotly_chart(
                    trend_line("model_pct", "Model Auto-Approval Rate", "Model %", pct=True),
                    use_container_width=True, config={"displayModeBar": False},
                )
            with r2c2:
                st.plotly_chart(
                    trend_line("aht_sec",
                               "Avg Handle Time — Human Review (seconds)", "AHT (sec)"),
                    use_container_width=True, config={"displayModeBar": False},
                )

            st.divider()

            cso_df = df[df["PA_SOURCE"] == "CSO"].sort_values("_x_date")
            if not cso_df.empty and cso_df["model_auto"].sum() > 0:
                section_header("CSO Model Breakdown by Month")
                fig_mdl = go.Figure()
                for col_name, label, color in [
                    ("glp_genai_auto",  "GLP GenAI",            MODEL_COLORS["GLP GenAI"]),
                    ("predictive_auto", "Predictive",           MODEL_COLORS["Predictive"]),
                    ("override_auto",   "Override",             MODEL_COLORS["Override"]),
                ]:
                    if col_name in cso_df.columns and cso_df[col_name].sum() > 0:
                        fig_mdl.add_trace(go.Scatter(
                            x=cso_df["_x_date"], y=cso_df[col_name],
                            name=label, mode="lines+markers",
                            line=dict(color=color, width=2), marker=dict(size=5),
                        ))
                fig_mdl.update_layout(
                    height=300, margin=dict(t=20, l=10, r=10, b=40),
                    legend=dict(orientation="h", y=-0.3),
                    xaxis=_trend_xaxis,
                )
                st.plotly_chart(fig_mdl, use_container_width=True,
                                config={"displayModeBar": False})

            gso_df = df[df["PA_SOURCE"] == "GSO"].sort_values("_x_date")
            if not gso_df.empty and gso_df["model_auto"].sum() > 0:
                section_header("GSO Model Breakdown by Month", color=CVS["teal"])
                fig_gso = go.Figure()
                for col_name, label, color in [
                    ("dlt_auto",        "DLT",                  MODEL_COLORS["DLT"]),
                    ("attachment_auto", "Attachment Automation", MODEL_COLORS["Attachment Automation"]),
                ]:
                    if col_name in gso_df.columns and gso_df[col_name].sum() > 0:
                        fig_gso.add_trace(go.Scatter(
                            x=gso_df["_x_date"], y=gso_df[col_name],
                            name=label, mode="lines+markers",
                            line=dict(color=color, width=2), marker=dict(size=5),
                        ))
                fig_gso.update_layout(
                    height=280, margin=dict(t=20, l=10, r=10, b=40),
                    legend=dict(orientation="h", y=-0.3),
                    xaxis=_trend_xaxis,
                )
                st.plotly_chart(fig_gso, use_container_width=True,
                                config={"displayModeBar": False})

            with st.expander("Raw monthly data", expanded=False):
                disp_cols = ["month_year", "PA_SOURCE", "original_pas",
                             "epa_rules_auto", "model_auto", "approvals",
                             "denials", "ops_cost", "avg_aht_seconds"]
                display = df[[c for c in disp_cols if c in df.columns]].copy()
                col_map = {
                    "month_year": "Month", "PA_SOURCE": "Source",
                    "original_pas": "Original PAs", "epa_rules_auto": "ePA Rules Auto",
                    "model_auto": "Model Auto", "approvals": "Approvals",
                    "denials": "Denials", "ops_cost": "Ops Cost ($)",
                    "avg_aht_seconds": "Avg AHT (sec)",
                }
                display = display.rename(columns=col_map)
                if "Ops Cost ($)" in display.columns:
                    display["Ops Cost ($)"] = display["Ops Cost ($)"].apply(
                        lambda x: fmt(x, currency=True))
                if "Avg AHT (sec)" in display.columns:
                    display["Avg AHT (sec)"] = display["Avg AHT (sec)"].apply(
                        lambda x: f"{x:.0f}s ({x/60:.1f}min)" if pd.notna(x) else "-")
                st.dataframe(display, hide_index=True, use_container_width=True)
