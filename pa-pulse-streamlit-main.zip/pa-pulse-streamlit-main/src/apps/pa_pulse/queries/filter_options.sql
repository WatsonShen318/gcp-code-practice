-- filter_options.sql
-- Single query that loads distinct filter values for all dynamic dropdowns.
-- Result schema: col_name STRING, col_value STRING
-- Cached 24 hours in the app.

WITH drug_name AS (
  SELECT 'drug_name' AS col_name, DRUG_NAME AS col_value, COUNT(*) AS cnt
  FROM `edp-pdev-restrict-pbmstorage.edp_paops_enr.kc_pa_data`
  WHERE DRUG_NAME IS NOT NULL AND CRTE_DT >= '2025-01-01'
  GROUP BY DRUG_NAME
  QUALIFY ROW_NUMBER() OVER (ORDER BY cnt DESC) <= 400
),
pac_cd AS (
  SELECT 'pac_cd' AS col_name, PAC_CD AS col_value, COUNT(*) AS cnt
  FROM `edp-pdev-restrict-pbmstorage.edp_paops_enr.kc_pa_data`
  WHERE PAC_CD IS NOT NULL AND CRTE_DT >= '2025-01-01'
  GROUP BY PAC_CD
  QUALIFY ROW_NUMBER() OVER (ORDER BY cnt DESC) <= 300
),
pac_cd_desc AS (
  SELECT 'pac_cd_desc' AS col_name, PAC_CD_DESC AS col_value, COUNT(*) AS cnt
  FROM `edp-pdev-restrict-pbmstorage.edp_paops_enr.kc_pa_data`
  WHERE PAC_CD_DESC IS NOT NULL AND CRTE_DT >= '2025-01-01'
  GROUP BY PAC_CD_DESC
  QUALIFY ROW_NUMBER() OVER (ORDER BY cnt DESC) <= 300
),
qset_nbr AS (
  SELECT 'qset_nbr' AS col_name, QSET_NBR AS col_value, COUNT(*) AS cnt
  FROM `edp-pdev-restrict-pbmstorage.edp_paops_enr.kc_pa_data`
  WHERE QSET_NBR IS NOT NULL AND CRTE_DT >= '2025-01-01'
  GROUP BY QSET_NBR
  QUALIFY ROW_NUMBER() OVER (ORDER BY cnt DESC) <= 300
),
qset_nbr_desc AS (
  SELECT 'qset_nbr_desc' AS col_name, QSET_NBR_DESC AS col_value, COUNT(*) AS cnt
  FROM `edp-pdev-restrict-pbmstorage.edp_paops_enr.kc_pa_data`
  WHERE QSET_NBR_DESC IS NOT NULL AND CRTE_DT >= '2025-01-01'
  GROUP BY QSET_NBR_DESC
  QUALIFY ROW_NUMBER() OVER (ORDER BY cnt DESC) <= 200
),
rfrnc_nbr AS (
  SELECT 'rfrnc_nbr' AS col_name, RFRNC_NBR AS col_value, COUNT(*) AS cnt
  FROM `edp-pdev-restrict-pbmstorage.edp_paops_enr.kc_pa_data`
  WHERE RFRNC_NBR IS NOT NULL AND CRTE_DT >= '2025-01-01'
  GROUP BY RFRNC_NBR
  QUALIFY ROW_NUMBER() OVER (ORDER BY cnt DESC) <= 400
),
rfrnc_nbr_crtra_nm AS (
  SELECT 'rfrnc_nbr_crtra_nm' AS col_name, RFRNC_NBR_CRTRA_NM AS col_value, COUNT(*) AS cnt
  FROM `edp-pdev-restrict-pbmstorage.edp_paops_enr.kc_pa_data`
  WHERE RFRNC_NBR_CRTRA_NM IS NOT NULL AND CRTE_DT >= '2025-01-01'
  GROUP BY RFRNC_NBR_CRTRA_NM
  QUALIFY ROW_NUMBER() OVER (ORDER BY cnt DESC) <= 400
),
epa_fallout_step AS (
  SELECT 'epa_fallout_step' AS col_name, EPA_FALLOUT_STEP AS col_value, COUNT(*) AS cnt
  FROM `edp-pdev-restrict-pbmstorage.edp_paops_enr.kc_pa_data`
  WHERE EPA_FALLOUT_STEP IS NOT NULL AND CRTE_DT >= '2025-01-01'
  GROUP BY EPA_FALLOUT_STEP
  QUALIFY ROW_NUMBER() OVER (ORDER BY cnt DESC) <= 100
),
epa_fallout_reason AS (
  SELECT 'epa_fallout_reason' AS col_name, EPA_FALLOUT_REASON AS col_value, COUNT(*) AS cnt
  FROM `edp-pdev-restrict-pbmstorage.edp_paops_enr.kc_pa_data`
  WHERE EPA_FALLOUT_REASON IS NOT NULL AND CRTE_DT >= '2025-01-01'
  GROUP BY EPA_FALLOUT_REASON
  QUALIFY ROW_NUMBER() OVER (ORDER BY cnt DESC) <= 100
),
gpi_cls_nm AS (
  SELECT 'gpi_cls_nm' AS col_name, GPI_CLS_NM AS col_value, COUNT(*) AS cnt
  FROM `edp-pdev-restrict-pbmstorage.edp_paops_enr.kc_pa_data`
  WHERE GPI_CLS_NM IS NOT NULL AND CRTE_DT >= '2025-01-01'
  GROUP BY GPI_CLS_NM
  QUALIFY ROW_NUMBER() OVER (ORDER BY cnt DESC) <= 200
),
gpi_4_cd AS (
  SELECT 'gpi_4_cd' AS col_name, GPI_4_CD AS col_value, COUNT(*) AS cnt
  FROM `edp-pdev-restrict-pbmstorage.edp_paops_enr.kc_pa_data`
  WHERE GPI_4_CD IS NOT NULL AND CRTE_DT >= '2025-01-01'
  GROUP BY GPI_4_CD
  QUALIFY ROW_NUMBER() OVER (ORDER BY cnt DESC) <= 200
),
gpi_10_cd AS (
  SELECT 'gpi_10_cd' AS col_name, GPI_10_CD AS col_value, COUNT(*) AS cnt
  FROM `edp-pdev-restrict-pbmstorage.edp_paops_enr.kc_pa_data`
  WHERE GPI_10_CD IS NOT NULL AND CRTE_DT >= '2025-01-01'
  GROUP BY GPI_10_CD
  QUALIFY ROW_NUMBER() OVER (ORDER BY cnt DESC) <= 300
),
formulary_name AS (
  SELECT 'formulary_name' AS col_name, FORMULARY_NAME AS col_value, COUNT(*) AS cnt
  FROM `edp-pdev-restrict-pbmstorage.edp_paops_enr.kc_pa_data`
  WHERE FORMULARY_NAME IS NOT NULL AND CRTE_DT >= '2025-01-01'
  GROUP BY FORMULARY_NAME
  QUALIFY ROW_NUMBER() OVER (ORDER BY cnt DESC) <= 200
),
formulary_status AS (
  SELECT 'formulary_status' AS col_name, FORMULARY_STATUS AS col_value, COUNT(*) AS cnt
  FROM `edp-pdev-restrict-pbmstorage.edp_paops_enr.kc_pa_data`
  WHERE FORMULARY_STATUS IS NOT NULL AND CRTE_DT >= '2025-01-01'
  GROUP BY FORMULARY_STATUS
  QUALIFY ROW_NUMBER() OVER (ORDER BY cnt DESC) <= 50
),
formulary_pa_flg AS (
  SELECT 'formulary_pa_flg' AS col_name, CAST(FORMULARY_PA_FLG AS STRING) AS col_value,
    COUNT(*) AS cnt
  FROM `edp-pdev-restrict-pbmstorage.edp_paops_enr.kc_pa_data`
  WHERE FORMULARY_PA_FLG IS NOT NULL AND CRTE_DT >= '2025-01-01'
  GROUP BY FORMULARY_PA_FLG
  QUALIFY ROW_NUMBER() OVER (ORDER BY cnt DESC) <= 20
),
um_typ_cd AS (
  SELECT 'um_typ_cd' AS col_name, UM_TYP_CD AS col_value, COUNT(*) AS cnt
  FROM `edp-pdev-restrict-pbmstorage.edp_paops_enr.kc_pa_data`
  WHERE UM_TYP_CD IS NOT NULL AND CRTE_DT >= '2025-01-01'
  GROUP BY UM_TYP_CD
  QUALIFY ROW_NUMBER() OVER (ORDER BY cnt DESC) <= 50
),
pa_fill_type AS (
  SELECT 'pa_fill_type' AS col_name, PA_FILL_TYPE AS col_value, COUNT(*) AS cnt
  FROM `edp-pdev-restrict-pbmstorage.edp_paops_enr.kc_pa_data`
  WHERE PA_FILL_TYPE IS NOT NULL AND CRTE_DT >= '2025-01-01'
  GROUP BY PA_FILL_TYPE
  QUALIFY ROW_NUMBER() OVER (ORDER BY cnt DESC) <= 30
),
bnft_plan_nm AS (
  SELECT 'bnft_plan_nm' AS col_name, BNFT_PLAN_NM AS col_value, COUNT(*) AS cnt
  FROM `edp-pdev-restrict-pbmstorage.edp_paops_enr.kc_pa_data`
  WHERE BNFT_PLAN_NM IS NOT NULL AND CRTE_DT >= '2025-01-01'
  GROUP BY BNFT_PLAN_NM
  QUALIFY ROW_NUMBER() OVER (ORDER BY cnt DESC) <= 100
),
initial_path AS (
  SELECT 'initial_approval_path' AS col_name, INITIAL_APPROVAL_PATH AS col_value, COUNT(*) AS cnt
  FROM `edp-pdev-restrict-pbmstorage.edp_paops_enr.kc_pa_data`
  WHERE INITIAL_APPROVAL_PATH IS NOT NULL AND CRTE_DT >= '2025-01-01'
  GROUP BY INITIAL_APPROVAL_PATH
  QUALIFY ROW_NUMBER() OVER (ORDER BY cnt DESC) <= 100
),
final_path AS (
  SELECT 'final_approval_path' AS col_name, FINAL_APPROVAL_PATH AS col_value, COUNT(*) AS cnt
  FROM `edp-pdev-restrict-pbmstorage.edp_paops_enr.kc_pa_data`
  WHERE FINAL_APPROVAL_PATH IS NOT NULL AND CRTE_DT >= '2025-01-01'
  GROUP BY FINAL_APPROVAL_PATH
  QUALIFY ROW_NUMBER() OVER (ORDER BY cnt DESC) <= 100
),
lvl0_acct_nm AS (
  SELECT 'lvl0_acct_nm' AS col_name, LVL0_ACCT_NM AS col_value, COUNT(*) AS cnt
  FROM `edp-pdev-restrict-pbmstorage.edp_paops_enr.kc_pa_data`
  WHERE LVL0_ACCT_NM IS NOT NULL AND CRTE_DT >= '2025-01-01'
  GROUP BY LVL0_ACCT_NM
  QUALIFY ROW_NUMBER() OVER (ORDER BY cnt DESC) <= 200
),
lvl1_acct_nm AS (
  SELECT 'lvl1_acct_nm' AS col_name, LVL1_ACCT_NM AS col_value, COUNT(*) AS cnt
  FROM `edp-pdev-restrict-pbmstorage.edp_paops_enr.kc_pa_data`
  WHERE LVL1_ACCT_NM IS NOT NULL AND CRTE_DT >= '2025-01-01'
  GROUP BY LVL1_ACCT_NM
  QUALIFY ROW_NUMBER() OVER (ORDER BY cnt DESC) <= 400
),
lvl1_acct_id AS (
  SELECT 'lvl1_acct_id' AS col_name, CAST(LVL1_ACCT_ID AS STRING) AS col_value, COUNT(*) AS cnt
  FROM `edp-pdev-restrict-pbmstorage.edp_paops_enr.kc_pa_data`
  WHERE LVL1_ACCT_ID IS NOT NULL AND CRTE_DT >= '2025-01-01'
  GROUP BY LVL1_ACCT_ID
  QUALIFY ROW_NUMBER() OVER (ORDER BY cnt DESC) <= 400
),
pag_cd AS (
  SELECT 'pag_cd' AS col_name, PAG_CD AS col_value, COUNT(*) AS cnt
  FROM `edp-pdev-restrict-pbmstorage.edp_paops_enr.kc_pa_data`
  WHERE PAG_CD IS NOT NULL AND CRTE_DT >= '2025-01-01'
  GROUP BY PAG_CD
  QUALIFY ROW_NUMBER() OVER (ORDER BY cnt DESC) <= 400
),
pag_cd_desc AS (
  SELECT 'pag_cd_desc' AS col_name, PAG_CD_DESC AS col_value, COUNT(*) AS cnt
  FROM `edp-pdev-restrict-pbmstorage.edp_paops_enr.kc_pa_data`
  WHERE PAG_CD_DESC IS NOT NULL AND CRTE_DT >= '2025-01-01'
  GROUP BY PAG_CD_DESC
  QUALIFY ROW_NUMBER() OVER (ORDER BY cnt DESC) <= 400
),
macro_type AS (
  SELECT 'macro_type' AS col_name, mt AS col_value, COUNT(*) AS cnt
  FROM (
    SELECT
      CASE
        WHEN kc.PA_SOURCE = 'GSO' THEN 'GSO-MHK'
        WHEN config_macro_dtl.PARTL_IND = 1 THEN 'PARTIAL'
        WHEN ARRAY_LENGTH(SPLIT(REPLACE(TRIM(pa_main.APPLD_MACROS_TXT), "'", ""), ',')) > 1
          THEN 'MULTIPLE MACROS'
        WHEN pa_main.APPLD_MACROS_TXT IS NOT NULL
         AND TRIM(pa_main.APPLD_MACROS_TXT) <> '' THEN 'FULL'
        ELSE NULL
      END AS mt
    FROM `edp-pdev-restrict-pbmstorage.edp_paops_enr.kc_pa_data` kc
    LEFT JOIN `edp-prod-restrict-pbmstorage.edp_customer_pbmedh_cnsv.V_PRIOR_ATHZN_MAIN` pa_main
      ON kc.CASE_ID = pa_main.PRIOR_ATHZN_NBR
    LEFT JOIN `edp-prod-restrict-pbmstorage.edp_customer_pbmedh_cnsv.V_CAS_PAORXCLAIM` config_macro_dtl
      ON REPLACE(pa_main.APPLD_MACROS_TXT, "'", "") = config_macro_dtl.PRIOR_ATHZN_OVRD_ID
     AND TRIM(UPPER(config_macro_dtl.RSLTN_TYP_CD)) = 'APPROVED'
    WHERE kc.CRTE_DT >= '2025-01-01'
  )
  WHERE mt IS NOT NULL
  GROUP BY mt
  QUALIFY ROW_NUMBER() OVER (ORDER BY cnt DESC) <= 50
)

SELECT col_name, col_value FROM drug_name
UNION ALL SELECT col_name, col_value FROM pac_cd
UNION ALL SELECT col_name, col_value FROM pac_cd_desc
UNION ALL SELECT col_name, col_value FROM qset_nbr
UNION ALL SELECT col_name, col_value FROM qset_nbr_desc
UNION ALL SELECT col_name, col_value FROM rfrnc_nbr
UNION ALL SELECT col_name, col_value FROM rfrnc_nbr_crtra_nm
UNION ALL SELECT col_name, col_value FROM epa_fallout_step
UNION ALL SELECT col_name, col_value FROM epa_fallout_reason
UNION ALL SELECT col_name, col_value FROM gpi_cls_nm
UNION ALL SELECT col_name, col_value FROM gpi_4_cd
UNION ALL SELECT col_name, col_value FROM gpi_10_cd
UNION ALL SELECT col_name, col_value FROM formulary_name
UNION ALL SELECT col_name, col_value FROM formulary_status
UNION ALL SELECT col_name, col_value FROM formulary_pa_flg
UNION ALL SELECT col_name, col_value FROM um_typ_cd
UNION ALL SELECT col_name, col_value FROM pa_fill_type
UNION ALL SELECT col_name, col_value FROM bnft_plan_nm
UNION ALL SELECT col_name, col_value FROM initial_path
UNION ALL SELECT col_name, col_value FROM final_path
UNION ALL SELECT col_name, col_value FROM lvl0_acct_nm
UNION ALL SELECT col_name, col_value FROM lvl1_acct_nm
UNION ALL SELECT col_name, col_value FROM lvl1_acct_id
UNION ALL SELECT col_name, col_value FROM pag_cd
UNION ALL SELECT col_name, col_value FROM pag_cd_desc
UNION ALL SELECT col_name, col_value FROM macro_type
ORDER BY col_name, col_value
