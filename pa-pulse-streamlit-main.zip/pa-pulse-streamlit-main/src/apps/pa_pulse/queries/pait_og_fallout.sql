-- pait_og_fallout.sql
-- ePA fallout step, reason, and step→reason breakdowns.
-- CSO: EPA_FALLOUT_STEP + EPA_FALLOUT_REASON (both on same row — linkage available)
-- GSO: EPA_FALLOUT_REASON only (no step data for MHK)
-- Schema: PA_SOURCE, fallout_type, fallout_step (NULL except for step_reason rows), fallout_value, cnt
-- Placeholders: start_date, end_date, extra_filters

WITH kc_pa_data AS (
  SELECT
    kc.* EXCEPT(MACRO_TYPE),
    CASE
      WHEN kc.PA_SOURCE = 'GSO' THEN 'GSO-MHK'
      WHEN config_macro_dtl.PARTL_IND = 1 THEN 'PARTIAL'
      WHEN ARRAY_LENGTH(SPLIT(REPLACE(TRIM(pa_main.APPLD_MACROS_TXT), "'", ""), ',')) > 1
        THEN 'MULTIPLE MACROS'
      WHEN pa_main.APPLD_MACROS_TXT IS NOT NULL
       AND TRIM(pa_main.APPLD_MACROS_TXT) <> '' THEN 'FULL'
      ELSE NULL
    END AS MACRO_TYPE
  FROM `edp-pdev-restrict-pbmstorage.edp_paops_enr.kc_pa_data` kc
  LEFT JOIN `edp-prod-restrict-pbmstorage.edp_customer_pbmedh_cnsv.V_PRIOR_ATHZN_MAIN` pa_main
    ON kc.CASE_ID = pa_main.PRIOR_ATHZN_NBR
  LEFT JOIN `edp-prod-restrict-pbmstorage.edp_customer_pbmedh_cnsv.V_CAS_PAORXCLAIM` config_macro_dtl
    ON REPLACE(pa_main.APPLD_MACROS_TXT, "'", "") = config_macro_dtl.PRIOR_ATHZN_OVRD_ID
   AND TRIM(UPPER(config_macro_dtl.RSLTN_TYP_CD)) = 'APPROVED'
  WHERE kc.CRTE_DT BETWEEN '{start_date}' AND '{end_date}'
),
step_data AS (
  SELECT
    PA_SOURCE,
    'step'           AS fallout_type,
    CAST(NULL AS STRING) AS fallout_step,
    EPA_FALLOUT_STEP AS fallout_value,
    COUNT(*)         AS cnt
  FROM kc_pa_data
  WHERE CRTE_DT BETWEEN '{start_date}' AND '{end_date}'
    AND PA_ORIGIN_CD = 'EPA'
    AND PA_SOURCE = 'CSO'
    AND AUTO_APPROVAL = 'N'
    AND EPA_FALLOUT_STEP IS NOT NULL
    AND EPA_FALLOUT_STEP NOT LIKE '%may be ePAs Auto%'
    AND EPA_FALLOUT_STEP NOT LIKE '%Non-ePAs%'
    {extra_filters}
  GROUP BY 1, 2, 3, 4
  HAVING cnt > 0
),
reason_data AS (
  SELECT
    PA_SOURCE,
    'reason'             AS fallout_type,
    CAST(NULL AS STRING) AS fallout_step,
    EPA_FALLOUT_REASON   AS fallout_value,
    COUNT(*)             AS cnt
  FROM kc_pa_data
  WHERE CRTE_DT BETWEEN '{start_date}' AND '{end_date}'
    AND PA_ORIGIN_CD = 'EPA'
    AND AUTO_APPROVAL = 'N'
    AND EPA_FALLOUT_REASON IS NOT NULL
    AND EPA_FALLOUT_REASON NOT LIKE '%may be ePAs Auto%'
    AND EPA_FALLOUT_REASON NOT LIKE '%Non-ePAs%'
    AND EPA_FALLOUT_REASON NOT LIKE '%MHK - It may%'
    {extra_filters}
  GROUP BY 1, 2, 3, 4
  HAVING cnt > 0
),
step_reason_data AS (
  -- CSO only: top-8 reasons within each of the top-15 steps
  SELECT
    PA_SOURCE,
    'step_reason'        AS fallout_type,
    EPA_FALLOUT_STEP     AS fallout_step,
    EPA_FALLOUT_REASON   AS fallout_value,
    COUNT(*)             AS cnt
  FROM kc_pa_data
  WHERE CRTE_DT BETWEEN '{start_date}' AND '{end_date}'
    AND PA_ORIGIN_CD = 'EPA'
    AND PA_SOURCE = 'CSO'
    AND AUTO_APPROVAL = 'N'
    AND EPA_FALLOUT_STEP IS NOT NULL
    AND EPA_FALLOUT_REASON IS NOT NULL
    AND EPA_FALLOUT_STEP NOT LIKE '%may be ePAs Auto%'
    AND EPA_FALLOUT_STEP NOT LIKE '%Non-ePAs%'
    AND EPA_FALLOUT_REASON NOT LIKE '%may be ePAs Auto%'
    AND EPA_FALLOUT_REASON NOT LIKE '%Non-ePAs%'
    {extra_filters}
  GROUP BY 1, 2, 3, 4
  HAVING cnt > 0
)

,
-- Cases that DON'T have a recorded fallout step (CSO) — synthetic bucket so the
-- donut/table reconciles to the full ePA+human-reviewed universe.
no_step_data AS (
  SELECT
    PA_SOURCE,
    'step'                          AS fallout_type,
    CAST(NULL AS STRING)            AS fallout_step,
    'No fallout category found'     AS fallout_value,
    COUNT(*)                        AS cnt
  FROM kc_pa_data
  WHERE CRTE_DT BETWEEN '{start_date}' AND '{end_date}'
    AND PA_ORIGIN_CD = 'EPA'
    AND PA_SOURCE = 'CSO'
    AND AUTO_APPROVAL = 'N'
    AND (
      EPA_FALLOUT_STEP IS NULL
      OR EPA_FALLOUT_STEP LIKE '%may be ePAs Auto%'
      OR EPA_FALLOUT_STEP LIKE '%Non-ePAs%'
    )
    {extra_filters}
  GROUP BY 1, 2, 3, 4
  HAVING cnt > 0
),
-- 'No fallout' bucket split: GSO splits into 'Scored Denial — No Loop 2' and
-- 'Fallout unknown'; CSO stays as a single 'No fallout category found'.
no_reason_data AS (
  SELECT
    PA_SOURCE,
    'reason'                        AS fallout_type,
    CAST(NULL AS STRING)            AS fallout_step,
    CASE
      WHEN PA_SOURCE = 'GSO' AND AUTO_SCORE_RESULT_STATUS = 'DENIAL'
        THEN 'Auto-scored result of this PA is Denied'
      WHEN PA_SOURCE = 'GSO'
        THEN 'Fallout unknown'
      ELSE 'No fallout category found'
    END                             AS fallout_value,
    COUNT(*)                        AS cnt
  FROM kc_pa_data
  WHERE CRTE_DT BETWEEN '{start_date}' AND '{end_date}'
    AND PA_ORIGIN_CD = 'EPA'
    AND AUTO_APPROVAL = 'N'
    AND (
      EPA_FALLOUT_REASON IS NULL
      OR EPA_FALLOUT_REASON LIKE '%may be ePAs Auto%'
      OR EPA_FALLOUT_REASON LIKE '%Non-ePAs%'
      OR EPA_FALLOUT_REASON LIKE '%MHK - It may%'
    )
    {extra_filters}
  GROUP BY 1, 2, 3, 4
  HAVING cnt > 0
)

SELECT * FROM step_data
UNION ALL
SELECT * FROM no_step_data
UNION ALL
SELECT * FROM reason_data
UNION ALL
SELECT * FROM no_reason_data
UNION ALL
SELECT * FROM step_reason_data
ORDER BY PA_SOURCE, fallout_type, cnt DESC
