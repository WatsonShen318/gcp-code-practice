-- pait_og_raw.sql
-- OG View raw data tab — full lifecycle metrics per group.
-- Decision rules:
--   All PAs           → FNL_RSLTN_CD
--   Original Review   → ORGNL_RSLTN_CD  (APPEAL_IND = 0)
--   Appeals           → FNL_RSLTN_CD    (APPEAL_IND > 0)
-- Always counts both appeals and original PAs.
-- Placeholders: group_by_cols, group_by_list, start_date, end_date, extra_filters
-- Note: extra_filters should NOT contain AND APPEAL_IND = 0 here.

WITH kc_pa_data AS (
  SELECT
    kc.* EXCEPT(MACRO_TYPE),
    CASE
      WHEN kc.PA_SOURCE = 'GSO' THEN 'GSO-MHK'
      WHEN config_macro_dtl.PARTL_IND = 1 THEN 'PARTIAL'
      WHEN ARRAY_LENGTH(SPLIT(REPLACE(TRIM(pa_main.APPLD_MACROS_TXT), "'", ""), ',')) > 1
        THEN 'MULTIPLE MACROS'
      WHEN pa_main.APPLD_MACROS_TXT IS NOT NULL
       AND TRIM(pa_main.APPLD_MACROS_TXT) <> '' THEN 'FULL'
      ELSE NULL
    END AS MACRO_TYPE
  FROM `edp-pdev-restrict-pbmstorage.edp_paops_enr.kc_pa_data` kc
  LEFT JOIN `edp-prod-restrict-pbmstorage.edp_customer_pbmedh_cnsv.V_PRIOR_ATHZN_MAIN` pa_main
    ON kc.CASE_ID = pa_main.PRIOR_ATHZN_NBR
  LEFT JOIN `edp-prod-restrict-pbmstorage.edp_customer_pbmedh_cnsv.V_CAS_PAORXCLAIM` config_macro_dtl
    ON REPLACE(pa_main.APPLD_MACROS_TXT, "'", "") = config_macro_dtl.PRIOR_ATHZN_OVRD_ID
   AND TRIM(UPPER(config_macro_dtl.RSLTN_TYP_CD)) = 'APPROVED'
)

SELECT
  {group_by_cols},

  -- =========================================================================
  -- Volume / Walkaways / Top-line $$
  -- =========================================================================
  COUNT(*)                                                                     AS overall_cases,
  SUM(CAST(COALESCE(WALKAWAY_IND, 0) AS INT64))                                AS walkaway_cnt,
  SUM(CAST(COALESCE(TOTAL_CLIENT_SAVINGS_DE_DUP, 0) AS FLOAT64))               AS pa_savings,
  SUM(CAST(COALESCE(CASE_TOTAL_OPS_COST, 0) AS FLOAT64))                       AS total_ops_cost,
  SUM(COALESCE(CAST(TOTAL_HANDLE_TIME AS FLOAT64), 0))                         AS total_handle_sec,

  -- =========================================================================
  -- ALL PAs  (incl. appeals; uses FNL_RSLTN_CD)
  -- =========================================================================
  COUNT(*)                                                                     AS all_pas,
  COUNTIF(AUTO_APPROVAL = 'Y')                                                 AS all_pa_auto,
  COUNTIF(FNL_RSLTN_CD = 'APPROVAL')                                           AS all_pa_apr,
  COUNTIF(FNL_RSLTN_CD = 'DENIAL')                                             AS all_pa_den,
  COUNTIF(FNL_RSLTN_CD IN ('ADMIN DENIAL','DISMISS'))                          AS all_pa_adm,

  -- ALL ePAs ----------------------------------------------------------------
  COUNTIF(PA_ORIGIN_CD = 'EPA')                                                AS all_epa,
  COUNTIF(PA_ORIGIN_CD = 'EPA' AND AUTO_APPROVAL = 'Y')                        AS all_epa_auto,
  COUNTIF(PA_ORIGIN_CD = 'EPA' AND AUTO_APPROVAL = 'Y' AND (
       COALESCE(IS_GLP_GENAI_COMBINED,0)           = 1
    OR COALESCE(IS_GENERAL_GENAI_AUTO_APPROVED,0)  = 1
    OR COALESCE(IS_PREDICTIVE_AUTO_APPROVED,0)     = 1
    OR COALESCE(IS_OVERRIDE_AUTO_APPROVED,0)       = 1
    OR COALESCE(IS_DLT_AUTO_APPROVED,0)            = 1
    OR COALESCE(IS_ATTACHMENT_AUTO_APPROVED,0)     = 1))                       AS all_epa_auto_model,
  COUNTIF(PA_ORIGIN_CD = 'EPA' AND AUTO_APPROVAL = 'N')                        AS all_epa_human,
  COUNTIF(PA_ORIGIN_CD = 'EPA' AND AUTO_APPROVAL = 'N'
    AND FNL_RSLTN_CD = 'APPROVAL')                                             AS all_epa_human_apr,
  COUNTIF(PA_ORIGIN_CD = 'EPA' AND AUTO_APPROVAL = 'N'
    AND FNL_RSLTN_CD = 'DENIAL')                                               AS all_epa_human_den,
  COUNTIF(PA_ORIGIN_CD = 'EPA' AND AUTO_APPROVAL = 'N'
    AND FNL_RSLTN_CD IN ('ADMIN DENIAL','DISMISS'))                            AS all_epa_human_adm,
  SUM(CAST(IF(PA_ORIGIN_CD = 'EPA' AND AUTO_APPROVAL = 'N',
    COALESCE(CASE_TOTAL_OPS_COST,0), 0) AS FLOAT64))                           AS all_epa_human_ops_cost,
  SUM(CAST(IF(PA_ORIGIN_CD = 'EPA' AND AUTO_APPROVAL = 'N',
    COALESCE(TOTAL_HANDLE_TIME,0), 0) AS FLOAT64))                             AS all_epa_human_handle_sec,
  SUM(CAST(IF(PA_ORIGIN_CD = 'EPA' AND AUTO_APPROVAL = 'N',
    COALESCE(TOTAL_CLIENT_SAVINGS_DE_DUP,0), 0) AS FLOAT64))                   AS all_epa_human_savings,

  -- ALL Non-ePAs ------------------------------------------------------------
  COUNTIF(PA_ORIGIN_CD != 'EPA')                                               AS all_non_epa,
  COUNTIF(PA_ORIGIN_CD != 'EPA' AND FNL_RSLTN_CD = 'APPROVAL')                 AS all_non_epa_apr,
  COUNTIF(PA_ORIGIN_CD != 'EPA' AND FNL_RSLTN_CD = 'DENIAL')                   AS all_non_epa_den,
  COUNTIF(PA_ORIGIN_CD != 'EPA' AND FNL_RSLTN_CD IN ('ADMIN DENIAL','DISMISS'))AS all_non_epa_adm,
  SUM(CAST(IF(PA_ORIGIN_CD != 'EPA',
    COALESCE(CASE_TOTAL_OPS_COST,0), 0) AS FLOAT64))                           AS all_non_epa_ops_cost,
  SUM(CAST(IF(PA_ORIGIN_CD != 'EPA',
    COALESCE(TOTAL_HANDLE_TIME,0), 0) AS FLOAT64))                             AS all_non_epa_handle_sec,
  SUM(CAST(IF(PA_ORIGIN_CD != 'EPA',
    COALESCE(TOTAL_CLIENT_SAVINGS_DE_DUP,0), 0) AS FLOAT64))                   AS all_non_epa_savings,

  -- =========================================================================
  -- ORIGINAL REVIEW  (APPEAL_IND = 0; uses ORGNL_RSLTN_CD)
  -- =========================================================================
  COUNTIF(APPEAL_IND = 0)                                                      AS orig_pas,
  COUNTIF(APPEAL_IND = 0 AND ORGNL_RSLTN_CD = 'APPROVAL')                      AS orig_pa_apr,
  COUNTIF(APPEAL_IND = 0 AND ORGNL_RSLTN_CD = 'DENIAL')                        AS orig_pa_den,
  COUNTIF(APPEAL_IND = 0 AND ORGNL_RSLTN_CD IN ('ADMIN DENIAL','DISMISS'))     AS orig_pa_adm,

  -- ORIG ePAs ---------------------------------------------------------------
  COUNTIF(APPEAL_IND = 0 AND PA_ORIGIN_CD = 'EPA')                             AS orig_epa,
  COUNTIF(APPEAL_IND = 0 AND PA_ORIGIN_CD = 'EPA' AND AUTO_APPROVAL = 'Y')     AS orig_epa_auto,
  COUNTIF(APPEAL_IND = 0 AND PA_ORIGIN_CD = 'EPA' AND AUTO_APPROVAL = 'Y' AND (
       COALESCE(IS_GLP_GENAI_COMBINED,0)           = 1
    OR COALESCE(IS_GENERAL_GENAI_AUTO_APPROVED,0)  = 1
    OR COALESCE(IS_PREDICTIVE_AUTO_APPROVED,0)     = 1
    OR COALESCE(IS_OVERRIDE_AUTO_APPROVED,0)       = 1
    OR COALESCE(IS_DLT_AUTO_APPROVED,0)            = 1
    OR COALESCE(IS_ATTACHMENT_AUTO_APPROVED,0)     = 1))                       AS orig_epa_auto_model,
  COUNTIF(APPEAL_IND = 0 AND PA_ORIGIN_CD = 'EPA' AND AUTO_APPROVAL = 'N')     AS orig_epa_human,
  COUNTIF(APPEAL_IND = 0 AND PA_ORIGIN_CD = 'EPA' AND AUTO_APPROVAL = 'N'
    AND ORGNL_RSLTN_CD = 'APPROVAL')                                           AS orig_epa_human_apr,
  COUNTIF(APPEAL_IND = 0 AND PA_ORIGIN_CD = 'EPA' AND AUTO_APPROVAL = 'N'
    AND ORGNL_RSLTN_CD = 'DENIAL')                                             AS orig_epa_human_den,
  COUNTIF(APPEAL_IND = 0 AND PA_ORIGIN_CD = 'EPA' AND AUTO_APPROVAL = 'N'
    AND ORGNL_RSLTN_CD IN ('ADMIN DENIAL','DISMISS'))                          AS orig_epa_human_adm,
  SUM(CAST(IF(APPEAL_IND = 0 AND PA_ORIGIN_CD = 'EPA' AND AUTO_APPROVAL = 'N',
    COALESCE(CASE_TOTAL_OPS_COST,0), 0) AS FLOAT64))                           AS orig_epa_human_ops_cost,
  SUM(CAST(IF(APPEAL_IND = 0 AND PA_ORIGIN_CD = 'EPA' AND AUTO_APPROVAL = 'N',
    COALESCE(TOTAL_HANDLE_TIME,0), 0) AS FLOAT64))                             AS orig_epa_human_handle_sec,
  SUM(CAST(IF(APPEAL_IND = 0 AND PA_ORIGIN_CD = 'EPA' AND AUTO_APPROVAL = 'N',
    COALESCE(TOTAL_CLIENT_SAVINGS_DE_DUP,0), 0) AS FLOAT64))                   AS orig_epa_human_savings,

  -- ORIG Non-ePAs -----------------------------------------------------------
  COUNTIF(APPEAL_IND = 0 AND PA_ORIGIN_CD != 'EPA')                            AS orig_non_epa,
  COUNTIF(APPEAL_IND = 0 AND PA_ORIGIN_CD != 'EPA'
    AND ORGNL_RSLTN_CD = 'APPROVAL')                                           AS orig_non_epa_apr,
  COUNTIF(APPEAL_IND = 0 AND PA_ORIGIN_CD != 'EPA'
    AND ORGNL_RSLTN_CD = 'DENIAL')                                             AS orig_non_epa_den,
  COUNTIF(APPEAL_IND = 0 AND PA_ORIGIN_CD != 'EPA'
    AND ORGNL_RSLTN_CD IN ('ADMIN DENIAL','DISMISS'))                          AS orig_non_epa_adm,
  SUM(CAST(IF(APPEAL_IND = 0 AND PA_ORIGIN_CD != 'EPA',
    COALESCE(CASE_TOTAL_OPS_COST,0), 0) AS FLOAT64))                           AS orig_non_epa_ops_cost,
  SUM(CAST(IF(APPEAL_IND = 0 AND PA_ORIGIN_CD != 'EPA',
    COALESCE(TOTAL_HANDLE_TIME,0), 0) AS FLOAT64))                             AS orig_non_epa_handle_sec,
  SUM(CAST(IF(APPEAL_IND = 0 AND PA_ORIGIN_CD != 'EPA',
    COALESCE(TOTAL_CLIENT_SAVINGS_DE_DUP,0), 0) AS FLOAT64))                   AS orig_non_epa_savings,

  -- =========================================================================
  -- APPEALS  (APPEAL_IND > 0)
  --   Counts (Approvals / Denials / Admin Denials) → ORGNL_RSLTN_CD
  --   Approve on Appeal                            → ORGNL DENIAL → FNL APPROVAL
  --   Durable Denial                               → ORGNL DENIAL → FNL DENIAL/ADMIN/DISMISS
  -- =========================================================================
  COUNTIF(APPEAL_IND > 0)                                                      AS appeal_pas,
  COUNTIF(APPEAL_IND > 0 AND ORGNL_RSLTN_CD = 'APPROVAL')                      AS appeal_apr,
  COUNTIF(APPEAL_IND > 0 AND ORGNL_RSLTN_CD = 'DENIAL')                        AS appeal_den,
  COUNTIF(APPEAL_IND > 0 AND ORGNL_RSLTN_CD IN ('ADMIN DENIAL','DISMISS'))     AS appeal_adm,
  COUNTIF(APPEAL_IND > 0 AND ORGNL_RSLTN_CD = 'DENIAL'
    AND FNL_RSLTN_CD = 'APPROVAL')                                             AS appeal_aoa,
  COUNTIF(APPEAL_IND > 0 AND ORGNL_RSLTN_CD = 'DENIAL'
    AND FNL_RSLTN_CD IN ('DENIAL','ADMIN DENIAL'))                             AS appeal_durable_denial,
  SUM(CAST(IF(APPEAL_IND > 0,
    COALESCE(CASE_TOTAL_OPS_COST,0), 0) AS FLOAT64))                           AS appeal_ops_cost,
  SUM(CAST(IF(APPEAL_IND > 0,
    COALESCE(TOTAL_HANDLE_TIME,0), 0) AS FLOAT64))                             AS appeal_handle_sec,
  SUM(CAST(IF(APPEAL_IND > 0,
    COALESCE(TOTAL_CLIENT_SAVINGS_DE_DUP,0), 0) AS FLOAT64))                   AS appeal_savings

FROM kc_pa_data
WHERE CRTE_DT BETWEEN '{start_date}' AND '{end_date}'
{extra_filters}
GROUP BY {group_by_list}
ORDER BY overall_cases DESC
