-- walkaway.sql
-- Walkaway metrics from source-specific PAIT walkaway summary tables.
-- CSO: PAIT_CAS_PA_WALKAWAY_PERF_smry_vDaily
-- GSO: PAIT_MHK_PA_WALKAWAY_PERF_smry_vDaily
-- Savings column: WALKAWAY_SAVINGS (sum of total_client_savings_de_dup from uma_*_pa_walkaway).
-- CLIENT_SAVINGS_DE_DUP is zeroed out for walkaway rows in the FULL smry table — use this file.
-- Placeholders: start_date, end_date, source_filter

WITH cas AS (
  SELECT
    'CSO'                                                               AS PA_SOURCE,
    SUM(COALESCE(WALKAWAY_SAVINGS, 0))                                  AS walkaway_savings,
    SUM(COALESCE(WALKAWAYS_CNT, 0))                                     AS walkaway_cnt,
    COUNTIF(COALESCE(WALKAWAYS_FILL_TYPE, '') = 'WALKAWAYS_NO_FILL')    AS walkaway_no_fill,
    COUNTIF(COALESCE(WALKAWAYS_FILL_TYPE, '') = 'WALKAWAYS_ALT_FILL')   AS walkaway_alt_fill,
    COUNTIF(COALESCE(WALKAWAYS_FILL_TYPE, '') = 'WALKAWAYS_TRGT_FILL')  AS walkaway_trgt_fill,
    COUNTIF(
      COALESCE(WALKAWAYS_FILL_TYPE, '') != ''
      AND COALESCE(WALKAWAYS_FILL_TYPE, '') NOT IN (
        'WALKAWAYS_NO_FILL', 'WALKAWAYS_ALT_FILL', 'WALKAWAYS_TRGT_FILL'))
                                                                        AS walkaway_other_fill
  FROM `edp-prod-restrict-pbmstorage.edp_paops_enr.PAIT_CAS_PA_WALKAWAY_PERF_smry_vDaily`
  WHERE EPSD_STRT_DT BETWEEN '{start_date}' AND '{end_date}'
),
mhk AS (
  SELECT
    'GSO'                                                               AS PA_SOURCE,
    SUM(COALESCE(WALKAWAY_SAVINGS, 0))                                  AS walkaway_savings,
    SUM(COALESCE(WALKAWAYS_CNT, 0))                                     AS walkaway_cnt,
    COUNTIF(COALESCE(WALKAWAYS_FILL_TYPE, '') = 'WALKAWAYS_NO_FILL')    AS walkaway_no_fill,
    COUNTIF(COALESCE(WALKAWAYS_FILL_TYPE, '') = 'WALKAWAYS_ALT_FILL')   AS walkaway_alt_fill,
    COUNTIF(COALESCE(WALKAWAYS_FILL_TYPE, '') = 'WALKAWAYS_TRGT_FILL')  AS walkaway_trgt_fill,
    COUNTIF(
      COALESCE(WALKAWAYS_FILL_TYPE, '') != ''
      AND COALESCE(WALKAWAYS_FILL_TYPE, '') NOT IN (
        'WALKAWAYS_NO_FILL', 'WALKAWAYS_ALT_FILL', 'WALKAWAYS_TRGT_FILL'))
                                                                        AS walkaway_other_fill
  FROM `edp-prod-restrict-pbmstorage.edp_paops_enr.PAIT_MHK_PA_WALKAWAY_PERF_smry_vDaily`
  WHERE EPSD_STRT_DT BETWEEN '{start_date}' AND '{end_date}'
)

SELECT * FROM (
  SELECT * FROM cas
  UNION ALL
  SELECT * FROM mhk
)
WHERE 1=1
  {source_filter}
ORDER BY PA_SOURCE
