-- sizing_view.sql
-- Sizing View tab: per-source metrics for CSO and GSO waterfall charts.
-- CSO waterfall: Total → Appeals → Data Entry → Medicaid → IBRs →
--                Non-ePA remaining → ePA Unscored → ePA Scored Denied →
--                ePA Scored Approval Auto → ePA Scored Approval Human
-- GSO waterfall: Total → Med B (OD) → Appeals → Non-ePA →
--                ePA Unscored → ePA Scored Denied → ePA Scored Approval Auto →
--                ePA Scored Approval Human
-- Placeholders: start_date, end_date, extra_filters

WITH kc_pa_data AS (
  SELECT
    kc.* EXCEPT(MACRO_TYPE),
    CASE
      WHEN kc.PA_SOURCE = 'GSO' THEN 'GSO-MHK'
      WHEN config_macro_dtl.PARTL_IND = 1 THEN 'PARTIAL'
      WHEN ARRAY_LENGTH(SPLIT(REPLACE(TRIM(pa_main.APPLD_MACROS_TXT), "'", ""), ',')) > 1
        THEN 'MULTIPLE MACROS'
      WHEN pa_main.APPLD_MACROS_TXT IS NOT NULL
       AND TRIM(pa_main.APPLD_MACROS_TXT) <> '' THEN 'FULL'
      ELSE NULL
    END AS MACRO_TYPE
  FROM `edp-pdev-restrict-pbmstorage.edp_paops_enr.kc_pa_data` kc
  LEFT JOIN `edp-prod-restrict-pbmstorage.edp_customer_pbmedh_cnsv.V_PRIOR_ATHZN_MAIN` pa_main
    ON kc.CASE_ID = pa_main.PRIOR_ATHZN_NBR
  LEFT JOIN `edp-prod-restrict-pbmstorage.edp_customer_pbmedh_cnsv.V_CAS_PAORXCLAIM` config_macro_dtl
    ON REPLACE(pa_main.APPLD_MACROS_TXT, "'", "") = config_macro_dtl.PRIOR_ATHZN_OVRD_ID
   AND TRIM(UPPER(config_macro_dtl.RSLTN_TYP_CD)) = 'APPROVED'
  WHERE kc.CRTE_DT BETWEEN '{start_date}' AND '{end_date}'
)

SELECT
  PA_SOURCE,

  -- ── OVERALL ─────────────────────────────────────────────────────────────────
  COUNT(*)                                                                    AS total_pas,
  COUNTIF(APPEAL_IND > 0)                                                     AS appeals_cnt,
  COUNTIF(APPEAL_IND = 0 AND AUTO_APPROVAL = 'Y')                            AS total_auto,

  -- ── CSO LOB BUCKETS (original PAs only) ─────────────────────────────────────
  -- Data Entry — handle both raw ('Data Entry') and PAIT-prefixed ('CSO - Data Entry')
  COUNTIF(APPEAL_IND = 0
    AND LINE_OF_BUSINESS IN ('CSO - Data Entry', 'Data Entry'))               AS data_entry_cnt,
  -- Medicaid — handle both raw ('Medicaid') and PAIT-prefixed ('CSO - Medicaid')
  COUNTIF(APPEAL_IND = 0
    AND LINE_OF_BUSINESS IN ('CSO - Medicaid', 'Medicaid'))                   AS medicaid_cnt,
  -- IBRs (Initial Benefit Review): CSO cases with no criteria (RFRNC_NBR and RFRNC_NBR_CRTRA_NM both null/empty)
  COUNTIF(APPEAL_IND = 0
    AND PA_SOURCE = 'CSO'
    AND (RFRNC_NBR IS NULL OR RFRNC_NBR = '')
    AND (RFRNC_NBR_CRTRA_NM IS NULL OR RFRNC_NBR_CRTRA_NM = '')
    AND LINE_OF_BUSINESS NOT IN (
      'CSO - Data Entry', 'Data Entry',
      'CSO - Medicaid',   'Medicaid'))                                         AS ibr_cnt,

  -- CSO Non-ePA remaining after removing Data Entry, Medicaid, IBR
  COUNTIF(APPEAL_IND = 0 AND PA_SOURCE = 'CSO' AND PA_ORIGIN_CD != 'EPA'
    AND LINE_OF_BUSINESS NOT IN (
      'CSO - Data Entry', 'Data Entry',
      'CSO - Medicaid',   'Medicaid')
    AND NOT (
      (RFRNC_NBR IS NULL OR RFRNC_NBR = '')
      AND (RFRNC_NBR_CRTRA_NM IS NULL OR RFRNC_NBR_CRTRA_NM = '')))           AS cso_non_epa_remaining,

  -- ── GSO BUCKETS (original PAs only) ──────────────────────────────────────────
  -- Med B = Organization Determination (Part B) — raw: 'OD' or prefixed: 'GSO - OD'
  COUNTIF(APPEAL_IND = 0
    AND LINE_OF_BUSINESS IN ('GSO - OD', 'OD', 'Organization Determination')) AS med_b_cnt,

  -- GSO Non-ePA remaining after removing Med B
  COUNTIF(APPEAL_IND = 0 AND PA_ORIGIN_CD != 'EPA'
    AND LINE_OF_BUSINESS NOT IN (
      'GSO - OD', 'OD', 'Organization Determination'))                        AS gso_non_epa_remaining,

  -- ── ePA SCORING (all original ePA cases, both sources) ────────────────────────
  COUNTIF(APPEAL_IND = 0 AND PA_ORIGIN_CD = 'EPA'
    AND AUTO_SCORE_RESULT_STATUS = 'Unscored')                                AS epa_unscored,
  COUNTIF(APPEAL_IND = 0 AND PA_ORIGIN_CD = 'EPA'
    AND AUTO_SCORE_RESULT_STATUS = 'DENIAL')                                  AS epa_scored_den,
  COUNTIF(APPEAL_IND = 0 AND PA_ORIGIN_CD = 'EPA'
    AND AUTO_SCORE_RESULT_STATUS = 'APPROVAL')                                AS epa_scored_apr,

  -- ePA Scored Approval → breakdown by auto vs human
  COUNTIF(APPEAL_IND = 0 AND PA_ORIGIN_CD = 'EPA'
    AND AUTO_SCORE_RESULT_STATUS = 'APPROVAL' AND AUTO_APPROVAL = 'Y')        AS epa_scored_apr_auto,
  COUNTIF(APPEAL_IND = 0 AND PA_ORIGIN_CD = 'EPA'
    AND AUTO_SCORE_RESULT_STATUS = 'APPROVAL' AND AUTO_APPROVAL = 'N')        AS epa_scored_apr_human,

  -- ── AUTO-APPROVAL MODEL BREAKDOWN (original PAs) ─────────────────────────────
  -- Note: a case can be attributed to multiple models; counts may overlap.
  COUNTIF(APPEAL_IND = 0 AND AUTO_APPROVAL = 'Y'
    AND COALESCE(IS_GLP_GENAI_COMBINED, 0) = 1)                              AS auto_glp_genai,
  COUNTIF(APPEAL_IND = 0 AND AUTO_APPROVAL = 'Y'
    AND COALESCE(IS_GENERAL_GENAI_AUTO_APPROVED, 0) = 1
    AND COALESCE(IS_GLP_GENAI_COMBINED, 0) = 0)                              AS auto_general_genai,
  COUNTIF(APPEAL_IND = 0 AND AUTO_APPROVAL = 'Y'
    AND COALESCE(IS_PREDICTIVE_AUTO_APPROVED, 0) = 1)                        AS auto_predictive,
  COUNTIF(APPEAL_IND = 0 AND AUTO_APPROVAL = 'Y'
    AND COALESCE(IS_OVERRIDE_AUTO_APPROVED, 0) = 1)                          AS auto_override,
  COUNTIF(APPEAL_IND = 0 AND AUTO_APPROVAL = 'Y'
    AND COALESCE(IS_DLT_AUTO_APPROVED, 0) = 1)                               AS auto_dlt,
  COUNTIF(APPEAL_IND = 0 AND AUTO_APPROVAL = 'Y'
    AND COALESCE(IS_ATTACHMENT_AUTO_APPROVED, 0) = 1)                        AS auto_attachment,
  -- Rules/system only: auto-approved but no model flag set
  COUNTIF(APPEAL_IND = 0 AND AUTO_APPROVAL = 'Y'
    AND COALESCE(IS_GLP_GENAI_COMBINED, 0)          = 0
    AND COALESCE(IS_GENERAL_GENAI_AUTO_APPROVED, 0) = 0
    AND COALESCE(IS_PREDICTIVE_AUTO_APPROVED, 0)    = 0
    AND COALESCE(IS_OVERRIDE_AUTO_APPROVED, 0)      = 0
    AND COALESCE(IS_DLT_AUTO_APPROVED, 0)           = 0
    AND COALESCE(IS_ATTACHMENT_AUTO_APPROVED, 0)    = 0)                     AS auto_rules_only,

  -- ── COST & EFFICIENCY ─────────────────────────────────────────────────────────
  SUM(CAST(COALESCE(CASE_TOTAL_OPS_COST, 0) AS FLOAT64))                     AS total_ops_cost,
  AVG(CASE
    WHEN APPEAL_IND = 0 AND AUTO_APPROVAL = 'N' AND TOTAL_HANDLE_TIME > 0
    THEN CAST(TOTAL_HANDLE_TIME AS FLOAT64)
  END)                                                                         AS avg_aht_seconds

FROM kc_pa_data
WHERE CRTE_DT BETWEEN '{start_date}' AND '{end_date}'
{extra_filters}
GROUP BY 1
ORDER BY 1
