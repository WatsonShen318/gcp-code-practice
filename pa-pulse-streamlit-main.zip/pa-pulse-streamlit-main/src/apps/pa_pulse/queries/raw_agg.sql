-- raw_agg.sql
-- Flexible aggregation driven by {group_by_cols} and {group_by_list} filled by Python.
-- Placeholders: group_by_cols, group_by_list, start_date, end_date, extra_filters

WITH kc_pa_data AS (
  SELECT
    kc.* EXCEPT(MACRO_TYPE),
    CASE
      WHEN kc.PA_SOURCE = 'GSO' THEN 'GSO-MHK'
      WHEN config_macro_dtl.PARTL_IND = 1 THEN 'PARTIAL'
      WHEN ARRAY_LENGTH(SPLIT(REPLACE(TRIM(pa_main.APPLD_MACROS_TXT), "'", ""), ',')) > 1
        THEN 'MULTIPLE MACROS'
      WHEN pa_main.APPLD_MACROS_TXT IS NOT NULL
       AND TRIM(pa_main.APPLD_MACROS_TXT) <> '' THEN 'FULL'
      ELSE NULL
    END AS MACRO_TYPE
  FROM `edp-pdev-restrict-pbmstorage.edp_paops_enr.kc_pa_data` kc
  LEFT JOIN `edp-prod-restrict-pbmstorage.edp_customer_pbmedh_cnsv.V_PRIOR_ATHZN_MAIN` pa_main
    ON kc.CASE_ID = pa_main.PRIOR_ATHZN_NBR
  LEFT JOIN `edp-prod-restrict-pbmstorage.edp_customer_pbmedh_cnsv.V_CAS_PAORXCLAIM` config_macro_dtl
    ON REPLACE(pa_main.APPLD_MACROS_TXT, "'", "") = config_macro_dtl.PRIOR_ATHZN_OVRD_ID
   AND TRIM(UPPER(config_macro_dtl.RSLTN_TYP_CD)) = 'APPROVED'
)

SELECT
  {group_by_cols},
  COUNTIF(APPEAL_IND = 0)                                       AS total_pas,
  COUNTIF(APPEAL_IND = 0 AND AUTO_APPROVAL = 'Y'
    AND COALESCE(IS_GLP_GENAI_COMBINED,0)           = 0
    AND COALESCE(IS_GENERAL_GENAI_AUTO_APPROVED,0)  = 0
    AND COALESCE(IS_PREDICTIVE_AUTO_APPROVED,0)     = 0
    AND COALESCE(IS_OVERRIDE_AUTO_APPROVED,0)       = 0
    AND COALESCE(IS_DLT_AUTO_APPROVED,0)            = 0
    AND COALESCE(IS_ATTACHMENT_AUTO_APPROVED,0)     = 0)        AS epa_rules_auto,
  COUNTIF(APPEAL_IND = 0 AND (
    COALESCE(IS_GLP_GENAI_COMBINED,0)           = 1
    OR COALESCE(IS_GENERAL_GENAI_AUTO_APPROVED,0) = 1
    OR COALESCE(IS_PREDICTIVE_AUTO_APPROVED,0)  = 1
    OR COALESCE(IS_OVERRIDE_AUTO_APPROVED,0)    = 1
    OR COALESCE(IS_DLT_AUTO_APPROVED,0)         = 1
    OR COALESCE(IS_ATTACHMENT_AUTO_APPROVED,0)  = 1))           AS model_auto,
  COUNTIF(APPEAL_IND = 0 AND ORGNL_RSLTN_CD = 'APPROVAL')     AS approvals,
  COUNTIF(APPEAL_IND = 0 AND ORGNL_RSLTN_CD = 'DENIAL')       AS denials,
  COUNTIF(APPEAL_IND = 0 AND ORGNL_RSLTN_CD IN ('ADMIN DENIAL','DISMISS')) AS admin_denials,
  SUM(CAST(CASE_TOTAL_OPS_COST AS FLOAT64))                    AS ops_cost

FROM kc_pa_data
WHERE CRTE_DT BETWEEN '{start_date}' AND '{end_date}'
{extra_filters}
GROUP BY {group_by_list}
ORDER BY total_pas DESC
