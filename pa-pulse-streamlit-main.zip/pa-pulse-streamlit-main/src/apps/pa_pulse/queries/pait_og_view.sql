-- pait_og_view.sql
-- Per-source summary for the PAIT OG View funnel tab.
-- NOTE: APPEAL_TYPE computed inline from ORGNL/FNL resolution codes (column may be NULL in source).
-- NOTE: LINE_OF_BUSINESS handled with both prefixed ('CSO - Data Entry') and raw ('Data Entry') forms.
-- Placeholders: start_date, end_date, extra_filters

WITH kc_pa_data AS (
  SELECT
    kc.* EXCEPT(MACRO_TYPE),
    CASE
      WHEN kc.PA_SOURCE = 'GSO' THEN 'GSO-MHK'
      WHEN config_macro_dtl.PARTL_IND = 1 THEN 'PARTIAL'
      WHEN ARRAY_LENGTH(SPLIT(REPLACE(TRIM(pa_main.APPLD_MACROS_TXT), "'", ""), ',')) > 1
        THEN 'MULTIPLE MACROS'
      WHEN pa_main.APPLD_MACROS_TXT IS NOT NULL
       AND TRIM(pa_main.APPLD_MACROS_TXT) <> '' THEN 'FULL'
      ELSE NULL
    END AS MACRO_TYPE
  FROM `edp-pdev-restrict-pbmstorage.edp_paops_enr.kc_pa_data` kc
  LEFT JOIN `edp-prod-restrict-pbmstorage.edp_customer_pbmedh_cnsv.V_PRIOR_ATHZN_MAIN` pa_main
    ON kc.CASE_ID = pa_main.PRIOR_ATHZN_NBR
  LEFT JOIN `edp-prod-restrict-pbmstorage.edp_customer_pbmedh_cnsv.V_CAS_PAORXCLAIM` config_macro_dtl
    ON REPLACE(pa_main.APPLD_MACROS_TXT, "'", "") = config_macro_dtl.PRIOR_ATHZN_OVRD_ID
   AND TRIM(UPPER(config_macro_dtl.RSLTN_TYP_CD)) = 'APPROVED'
  WHERE kc.CRTE_DT BETWEEN '{start_date}' AND '{end_date}'
)

SELECT
  PA_SOURCE,

  -- ── VOLUME ────────────────────────────────────────────────────────────────
  COUNT(*)                                                             AS all_pas_incl_appeals,
  COUNTIF(APPEAL_IND = 0)                                              AS total_pas,
  SUM(CAST(COALESCE(WALKAWAY_IND, 0) AS INT64))                        AS walkaway_cnt,

  -- ── CASE ORIGIN (all PAs incl. appeals, by entry channel) ────────────────
  COUNTIF(PA_ORIGIN_CD = 'EPA')                                        AS orig_epa_cnt,
  COUNTIF(UPPER(COALESCE(EPA_NON_EPA_SPLIT,'')) = 'FAX')               AS orig_fax_cnt,
  COUNTIF(UPPER(COALESCE(EPA_NON_EPA_SPLIT,'')) IN ('CALL','PHONE'))   AS orig_call_cnt,
  COUNTIF(PA_ORIGIN_CD != 'EPA'
    AND UPPER(COALESCE(EPA_NON_EPA_SPLIT,'')) NOT IN ('FAX','CALL','PHONE'))
                                                                        AS orig_other_cnt,

  -- ── INITIAL DECISION (all PAs incl. appeals) ─────────────────────────────
  COUNTIF(AUTO_APPROVAL = 'Y' AND (
    COALESCE(IS_GLP_GENAI_COMBINED,0)          = 1
    OR COALESCE(IS_GENERAL_GENAI_AUTO_APPROVED,0) = 1
    OR COALESCE(IS_PREDICTIVE_AUTO_APPROVED,0) = 1
    OR COALESCE(IS_OVERRIDE_AUTO_APPROVED,0)   = 1
    OR COALESCE(IS_DLT_AUTO_APPROVED,0)        = 1
    OR COALESCE(IS_ATTACHMENT_AUTO_APPROVED,0) = 1))                    AS init_model_auto,
  COUNTIF(AUTO_APPROVAL = 'Y'
    AND COALESCE(IS_GLP_GENAI_COMBINED,0)          = 0
    AND COALESCE(IS_GENERAL_GENAI_AUTO_APPROVED,0) = 0
    AND COALESCE(IS_PREDICTIVE_AUTO_APPROVED,0)    = 0
    AND COALESCE(IS_OVERRIDE_AUTO_APPROVED,0)      = 0
    AND COALESCE(IS_DLT_AUTO_APPROVED,0)           = 0
    AND COALESCE(IS_ATTACHMENT_AUTO_APPROVED,0)    = 0)                 AS init_system_auto,

  -- ── AUTO-APPROVAL MODEL BREAKDOWN (all PAs incl. appeals) ────────────────
  -- Note: a case can be attributed to multiple models; counts may overlap.
  COUNTIF(AUTO_APPROVAL = 'Y'
    AND (COALESCE(IS_GLP_GENAI_COMBINED,0) = 1
      OR COALESCE(IS_GENERAL_GENAI_AUTO_APPROVED,0) = 1))               AS auto_genai_cnt,
  COUNTIF(AUTO_APPROVAL = 'Y'
    AND COALESCE(IS_PREDICTIVE_AUTO_APPROVED,0) = 1)                    AS auto_predictive_cnt,
  COUNTIF(AUTO_APPROVAL = 'Y'
    AND COALESCE(IS_OVERRIDE_AUTO_APPROVED,0) = 1)                      AS auto_ofu_cnt,
  COUNTIF(AUTO_APPROVAL = 'Y'
    AND COALESCE(IS_DLT_AUTO_APPROVED,0) = 1)                           AS auto_dlt_cnt,
  COUNTIF(AUTO_APPROVAL = 'Y'
    AND COALESCE(IS_ATTACHMENT_AUTO_APPROVED,0) = 1)                    AS auto_attachment_cnt,

  COUNTIF(PA_ORIGIN_CD = 'EPA'  AND AUTO_APPROVAL = 'N'
    AND ORGNL_RSLTN_CD = 'APPROVAL')                                    AS init_epa_hum_apr,
  COUNTIF(PA_ORIGIN_CD = 'EPA'  AND AUTO_APPROVAL = 'N'
    AND ORGNL_RSLTN_CD = 'DENIAL')                                      AS init_epa_hum_den,
  COUNTIF(PA_ORIGIN_CD = 'EPA'  AND AUTO_APPROVAL = 'N'
    AND ORGNL_RSLTN_CD IN ('ADMIN DENIAL','DISMISS'))                   AS init_epa_hum_adm,
  COUNTIF(PA_ORIGIN_CD != 'EPA' AND AUTO_APPROVAL = 'N'
    AND ORGNL_RSLTN_CD = 'APPROVAL')                                    AS init_non_epa_apr,
  COUNTIF(PA_ORIGIN_CD != 'EPA' AND AUTO_APPROVAL = 'N'
    AND ORGNL_RSLTN_CD = 'DENIAL')                                      AS init_non_epa_den,
  COUNTIF(PA_ORIGIN_CD != 'EPA' AND AUTO_APPROVAL = 'N'
    AND ORGNL_RSLTN_CD IN ('ADMIN DENIAL','DISMISS'))                   AS init_non_epa_adm,

  -- ── FINAL DECISION (all PAs incl. appeals, using FNL_RSLTN_CD) ───────────
  COUNTIF(AUTO_APPROVAL = 'Y'   AND FNL_RSLTN_CD = 'APPROVAL')         AS fin_auto_cnt,
  COUNTIF(PA_ORIGIN_CD = 'EPA'  AND AUTO_APPROVAL = 'N'
    AND FNL_RSLTN_CD = 'APPROVAL')                                      AS fin_epa_hum_apr,
  COUNTIF(PA_ORIGIN_CD = 'EPA'  AND AUTO_APPROVAL = 'N'
    AND FNL_RSLTN_CD = 'DENIAL')                                        AS fin_epa_hum_den,
  COUNTIF(PA_ORIGIN_CD = 'EPA'  AND AUTO_APPROVAL = 'N'
    AND FNL_RSLTN_CD IN ('ADMIN DENIAL','DISMISS'))                     AS fin_epa_hum_adm,
  COUNTIF(PA_ORIGIN_CD != 'EPA' AND AUTO_APPROVAL = 'N'
    AND FNL_RSLTN_CD = 'APPROVAL')                                      AS fin_non_epa_apr,
  COUNTIF(PA_ORIGIN_CD != 'EPA' AND AUTO_APPROVAL = 'N'
    AND FNL_RSLTN_CD = 'DENIAL')                                        AS fin_non_epa_den,
  COUNTIF(PA_ORIGIN_CD != 'EPA' AND AUTO_APPROVAL = 'N'
    AND FNL_RSLTN_CD IN ('ADMIN DENIAL','DISMISS'))                     AS fin_non_epa_adm,

  -- ── CASE FILL TYPE (all PAs incl. appeals: TARGET FILL, NO FILL, ALT FILL) ──
  COUNTIF(COALESCE(PA_FILL_TYPE,'') = 'TARGET FILL')                   AS fill_target_cnt,
  COUNTIF(COALESCE(PA_FILL_TYPE,'') = 'NO FILL')                       AS fill_no_cnt,
  COUNTIF(COALESCE(PA_FILL_TYPE,'') = 'ALT FILL')                      AS fill_alt_cnt,
  COUNTIF(COALESCE(PA_FILL_TYPE,'') NOT IN ('TARGET FILL','NO FILL','ALT FILL')
    AND COALESCE(PA_FILL_TYPE,'') != '')                                AS fill_other_cnt,

  -- ── APPEAL DECISION (inline — APPEAL_TYPE column may be NULL) ─────────────
  COUNTIF(APPEAL_IND > 0)                                              AS appeal_total,
  -- Approve on Appeal: originally denied, finally approved
  COUNTIF(APPEAL_IND > 0
    AND ORGNL_RSLTN_CD = 'DENIAL' AND FNL_RSLTN_CD = 'APPROVAL')      AS appeal_aoa,
  -- Durable Denial: originally denied, still denied after appeal
  COUNTIF(APPEAL_IND > 0
    AND ORGNL_RSLTN_CD = 'DENIAL'
    AND FNL_RSLTN_CD IN ('DENIAL','ADMIN DENIAL'))                      AS appeal_dur_den,
  -- Other: original approval appeals, admin-original cases, etc.
  COUNTIF(APPEAL_IND > 0
    AND NOT (ORGNL_RSLTN_CD = 'DENIAL'
             AND FNL_RSLTN_CD IN ('APPROVAL','DENIAL','ADMIN DENIAL','DISMISS')))
                                                                        AS appeal_other,

  -- ── OPS COST by decision type ──────────────────────────────────────────────
  SUM(CASE WHEN APPEAL_IND = 0 AND AUTO_APPROVAL = 'Y' AND (
    COALESCE(IS_GLP_GENAI_COMBINED,0)=1 OR COALESCE(IS_GENERAL_GENAI_AUTO_APPROVED,0)=1
    OR COALESCE(IS_PREDICTIVE_AUTO_APPROVED,0)=1 OR COALESCE(IS_OVERRIDE_AUTO_APPROVED,0)=1
    OR COALESCE(IS_DLT_AUTO_APPROVED,0)=1 OR COALESCE(IS_ATTACHMENT_AUTO_APPROVED,0)=1)
    THEN CAST(COALESCE(CASE_TOTAL_OPS_COST,0) AS FLOAT64) ELSE 0 END)  AS cost_model_auto,
  SUM(CASE WHEN APPEAL_IND = 0 AND AUTO_APPROVAL = 'Y'
    AND COALESCE(IS_GLP_GENAI_COMBINED,0)=0 AND COALESCE(IS_GENERAL_GENAI_AUTO_APPROVED,0)=0
    AND COALESCE(IS_PREDICTIVE_AUTO_APPROVED,0)=0 AND COALESCE(IS_OVERRIDE_AUTO_APPROVED,0)=0
    AND COALESCE(IS_DLT_AUTO_APPROVED,0)=0 AND COALESCE(IS_ATTACHMENT_AUTO_APPROVED,0)=0
    THEN CAST(COALESCE(CASE_TOTAL_OPS_COST,0) AS FLOAT64) ELSE 0 END)  AS cost_system_auto,
  SUM(CASE WHEN APPEAL_IND=0 AND PA_ORIGIN_CD='EPA'  AND AUTO_APPROVAL='N' AND ORGNL_RSLTN_CD='APPROVAL'
    THEN CAST(COALESCE(CASE_TOTAL_OPS_COST,0) AS FLOAT64) ELSE 0 END)  AS cost_epa_hum_apr,
  SUM(CASE WHEN APPEAL_IND=0 AND PA_ORIGIN_CD='EPA'  AND AUTO_APPROVAL='N' AND ORGNL_RSLTN_CD='DENIAL'
    THEN CAST(COALESCE(CASE_TOTAL_OPS_COST,0) AS FLOAT64) ELSE 0 END)  AS cost_epa_hum_den,
  SUM(CASE WHEN APPEAL_IND=0 AND PA_ORIGIN_CD='EPA'  AND AUTO_APPROVAL='N'
    AND ORGNL_RSLTN_CD IN ('ADMIN DENIAL','DISMISS')
    THEN CAST(COALESCE(CASE_TOTAL_OPS_COST,0) AS FLOAT64) ELSE 0 END)  AS cost_epa_hum_adm,
  SUM(CASE WHEN APPEAL_IND=0 AND PA_ORIGIN_CD!='EPA' AND AUTO_APPROVAL='N' AND ORGNL_RSLTN_CD='APPROVAL'
    THEN CAST(COALESCE(CASE_TOTAL_OPS_COST,0) AS FLOAT64) ELSE 0 END)  AS cost_non_epa_apr,
  SUM(CASE WHEN APPEAL_IND=0 AND PA_ORIGIN_CD!='EPA' AND AUTO_APPROVAL='N' AND ORGNL_RSLTN_CD='DENIAL'
    THEN CAST(COALESCE(CASE_TOTAL_OPS_COST,0) AS FLOAT64) ELSE 0 END)  AS cost_non_epa_den,
  SUM(CASE WHEN APPEAL_IND=0 AND PA_ORIGIN_CD!='EPA' AND AUTO_APPROVAL='N'
    AND ORGNL_RSLTN_CD IN ('ADMIN DENIAL','DISMISS')
    THEN CAST(COALESCE(CASE_TOTAL_OPS_COST,0) AS FLOAT64) ELSE 0 END)  AS cost_non_epa_adm,

  -- ── ORIGINAL vs APPEALS COST ───────────────────────────────────────────────
  SUM(CASE WHEN APPEAL_IND = 0 THEN CAST(COALESCE(CASE_TOTAL_OPS_COST,0) AS FLOAT64) ELSE 0 END)
                                                                        AS orig_ops_cost,
  SUM(CASE WHEN APPEAL_IND > 0 THEN CAST(COALESCE(CASE_TOTAL_OPS_COST,0) AS FLOAT64) ELSE 0 END)
                                                                        AS appeal_ops_cost,
  SUM(CAST(COALESCE(CASE_TOTAL_OPS_COST,0) AS FLOAT64))                AS total_ops_cost,

  -- ── SAVINGS ────────────────────────────────────────────────────────────────
  SUM(CAST(COALESCE(TOTAL_CLIENT_SAVINGS_DE_DUP, 0) AS FLOAT64))       AS total_savings,

  -- ── SAVINGS BY FILL TYPE ──────────────────────────────────────────────────
  SUM(CASE WHEN APPEAL_IND = 0 AND COALESCE(PA_FILL_TYPE,'') = 'TARGET FILL'
      THEN CAST(COALESCE(TOTAL_CLIENT_SAVINGS_DE_DUP, 0) AS FLOAT64) ELSE 0 END)
                                                                        AS savings_target_fill,
  SUM(CASE WHEN APPEAL_IND = 0 AND COALESCE(PA_FILL_TYPE,'') = 'NO FILL'
      THEN CAST(COALESCE(TOTAL_CLIENT_SAVINGS_DE_DUP, 0) AS FLOAT64) ELSE 0 END)
                                                                        AS savings_no_fill,
  SUM(CASE WHEN APPEAL_IND = 0 AND COALESCE(PA_FILL_TYPE,'') = 'ALT FILL'
      THEN CAST(COALESCE(TOTAL_CLIENT_SAVINGS_DE_DUP, 0) AS FLOAT64) ELSE 0 END)
                                                                        AS savings_alt_fill,

  -- ── HANDLE TIME / AHT ─────────────────────────────────────────────────────
  -- AHT = SUM(handle seconds) / COUNT(cases) in that group, expressed in seconds.
  SUM(CAST(COALESCE(TOTAL_HANDLE_TIME, 0) AS FLOAT64))                 AS total_handle_sec,
  SAFE_DIVIDE(
    SUM(CAST(COALESCE(TOTAL_HANDLE_TIME, 0) AS FLOAT64)),
    COUNT(*)
  )                                                                     AS avg_aht_seconds,
  SUM(CAST(COALESCE(TOTAL_HANDLE_TIME, 0) AS FLOAT64))                 AS aht_seconds,
  -- AHT numerator (sum handle sec) + denominator (count) per Final Decision group.
  -- App computes sec/case as SUM(num)/SUM(den) across PA_SOURCEs for proper weighting.
  SUM(IF(AUTO_APPROVAL='Y' AND FNL_RSLTN_CD='APPROVAL',
         CAST(COALESCE(TOTAL_HANDLE_TIME,0) AS FLOAT64), 0))             AS aht_num_fin_auto,
  SUM(IF(PA_ORIGIN_CD='EPA' AND AUTO_APPROVAL='N' AND FNL_RSLTN_CD='APPROVAL',
         CAST(COALESCE(TOTAL_HANDLE_TIME,0) AS FLOAT64), 0))             AS aht_num_fin_epa_apr,
  SUM(IF(PA_ORIGIN_CD='EPA' AND AUTO_APPROVAL='N' AND FNL_RSLTN_CD='DENIAL',
         CAST(COALESCE(TOTAL_HANDLE_TIME,0) AS FLOAT64), 0))             AS aht_num_fin_epa_den,
  SUM(IF(PA_ORIGIN_CD='EPA' AND AUTO_APPROVAL='N' AND FNL_RSLTN_CD IN ('ADMIN DENIAL','DISMISS'),
         CAST(COALESCE(TOTAL_HANDLE_TIME,0) AS FLOAT64), 0))             AS aht_num_fin_epa_adm,
  SUM(IF(PA_ORIGIN_CD!='EPA' AND AUTO_APPROVAL='N' AND FNL_RSLTN_CD='APPROVAL',
         CAST(COALESCE(TOTAL_HANDLE_TIME,0) AS FLOAT64), 0))             AS aht_num_fin_non_epa_apr,
  SUM(IF(PA_ORIGIN_CD!='EPA' AND AUTO_APPROVAL='N' AND FNL_RSLTN_CD='DENIAL',
         CAST(COALESCE(TOTAL_HANDLE_TIME,0) AS FLOAT64), 0))             AS aht_num_fin_non_epa_den,
  SUM(IF(PA_ORIGIN_CD!='EPA' AND AUTO_APPROVAL='N' AND FNL_RSLTN_CD IN ('ADMIN DENIAL','DISMISS'),
         CAST(COALESCE(TOTAL_HANDLE_TIME,0) AS FLOAT64), 0))             AS aht_num_fin_non_epa_adm,

  -- ── MEDIAN TAT (in minutes) — original PAs, Approval/Denial only ──────────
  APPROX_QUANTILES(
    IF(APPEAL_IND = 0
       AND ORGNL_RSLTN_CD IN ('APPROVAL', 'DENIAL')
       AND TAT_MINS IS NOT NULL AND TAT_MINS > 0,
       CAST(TAT_MINS AS FLOAT64), NULL), 100
  )[OFFSET(50)]                                                          AS median_tat_mins,

  -- ── LEGACY FIELDS ─────────────────────────────────────────────────────────
  COUNTIF(APPEAL_IND = 0 AND PA_ORIGIN_CD = 'EPA')                    AS epa_pas,
  COUNTIF(APPEAL_IND = 0 AND AUTO_APPROVAL = 'Y'
    AND COALESCE(IS_GLP_GENAI_COMBINED,0)=0 AND COALESCE(IS_GENERAL_GENAI_AUTO_APPROVED,0)=0
    AND COALESCE(IS_PREDICTIVE_AUTO_APPROVED,0)=0 AND COALESCE(IS_OVERRIDE_AUTO_APPROVED,0)=0
    AND COALESCE(IS_DLT_AUTO_APPROVED,0)=0 AND COALESCE(IS_ATTACHMENT_AUTO_APPROVED,0)=0) AS epa_rules_auto,
  COUNTIF(APPEAL_IND = 0 AND (
    COALESCE(IS_GLP_GENAI_COMBINED,0)=1 OR COALESCE(IS_GENERAL_GENAI_AUTO_APPROVED,0)=1
    OR COALESCE(IS_PREDICTIVE_AUTO_APPROVED,0)=1 OR COALESCE(IS_OVERRIDE_AUTO_APPROVED,0)=1
    OR COALESCE(IS_DLT_AUTO_APPROVED,0)=1 OR COALESCE(IS_ATTACHMENT_AUTO_APPROVED,0)=1)) AS model_auto,
  COUNTIF(APPEAL_IND = 0 AND AUTO_APPROVAL = 'N'
    AND COALESCE(IS_GLP_GENAI_COMBINED,0)=0 AND COALESCE(IS_GENERAL_GENAI_AUTO_APPROVED,0)=0
    AND COALESCE(IS_PREDICTIVE_AUTO_APPROVED,0)=0 AND COALESCE(IS_OVERRIDE_AUTO_APPROVED,0)=0
    AND COALESCE(IS_DLT_AUTO_APPROVED,0)=0 AND COALESCE(IS_ATTACHMENT_AUTO_APPROVED,0)=0) AS human_reviewed,
  COUNTIF(APPEAL_IND = 0 AND ORGNL_RSLTN_CD = 'APPROVAL')            AS approvals,
  COUNTIF(APPEAL_IND = 0 AND ORGNL_RSLTN_CD = 'DENIAL')              AS denials,
  COUNTIF(APPEAL_IND = 0 AND ORGNL_RSLTN_CD IN ('ADMIN DENIAL','DISMISS')) AS admin_denials,
  COUNTIF(APPEAL_IND > 0)                                              AS appeal_pas,
  COUNTIF(APPEAL_IND > 0 AND FNL_RSLTN_CD = 'APPROVAL')              AS appeal_approvals

FROM kc_pa_data
WHERE CRTE_DT BETWEEN '{start_date}' AND '{end_date}'
{extra_filters}
GROUP BY 1
ORDER BY 1
