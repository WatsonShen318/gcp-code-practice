-- overview_bars.sql
-- Returns one summary row for the CGSO Overview funnel + model breakdown.
-- Placeholders filled by Python: start_date, end_date, extra_filters

WITH kc_pa_data AS (
  SELECT
    kc.* EXCEPT(MACRO_TYPE),
    CASE
      WHEN kc.PA_SOURCE = 'GSO' THEN 'GSO-MHK'
      WHEN config_macro_dtl.PARTL_IND = 1 THEN 'PARTIAL'
      WHEN ARRAY_LENGTH(SPLIT(REPLACE(TRIM(pa_main.APPLD_MACROS_TXT), "'", ""), ',')) > 1
        THEN 'MULTIPLE MACROS'
      WHEN pa_main.APPLD_MACROS_TXT IS NOT NULL
       AND TRIM(pa_main.APPLD_MACROS_TXT) <> '' THEN 'FULL'
      ELSE NULL
    END AS MACRO_TYPE
  FROM `edp-pdev-restrict-pbmstorage.edp_paops_enr.kc_pa_data` kc
  LEFT JOIN `edp-prod-restrict-pbmstorage.edp_customer_pbmedh_cnsv.V_PRIOR_ATHZN_MAIN` pa_main
    ON kc.CASE_ID = pa_main.PRIOR_ATHZN_NBR
  LEFT JOIN `edp-prod-restrict-pbmstorage.edp_customer_pbmedh_cnsv.V_CAS_PAORXCLAIM` config_macro_dtl
    ON REPLACE(pa_main.APPLD_MACROS_TXT, "'", "") = config_macro_dtl.PRIOR_ATHZN_OVRD_ID
   AND TRIM(UPPER(config_macro_dtl.RSLTN_TYP_CD)) = 'APPROVED'
)

SELECT
  -- ── Volume funnel (original cases only) ──────────────────────────
  COUNTIF(APPEAL_IND = 0)                                        AS original_pas,
  COUNTIF(APPEAL_IND = 0 AND PA_ORIGIN_CD = 'EPA')              AS epa_pas,
  COUNTIF(APPEAL_IND = 0 AND AUTO_APPROVAL = 'Y'
    AND COALESCE(IS_GLP_GENAI_COMBINED,0)           = 0
    AND COALESCE(IS_GENERAL_GENAI_AUTO_APPROVED,0)  = 0
    AND COALESCE(IS_PREDICTIVE_AUTO_APPROVED,0)     = 0
    AND COALESCE(IS_OVERRIDE_AUTO_APPROVED,0)       = 0
    AND COALESCE(IS_DLT_AUTO_APPROVED,0)            = 0
    AND COALESCE(IS_ATTACHMENT_AUTO_APPROVED,0)     = 0)         AS epa_rules_auto,
  COUNTIF(APPEAL_IND = 0 AND (
    COALESCE(IS_GLP_GENAI_COMBINED,0)           = 1
    OR COALESCE(IS_GENERAL_GENAI_AUTO_APPROVED,0) = 1
    OR COALESCE(IS_PREDICTIVE_AUTO_APPROVED,0)  = 1
    OR COALESCE(IS_OVERRIDE_AUTO_APPROVED,0)    = 1
    OR COALESCE(IS_DLT_AUTO_APPROVED,0)         = 1
    OR COALESCE(IS_ATTACHMENT_AUTO_APPROVED,0)  = 1))            AS model_auto,
  COUNTIF(APPEAL_IND = 0 AND AUTO_APPROVAL = 'N'
    AND COALESCE(IS_GLP_GENAI_COMBINED,0)           = 0
    AND COALESCE(IS_GENERAL_GENAI_AUTO_APPROVED,0)  = 0
    AND COALESCE(IS_PREDICTIVE_AUTO_APPROVED,0)     = 0
    AND COALESCE(IS_OVERRIDE_AUTO_APPROVED,0)       = 0
    AND COALESCE(IS_DLT_AUTO_APPROVED,0)            = 0
    AND COALESCE(IS_ATTACHMENT_AUTO_APPROVED,0)     = 0)         AS human_reviewed,

  -- ── Human outcomes ───────────────────────────────────────────────
  COUNTIF(APPEAL_IND = 0 AND ORGNL_RSLTN_CD = 'APPROVAL')      AS human_approvals,
  COUNTIF(APPEAL_IND = 0 AND ORGNL_RSLTN_CD = 'DENIAL')        AS human_denials,
  COUNTIF(APPEAL_IND = 0 AND ORGNL_RSLTN_CD IN ('ADMIN DENIAL','DISMISS')) AS human_admin_denials,

  -- ── Model breakdown (CSO) ────────────────────────────────────────
  COUNTIF(APPEAL_IND = 0 AND COALESCE(IS_GLP_GENAI_COMBINED,0) = 1)          AS glp_genai_auto,
  COUNTIF(APPEAL_IND = 0 AND COALESCE(IS_GENERAL_GENAI_AUTO_APPROVED,0) = 1
    AND COALESCE(IS_PREDICTIVE_AUTO_APPROVED,0) = 0)                          AS general_genai_auto,
  COUNTIF(APPEAL_IND = 0 AND COALESCE(IS_PREDICTIVE_AUTO_APPROVED,0) = 1)    AS predictive_auto,
  COUNTIF(APPEAL_IND = 0 AND COALESCE(IS_OVERRIDE_AUTO_APPROVED,0) = 1
    AND COALESCE(IS_PREDICTIVE_AUTO_APPROVED,0) = 0)                          AS override_auto,

  -- ── Model breakdown (GSO) ────────────────────────────────────────
  COUNTIF(APPEAL_IND = 0 AND COALESCE(IS_DLT_AUTO_APPROVED,0) = 1)           AS dlt_auto,
  COUNTIF(APPEAL_IND = 0 AND COALESCE(IS_ATTACHMENT_AUTO_APPROVED,0) = 1)    AS attachment_auto,

  -- ── Appeals ──────────────────────────────────────────────────────
  COUNTIF(APPEAL_IND > 0)                                        AS appeal_pas,
  COUNTIF(APPEAL_IND > 0 AND FNL_RSLTN_CD = 'APPROVAL')        AS appeal_approvals,

  -- ── Cost ─────────────────────────────────────────────────────────
  SUM(CAST(CASE_TOTAL_OPS_COST AS FLOAT64))                     AS total_ops_cost,
  SUM(CAST(TOTAL_CLIENT_SAVINGS_DE_DUP AS FLOAT64))             AS total_savings

FROM kc_pa_data
WHERE CRTE_DT BETWEEN '{start_date}' AND '{end_date}'
{extra_filters}
