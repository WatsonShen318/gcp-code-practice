"""Fetch SSO secrets from GCP Secret Manager and inject into os.environ.

Pattern mirrors gen-ai-pa-analysis-main: implicit ADC, project ID derived
from google.auth.default(), JSON blob fetched in one call.

Always runs on startup. Falls back silently if Secret Manager is unreachable
(e.g. local dev without GCP credentials — use .env to set sso_client_secret directly).
"""

import json
import os

import google.auth
from google.cloud import secretmanager


def _compute_project_id() -> str:
    """Return the GCP project that owns the paops secrets."""
    return os.environ.get("GCP_PROJECT_ID", "edp-pdev-restrict-paops")


def access_secret(secret_id: str, version: str = "latest") -> str:
    project_id = _compute_project_id()
    credentials, _ = google.auth.default()
    client = secretmanager.SecretManagerServiceClient(credentials=credentials)
    name = f"projects/{project_id}/secrets/{secret_id}/versions/{version}"
    print(f"INFO: Fetching secret from {name}")
    response = client.access_secret_version(request={"name": name})
    return response.payload.data.decode("UTF-8")


def extract_credentials() -> None:
    """Fetch the paops-streamlit secret JSON and set env vars.

    Expected secret JSON shape:
    {
        "sso_client_secret": "..."
    }

    Falls back silently if Secret Manager is unreachable so local dev
    can still run with sso_client_secret set via .env.
    Set USE_SECRET_MANAGER=0 to skip Secret Manager entirely (local dev).
    """
    if os.environ.get("USE_SECRET_MANAGER", "1") == "0":
        if os.environ.get("sso_client_secret"):
            print("INFO: USE_SECRET_MANAGER=0 — using sso_client_secret from environment.")
        else:
            print("ERROR: USE_SECRET_MANAGER=0 but sso_client_secret is not set.")
        return

    from src.config import Config
    try:
        raw = access_secret(Config.secret_id, Config.secret_version)
        secrets = json.loads(raw)
        os.environ["sso_client_secret"] = secrets["sso_client_secret"].strip()
    except Exception as e:
        print(f"WARNING: Could not fetch secrets from Secret Manager: {type(e).__name__}: {e}")
        if os.environ.get("sso_client_secret"):
            print("WARNING: Falling back to sso_client_secret from environment variable.")
        else:
            print("ERROR: sso_client_secret is not set — SSO token exchange will fail with invalid_client.")
