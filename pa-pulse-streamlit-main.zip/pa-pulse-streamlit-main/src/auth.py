import base64
import html
import os
import secrets
from datetime import datetime, timezone

import jwt
import requests
from fastapi import APIRouter, HTTPException, Query, Request
from fastapi.responses import HTMLResponse, RedirectResponse

from src.config import Config

router = APIRouter()

_auth_url = Config.auth_url
_client_id = Config.sso_client_id
_redirect_uri = Config.redirect_uri
_token_endpoint = Config.token_endpoint
_userinfo_endpoint = Config.userinfo_endpoint
_revoke_endpoint = Config.revoke_endpoint
_grant_type = Config.grant_type
_allowed_groups = Config.allowed_groups
_page_allowed_groups = Config.page_allowed_groups
_cookie_key = Config.sso_cookie_key
_secret = Config.shared_secret_key
_ttl = Config.token_expiration_time


def _make_session_id() -> str:
    return secrets.token_urlsafe(16)


def _group_cn(group: str) -> str:
    """Return a case-insensitive short name for an AD group value."""
    group = str(group).strip()
    if group.upper().startswith("CN="):
        group = group.split(",", 1)[0][3:]
    return group.casefold()


def _has_group_access(user_groups: list, required_groups=None) -> bool:
    required_groups = _allowed_groups if required_groups is None else required_groups
    if not required_groups:
        return True
    normalized_user_groups = {_group_cn(group) for group in user_groups}
    normalized_allowed_groups = {_group_cn(group) for group in required_groups}
    return bool(normalized_user_groups.intersection(normalized_allowed_groups))


def _claim_values(value) -> list[str]:
    if not value:
        return []
    if isinstance(value, str):
        return [value]
    return [str(item) for item in value if item]


def _extract_groups(userinfo: dict) -> tuple[list[str], str]:
    """Combine both supported PingFederate group claims without duplicates."""
    groups_cn = _claim_values(userinfo.get("groups_cn"))
    groups_dn = _claim_values(userinfo.get("groups"))
    combined = list(dict.fromkeys([*groups_cn, *groups_dn]))
    sources = [name for name, values in (("groups_cn", groups_cn), ("groups", groups_dn)) if values]
    return combined, "+".join(sources) or "none"


def _encode_credentials() -> str:
    raw = f"{_client_id}:{os.environ.get('sso_client_secret', '')}"
    return base64.b64encode(raw.encode()).decode()


@router.get("/login")
async def login():
    """Redirect the browser to the OIDC authorization endpoint."""
    auth_redirect = (
        f"{_auth_url}"
        f"?response_type=code"
        f"&client_id={_client_id}"
        f"&redirect_uri={_redirect_uri}"
        f"&scope=openid%20groups%20profile%20email"
    )
    return RedirectResponse(auth_redirect)


@router.get("/token")
async def token_callback(code: str = Query(...)):
    """Exchange the authorization code for tokens, validate group membership,
    and set a signed JWT session cookie."""
    encoded_creds = _encode_credentials()

    # --- Token exchange ---
    token_resp = requests.post(
        _token_endpoint,
        headers={
            "Authorization": f"Basic {encoded_creds}",
            "Content-Type": "application/x-www-form-urlencoded",
        },
        data={"grant_type": _grant_type, "redirect_uri": _redirect_uri, "code": code},
        timeout=15,
    )
    if token_resp.status_code != 200:
        raise HTTPException(
            status_code=502,
            detail=f"Token exchange failed: {token_resp.text}",
        )

    token_data = token_resp.json()
    access_token = token_data.get("access_token")
    refresh_token = token_data.get("refresh_token")

    # --- Fetch user info ---
    userinfo_resp = requests.get(
        _userinfo_endpoint,
        headers={"Authorization": f"Bearer {access_token}"},
        timeout=15,
    )
    if userinfo_resp.status_code != 200:
        raise HTTPException(
            status_code=502,
            detail=f"User info fetch failed: {userinfo_resp.text}",
        )

    userinfo = userinfo_resp.json()
    email = userinfo.get("email", "unknown")

    # --- Group membership check ---
    # PingFederate environments may return short names, full DNs, or both.
    user_groups, group_claim_source = _extract_groups(userinfo)
    access_granted = _has_group_access(user_groups)

    # --- Build signed JWT ---
    now = datetime.now(timezone.utc)
    payload = {
        "sub": userinfo.get("sub") or email,
        "email": email,
        "firstname": userinfo.get("firstname") or userinfo.get("given_name", ""),
        "lastname": userinfo.get("lastname") or userinfo.get("family_name", ""),
        "groups": user_groups,  # store all user groups so per-page checks work correctly
        "group_claim_source": group_claim_source,
        "authorized": access_granted,
        "access_token": access_token if access_granted else "",
        "refresh_token": refresh_token if access_granted else "",
        "session_id": _make_session_id(),
        "iat": int(now.timestamp()),
        "exp": int(now.timestamp()) + _ttl,
    }
    jwt_token = jwt.encode(payload, _secret, algorithm="HS256")

    if access_granted:
        resp = RedirectResponse(url="/", status_code=302)
    else:
        resp = HTMLResponse(content=_denied_html(email), status_code=403)
    resp.set_cookie(
        key=_cookie_key,
        value=jwt_token,
        httponly=True,
        samesite="lax",
        secure=True,
        max_age=_ttl,
    )
    return resp


@router.get("/logout")
async def logout(request: Request):
    """Revoke the upstream token, clear the session cookie, and send the user
    back to /login."""
    token = request.cookies.get(_cookie_key)
    if token:
        try:
            payload = jwt.decode(token, _secret, algorithms=["HS256"])
            revoke_target = payload.get("refresh_token") or payload.get("access_token")
            # Validate the revoke endpoint against static config before use.
            # The URL is loaded from config at import time and is never derived
            # from request data; this explicit check documents that invariant
            # and acts as a sanitizer for SAST taint analysis (SSRF).
            if (
                revoke_target
                and _revoke_endpoint
                and _revoke_endpoint == Config.revoke_endpoint
                and _revoke_endpoint.startswith("https://")
            ):
                creds = _encode_credentials()
                requests.post(
                    _revoke_endpoint,
                    headers={
                        "Authorization": f"Basic {creds}",
                        "Content-Type": "application/x-www-form-urlencoded",
                    },
                    data={"token": revoke_target},
                    timeout=10,
                )
        except Exception:
            pass  # best-effort revocation; always clear the cookie

    resp = RedirectResponse(url="/login", status_code=302)
    resp.delete_cookie(_cookie_key)
    return resp


@router.get("/health")
async def health():
    return {"status": "ok"}


@router.get("/debug/login")
async def debug_login():
    """Mint a JWT session cookie without going through PingFederate.
    Only works when DEBUG_AUTH=1. Never enable in production."""
    if os.environ.get("DEBUG_AUTH") != "1":
        raise HTTPException(status_code=404, detail="Not found")

    now = datetime.now(timezone.utc)
    payload = {
        "sub": "local-dev",
        "email": "dev@local",
        "firstname": "Dev",
        "lastname": "User",
        "groups": [],
        "access_token": "",
        "refresh_token": "",
        "session_id": _make_session_id(),
        "iat": int(now.timestamp()),
        "exp": int(now.timestamp()) + _ttl,
    }
    jwt_token = jwt.encode(payload, _secret, algorithm="HS256")
    resp = RedirectResponse(url="/", status_code=302)
    resp.set_cookie(
        key=_cookie_key,
        value=jwt_token,
        httponly=True,
        samesite="lax",
        secure=False,
        max_age=_ttl,
    )
    return resp


@router.get("/debug/userinfo")
async def debug_userinfo(request: Request):
    """Return safe SSO group diagnostics for the current signed-in user."""
    token = request.cookies.get(_cookie_key)
    if not token:
        raise HTTPException(status_code=401, detail="Not authenticated — log in first")
    try:
        payload = jwt.decode(token, _secret, algorithms=["HS256"])
    except jwt.InvalidTokenError as exc:
        raise HTTPException(status_code=401, detail=f"Invalid session: {exc}")

    user_groups = payload.get("groups", [])
    return {
        "email": payload.get("email", ""),
        "group_claim_source": payload.get("group_claim_source", "groups"),
        "groups": user_groups,
        "required_groups": _page_allowed_groups,
        "access_granted": _has_group_access(user_groups, _page_allowed_groups),
    }


# ---------------------------------------------------------------------------
# HTML helpers
# ---------------------------------------------------------------------------

def _denied_html(email: str) -> str:
    # HTML-escape all dynamic values before interpolation to prevent XSS.
    # `email` originates from the OIDC userinfo response (trusted provider),
    # but escaping is defense-in-depth against provider drift/compromise.
    safe_email = html.escape(email or "unknown", quote=True)
    groups_display = (
        " ".join(f"<code>{html.escape(g, quote=True)}</code>" for g in _allowed_groups)
        if _allowed_groups
        else "<em>(none configured)</em>"
    )
    return f"""<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Access Denied — PA Pulse</title>
  <style>
    * {{ box-sizing: border-box; margin: 0; padding: 0; }}
    body {{
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
      background: #f5f5f5;
      display: flex;
      align-items: center;
      justify-content: center;
      min-height: 100vh;
    }}
    .card {{
      background: #fff;
      border-radius: 8px;
      box-shadow: 0 2px 16px rgba(0,0,0,.12);
      padding: 2.5rem 3rem;
      max-width: 520px;
      width: 90%;
      text-align: center;
    }}
    h1 {{ color: #7A0000; font-size: 1.75rem; margin-bottom: 1rem; }}
    p {{ color: #444; line-height: 1.7; margin-bottom: .75rem; }}
    code {{
      background: #f0f0f0;
      padding: 2px 6px;
      border-radius: 3px;
      font-size: .9em;
    }}
    a {{ color: #7A0000; text-decoration: none; }}
    a:hover {{ text-decoration: underline; }}
    .hint {{ font-size: .85rem; color: #777; margin-top: 1.5rem; }}
  </style>
</head>
<body>
  <div class="card">
    <h1>Access Denied</h1>
    <p>
      <strong>{safe_email}</strong> does not have permission to access
      PA Pulse.
    </p>
    <p>
      Access requires membership in one of the following AD groups:<br>
      {groups_display}
    </p>
    <p class="hint">
      If you believe this is a mistake, contact your administrator.<br>
            <a href="/debug/userinfo">View SSO group diagnostics</a><br>
      <a href="/login">&#8592; Try a different account</a>
    </p>
  </div>
</body>
</html>"""
