"""Compare two benchmark result JSON files and print a Markdown diff table.

Usage:
    python bench/report.py bench/results/before.json bench/results/after.json
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path


def load(path: Path) -> dict[str, dict]:
    doc = json.loads(path.read_text())
    return {r["id"]: r for r in doc["results"]}


def server_wall(r: dict) -> int | None:
    """Return the ALL_QUERIES_WALL total_ms if this scenario ran queries, else None."""
    for e in r.get("server_events", []):
        if e.get("tag") == "ALL_QUERIES_WALL":
            return e.get("total_ms")
    return None


def slowest_server_query(r: dict) -> tuple[str, int] | None:
    events = [e for e in r.get("server_events", []) if e.get("event") == "query"]
    if not events:
        return None
    e = max(events, key=lambda x: x.get("total_ms") or 0)
    return e["tag"], e["total_ms"]


def render_row(sid: str, before: dict, after: dict) -> str:
    name = (before or after)["name"]

    b_client = before.get("client_ms") if before else None
    a_client = after.get("client_ms") if after else None
    b_server = server_wall(before) if before else None
    a_server = server_wall(after) if after else None

    def cell(v: int | None) -> str:
        return "-" if v is None else f"{v/1000:.1f}s"

    def delta(b: int | None, a: int | None) -> str:
        if b is None or a is None or b == 0:
            return "-"
        pct = (a - b) / b * 100
        sign = "+" if pct >= 0 else ""
        return f"{sign}{pct:.0f}%"

    slow_b = slowest_server_query(before) if before else None
    slow_a = slowest_server_query(after) if after else None
    slow_str = ""
    if slow_a:
        slow_str = f"{slow_a[0]} {slow_a[1]/1000:.1f}s"
    elif slow_b:
        slow_str = f"{slow_b[0]} {slow_b[1]/1000:.1f}s"

    return (
        f"| {sid} | {name[:60]} | {cell(b_client)} | {cell(a_client)} | "
        f"{delta(b_client, a_client)} | {cell(b_server)} | {cell(a_server)} | "
        f"{delta(b_server, a_server)} | {slow_str} |"
    )


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("before", type=Path)
    ap.add_argument("after", type=Path)
    args = ap.parse_args()

    before = load(args.before)
    after = load(args.after)
    ids = sorted(set(before) | set(after))

    print(f"# PA Pulse benchmark: {args.before.stem} vs {args.after.stem}\n")
    print("Client = wall time from trigger click → stable DOM.")
    print("Server = ALL_QUERIES_WALL from main.py [BENCH] log (query scenarios only).\n")
    print("| ID | Scenario | B client | A client | Δ | B server | A server | Δ | Slowest query (A) |")
    print("|---|---|---|---|---|---|---|---|---|")
    for sid in ids:
        print(render_row(sid, before.get(sid, {}), after.get(sid, {})))

    # Aggregate
    def agg(res_map: dict[str, dict], key_fn) -> int:
        vals = [v for r in res_map.values() if (v := key_fn(r)) is not None]
        return sum(vals)

    b_client_total = agg(before, lambda r: r.get("client_ms"))
    a_client_total = agg(after, lambda r: r.get("client_ms"))
    b_server_total = agg(before, server_wall)
    a_server_total = agg(after, server_wall)
    print()
    print(f"**Aggregate client-side**: {b_client_total/1000:.1f}s → {a_client_total/1000:.1f}s"
          f"  ({((a_client_total-b_client_total)/max(b_client_total,1)*100):+.0f}%)")
    print(f"**Aggregate server-side (Evaluate scenarios)**: {b_server_total/1000:.1f}s → "
          f"{a_server_total/1000:.1f}s  "
          f"({((a_server_total-b_server_total)/max(b_server_total,1)*100):+.0f}%)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
