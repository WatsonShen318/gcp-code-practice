# Bench comparison — V0_baseline (n=10) vs V1_phase1 (n=10)

Median (p90) in milliseconds. `stable=false` runs excluded per scenario.

## load (target < 10000ms)

| scenario | V0_baseline med (p90) | V1_phase1 med (p90) | Δmed | Δ% | hits |
|---|---:|---:|---:|---:|:---:|
| 01_cold_load — Cold navigation → first stable render (auto-runs 6 | 22,126 (60,579) | 32,519 (49,627) | +10,394 | +47.0% |  |

## query (target < 5000ms)

| scenario | V0_baseline med (p90) | V1_phase1 med (p90) | Δmed | Δ% | hits |
|---|---:|---:|---:|---:|:---:|
| 02_evaluate_same_filters_warm — Click Evaluate with unchanged filters (warm cache_ | 2,065 (2,448) | 1,848 (2,024) | -217 | -10.5% | ✓ |
| 03_pa_source_cso — Filter PA Source = CSO only | 17,410 (73,147) | 11,165 (16,999) | -6,246 | -35.9% |  |
| 04_pa_source_gso — Filter PA Source = GSO only (reset then set) | 10,321 (18,823) | 9,328 (13,579) | -993 | -9.6% |  |
| 05_pa_source_reset — Reset PA Source to All (empty multiselect) | 1,723 (1,731) | 1,714 (65,985) | -8 | -0.5% | ✓ |
| 06_narrow_dates_q1 — Narrow dates: 2025-01-01 → 2025-03-31 | 13,538 (13,712) | 9,742 (23,501) | -3,796 | -28.0% |  |
| 07_full_history_dates — Wide dates: 2023-06-01 → today | 14,022 (15,879) | 12,536 (22,587) | -1,486 | -10.6% |  |
| 08_aetna_only — Aetna Flag = Aetna Only | 11,201 (55,796) | 8,577 (12,881) | -2,624 | -23.4% |  |
| 09_non_aetna_only — Aetna Flag = Non-Aetna Only | 9,624 (17,840) | 9,103 (24,489) | -521 | -5.4% |  |
| 10_aetna_reset — Aetna Flag = All (reset) | 1,816 (1,865) | 1,686 (1,751) | -130 | -7.1% | ✓ |
| 11_appeals_only — Cases = Appeals Only | 7,322 (14,086) | 13,844 (34,349) | +6,522 | +89.1% |  |
| 12_original_only — Cases = Original PAs Only | 8,330 (17,550) | 13,248 (18,853) | +4,918 | +59.0% |  |
| 13_auto_approval_y — Auto Approval = Y only | 12,906 (15,419) | 8,807 (20,332) | -4,099 | -31.8% |  |
| 14_auto_approval_n — Auto Approval = N only (Human-Reviewed) | 18,640 (31,708) | 9,832 (37,841) | -8,808 | -47.3% |  |
| 15_auto_approval_reset — Auto Approval = All (reset) | 1,748 (1,850) | 1,741 (1,745) | -7 | -0.4% | ✓ |
| 16_drug_specialty — Drug Type = SPECIALTY | 10,040 (11,491) | 8,752 (24,815) | -1,288 | -12.8% |  |
| 17_formulary_pa_yes — Formulary PA Flag = Yes | 9,807 (15,371) | 1,756 (1,778) | -8,050 | -82.1% | ✓ |
| 18_combined_restrictive — Combined: CSO + Q1 2025 + Auto=Y + Formulary=Yes | 11,947 (30,609) | 11,527 (18,633) | -420 | -3.5% |  |

## raw_data (target < 5000ms)

| scenario | V0_baseline med (p90) | V1_phase1 med (p90) | Δmed | Δ% | hits |
|---|---:|---:|---:|---:|:---:|
| 26_raw_data_1dim — Raw Data: group by [PA Source] | 9,459 (29,867) | 9,584 (24,058) | +126 | +1.3% |  |
| 27_raw_data_3dim — Raw Data: group by [Month-Year, PA Source, Drug Ty | 1,732 (1,932) | 1,845 (1,994) | +113 | +6.5% | ✓ |
| 28_raw_data_5dim — Raw Data: group by 5 dims (Month-Year, Source, LOB | 1,725 (2,750) | 1,726 (1,736) | +2 | +0.1% | ✓ |

## tab (target < 5000ms)

| scenario | V0_baseline med (p90) | V1_phase1 med (p90) | Δmed | Δ% | hits |
|---|---:|---:|---:|---:|:---:|
| 19_tab_pait_to_raw — Sub-tab: Funnel View → Raw Data | 906 (912) | 904 (914) | -2 | -0.2% | ✓ |
| 20_tab_raw_to_funnel — Sub-tab: Raw Data → Funnel View | 902 (910) | 892 (910) | -10 | -1.1% | ✓ |
| 21_tab_pait_to_sizing — Tab: PAIT OG View → Sizing View | 910 (931) | 1,190 (8,175) | +280 | +30.8% | ✓ |
| 22_tab_sizing_to_trends — Tab: Sizing View → Trends | 907 (938) | 1,188 (9,734) | +282 | +31.0% | ✓ |
| 23_tab_trends_to_pait — Tab: Trends → PAIT OG View | 908 (917) | 1,236 (1,362) | +328 | +36.2% | ✓ |

## rerun (target < 5000ms)

| scenario | V0_baseline med (p90) | V1_phase1 med (p90) | Δmed | Δ% | hits |
|---|---:|---:|---:|---:|:---:|
| 24_sizing_source_gso — Sizing View source selectbox: CSO → GSO | 30,842 (30,849) | 30,834 (30,840) | -8 | -0.0% |  |
| 25_sizing_source_cso — Sizing View source selectbox: GSO → CSO | 30,840 (30,845) | 30,839 (30,846) | -0 | -0.0% |  |
| 29_raw_col_picker_clear_all — Raw Data column picker: Clear all | 1,542 (1,644) | 929 (2,915) | -614 | -39.8% | ✓ |
| 30_raw_col_picker_select_all — Raw Data column picker: Select all | 25,850 (25,869) | 25,840 (25,860) | -10 | -0.0% |  |
| 31_trends_raw_monthly_expand — Trends: open 'Raw monthly data' expander | 60,846 (60,856) | 60,836 (60,856) | -10 | -0.0% |  |

