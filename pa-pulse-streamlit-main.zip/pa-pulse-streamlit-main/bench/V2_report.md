# Bench comparison — V1 (n=10) vs V2 (n=10)

Median (p90) in milliseconds. `stable=false` runs excluded per scenario.

## load (target < 10000ms)

| scenario | V1 med (p90) | V2 med (p90) | Δmed | Δ% | hits |
|---|---:|---:|---:|---:|:---:|
| 01_cold_load — Cold navigation → first stable render (auto-runs 6 | 21,420 (29,418) | 4,620 (7,229) | -16,800 | -78.4% | ✓ |

## query (target < 5000ms)

| scenario | V1 med (p90) | V2 med (p90) | Δmed | Δ% | hits |
|---|---:|---:|---:|---:|:---:|
| 02_evaluate_same_filters_warm — Click Evaluate with unchanged filters (warm cache_ | 1,804 (2,145) | 1,922 (2,140) | +118 | +6.5% | ✓ |
| 03_pa_source_cso — Filter PA Source = CSO only | 8,864 (10,575) | 1,983 (2,990) | -6,881 | -77.6% | ✓ |
| 04_pa_source_gso — Filter PA Source = GSO only (reset then set) | 8,768 (9,540) | 1,856 (3,066) | -6,912 | -78.8% | ✓ |
| 05_pa_source_reset — Reset PA Source to All (empty multiselect) | 1,743 (1,753) | 1,736 (1,746) | -7 | -0.4% | ✓ |
| 06_narrow_dates_q1 — Narrow dates: 2025-01-01 → 2025-03-31 | 7,633 (8,211) | 1,948 (2,826) | -5,684 | -74.5% | ✓ |
| 07_full_history_dates — Wide dates: 2023-06-01 → today | 8,756 (10,984) | 1,732 (2,855) | -7,024 | -80.2% | ✓ |
| 08_aetna_only — Aetna Flag = Aetna Only | 6,910 (8,077) | 1,870 (2,851) | -5,040 | -72.9% | ✓ |
| 09_non_aetna_only — Aetna Flag = Non-Aetna Only | 8,042 (9,634) | 1,732 (2,971) | -6,310 | -78.5% | ✓ |
| 10_aetna_reset — Aetna Flag = All (reset) | 1,749 (1,759) | 1,756 (2,035) | +7 | +0.4% | ✓ |
| 11_appeals_only — Cases = Appeals Only | 6,625 (6,986) | 1,700 (2,420) | -4,924 | -74.3% | ✓ |
| 12_original_only — Cases = Original PAs Only | 8,122 (9,988) | 1,809 (3,126) | -6,314 | -77.7% | ✓ |
| 13_auto_approval_y — Auto Approval = Y only | 6,552 (6,762) | 1,762 (2,693) | -4,791 | -73.1% | ✓ |
| 14_auto_approval_n — Auto Approval = N only (Human-Reviewed) | 7,909 (8,292) | 1,756 (2,830) | -6,152 | -77.8% | ✓ |
| 15_auto_approval_reset — Auto Approval = All (reset) | 1,712 (1,768) | 1,749 (1,786) | +36 | +2.1% | ✓ |
| 16_drug_specialty — Drug Type = SPECIALTY | 7,356 (7,736) | 1,741 (2,771) | -5,614 | -76.3% | ✓ |
| 17_formulary_pa_yes — Formulary PA Flag = Yes | 1,766 (2,209) | 1,748 (2,590) | -18 | -1.0% | ✓ |
| 18_combined_restrictive — Combined: CSO + Q1 2025 + Auto=Y + Formulary=Yes | 8,595 (14,129) | 2,172 (9,012) | -6,423 | -74.7% | ✓ |

## raw_data (target < 5000ms)

| scenario | V1 med (p90) | V2 med (p90) | Δmed | Δ% | hits |
|---|---:|---:|---:|---:|:---:|
| 26_raw_data_1dim — Raw Data: group by [PA Source] | 7,602 (9,127) | 2,118 (10,770) | -5,485 | -72.1% | ✓ |
| 27_raw_data_3dim — Raw Data: group by [Month-Year, PA Source, Drug Ty | 1,738 (1,970) | 1,756 (2,019) | +19 | +1.1% | ✓ |
| 28_raw_data_5dim — Raw Data: group by 5 dims (Month-Year, Source, LOB | 1,732 (1,746) | 1,738 (1,784) | +6 | +0.3% | ✓ |

## tab (target < 5000ms)

| scenario | V1 med (p90) | V2 med (p90) | Δmed | Δ% | hits |
|---|---:|---:|---:|---:|:---:|
| 19_tab_pait_to_raw — Sub-tab: Funnel View → Raw Data | 910 (924) | 912 (922) | +2 | +0.2% | ✓ |
| 20_tab_raw_to_funnel — Sub-tab: Raw Data → Funnel View | 901 (911) | 903 (910) | +2 | +0.2% | ✓ |
| 21_tab_pait_to_sizing — Tab: PAIT OG View → Sizing View | 6,328 (7,281) | 2,474 (6,650) | -3,854 | -60.9% | ✓ |
| 22_tab_sizing_to_trends — Tab: Sizing View → Trends | 5,479 (6,116) | 1,239 (4,614) | -4,240 | -77.4% | ✓ |
| 23_tab_trends_to_pait — Tab: Trends → PAIT OG View | 1,287 (1,298) | 1,280 (1,302) | -8 | -0.6% | ✓ |

## rerun (target < 5000ms)

| scenario | V1 med (p90) | V2 med (p90) | Δmed | Δ% | hits |
|---|---:|---:|---:|---:|:---:|
| 24_sizing_source_gso — Sizing View source selectbox: CSO → GSO | 1,076 (1,125) | 1,063 (1,086) | -13 | -1.2% | ✓ |
| 25_sizing_source_cso — Sizing View source selectbox: GSO → CSO | 1,104 (1,114) | 1,108 (1,122) | +4 | +0.4% | ✓ |
| 29_raw_col_picker_clear_all — Raw Data column picker: Clear all | 995 (1,023) | 986 (996) | -10 | -1.0% | ✓ |
| 30_raw_col_picker_select_all — Raw Data column picker: Select all | 20,876 (20,885) | 20,878 (20,885) | +3 | +0.0% |  |
| 31_trends_raw_monthly_expand — Trends: open 'Raw monthly data' expander | 926 (960) | 938 (948) | +12 | +1.2% | ✓ |

