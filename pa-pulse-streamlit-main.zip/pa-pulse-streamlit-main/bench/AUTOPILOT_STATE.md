# Autopilot state

Running overnight iteration to close in on <10s cold / <5s filter targets, no SQL changes, no functionality changes.

## Progress

| Version | Description | Status | Bench file |
|---|---|---|---|
| V0 | migration_version HEAD (2a22cf4) | baseline | `results/baseline_p1-10.json` |
| V1 | phase1: per-view lazy loading | ✓ benched N=10 | `results/phase1_p1-10.json` (→ [V1_report.md](V1_report.md)) |
| V2 | V1 + disk-persist cache + background prefetch + cold-load stability fix | in progress | pending |
| V3 | V2 + gap-driven improvements | pending | pending |

## V1 headline findings (median of N=10 vs baseline)

Real wins:
- `17_formulary_pa_yes`: 9.8s → 1.8s (-82%) ✓ **hits target**
- `14_auto_approval_n`: 18.6s → 9.8s (-47%)
- `03_pa_source_cso`: 17.4s → 11.2s (-36%)
- `13_auto_approval_y`: 12.9s → 8.8s (-32%)
- `06_narrow_dates_q1`: 13.5s → 9.7s (-28%)

Regressions to investigate:
- `01_cold_load`: 22.1s → 32.5s (+47%) — client-side artifact (server-side ~7.8s); segmented_control rerun suspected
- `11_appeals_only`: 7.3s → 13.8s (+89%) — with N=10, this regressed vs baseline
- `12_original_only`: 8.3s → 13.2s (+59%) — same pattern
- Tab-switch penalty: 21/22/23 now ~1.2s median but p90 up to 9.7s (lazy load fires under a fresh cache)

Full V1 report: [`V1_report.md`](V1_report.md).

## V2 plan (code applied, benchmark BLOCKED)

Three changes applied to `main.py`:

1. **Disk-persist `@st.cache_data(ttl=3600, persist="disk")`** on `run_query`.
2. **Disk-persist `@st.cache_data(ttl=86400, persist="disk")`** on `load_filter_options`.
3. **Background prefetch** — after the active view's queries load, a daemon thread pre-warms the other views' queries. See `_prefetch_other_views()` in `main.py`.
4. **Cold-load stability fix** — pre-seed `st.session_state.active_view` BEFORE `st.segmented_control` renders, avoiding the first-render default-persist rerun that briefly destabilizes the DOM.

## ⚠ BLOCKED — needs BQ reauth

Ran `gcloud auth application-default print-access-token` at 07:34 → **reauth failed** (invalid_rapt, MFA-related refresh required). Non-interactive session can't complete `gcloud auth application-default login` (browser flow).

App renders now but every query returns `Query failed: Reauthentication is needed`. Can't run V2 bench without BQ access.

**To unblock**: run `gcloud auth application-default login` interactively, then either resume this session or run:

```bash
/tmp/bench_alternate.sh 10   # will produce phase1_p*.json and baseline_p*.json
# ... but that clobbers V1 filenames. Better to update the script's labels first.
```

I'll wait; nothing else productive I can do here without BQ.
