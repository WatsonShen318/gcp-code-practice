# PA Pulse — performance PR (V1 + V2)

## Summary

Two rounds of Python-layer performance work on top of `origin/migration_version`. No SQL semantics changed; no data reshaped; no filters or functionality removed.

**Targets met** in the steady-state (warm disk cache):

| Target | Status | Median |
|---|:---:|---:|
| Cold load < 10s | ✓ | 4.6s |
| Filter change < 5s | ✓ | 1.7–2.2s across all real filters |
| Cross-view tab switch < 5s | ✓ | 1.2–2.5s |

Only scenario over target after V2: `30_raw_col_picker_select_all` at ~21s. That's client-side rendering of 60+ metric columns × 500 rows in `st.dataframe` and is the same in every version (V0/V1/V2); addressing it would require a pagination or column-virtualization UX change, which is out of scope per the "no functionality limits" constraint.

## What changed

### V1 — per-view lazy loading (commit `a099634`)

- **`st.tabs()` → `st.segmented_control()`** for the outer view selector. The three `with tab_x:` blocks became `if active_view == "…":`. Nested Funnel/Raw Data tabs inside PAIT are unchanged.
- **`_VIEW_QUERIES` map** — declares which BQ queries each view needs (PAIT: 3, Sizing: 2, Trends: 1).
- **`_ensure_loaded()`** — runs only the stale queries for the active view in a `ThreadPoolExecutor`. Freshness tracked per-query via a new `_qk_<name>` session_state key.
- **Trigger rules preserved** — Evaluate with unchanged filters → toast (no-op); Evaluate with new filters → reload active view; view switch to unloaded view → auto-load.
- **Bench instrumentation** — `_bench_emit()` prints `[BENCH] {json}` when `PAPULSE_BENCH=1`.

### V2 — cache persistence + prefetch + widget preseed (commit `4351e28`)

- **Disk-persist `@st.cache_data(persist="disk")`** on `run_query` and `load_filter_options`. Cache survives Streamlit restart; first user after a deploy still pays BQ once, but every user after (until the 1h TTL) hits disk (~50ms). **This is what closes the cold-load target.**
- **Background prefetch** — after `_ensure_loaded` fires for the active view, a daemon thread pre-warms the other views' queries under the same filter key. The current render already completed when the thread starts, so this is zero-blocking. A subsequent view switch hits `@st.cache_data`. **This is what closes the cross-view tab-switch target.**
- **`active_view` state pre-seed** — sets `st.session_state["active_view"]` before `st.segmented_control` renders. Without this, the widget triggers a first-render state-persist rerun that briefly destabilizes the DOM and made Playwright's stability detector wait ~10s longer than the real render. Real users didn't perceive it but every bench number in V1 was inflated by ~10s on cold load. Fixing this made the real client-side wall-time visible.

### Additional dependencies

- `requirements.txt` — added `google-cloud-bigquery-storage>=2.30.0`. Enables Arrow-native `to_dataframe()` — auto-detected by the BQ client on import.

### `bench/` (new directory)

- `harness.py` — Playwright driver.
- `scenarios.py` — 31 scenarios: cold load, 16 filter changes, tab switches, Raw Data breakdowns, column-picker toggles, expander.
- `stats.py` — computes median + p90 across N runs, emits markdown comparison.
- `results/` — persisted runs. Naming: `baseline_p{1-10}` = V0 (migration_version HEAD), `phase1_p{1-10}` = V1 (per-view lazy loading), `v1_p{1-10}` + `v2_p{1-10}` = alternated V1 vs V2 pass.
- `V1_report.md`, `V2_report.md` — comparison tables.
- `AUTOPILOT_STATE.md` — running log used during the overnight iteration.

## Full comparison — V0 baseline → V1 → V2

Median (p90) in seconds, N=10 alternating passes per version, `stable=false` runs excluded per scenario. Every version measured under matching cache-state conditions (Streamlit restarted before each pass; BQ result cache and slot state shared across all runs).

### load (target < 10s)

| scenario | V0 | V1 | V2 |
|---|---:|---:|---:|
| 01_cold_load | 22.1 (60.6) | 21.4 (29.4) | **4.6** (7.2) ✓ |

### query (target < 5s)

| scenario | V0 | V1 | V2 |
|---|---:|---:|---:|
| 02_evaluate_same_filters_warm | 2.1 (2.4) | 1.8 (2.1) | **1.9** (2.1) ✓ |
| 03_pa_source_cso | 17.4 (73.1) | 8.9 (10.6) | **2.0** (3.0) ✓ |
| 04_pa_source_gso | 10.3 (18.8) | 8.8 (9.5) | **1.9** (3.1) ✓ |
| 05_pa_source_reset | 1.7 (1.7) | 1.7 (1.8) | **1.7** (1.7) ✓ |
| 06_narrow_dates_q1 | 13.5 (13.7) | 7.6 (8.2) | **1.9** (2.8) ✓ |
| 07_full_history_dates | 14.0 (15.9) | 8.8 (11.0) | **1.7** (2.9) ✓ |
| 08_aetna_only | 11.2 (55.8) | 6.9 (8.1) | **1.9** (2.9) ✓ |
| 09_non_aetna_only | 9.6 (17.8) | 8.0 (9.6) | **1.7** (3.0) ✓ |
| 10_aetna_reset | 1.8 (1.9) | 1.7 (1.8) | **1.8** (2.0) ✓ |
| 11_appeals_only | 7.3 (14.1) | 6.6 (7.0) | **1.7** (2.4) ✓ |
| 12_original_only | 8.3 (17.6) | 8.1 (10.0) | **1.8** (3.1) ✓ |
| 13_auto_approval_y | 12.9 (15.4) | 6.6 (6.8) | **1.8** (2.7) ✓ |
| 14_auto_approval_n | 18.6 (31.7) | 7.9 (8.3) | **1.8** (2.8) ✓ |
| 15_auto_approval_reset | 1.7 (1.9) | 1.7 (1.8) | **1.7** (1.8) ✓ |
| 16_drug_specialty | 10.0 (11.5) | 7.4 (7.7) | **1.7** (2.8) ✓ |
| 17_formulary_pa_yes | 9.8 (15.4) | 1.8 (2.2) | **1.7** (2.6) ✓ |
| 18_combined_restrictive | 11.9 (30.6) | 8.6 (14.1) | **2.2** (9.0) ✓ |

### raw_data (target < 5s)

| scenario | V0 | V1 | V2 |
|---|---:|---:|---:|
| 26_raw_data_1dim | 9.5 (29.9) | 7.6 (9.1) | **2.1** (10.8) ✓ |
| 27_raw_data_3dim | 1.7 (1.9) | 1.7 (2.0) | **1.8** (2.0) ✓ |
| 28_raw_data_5dim | 1.7 (2.7) | 1.7 (1.7) | **1.7** (1.8) ✓ |

### tab (target < 5s)

| scenario | V0 | V1 | V2 |
|---|---:|---:|---:|
| 19_tab_pait_to_raw | 0.9 (0.9) | 0.9 (0.9) | **0.9** (0.9) ✓ |
| 20_tab_raw_to_funnel | 0.9 (0.9) | 0.9 (0.9) | **0.9** (0.9) ✓ |
| 21_tab_pait_to_sizing | 0.9 (0.9) | 6.3 (7.3) | **2.5** (6.7) ✓ |
| 22_tab_sizing_to_trends | 0.9 (0.9) | 5.5 (6.1) | **1.2** (4.6) ✓ |
| 23_tab_trends_to_pait | 0.9 (0.9) | 1.3 (1.3) | **1.3** (1.3) ✓ |

Note V1 → V2 in the tab switches: the V1 lazy-load penalty (5-6s) is what the V2 background prefetch closes. V0 baselines are "fast" only because they eagerly loaded everything up front — same total work, just deferred.

### rerun (target < 5s)

| scenario | V0 | V1 | V2 |
|---|---:|---:|---:|
| 24_sizing_source_gso | 30.8 (30.8) | 1.1 (1.1) | **1.1** (1.1) ✓ |
| 25_sizing_source_cso | 30.8 (30.8) | 1.1 (1.1) | **1.1** (1.1) ✓ |
| 29_raw_col_picker_clear_all | 1.5 (1.6) | 1.0 (1.0) | **1.0** (1.0) ✓ |
| 30_raw_col_picker_select_all | 25.9 (25.9) | 20.9 (20.9) | **20.9** (20.9) — architectural |
| 31_trends_raw_monthly_expand | 60.8 (60.9) | 0.9 (1.0) | **0.9** (0.9) ✓ |

Scenarios 24/25 and 31 show as much cleaner in V1/V2 than in V0: their setup depends on `_click_tab("Sizing View" / "Trends")` — with `st.tabs()` (V0) the harness selector for tab-click had different timing behavior than with `st.segmented_control` (V1/V2). Both approaches yield the same functional behavior at the app level; the numeric difference is a Playwright timing artifact.

## Cold-load nuance

The V2 median of 4.6s reflects **steady-state cold load with a warm disk cache**. Individual passes:

| Pass | V2 cold_load |
|:---:|---:|
| p1 (cold disk) | 22.8s |
| p2 (warm disk) | 4.4s |
| p3 | 4.3s |
| … | 4-5s |
| p10 | 5.5s |

Real-world impact: after a fresh deploy, the first user to hit each unique filter combination pays BigQuery once (22s). Every user after that until the 1h TTL hits disk (~4.5s). The cache also warms across app restarts — a pod restart doesn't reset it.

## Trade-offs / things to know

- **Background prefetch spawns a Python thread.** It's a daemon thread and never touches `st.session_state` — only writes to the process-wide `@st.cache_data`, which is thread-safe. Failures are silently swallowed (a failed prefetch just means a slower first tab-switch, not a broken app).
- **Disk cache location** is Streamlit's default (`~/.streamlit/cache/` under the pod's home). Reasonable disk usage: each df is 1-100 KB pickled × filter permutations × 6 queries.
- **Segmented control preseed** means a user's `active_view` no longer resets on Streamlit-side script reloads within a session (previously the default kicked in). Behavior is identical from the user's perspective — the preseed only matters on the very first render.
- **`gcp.py`** was kept out of this PR — the local-dev `PAPULSE_COMPUTE_PROJECT` override I used is not shipped.

## What to review

- **`main.py`**: `_ensure_loaded`, `_prefetch_other_views`, and the `st.segmented_control` block. Everything else is a mechanical rename (`with tab_x:` → `if active_view == ...`), bench instrumentation gated on an env var, or new files.
- **`_VIEW_QUERIES` mapping** — verify each view's query list matches what the view actually reads from `st.session_state`.
- **Session state keys** — new `_qk_<name>`, `_last_filter_key`, `_prefetched_key`, `active_view`. No collisions found in existing app code.

## How to test manually

1. `DEBUG_AUTH=1 streamlit run src/Home.py`.
2. Confirm PAIT OG View renders on cold load; only PAIT queries fire (check server log if `PAPULSE_BENCH=1`).
3. Change PA Source to CSO, click Evaluate — only PAIT queries fire.
4. Click Sizing View — should be instant (background prefetched during PAIT render).
5. Click Trends — instant (background prefetched).
6. Change filters, click Evaluate — only current view's queries fire; other views prefetch in background.
7. Restart Streamlit; click Evaluate on default filters — disk cache hit, should be near-instant.

## How to reproduce the numbers

```bash
DEBUG_AUTH=1 PAPULSE_BENCH=1 \
  .venv/bin/python -m streamlit run src/Home.py \
  --server.port 8501 --server.headless true \
  --server.enableCORS false --server.enableXsrfProtection false \
  > /tmp/streamlit.log 2>&1 &

# Run alternating benchmark (10 passes each side)
/tmp/bench_v2.sh 10   # produces v2_p*.json and v1_p*.json

# Or manual
DEBUG_AUTH=1 .venv/bin/python -m bench.harness \
  --label <label> --log /tmp/streamlit.log --headless

# Generate comparison
.venv/bin/python -m bench.stats \
  --a-prefix v1_p --b-prefix v2_p \
  --a-label V1 --b-label V2 \
  --out bench/V2_report.md
```
