"""Playwright-based benchmark harness for the PA Pulse Streamlit dashboard.

Usage
-----
Prerequisites (see bench/README.md for full setup):
    1. `pip install playwright && playwright install chromium`
    2. `pip install google-cloud-bigquery-storage[pyarrow]` (for the app itself)
    3. Streamlit must already be running on localhost:8501 with PAPULSE_BENCH=1.

Run the suite (produces bench/results/<label>.json):
    python bench/harness.py --label before
    python bench/harness.py --label after

The harness drives every scenario in `bench/scenarios.py` and records, per
scenario:
  - client-side wall time from the trigger click to the "wait_for" predicate
    resolving,
  - the server-side [BENCH] JSON emitted by main.py during that window
    (parsed from the streamlit log file).

If the harness cannot find a widget it prints a WARN and moves on so a single
brittle scenario doesn't kill the whole run.
"""

from __future__ import annotations

import argparse
import json
import re
import sys
import time
from dataclasses import asdict
from pathlib import Path

from playwright.sync_api import Page, sync_playwright

sys.path.insert(0, str(Path(__file__).parent))
from scenarios import SCENARIOS, Scenario  # noqa: E402


# -------------------------------------------------------------------------
# Log parser — reads [BENCH] JSON lines that main.py emits into the log
# -------------------------------------------------------------------------

BENCH_RE = re.compile(r"^\[BENCH\]\s+(\{.*\})\s*$")


class LogTail:
    """Cheap tailer that remembers the last read offset so we can attribute
    log lines to individual scenarios."""

    def __init__(self, path: Path):
        self.path = path
        self.offset = 0
        if path.exists():
            self.offset = path.stat().st_size

    def read_new(self) -> list[dict]:
        events: list[dict] = []
        if not self.path.exists():
            return events
        with self.path.open("r") as f:
            f.seek(self.offset)
            for line in f:
                m = BENCH_RE.match(line.strip())
                if m:
                    try:
                        events.append(json.loads(m.group(1)))
                    except json.JSONDecodeError:
                        pass
            self.offset = f.tell()
        return events


# -------------------------------------------------------------------------
# Widget driver
# -------------------------------------------------------------------------

class Driver:
    def __init__(self, page: Page, base_url: str):
        self.page = page
        self.base_url = base_url

    # ---- primitive helpers ------------------------------------------------
    def _combobox(self, label: str):
        return self.page.get_by_role("combobox", name=label)

    def multiselect_add(self, label: str, option: str) -> None:
        cb = self._combobox(label)
        self._safe_click(cb)
        # Streamlit's multiselect pops a listbox — click the option by exact text.
        self._safe_click(
            self.page.get_by_role("option", name=option, exact=True).first
        )
        # Wait for the option to render as a selected chip inside this widget
        # before closing the dropdown; otherwise Streamlit can drop the
        # selection when the popover is dismissed too fast.
        widget = cb.locator(
            "xpath=ancestor::*[@data-testid='stMultiSelect'][1]"
        )
        chip = widget.locator(
            f"span[data-baseweb='tag']:has-text('{option}'), "
            f"[data-testid='stMultiSelectOptionsBase']:has-text('{option}')"
        )
        try:
            chip.first.wait_for(state="visible", timeout=5_000)
        except Exception:
            pass
        self.page.keyboard.press("Escape")

    def multiselect_clear(self, label: str) -> None:
        # Every selected chip in a Streamlit multiselect has an aria-label
        # starting with "Remove ". We click all of them, which drops the
        # multiselect back to the empty (== "All") state.
        cb = self._combobox(label)
        # The chip container is a sibling of the combobox; look near it.
        # Simpler: query all "Remove ..." buttons inside the parent widget row.
        widget = cb.locator(
            "xpath=ancestor::*[@data-testid='stMultiSelect'][1]"
        )
        remove_buttons = widget.locator("span[data-baseweb='tag'] span[role='button'], "
                                        "[aria-label^='Remove']")
        n = remove_buttons.count()
        for _ in range(n):
            remove_buttons.first.click()

    def selectbox(self, label: str, option: str) -> None:
        cb = self._combobox(label)
        cb.click()
        self.page.get_by_role("option", name=option, exact=True).first.click()

    def set_date(self, role: str, iso: str) -> None:
        # Streamlit date_input widgets appear top-to-bottom: start then end.
        # We locate them via the "Selected date is …" aria hint on the field.
        widgets = self.page.locator("[data-testid='stDateInput'] input")
        idx = 0 if role == "start" else 1
        target = widgets.nth(idx)
        target.click()
        target.press("Control+A")
        target.press("Meta+A")
        target.type(iso.replace("-", "/"))
        target.press("Enter")

    def _safe_click(self, locator) -> None:
        # Streamlit's sidebar has its own scroll container; the built-in
        # Playwright autoscroll doesn't always reach elements below the fold.
        # Scroll into view explicitly, then fall back to force-click if the
        # element still reports as outside the viewport (headless quirks).
        try:
            locator.scroll_into_view_if_needed(timeout=5_000)
        except Exception:
            pass
        try:
            locator.click(timeout=10_000)
        except Exception:
            locator.click(force=True, timeout=10_000)

    def click_button(self, label: str) -> None:
        self._safe_click(self.page.get_by_role("button", name=label, exact=True).first)

    def click_tab(self, label: str) -> None:
        # The outer view selector is a segmented control (role=radio) as of
        # Phase 1 lazy-loading; the inner Funnel/Raw Data selector stays
        # role=tab. Prefer tab (nested), fall back to radio (outer view).
        tab = self.page.get_by_role("tab", name=label, exact=True).first
        if tab.count() > 0:
            self._safe_click(tab)
        else:
            self._safe_click(self.page.get_by_role("radio", name=label, exact=True).first)

    def click_text(self, text: str) -> None:
        self._safe_click(self.page.get_by_text(text, exact=True).first)

    def expand_if_collapsed(self, label: str) -> None:
        # Streamlit expander: an element with text `label` and an aria-expanded state.
        # If already expanded, this click would collapse — so guard.
        header = self.page.locator(f"[data-testid='stExpander'] summary:has-text('{label}')")
        try:
            handle = header.first
            expanded = handle.evaluate("(el) => el.getAttribute('aria-expanded')")
            if expanded != "true":
                handle.click()
        except Exception:
            # Fall back: click by text; harmless if already open.
            try:
                self.page.get_by_text(label, exact=False).first.click()
            except Exception:
                pass

    # ---- dispatch --------------------------------------------------------
    def run_action(self, action: dict) -> None:
        kind = action["kind"]
        try:
            if kind == "navigate":
                self.page.goto(action["url"], wait_until="domcontentloaded")
            elif kind == "multiselect_add":
                self.multiselect_add(action["label"], action["option"])
            elif kind == "multiselect_clear":
                self.multiselect_clear(action["label"])
            elif kind == "selectbox":
                self.selectbox(action["label"], action["option"])
            elif kind == "set_date":
                self.set_date(action["role"], action["iso"])
            elif kind == "click_button":
                self.click_button(action["label"])
            elif kind == "click_tab":
                self.click_tab(action["label"])
            elif kind == "click_text":
                self.click_text(action["text"])
            elif kind == "expand_if_collapsed":
                self.expand_if_collapsed(action["label"])
            else:
                print(f"WARN unknown action kind: {kind}", file=sys.stderr)
        except Exception as e:
            print(f"WARN action {kind} failed: {e}", file=sys.stderr)


# -------------------------------------------------------------------------
# Wait-for predicates run in the browser
# -------------------------------------------------------------------------

WAIT_JS = r"""
async (opts) => {
  const kind = opts.kind;
  const stableForMs = opts.stable_for_ms || 1000;
  const timeoutMs = opts.timeout_ms || 60000;
  const t0 = performance.now();
  let stableSince = null;
  let lastSignal = null;

  function signal() {
    if (kind === "kpi_stable") {
      const count = document.querySelectorAll(".cvs-metric").length;
      const spinner = !!document.querySelector('[data-testid="stSpinner"]');
      if (spinner) return null;
      if (count < (opts.min_metrics || 12)) return null;
      return "kpi:" + count;
    }
    if (kind === "text_visible") {
      const t = document.body.innerText || "";
      if (t.toLowerCase().includes(String(opts.text).toLowerCase())) return "text";
      return null;
    }
    if (kind === "tab_stable") {
      const spinner = !!document.querySelector('[data-testid="stSpinner"]');
      if (spinner) return null;
      const bodyLen = (document.body.innerText || "").length;
      return "len:" + bodyLen;
    }
    if (kind === "dom_settled") {
      const spinner = !!document.querySelector('[data-testid="stSpinner"]');
      if (spinner) return null;
      const bodyLen = (document.body.innerText || "").length;
      return "len:" + bodyLen;
    }
    return "ok";
  }

  while (performance.now() - t0 < timeoutMs) {
    const s = signal();
    if (s !== null) {
      if (s === lastSignal) {
        if (!stableSince) stableSince = performance.now();
        if (performance.now() - stableSince >= stableForMs) {
          return { ok: true, ms: Math.round(performance.now() - t0), signal: s };
        }
      } else {
        stableSince = null;
        lastSignal = s;
      }
    } else {
      stableSince = null;
      lastSignal = null;
    }
    await new Promise(r => setTimeout(r, 80));
  }
  return { ok: false, ms: timeoutMs, signal: lastSignal };
}
"""


def wait_for(page: Page, predicate: dict | None) -> dict:
    if not predicate:
        # Default: a light settle.
        predicate = {"kind": "dom_settled", "stable_for_ms": 400, "timeout_ms": 30_000}
    return page.evaluate(WAIT_JS, predicate)


# -------------------------------------------------------------------------
# Scenario runner
# -------------------------------------------------------------------------

def run_scenario(
    scenario: Scenario, driver: Driver, log_tail: LogTail
) -> dict:
    # Drain any pre-existing bench events so they don't pollute this scenario.
    log_tail.read_new()

    # Setup steps — untimed.
    for action in scenario.setup:
        driver.run_action(action)
        driver.page.wait_for_timeout(120)

    # Trigger — timed.
    t0 = time.perf_counter()
    if scenario.trigger:
        driver.run_action(scenario.trigger)
    wait_result = wait_for(driver.page, scenario.wait_for)
    client_ms = int((time.perf_counter() - t0) * 1000)

    # Give the server a beat to flush its final bench line for slow queries.
    time.sleep(0.4)
    bench_events = log_tail.read_new()

    return {
        "id": scenario.id,
        "name": scenario.name,
        "category": scenario.category,
        "client_ms": client_ms,
        "waited_stable": wait_result.get("ok", False),
        "wait_signal": wait_result.get("signal"),
        "server_events": bench_events,
    }


# -------------------------------------------------------------------------
# Main
# -------------------------------------------------------------------------

def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--label", required=True, help="Output label (e.g. 'before' or 'after')")
    ap.add_argument("--url", default="http://localhost:8501/")
    ap.add_argument("--log", default="/tmp/streamlit.log")
    ap.add_argument(
        "--only",
        default=None,
        help="Comma-separated list of scenario IDs (e.g. 01_cold_load,03_pa_source_cso)",
    )
    ap.add_argument("--headless", action="store_true", default=True)
    args = ap.parse_args()

    log_tail = LogTail(Path(args.log))
    only = set(args.only.split(",")) if args.only else None
    scenarios = [s for s in SCENARIOS if (only is None or s.id in only)]

    print(f"Running {len(scenarios)} scenarios against {args.url}", flush=True)

    results: list[dict] = []
    with sync_playwright() as pw:
        browser = pw.chromium.launch(headless=args.headless)
        context = browser.new_context(viewport={"width": 1600, "height": 1400})
        page = context.new_page()
        driver = Driver(page, args.url)

        # Do NOT prime the page — the first scenario is expected to be
        # 01_cold_load which itself does the initial navigate and is timed.
        # (Priming would warm Streamlit's cache_data and make the cold-load
        # measurement meaningless.)

        for s in scenarios:
            print(f"→ {s.id} {s.name}", flush=True)
            try:
                r = run_scenario(s, driver, log_tail)
            except Exception as e:
                r = {"id": s.id, "name": s.name, "category": s.category,
                     "error": str(e), "client_ms": None,
                     "waited_stable": False, "server_events": []}
            results.append(r)
            print(
                f"   client_ms={r.get('client_ms')} "
                f"stable={r.get('waited_stable')} "
                f"server_events={len(r.get('server_events', []))}",
                flush=True,
            )

        context.close()
        browser.close()

    out_dir = Path(__file__).parent / "results"
    out_dir.mkdir(parents=True, exist_ok=True)
    out_path = out_dir / f"{args.label}.json"
    out_path.write_text(json.dumps({"label": args.label, "results": results}, indent=2))
    print(f"Wrote {out_path}", flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
