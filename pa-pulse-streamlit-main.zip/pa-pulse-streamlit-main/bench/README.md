# PA Pulse benchmark suite

Reproducible latency measurement for the Streamlit dashboard. Uses Playwright
to drive the app end-to-end and correlates each interaction with the server's
`[BENCH]` log lines so you can attribute wall-clock time to either the
BigQuery round-trip or downstream Streamlit rendering.

## Contents

| File | Purpose |
|---|---|
| `scenarios.py` | 25+ scenario definitions (filter changes, tab switches, Raw Data loads). Each is a dataclass — a setup list, a trigger action, and a "wait until stable" predicate. |
| `harness.py` | Playwright driver. Executes each scenario and records per-scenario client-side wall time + the `[BENCH]` events emitted during that window. |
| `report.py` | Compares two result JSONs and prints a Markdown table. |
| `results/` | Persisted runs. |

## One-time setup

```bash
# App-side deps (usually already installed in .venv):
pip install google-cloud-bigquery-storage[pyarrow]

# Bench-side deps:
pip install playwright
playwright install chromium
```

## Running

Start Streamlit with bench instrumentation on (writes `[BENCH]` JSON lines
into stdout / the log file):

```bash
DEBUG_AUTH=1 PAPULSE_BENCH=1 \
  python -m streamlit run src/Home.py \
  --server.port 8501 --server.headless true \
  > /tmp/streamlit.log 2>&1 &
```

Once the app is up on `localhost:8501`, run the harness:

```bash
python bench/harness.py --label before
# ... make changes ...
python bench/harness.py --label after
```

The harness always drives a fresh navigation before scenario 1 so results are
reproducible from a cold cache. Note: `@st.cache_data(ttl=3600)` warms across
scenarios within a single run — that's intentional; scenarios like
`02_evaluate_same_filters_warm` are explicitly designed to hit the cache.

To run a single scenario:

```bash
python bench/harness.py --label debug --only 01_cold_load,03_pa_source_cso
```

## Interpreting results

Each result row in the output JSON has:

- `client_ms` — wall time from trigger click to a stable DOM state.
- `server_events` — a list of parsed `[BENCH]` JSON events emitted during that
  window. Query scenarios yield one `event: "query"` per BQ call plus a
  summary `event: "evaluate"` with `tag: "ALL_QUERIES_WALL"`.

`report.py` distills this into a Markdown table:

```bash
python bench/report.py bench/results/before.json bench/results/after.json > digest.md
```

## The `[BENCH]` instrumentation

`src/apps/pa_pulse/main.py` emits one JSON line per BigQuery call when
`PAPULSE_BENCH=1` is set. The lines look like:

```
[BENCH] {"event": "query", "tag": "pait_fallout_df", "total_ms": 17214, "bq_ms": 322, "rows": 393241, "cols": 5, "bytes_processed": 0}
[BENCH] {"event": "evaluate", "tag": "ALL_QUERIES_WALL", "total_ms": 17245, "start_date": "2023-06-01", "end_date": "2026-06-30"}
```

- `total_ms` is the full `client.query(...).to_dataframe()` round-trip.
- `bq_ms` is the BigQuery job's own reported duration
  (`job.ended - job.started`); when the BigQuery Storage API is used for the
  DataFrame read, this can be tiny even when `total_ms` is large — the
  difference is time spent streaming rows into Python.
- `bytes_processed` is `job.total_bytes_processed`; a large value on a query
  that returns a handful of rows is a partition-pruning smell.

When `PAPULSE_BENCH` is unset (default), instrumentation is silent and has
zero runtime overhead beyond one `os.environ.get` per call.
