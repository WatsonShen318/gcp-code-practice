"""Aggregate multiple bench result JSONs and emit a comparison table.

Usage:
    python -m bench.stats --a-prefix baseline_p --b-prefix phase1_p --a-label baseline --b-label phase1

Prints a markdown table with median and p90 per scenario, plus which target each hits.
"""
from __future__ import annotations

import argparse
import json
import statistics
from pathlib import Path
from typing import Iterable

RES_DIR = Path(__file__).parent / "results"

TARGETS_MS = {"load": 10_000, "query": 5_000, "raw_data": 5_000, "tab": 5_000, "rerun": 5_000}


def load_runs(prefix: str) -> list[dict[str, dict]]:
    files = sorted(RES_DIR.glob(f"{prefix}*.json"))
    return [{r["id"]: r for r in json.load(f.open())["results"]} for f in files]


def stable_series(runs: Iterable[dict[str, dict]], sid: str) -> list[float]:
    return [r[sid]["client_ms"] for r in runs
            if sid in r and r[sid].get("waited_stable") is True]


def p90(vals: list[float]) -> float:
    if not vals:
        return float("nan")
    if len(vals) == 1:
        return vals[0]
    s = sorted(vals)
    k = 0.9 * (len(s) - 1)
    lo = int(k)
    hi = min(lo + 1, len(s) - 1)
    frac = k - lo
    return s[lo] + frac * (s[hi] - s[lo])


def summarize(runs, sid: str) -> dict:
    vals = stable_series(runs, sid)
    return {
        "n": len(vals),
        "median": statistics.median(vals) if vals else float("nan"),
        "p90": p90(vals),
    }


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--a-prefix", required=True)
    ap.add_argument("--b-prefix", required=True)
    ap.add_argument("--a-label", default="A")
    ap.add_argument("--b-label", default="B")
    ap.add_argument("--out", default=None, help="Optional path to write markdown output")
    args = ap.parse_args()

    a_runs = load_runs(args.a_prefix)
    b_runs = load_runs(args.b_prefix)
    if not a_runs or not b_runs:
        raise SystemExit(f"No runs found for prefixes {args.a_prefix!r} and/or {args.b_prefix!r}")

    ids = list(a_runs[0].keys())
    lines: list[str] = []
    lines.append(f"# Bench comparison — {args.a_label} (n={len(a_runs)}) vs {args.b_label} (n={len(b_runs)})")
    lines.append("")
    lines.append("Median (p90) in milliseconds. `stable=false` runs excluded per scenario.")
    lines.append("")

    for cat in ["load", "query", "raw_data", "tab", "rerun"]:
        cat_ids = [sid for sid in ids if a_runs[0].get(sid, {}).get("category") == cat]
        if not cat_ids:
            continue
        target = TARGETS_MS.get(cat, 999_999)
        lines.append(f"## {cat} (target < {target}ms)")
        lines.append("")
        lines.append(f"| scenario | {args.a_label} med (p90) | {args.b_label} med (p90) | Δmed | Δ% | hits |")
        lines.append("|---|---:|---:|---:|---:|:---:|")
        for sid in cat_ids:
            a = summarize(a_runs, sid)
            b = summarize(b_runs, sid)
            if a["n"] == 0 or b["n"] == 0:
                continue
            delta = b["median"] - a["median"]
            pct = 100 * delta / a["median"] if a["median"] > 0 else 0
            hit = "✓" if b["median"] < target else ""
            name = a_runs[0][sid]["name"][:50]
            lines.append(
                f"| {sid} — {name} | "
                f"{a['median']:,.0f} ({a['p90']:,.0f}) | "
                f"{b['median']:,.0f} ({b['p90']:,.0f}) | "
                f"{delta:+,.0f} | {pct:+.1f}% | {hit} |"
            )
        lines.append("")

    out = "\n".join(lines)
    print(out)
    if args.out:
        Path(args.out).write_text(out + "\n")


if __name__ == "__main__":
    main()
