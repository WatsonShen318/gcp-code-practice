"""Scenario definitions for the PA Pulse Streamlit benchmark harness.

Each Scenario is a small dataclass describing:
  - a display name / category
  - whether the scenario is expected to hit BigQuery (rerun_type="query"),
    stay client-side (rerun_type="rerun"), or be a raw browser navigation
  - a "setup" list of Playwright actions to reach the target state
  - a "trigger" — the single action whose latency we measure
  - a "wait_for" predicate — what the harness polls for to decide the trigger
    has resolved

Actions are represented as plain dicts (kind + args) instead of Playwright API
objects so this file has no import-time dependencies. The harness in
`harness.py` interprets them.

Design notes:
  - We measure at least 25 distinct scenarios covering initial load,
    cache-busting filter changes, tab switches, in-page reruns, and Raw Data
    aggregations. This gives the app owner a broad baseline.
  - "warm cache" scenarios re-click Evaluate with identical filters to isolate
    Streamlit's rerun cost from BigQuery cost.
"""

from dataclasses import dataclass, field
from typing import Any


@dataclass
class Scenario:
    id: str
    name: str
    category: str  # "load" | "query" | "rerun" | "tab" | "raw_data"
    setup: list[dict[str, Any]] = field(default_factory=list)
    trigger: dict[str, Any] | None = None
    wait_for: dict[str, Any] | None = None
    notes: str = ""


# Helper builders -----------------------------------------------------------

def _open_expander(label: str) -> dict:
    return {"kind": "expand_if_collapsed", "label": label}

def _pick_multiselect(label: str, option: str) -> dict:
    return {"kind": "multiselect_add", "label": label, "option": option}

def _clear_multiselect(label: str) -> dict:
    return {"kind": "multiselect_clear", "label": label}

def _select(label: str, option: str) -> dict:
    return {"kind": "selectbox", "label": label, "option": option}

def _set_date(role: str, iso: str) -> dict:
    # role in {"start", "end"} — corresponds to the two st.date_input widgets
    return {"kind": "set_date", "role": role, "iso": iso}

def _click(target: str) -> dict:
    return {"kind": "click_text", "text": target}

def _click_button(label: str) -> dict:
    return {"kind": "click_button", "label": label}

def _click_tab(label: str) -> dict:
    return {"kind": "click_tab", "label": label}


# Wait-for predicates -------------------------------------------------------
# Each of these is polled by the harness's JS to detect "stable render".

WAIT_KPI_STABLE = {
    "kind": "kpi_stable",
    "min_metrics": 12,
    "stable_for_ms": 1500,
    "timeout_ms": 180_000,
}
WAIT_RAW_TABLE = {
    "kind": "text_visible",
    "text": "Breakdown by",
    "stable_for_ms": 1500,
    "timeout_ms": 180_000,
}
WAIT_TAB_LOADED = {
    "kind": "tab_stable",
    "stable_for_ms": 700,
    "timeout_ms": 60_000,
}
WAIT_SIZING_LOADED = {
    "kind": "text_visible",
    "text": "sizing",
    "stable_for_ms": 1000,
    "timeout_ms": 60_000,
}
WAIT_INSTANT = {
    "kind": "dom_settled",
    "stable_for_ms": 500,
    "timeout_ms": 30_000,
}


# ----------------------------------------------------------------------------
# Scenario catalog
# ----------------------------------------------------------------------------

SCENARIOS: list[Scenario] = [
    # --- Cold load & warm cache -------------------------------------------
    Scenario(
        id="01_cold_load",
        name="Cold navigation → first stable render (auto-runs 6 queries)",
        category="load",
        setup=[],
        trigger={"kind": "navigate", "url": "http://localhost:8501/"},
        wait_for=WAIT_KPI_STABLE,
    ),
    Scenario(
        id="02_evaluate_same_filters_warm",
        name="Click Evaluate with unchanged filters (warm cache_data)",
        category="query",
        setup=[],
        trigger=_click_button("Evaluate"),
        wait_for=WAIT_KPI_STABLE,
    ),

    # --- Source / origin filter cache-bust --------------------------------
    Scenario(
        id="03_pa_source_cso",
        name="Filter PA Source = CSO only",
        category="query",
        setup=[_pick_multiselect("PA Source", "CSO")],
        trigger=_click_button("Evaluate"),
        wait_for=WAIT_KPI_STABLE,
    ),
    Scenario(
        id="04_pa_source_gso",
        name="Filter PA Source = GSO only (reset then set)",
        category="query",
        setup=[_clear_multiselect("PA Source"), _pick_multiselect("PA Source", "GSO")],
        trigger=_click_button("Evaluate"),
        wait_for=WAIT_KPI_STABLE,
    ),
    Scenario(
        id="05_pa_source_reset",
        name="Reset PA Source to All (empty multiselect)",
        category="query",
        setup=[_clear_multiselect("PA Source")],
        trigger=_click_button("Evaluate"),
        wait_for=WAIT_KPI_STABLE,
    ),

    # --- Date range changes -----------------------------------------------
    Scenario(
        id="06_narrow_dates_q1",
        name="Narrow dates: 2025-01-01 → 2025-03-31",
        category="query",
        setup=[_set_date("start", "2025-01-01"), _set_date("end", "2025-03-31")],
        trigger=_click_button("Evaluate"),
        wait_for=WAIT_KPI_STABLE,
    ),
    Scenario(
        id="07_full_history_dates",
        name="Wide dates: 2023-06-01 → today",
        category="query",
        setup=[_set_date("start", "2023-06-01"), _set_date("end", "2026-07-15")],
        trigger=_click_button("Evaluate"),
        wait_for=WAIT_KPI_STABLE,
    ),

    # --- Aetna flag -------------------------------------------------------
    Scenario(
        id="08_aetna_only",
        name="Aetna Flag = Aetna Only",
        category="query",
        setup=[_select("Aetna Flag", "Aetna Only")],
        trigger=_click_button("Evaluate"),
        wait_for=WAIT_KPI_STABLE,
    ),
    Scenario(
        id="09_non_aetna_only",
        name="Aetna Flag = Non-Aetna Only",
        category="query",
        setup=[_select("Aetna Flag", "Non-Aetna Only")],
        trigger=_click_button("Evaluate"),
        wait_for=WAIT_KPI_STABLE,
    ),
    Scenario(
        id="10_aetna_reset",
        name="Aetna Flag = All (reset)",
        category="query",
        setup=[_select("Aetna Flag", "All")],
        trigger=_click_button("Evaluate"),
        wait_for=WAIT_KPI_STABLE,
    ),

    # --- Resolution / decision filters ------------------------------------
    Scenario(
        id="11_appeals_only",
        name="Cases = Appeals Only",
        category="query",
        setup=[
            _open_expander("Resolution & Decision"),
            _select("Cases to Include", "Appeals Only"),
        ],
        trigger=_click_button("Evaluate"),
        wait_for=WAIT_KPI_STABLE,
    ),
    Scenario(
        id="12_original_only",
        name="Cases = Original PAs Only",
        category="query",
        setup=[_select("Cases to Include", "Original PAs Only")],
        trigger=_click_button("Evaluate"),
        wait_for=WAIT_KPI_STABLE,
    ),
    Scenario(
        id="13_auto_approval_y",
        name="Auto Approval = Y only",
        category="query",
        setup=[_select("Auto Approval", "Y only (Auto-Approved)")],
        trigger=_click_button("Evaluate"),
        wait_for=WAIT_KPI_STABLE,
    ),
    Scenario(
        id="14_auto_approval_n",
        name="Auto Approval = N only (Human-Reviewed)",
        category="query",
        setup=[_select("Auto Approval", "N only (Human-Reviewed)")],
        trigger=_click_button("Evaluate"),
        wait_for=WAIT_KPI_STABLE,
    ),
    Scenario(
        id="15_auto_approval_reset",
        name="Auto Approval = All (reset)",
        category="query",
        setup=[_select("Auto Approval", "All")],
        trigger=_click_button("Evaluate"),
        wait_for=WAIT_KPI_STABLE,
    ),

    # --- Drug / formulary -------------------------------------------------
    Scenario(
        id="16_drug_specialty",
        name="Drug Type = SPECIALTY",
        category="query",
        setup=[
            _open_expander("Drug"),
            _pick_multiselect("Drug Type", "SPECIALTY"),
        ],
        trigger=_click_button("Evaluate"),
        wait_for=WAIT_KPI_STABLE,
    ),
    Scenario(
        id="17_formulary_pa_yes",
        name="Formulary PA Flag = Yes",
        category="query",
        setup=[
            _open_expander("Formulary & Fill Type"),
            _select("Formulary PA Flag", "Yes"),
        ],
        trigger=_click_button("Evaluate"),
        wait_for=WAIT_KPI_STABLE,
    ),

    # --- Combined restrictive filter --------------------------------------
    Scenario(
        id="18_combined_restrictive",
        name="Combined: CSO + Q1 2025 + Auto=Y + Formulary=Yes",
        category="query",
        setup=[
            _select("Formulary PA Flag", "All"),
            _pick_multiselect("PA Source", "CSO"),
            _set_date("start", "2025-01-01"),
            _set_date("end", "2025-03-31"),
            _select("Auto Approval", "Y only (Auto-Approved)"),
            _select("Formulary PA Flag", "Yes"),
        ],
        trigger=_click_button("Evaluate"),
        wait_for=WAIT_KPI_STABLE,
    ),

    # --- Tab switches (no re-query) ---------------------------------------
    Scenario(
        id="19_tab_pait_to_raw",
        name="Sub-tab: Funnel View → Raw Data",
        category="tab",
        setup=[],
        trigger=_click_tab("Raw Data"),
        wait_for=WAIT_TAB_LOADED,
    ),
    Scenario(
        id="20_tab_raw_to_funnel",
        name="Sub-tab: Raw Data → Funnel View",
        category="tab",
        setup=[],
        trigger=_click_tab("Funnel View"),
        wait_for=WAIT_TAB_LOADED,
    ),
    Scenario(
        id="21_tab_pait_to_sizing",
        name="Tab: PAIT OG View → Sizing View",
        category="tab",
        setup=[],
        trigger=_click_tab("Sizing View"),
        wait_for=WAIT_TAB_LOADED,
    ),
    Scenario(
        id="22_tab_sizing_to_trends",
        name="Tab: Sizing View → Trends",
        category="tab",
        setup=[],
        trigger=_click_tab("Trends"),
        wait_for=WAIT_TAB_LOADED,
    ),
    Scenario(
        id="23_tab_trends_to_pait",
        name="Tab: Trends → PAIT OG View",
        category="tab",
        setup=[],
        trigger=_click_tab("PAIT OG View"),
        wait_for=WAIT_TAB_LOADED,
    ),

    # --- Sizing source toggle (in-memory filter) --------------------------
    Scenario(
        id="24_sizing_source_gso",
        name="Sizing View source selectbox: CSO → GSO",
        category="rerun",
        setup=[_click_tab("Sizing View")],
        trigger=_select("Select Source", "GSO"),
        wait_for=WAIT_TAB_LOADED,
    ),
    Scenario(
        id="25_sizing_source_cso",
        name="Sizing View source selectbox: GSO → CSO",
        category="rerun",
        setup=[],
        trigger=_select("Select Source", "CSO"),
        wait_for=WAIT_TAB_LOADED,
    ),

    # --- Raw Data aggregations (queries pait_og_raw.sql) ------------------
    Scenario(
        id="26_raw_data_1dim",
        name="Raw Data: group by [PA Source]",
        category="raw_data",
        setup=[
            _click_tab("PAIT OG View"),
            _click_tab("Raw Data"),
            _clear_multiselect("Group by (select one or more)"),
            _pick_multiselect("Group by (select one or more)", "PA Source"),
        ],
        trigger=_click_button("Load Raw Data"),
        wait_for=WAIT_RAW_TABLE,
    ),
    Scenario(
        id="27_raw_data_3dim",
        name="Raw Data: group by [Month-Year, PA Source, Drug Type]",
        category="raw_data",
        setup=[
            _clear_multiselect("Group by (select one or more)"),
            _pick_multiselect("Group by (select one or more)", "Month-Year"),
            _pick_multiselect("Group by (select one or more)", "PA Source"),
            _pick_multiselect("Group by (select one or more)", "Drug Type"),
        ],
        trigger=_click_button("Load Raw Data"),
        wait_for=WAIT_RAW_TABLE,
    ),
    Scenario(
        id="28_raw_data_5dim",
        name="Raw Data: group by 5 dims (Month-Year, Source, LOB, Origin, Drug Type)",
        category="raw_data",
        setup=[
            _clear_multiselect("Group by (select one or more)"),
            _pick_multiselect("Group by (select one or more)", "Month-Year"),
            _pick_multiselect("Group by (select one or more)", "PA Source"),
            _pick_multiselect("Group by (select one or more)", "Line of Business"),
            _pick_multiselect("Group by (select one or more)", "PA Origin"),
            _pick_multiselect("Group by (select one or more)", "Drug Type"),
        ],
        trigger=_click_button("Load Raw Data"),
        wait_for=WAIT_RAW_TABLE,
    ),

    # --- Column picker (Raw Data) — pure rerun, no query --------------------
    # These live inside the "Choose columns" expander on the Raw Data sub-tab,
    # which is collapsed by default. Setup opens both the tab and the expander
    # so the harness can reach the button reliably.
    Scenario(
        id="29_raw_col_picker_clear_all",
        name="Raw Data column picker: Clear all",
        category="rerun",
        setup=[
            _click_tab("PAIT OG View"),
            _click_tab("Raw Data"),
            _open_expander("Choose columns"),
        ],
        trigger=_click_button("Clear all"),
        wait_for=WAIT_TAB_LOADED,
    ),
    Scenario(
        id="30_raw_col_picker_select_all",
        name="Raw Data column picker: Select all",
        category="rerun",
        setup=[
            # Expander state persists after the previous scenario's rerun, but
            # re-open defensively in case Streamlit collapsed it during the
            # rerun caused by "Clear all".
            _open_expander("Choose columns"),
        ],
        trigger=_click_button("Select all"),
        wait_for=WAIT_TAB_LOADED,
    ),

    # --- Trends "Raw monthly data" expander — measures render of hidden df --
    Scenario(
        id="31_trends_raw_monthly_expand",
        name="Trends: open 'Raw monthly data' expander",
        category="rerun",
        setup=[_click_tab("Trends")],
        trigger=_open_expander("Raw monthly data"),
        wait_for=WAIT_TAB_LOADED,
    ),
]
