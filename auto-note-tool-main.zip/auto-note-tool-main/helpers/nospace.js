module.exports = function (str) {
  // return (newStr = str.replace(/\s/g, ''));
  return str.replace(/[^a-zA-Z0-9]/g, '');
};
