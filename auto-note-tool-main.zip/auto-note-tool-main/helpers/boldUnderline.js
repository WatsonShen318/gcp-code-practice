module.exports = function (str) {
  const words = [
    'Clinical Review',
    'Forward to RFI',
    'perform initial outreach to gather info from MDO',
    'Approve',
    'Return to Question',
    'continue to Additional Questions',
    'select BvD guideline below',
  ];
  return str.replace(
    new RegExp(`(\\b)(${words.join('|')})(\\b)`, 'gi'),
    '$1<span class="fw-bold"><u>$2</u></span>$3'
  );
};
