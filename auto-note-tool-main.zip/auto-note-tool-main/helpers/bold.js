module.exports = function (str) {
  const words = [
    'Type',
    'Notes History',
    'Example',
    'Examples may include',
    'Note',
    'DO',
    'IF ',
    'AND',
    'Not found',
    'Tech Note',
    'is displayed in black text',
    //AMN 12/8/22 - December 2022 Enhancement - #113: Intake Update for BCBS of MASS
    'and is a BCBS of MASS member',
    'is highlighted in blue',
    'red text',
    'unable',
    'MA only plan',
    'NOT',
    'ALWAYS',
    'LISTEN',
    'Restricted Client',
    'After hours',
    'Appeals Process',
    'CIF',
    'Notes',
    'Refer',
    'OR',
    '360Member',
    'During Q4',
    'Dual Special Needs Plan [(]dSNP[)] for Devoted Health Plan', //AMN 9/12/22 - #106: ADD New Note in tool for users when dSNP record
  ];
  const newStr = str.replace(
    new RegExp(`(\\b)(${words.join('|\(\)')})(\\b)`, 'g'),
    '$1<span class="fw-bold">$2</span>$3'
  );
  return newStr;
};
