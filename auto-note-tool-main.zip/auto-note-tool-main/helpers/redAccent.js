module.exports = function (str) {
  const words = ['ONLY'];
  const newStr = str.replace(
    new RegExp(`(\\b)(${words.join('|')})(\\b)`, 'gi'),
    '$1<span class="text-primary">$2</span>$3'
  );
  return newStr;
};
