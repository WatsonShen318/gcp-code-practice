# Auto Note Tool

## Description
Automatic Note Generation for Medhok case requests to boost adjudication response time

## Business Need
Prior Authorization tasks are handled by Adjudicator/Reviewer and they have to manually fill up all the details related to case in a web form. There is potential for ~75% automation for these fields, by fetching these details from MHK API (3P), hereby reducing overall time spent on adjudication.

## Who Uses the Tool
CD&A Operations team members uses the tool to generate notes, and paste them to MHK UI.

## Solutioning
This solution provides an enhanced UI that will allow users to authenticate themselves. They would then be redirected to the tool. User will be prompted to submit a "CASE ID". This "CASE ID" will be used in the backend to fetch all case details from Medhok. User will then have to manually type in the remaining fields that could not be automated. They will then click on "Generate Note" button to generate the note summary and paste it to Medhok UI. 

## Backend Repo
https://github.aetna.com/paops/auto-note-backend

### Scope
Phase 1 (Nov-2024): Tech >case queue, Pharmacist > Case Queue & MD Template to be automated. Rest functionality needs to remain same.

## Flow Chart
![image](./images/auto-note-flow.jpg)

## Data Sources
1. Medhok will serve as the source of case details given the CASE ID by user. 
2. Reviewer Details - Data about reviewers, supervisor details, etc from BigQuery. This will be used for logging/audit purpose.

## URLs
1. Dev - https://auto-note-tool.pdev.cvshealth.com/
2. Test - https://auto-note-tool.pqa.cvshealth.com/
3. Prod - https://auto-note-tool.prod.cvshealth.com/

Usage - Enter CASE ID. Select Tech > case Queue. Fill entries for manual fields. Click "Generate Note"

Response - Note summary

  
## Design
![image](./images/auto-note-architecture.jpg)




