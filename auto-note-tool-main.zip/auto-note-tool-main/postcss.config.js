const prodMode =
  process.env.NODE_ENV === 'production' || process.env.NODE_ENV === 'pqa';
const autoprefixer = require('autoprefixer');
const { purgeCSSPlugin } = require('@fullhuman/postcss-purgecss');
const purgecss = purgeCSSPlugin({
  content: ['**/*.js', '**/*.hbs'],
});

module.exports = {
  plugins: [autoprefixer, prodMode ? [purgecss] : false],
};
