/* eslint-disable prefer-destructuring */
import axios from 'axios';
import { getEnvironmentVariables } from '../../../environment/config';

function extractAndStoreAuthToken() {
    const hash = window.location.hash;
    if (!hash.includes('_authToken=')) return;
    const params = new URLSearchParams(hash.slice(1));
    const token = params.get('_authToken');
    if (token) {
        sessionStorage.setItem('_authToken', token);
        history.replaceState(null, '', window.location.pathname + window.location.search);
    }
}

/*
    Handler to verify authentication.
    If logged in, stays on the same page.
    If logged out, takes to the sigin page.
*/
async function checkAuthentication(tryNumber) {
    if (tryNumber === 1) extractAndStoreAuthToken();

    const {
        AUTO_NOTE_BACKEND,
        BETA_AUTO_NOTE_TOOL,
        PROD_AUTO_NOTE_TOOL,
    } = getEnvironmentVariables();

    const storedToken = sessionStorage.getItem('_authToken');

    try {
        const authenticationResponse = await axios.get(`${AUTO_NOTE_BACKEND}/auth/check`, {
            withCredentials: true,
            headers: storedToken ? { Authorization: `Bearer ${storedToken}` } : {},
        });
        if(!authenticationResponse?.data?.isAuthenticated) {
            window.location.href = `${AUTO_NOTE_BACKEND}/auth/signin`;
        } else {
            const userInfo = authenticationResponse?.data?.userInfo || {};
            sessionStorage.setItem('userInfo', JSON.stringify(userInfo));
            sessionStorage.setItem('workFlow', 'Manual');

            if (BETA_AUTO_NOTE_TOOL && userInfo?.isBetaUser) {
                window.location.href = BETA_AUTO_NOTE_TOOL;
            } else if (PROD_AUTO_NOTE_TOOL && !userInfo?.isBetaUser) {
                alert(`You are on the Beta site, which is intended for beta testing only.\n\nPlease bookmark ${PROD_AUTO_NOTE_TOOL} for continuing to use the Auto Note Tool.\n\nYou will now be redirected to the prod Auto Note Tool shortly.`);
                window.location.href = PROD_AUTO_NOTE_TOOL;
            }
        }
    } catch (error) {
        if(tryNumber <= 3){
            console.error(`Authentication failed on ${tryNumber} try`, error);
            checkAuthentication(tryNumber + 1)
        } else {
        console.error('Error Checking Authentication', error);
        window.location.href = `${AUTO_NOTE_BACKEND}/auth/signin`;
        };
    }
};

/**
 * Handler for perform Signout
 */
function handleSignout() {
    const {
        AUTO_NOTE_BACKEND
    } = getEnvironmentVariables();
    sessionStorage.removeItem('_authToken');
    const signoutURL = `${AUTO_NOTE_BACKEND}/auth/signout`;
    window.location.href = signoutURL;
}

document.getElementById('AutoNoteToolSignoutLink')?.addEventListener('click', handleSignout);

export default checkAuthentication;