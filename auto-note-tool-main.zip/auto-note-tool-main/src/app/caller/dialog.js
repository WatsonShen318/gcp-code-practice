import { GeneralModal } from '../modal/alert.service';
import { bold } from '../utils/font.formatter';

export function msgSetMember() {
  GeneralModal({
    message: bold(
      'Update to Requested by Member on the case screen. Continue to process as member request.'
    ),
    icon: 'notification_important',
  });
}
