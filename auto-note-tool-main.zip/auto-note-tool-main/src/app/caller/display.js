import { toggleDisplay } from '../utils/notetool.display';
import { msgSetMember } from './dialog';
import { setRqstByRdo, setRqstByCallerRdo } from '../utils/automation';
import { requestBy } from '../qsets/fields';
import { getValue } from '../utils/getInputValue';

/**
 * * Toggle Did the member ask you to speak with someone else on their behalf? question when Requested By question option is selected
 * @param {origin} origin
 * @param {role} role
 * @param {answer} answer
 */
export function toggleRqstByCallerAOR(origin, role, answer) {
  const isRMtask = getValue('radio', `${role}${origin}rmTaskQrdo`) === 'Yes';
  if (role === 'tech') {
    if (answer === 'Member' && !isRMtask) {
      toggleDisplay('solo', [`${role}${origin}subrqstByCallerQ`], 'enable');
      toggleDisplay(
        'solo',
        [`${role}${origin}subAorOnFileQ`, `${role}${origin}subAorOnFileDocQ`],
        'disable'
      );
    } else {
      toggleDisplay('solo', [`${role}${origin}subrqstByCallerQ`], 'disable');
    }
  }
  if (answer === 'AOR') {
    toggleDisplay('solo', [`${role}${origin}subrqstByAORmemberQ`], 'enable');
  } else {
    toggleDisplay('solo', [`${role}${origin}subrqstByAORmemberQ`], 'disable');
  }
}

export function toggleRqstByCallerInfo(o, r, a) {
  if (a === 'Yes') {
    toggleDisplay('solo', [`${r}${o}subMemberWaorQ`], 'enable');
    toggleDisplay('solo', [`${r}${o}subrqstInfoQ`], 'disable');
  } else {
    // toggleDisplay('solo', [`${r}${o}subrqstInfoQ`], 'enable');
    toggleDisplay('solo', [`${r}${o}subMemberWaorQ`], 'disable');
  }
}

/**
 * * Toggle Requester's Name and Callback Number when Is request a RM Task = Yes is selected
 * @param {origin} origin
 * @param {role} role
 * @param {answer} answer
 */

export function toggleRqsterInfo(origin, role, answer) {
  const status = answer === 'Yes' ? 'disable' : 'enable';
  // toggleDisplay('solo', [`${role}${origin}subrqstInfoQ`], status);
}

export function showRqstByCaller(o, r, a) {
  const rqstBtn = requestBy(r, o, 'value');
  if (a === 'Yes' && rqstBtn === 'AOR') {
    msgSetMember();
    setRqstByRdo(o, r, 'Member');
    if (r === 'tech') setRqstByCallerRdo(o, r, 'Yes');
  }
}

/**
 * $ This function is used by Rph only
 * @param {origin} o
 * @param {role} r
 * @param {answer} a
 */
export function toggleRqsterNameCallBack(o, r, a) {
  if (a !== 'AOR') {
    // toggleDisplay('solo', [`${r}${o}subrqstInfoQ`], 'enable');
    toggleDisplay(
      'solo',
      [
        `${r}${o}subMemberWaorQ`,
        `${r}${o}subAorOnFileQ`,
        `${r}${o}subAorOnFileDocQ`,
      ],
      'disable'
    );
  }
}


/* Tech IBC specific handler */
export function toggleCallerProvidedClinicalInfo(role, origin, answer) {
  if (answer === "Prescriber") {
    toggleDisplay(
      "solo",
      [`${role}${origin}callerProvidedClinicalInfoQ`],
      "enable"
    );
  } else {
    toggleDisplay(
      "solo",
      [`${role}${origin}callerProvidedClinicalInfoQ`],
      "disable"
    );
  }
}
