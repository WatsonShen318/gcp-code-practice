import { GeneralModal } from '../modal/alert.service';
import { bold } from '../utils/font.formatter';

export function msgRFIFaxTemplate(o, r, a) {
  if (a === 'No') {
    GeneralModal({
      message: bold(
        'Update RFI template and resend fax.'
      ),
      icon: 'notification_important',
    });
  }
}

export function msgThreeOutreachAttempts(o, r, a) {
  if (a === 'No') {
    GeneralModal({
      message: bold(
        'Verify correct fax number and resend fax.'
      ),
      icon: 'notification_important',
    });
  }
}

export function msgFailedFax(o, r, a) {
  if (a === 'Yes') {
    GeneralModal({
      message: bold(
        'Check for valid fax number and resend fax.'
      ),
      icon: 'notification_important',
    });
  }
}
