import { isRequestReasonAutomated } from '../prefill/helpers';
import { toggleDisplay } from '../utils/notetool.display';
import togglePartialValidation from '../utils/validation';

const inqrys = (id, r, o) =>
  document.querySelectorAll(
    `div.tab-content>fieldset[id="${r}${o}"].active fieldset[data-tag='inquiry']:not(#${id}), #${r}${o}buttoniqnrySubmit`
  );
const allInqrys = (id, r, o) =>
  document.querySelectorAll(
    `div.tab-content>fieldset[id="${r}${o}"].active fieldset[data-tag='inquiry']:not(#${id}), div.tab-content>fieldset[id="${r}${o}"].active fieldset[data-tag='inquiry noShow']:not(#${id}), #${r}${o}buttoniqnrySubmit`
  );

/**
 * * Toggle Inquiry when Is request a RM Task = Yes is selected
 * @param {origin} origin
 * @param {role} role
 * @param {answer} answer
 */
export function toggleInquiry(origin, role, answer) {
  if (answer === 'No') {
    toggleDisplay('solo', [`${role}${origin}inquiryQ`], 'enable');
    toggleDisplay(
      'tag',
      allInqrys(`${role}${origin}inquiryQ`, role, origin),
      'disable'
    );
  } else {
    toggleDisplay('solo', [`${role}${origin}inquiryQ`], 'disable');
  }
}

export function toggleInqryDetail(o, r, a) {
  const id = `${r}${o}inquiryQ`;
  if (a === 'Yes') {
    toggleDisplay('tag', inqrys(id, r, o), 'enable');
    toggleDisplay('solo', ['generateNotebtn'], 'disable');
    toggleDisplay('rest', `#${r}${o}iqnrySubmitPA`, 'disable');
    const inqCallerElem = document.getElementById(`${r}${o}inqcallerQ`);
    if (
      inqCallerElem &&
      !inqCallerElem.hasAttribute('disabled') &&
      inqCallerElem.style.display !== 'none'
    ) {
      toggleDisplay('solo', [`${r}${o}subinqcallerQ`], 'disable');
    }
  } else {
    toggleDisplay('tag', allInqrys(id, r, o), 'disable');
    toggleDisplay('solo', ['generateNotebtn'], 'enable');
    toggleDisplay('rest', `#${r}${o}iqnrySubmitPA`, 'enable');
    
    // Skip enabling Request Reason Dropdown if Request Reason is already prefilled in Automated Flow
    if(isRequestReasonAutomated(r, o)) {
      toggleDisplay('button', [`${r}${o}rqstReasonQ`], 'disable');
    }
    togglePartialValidation(o, r, 'back');
    // Handling disabled behavior with claim Qs
    toggleDisplay('solo', [`${r}${o}claimQ`, `${r}${o}subclaimTodayDQ`, `${r}${o}claim90dQ`, `${r}${o}subclaim90dQ`], 'enable');
  }
}

export function toggleCMM(o, r, a) {
  if (a === 'Yes') {
    toggleDisplay('solo', [`${r}${o}subinqCMMdetailQ`], 'enable');
    toggleDisplay(
      'solo',
      [`${r}${o}subinqrejCodeQ`, `${r}${o}subinqreTRQ`],
      'disable'
    );
  } else {
    toggleDisplay('solo', [`${r}${o}subinqCMMdetailQ`], 'disable');
    toggleDisplay(
      'solo',
      [`${r}${o}subinqrejCodeQ`, `${r}${o}subinqreTRQ`],
      'enable'
    );
  }
}
