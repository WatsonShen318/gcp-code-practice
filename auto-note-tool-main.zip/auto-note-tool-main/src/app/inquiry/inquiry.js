import { setinqRejectCodeNA, setinqRqstReasonNA } from '../utils/automation';
import { toggleCMM } from './inquiry.display';
import {
  subInquiryCMM,
  subInquiryRjctNAbtn,
  subInquiryTRNAbtn,
} from '../qsets/fields';

export default function inq(origin, role) {
  let answer = null;

  //* Inquiry CMM question

  subInquiryCMM(role, origin, 'event').forEach((elem) => {
    elem.addEventListener('click', (e) => {
      answer = e.target.value;
      toggleCMM(origin, role, answer);
    });
  });

  //* N/A button Click for Reject Code
  subInquiryRjctNAbtn(role, origin, 'event').addEventListener('click', () => {
    setinqRejectCodeNA(origin, role);
  });

  //* N/A button Click for Request Reason
  subInquiryTRNAbtn(role, origin, 'event').addEventListener('click', () => {
    setinqRqstReasonNA(origin, role);
  });
}
