import { clearInputs } from '../utils/clearInput';

/**
 * * Clear all RM Task sub question input fields to be blank
 * @param {string} origin
 * @param {string} role
 */
export default function clearInquiryQuestion(origin, role) {
  const radioFields = document.getElementsByName(`${role}${origin}inquiryQrdo`);
  clearInputs(radioFields, 'radio');
}
