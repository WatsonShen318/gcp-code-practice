import { toggleDisplay } from '../utils/notetool.display';
import getFormularyOptions from '../form_alts/api/getFormularyOptions';

// Shared session storage key - owned here so both form_alts and quantity_limit read the same value.
export const SS_FORMULARY = 'formAltsFormularyId';
// Tracks how the formularyId was obtained: 'auto' | 'dropdown' | 'manual' | 'na'
export const SS_FORMULARY_SOURCE = 'formularyIdSource';
// Key written by _doInit when medhok CAG auto-resolves a formularyId; cleared on deliberate client change
export const SS_AUTO_RESOLVE = 'formAltsResolveResult';

/**
 * Ensures a confirmed formularyId exists for the given role+origin.
 *
 * If SS_FORMULARY is already set (e.g. formAlts already resolved it), calls onResolved
 * immediately with no UI shown - so the caller never asks the user to pick twice.
 *
 * Otherwise, reads the client from Q32 (${role}${origin}clientQsel) and shows:
 *   subclient picker → formulary dropdown → manual text+button
 *
 * When the client is EGWP / Other and Q33 (subegwpQ) is already visible,
 * the subclient step is folded into Q33 - Q33's text input is replaced with a dropdown
 * populated from the API subClients list. This avoids asking the same question twice.
 *
 * Element IDs use `uiPrefix` ('formulary') so all callers share the same set of
 * formulary resolution questions (Q254 formularySubclientQ, Q255 formularyDropdownQ,
 * Q249 formularyIdQ).
 *
 * Callbacks:
 *   onResolved(formularyId)  - called once a formularyId is confirmed
 *   onNotAvailable()         - called when the user clicks N/A (optional)
 *   onReset()                - called when a mid-flow change (subclient switch) invalidates
 *                              prior downstream state (optional)
 */
export async function resolveFormularyUI(role, origin, uiPrefix, { onResolved, onNotAvailable, onReset } = {}) {
  // Wrap onResolved so every resolution path also mirrors the value into
  // subFormularyIDQtxt - Aetna MAPD note generation reads that field.
  const _resolvedCb = (fId) => {
    const el = document.getElementById(`${role}${origin}subFormularyIDQtxt`);
    if (el) el.value = fId || '';
    onResolved(fId);
  };

  // When the formularyId is already known (CAG auto-resolved or previously selected),
  // fire _resolvedCb immediately so downstream can proceed, then asynchronously fetch
  // formulary options and render the dropdown so the user can see and override the value.
  // The stale-client guard discards the result if the client dropdown changed while the
  // API call was in flight.
  const _resolveAndShowDropdown = async (formularyId) => {
    _resolvedCb(formularyId);
    // CAG auto-resolved: formularyId is already determined — no dropdown needed.
    // Only re-show Q255 when the user had previously picked from it or entered it manually,
    // so their selection stays visible after a request-reason change.
    if (sessionStorage.getItem(SS_FORMULARY_SOURCE) === 'auto') return;
    const clientEl = document.getElementById(`${role}${origin}clientQsel`);
    const client = clientEl?.selectedOptions?.[0]?.text?.trim() || '';
    if (!client) return;
    try {
      const { formularies = [] } = await getFormularyOptions(client);
      const currentClient = document.getElementById(`${role}${origin}clientQsel`)?.selectedOptions?.[0]?.text?.trim() || '';
      if (currentClient !== client) return;
      if (formularies.length === 0) return;
      _renderFormularyDropdown(role, origin, uiPrefix, formularies, { onResolved: _resolvedCb, onNotAvailable });
      const sel = document.getElementById(`${role}${origin}${uiPrefix}DropdownQsel`);
      if (sel) sel.value = formularyId;
    } catch (_) {}
  };

  const existing = sessionStorage.getItem(SS_FORMULARY);
  if (existing) {
    _resolveAndShowDropdown(existing);
    return;
  }

  // If medhok CAG auto-resolved a formularyId, use it directly and show dropdown
  const autoResolved = JSON.parse(sessionStorage.getItem(SS_AUTO_RESOLVE) || 'null');
  if (autoResolved?.found && autoResolved?.formularyId) {
    sessionStorage.setItem(SS_FORMULARY, autoResolved.formularyId);
    sessionStorage.setItem(SS_FORMULARY_SOURCE, 'auto');
    _resolveAndShowDropdown(autoResolved.formularyId);
    return;
  }

  const clientEl = document.getElementById(`${role}${origin}clientQsel`);
  const client = clientEl?.selectedOptions?.[0]?.text?.trim() || '';
  const clientValue = clientEl?.value?.trim() || '';
  if (!client) return;

  try {
    const { formularies = [], subClients = [] } = await getFormularyOptions(client);
    // Stale-client guard: if the client dropdown changed while the API call was in-flight,
    // discard the result so we never render formularies for the wrong client.
    const clientNow = document.getElementById(`${role}${origin}clientQsel`)?.selectedOptions?.[0]?.text?.trim() || '';
    if (clientNow !== client) return;
    if (formularies.length > 0) {
      if (subClients.length > 0) {
        // Fold subclient into Q33 only for EGWP - these clients
        // treat Q33 as the subclient name. "Other" keeps Q33 as free text.
        const subegwpFieldset = document.getElementById(`${role}${origin}subegwpQ`);
        const subegwpVisible = subegwpFieldset && getComputedStyle(subegwpFieldset).display !== 'none';
        const useSubegwpDropdown = subegwpVisible && (clientValue === 'EGWP');

        if (useSubegwpDropdown) {
          // If subegwp dropdown already has a selection, go straight to the formulary dropdown
          // so the user's prior pick is not cleared by re-rendering the subclient step.
          const existingSubclient = document.getElementById(`${role}${origin}subegwpQdropdown`)?.value;
          if (existingSubclient) {
            const filtered = formularies.filter(f => f.subClientName === existingSubclient);
            _renderFormularyDropdown(role, origin, uiPrefix, filtered.length > 0 ? filtered : formularies, { onResolved: _resolvedCb, onNotAvailable });
          } else {
            _renderSubegwpAsDropdown(role, origin, uiPrefix, subClients, formularies, { onResolved: _resolvedCb, onNotAvailable, onReset });
          }
        } else {
          // If subclient picker already has a selection, go straight to the formulary dropdown
          // so the user's prior pick is not cleared by re-rendering the subclient step.
          const existingSubclient = document.getElementById(`${role}${origin}${uiPrefix}SubclientQsel`)?.value;
          if (existingSubclient) {
            const filtered = formularies.filter(f => f.subClientName === existingSubclient);
            _renderFormularyDropdown(role, origin, uiPrefix, filtered.length > 0 ? filtered : formularies, { onResolved: _resolvedCb, onNotAvailable });
          } else {
            _renderSubclientPicker(role, origin, uiPrefix, subClients, formularies, { onResolved: _resolvedCb, onNotAvailable, onReset });
          }
        }
      } else {
        _renderFormularyDropdown(role, origin, uiPrefix, formularies, { onResolved: _resolvedCb, onNotAvailable });
      }
      return;
    }
  } catch (err) {
    console.warn('[resolveFormularyUI] getFormularyOptions failed, falling back to manual entry:', err);
  }

  toggleDisplay('solo', [`${role}${origin}${uiPrefix}IdQ`], 'enable');
  _wireManualBtn(role, origin, uiPrefix, { onResolved: _resolvedCb, onNotAvailable });
}

/**
 * Converts Q33 (subegwpQ) text input into a subclient dropdown for NF/QL flows.
 * The selected value is mirrored back into the text input so note-generation (which
 * reads subegwpQtxt) continues to work without modification.
 * Call resetSubegwpDropdown() to restore the text input when the flow ends.
 */
function _renderSubegwpAsDropdown(role, origin, uiPrefix, subClients, formularies, { onResolved, onNotAvailable, onReset }) {
  const txtInput = document.getElementById(`${role}${origin}subegwpQtxt`);
  if (!txtInput) {
    // Fallback: subegwpQtxt not found - use the standard subclient picker
    _renderSubclientPicker(role, origin, uiPrefix, subClients, formularies, { onResolved, onNotAvailable, onReset });
    return;
  }

  // Avoid double-injection
  const selId = `${role}${origin}subegwpQdropdown`;
  let sel = document.getElementById(selId);
  if (!sel) {
    sel = document.createElement('select');
    sel.id = selId;
    sel.className = 'form-select form-select-sm mt-1';
    sel.setAttribute('data-subegwp-sel', 'true');
    txtInput.insertAdjacentElement('beforebegin', sel);
    txtInput.style.display = 'none';
  }

  sel.innerHTML = '<option value="">Select sub-client…</option>';
  subClients.forEach(sc => {
    const opt = document.createElement('option');
    opt.value = sc;
    opt.textContent = sc;
    sel.appendChild(opt);
  });
  txtInput.value = '';

  sel.onchange = () => {
    const sc = sel.value;
    if (!sc) return;

    // Mirror value into text input so note generation reads the chosen sub-client
    txtInput.value = sc;

    sessionStorage.removeItem(SS_FORMULARY);
    toggleDisplay('solo', [`${role}${origin}${uiPrefix}DropdownQ`], 'disable');
    toggleDisplay('solo', [`${role}${origin}${uiPrefix}IdQ`], 'disable');
    if (onReset) onReset();

    const filtered = formularies.filter(f => f.subClientName === sc);
    _renderFormularyDropdown(role, origin, uiPrefix, filtered.length > 0 ? filtered : formularies, { onResolved, onNotAvailable });
  };
}

/**
 * Restores Q33 (subegwpQ) from dropdown back to free-text.
 * Call from resetFormAlts / resetQl when the NF/QL flow is cleared.
 */
export function resetSubegwpDropdown(role, origin) {
  const selId = `${role}${origin}subegwpQdropdown`;
  const sel = document.getElementById(selId);
  if (!sel) return;

  const txtInput = document.getElementById(`${role}${origin}subegwpQtxt`);
  if (txtInput) {
    txtInput.style.display = '';
    txtInput.value = '';
  }
  sel.remove();
}

function _wireManualBtn(role, origin, uiPrefix, { onResolved, onNotAvailable }) {
  const txtId = `${role}${origin}${uiPrefix}IdQtxt`;
  const btnId = `${role}${origin}${uiPrefix}IdQbtn`;
  const btn = document.getElementById(btnId);
  if (!btn) return;

  btn.style.display = '';
  const txtEl = document.getElementById(txtId);
  if (txtEl) txtEl.value = '';

  // Track the last successfully submitted value so the label reflects current state:
  //   "Load"    — field is empty, nothing loaded yet
  //   "Update"  — field has a value different from what was last loaded
  //   "Updated" — field value matches the last loaded value
  let lastLoaded = sessionStorage.getItem(SS_FORMULARY) || '';

  const _refreshLabel = () => {
    const typed = document.getElementById(txtId)?.value?.trim() || '';
    if (!typed) { btn.textContent = ''; btn.className = 'btn'; return; }
    if (typed === lastLoaded) { btn.textContent = 'Updated!'; btn.className = 'btn btn-primary'; }
    else { btn.textContent = 'Update'; btn.className = 'btn btn-save-pending'; }
  };

  if (txtEl) txtEl.oninput = _refreshLabel;
  _refreshLabel();

  btn.onclick = () => {
    const val = document.getElementById(txtId)?.value?.trim();
    if (!val) return;
    sessionStorage.setItem(SS_FORMULARY, val);
    sessionStorage.setItem(SS_FORMULARY_SOURCE, 'manual');
    lastLoaded = val;
    btn.textContent = 'Updated!';
    btn.className = 'btn btn-primary';
    onResolved(val);
  };

  const naId = `${btnId}NA`;
  if (!document.getElementById(naId)) {
    const naBtn = document.createElement('button');
    naBtn.type = 'button';
    naBtn.id = naId;
    naBtn.className = 'btn btn-outline-secondary ms-2';
    naBtn.textContent = 'N/A';
    btn.insertAdjacentElement('afterend', naBtn);
    naBtn.addEventListener('click', () => {
      sessionStorage.removeItem(SS_FORMULARY);
      const naEl = document.getElementById(txtId);
      if (naEl) naEl.value = 'N/A';
      btn.style.display = 'none';
      if (onNotAvailable) onNotAvailable();
    });
  }
}

function _renderSubclientPicker(role, origin, uiPrefix, subClients, formularies, { onResolved, onNotAvailable, onReset }) {
  const sel = document.getElementById(`${role}${origin}${uiPrefix}SubclientQsel`);
  if (!sel) return;

  sel.innerHTML = '<option value="">Select sub-client…</option>';
  subClients.forEach(sc => {
    const opt = document.createElement('option');
    opt.value = sc;
    opt.textContent = sc;
    sel.appendChild(opt);
  });

  toggleDisplay('solo', [`${role}${origin}${uiPrefix}SubclientQ`], 'enable');

  sel.onchange = () => {
    const sc = sel.value;
    if (!sc) return;
    sessionStorage.removeItem(SS_FORMULARY);
    toggleDisplay('solo', [`${role}${origin}${uiPrefix}DropdownQ`], 'disable');
    toggleDisplay('solo', [`${role}${origin}${uiPrefix}IdQ`], 'disable');
    if (onReset) onReset();
    const filtered = formularies.filter(f => f.subClientName === sc);
    _renderFormularyDropdown(role, origin, uiPrefix, filtered.length > 0 ? filtered : formularies, { onResolved, onNotAvailable });
  };
}

// Installs (or replaces) the onchange handler on an already-rendered formulary select.
function _installDropdownHandler(sel, role, origin, uiPrefix, { onResolved, onNotAvailable }) {
  sel.onchange = () => {
    const val = sel.value;
    if (!val) return;

    if (val === '__na__') {
      toggleDisplay('solo', [`${role}${origin}${uiPrefix}IdQ`], 'disable');
      sessionStorage.removeItem(SS_FORMULARY);
      if (onNotAvailable) onNotAvailable();
      return;
    }

    if (val === '__other__') {
      toggleDisplay('solo', [`${role}${origin}${uiPrefix}IdQ`], 'enable');
      _wireManualBtn(role, origin, uiPrefix, { onResolved, onNotAvailable });
      return;
    }

    toggleDisplay('solo', [`${role}${origin}${uiPrefix}IdQ`], 'disable');
    sessionStorage.setItem(SS_FORMULARY, val);
    sessionStorage.setItem(SS_FORMULARY_SOURCE, 'dropdown');
    onResolved(val);
  };
}

function _renderFormularyDropdown(role, origin, uiPrefix, formularies, { onResolved, onNotAvailable }) {
  const sel = document.getElementById(`${role}${origin}${uiPrefix}DropdownQsel`);
  if (!sel) return;

  sel.innerHTML = '<option value="">Select formulary…</option>';
  formularies.filter(f => f.formularyId && f.formularyName).forEach(f => {
    const opt = document.createElement('option');
    opt.value = f.formularyId;
    opt.textContent = `${f.formularyName} (${f.formularyId})`;
    sel.appendChild(opt);
  });

  const otherOpt = document.createElement('option');
  otherOpt.value = '__other__';
  otherOpt.textContent = 'Other (enter manually)';
  sel.appendChild(otherOpt);

  // N/A directly selectable from the dropdown (Gap 3)
  const naOpt = document.createElement('option');
  naOpt.value = '__na__';
  naOpt.textContent = 'N/A - formulary not applicable';
  sel.appendChild(naOpt);

  toggleDisplay('solo', [`${role}${origin}${uiPrefix}DropdownQ`], 'enable');
  toggleDisplay('solo', [`${role}${origin}${uiPrefix}IdQ`], 'disable');

  _installDropdownHandler(sel, role, origin, uiPrefix, { onResolved, onNotAvailable });
}
