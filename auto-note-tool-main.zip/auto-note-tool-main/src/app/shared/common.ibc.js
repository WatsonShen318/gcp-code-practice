import { inquiry } from '../qsets/fields';
import { ShowSideNote } from '../buttons/buttons';
import { handleInqury } from './clickEvents';

/**
 * Common functions between Tech and RPH Inbound Call Origin
 * @param {*} origin
 * @param {*} role
 */
export default function commonIBC(origin, role) {
  //* * Generate Inquiry Note */
  ShowSideNote(origin, role, 'inquiry');

  //* Inquiry field
  inquiry(role, origin, 'event').forEach((elem) => {
    elem.addEventListener('click', (e) => {
      handleInqury(e, role, origin);
    });
  });
}
