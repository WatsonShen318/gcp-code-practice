import { setInqryCaller, setSourceMDO } from '../utils/automation';
import { toggleInqryDetail } from '../inquiry/inquiry.display';
import validateChecks from '../member/validation';
import { toggleCaseCount } from '../multiCase/display';
import { memberCaseBalance } from '../multiCase/math';

let answer = null;

export const handleInqury = (e, role, origin) => {
  answer = e.target.value;
  setInqryCaller(origin, role, answer);
  toggleInqryDetail(origin, role, answer);
  import(
    /* webpackPrefetch: true */ /* webpackChunkName: "Inquiry" */ '../inquiry/inquiry'
  ).then((module) => {
    module.default(origin, role);
  });
};

export const handleMember = (e, role, origin) => {
  answer = e.target.value;
  validateChecks(origin, role);
  setSourceMDO(origin, role);
};

export const handleMultiDrug = (e, role, origin) => {
  answer = e.target.value;
  toggleCaseCount(origin, role, answer);
};

export const handleCaseBalance = (e, role, origin) => {
  answer = e.target.value;
  memberCaseBalance(origin, role, answer);
};
