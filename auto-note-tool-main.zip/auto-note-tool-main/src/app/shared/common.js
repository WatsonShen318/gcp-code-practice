import { toggleHIVMed, toggleSmartMed } from '../drugs/drugs.display';
// import { ShowOBCNote } from '../buttons/buttons';
import { ele } from '../utils/inputSelect';
import { toggleOBdetails } from '../outbound/outbound.display';
import { setDiagDLTNA } from '../utils/automation';
import {
  clearDLTrdo,
  clearLetterPreview,
  clearMatchCase,
  clearTierCaseCreate,
  clearDrugs,  //AMN 5/16/23 - May 2023 Enhancements - #125: Add red note for drug name field
} from '../reset/reset';
import { toggleIndication } from '../priority/displays';
import msgPriority from '../priority/priority.dialog';
import msgTimeStamp from '../timestamp/dialogs';
import { togglepplSafeBadge } from '../aor/aor.display';
import { hideallCompendia } from '../compendia/display';
import { toggleTCaseCreate } from '../tiering/display';
import msgTierCaseCreate from '../tiering/dialogs';
import {
  diagnosis,
  diagnosisbtn,
  drugName,
  letterPreview,
  member,
  memberCaseCount,
  memberMultiDrug,
  memberRqstTotalCount,
  obcCompleted,
  outbound,
  priority,
  prospectiveReview,
  subTierRequest,
  tierRequest,
  timeStamp,
  client,
  decisionRouting, //AMN 5/16/23 - May 2023 Enhancements - #125: Add red note for drug name field
  outboundalt,
} from '../qsets/fields';

import msgLetterPreview from '../letterPreview/dialogs';
import {
  handleCaseBalance,
  handleMember,
  handleMultiDrug,
} from './clickEvents';
import { resetByCreateNextbtn } from '../reset/notetool.reset';
import { memberCaseIncrement } from '../multiCase/math';
import msgOBCDone from '../outbound/dialog';
import msgDecision from '../decision/decision.dialog';

let answer = null;

/**
 * All Common/Shared functions between Tech and RPH and all origins
 * @param {*} role
 * @param {*} origin
 */
export default function common(role, origin) {
  const getField = (t) => document.getElementById(`${role}${origin}${t}`);

  //* member checkboxes
  if (getField('memberidsQ')) {
    member(role, origin, 'event').forEach((elem) => {
      elem.addEventListener('click', (e) => {
        handleMember(e, role, origin);
      });
    });
  }

  //* Member Multiple Drug
  if (getField('memberMultiDrugQ')) {
    memberMultiDrug(role, origin, 'event').forEach((elem) => {
      elem.addEventListener('click', (e) => {
        handleMultiDrug(e, role, origin);
      });
    });
  }

  //* Member Multiple Drug Case Counts
  if (getField('submemberCaseCountQ')) {
    memberRqstTotalCount(role, origin, 'event').addEventListener(
      'change',
      (e) => {
        handleCaseBalance(e, role, origin);
      }
    );
    memberCaseCount(role, origin, 'event').addEventListener('change', (e) => {
      handleCaseBalance(e, role, origin);
    });
  }

  //* Create Next Case Button Click
  if (getField('moreBtn')) {
    document
      .getElementById(`${role}${origin}moreBtn`)
      .addEventListener('click', () => {
        memberCaseIncrement(origin, role);
        resetByCreateNextbtn(origin, role);
      });
  }
  //* TimeStamp
  if (getField('timestampQ')) {
    timeStamp(role, origin, 'event').forEach((elem) => {
      elem.addEventListener('click', (e) => {
        answer = e.target.value;
        msgTimeStamp(origin, role, answer);
      });
    });
  }

  //* Tiering?
  if (getField('tierRqstQ')) {
    tierRequest(role, origin, 'event').forEach((elem) => {
      elem.addEventListener('click', (e) => {
        answer = e.target.value;
        toggleTCaseCreate(origin, role, answer);
        clearMatchCase(origin, role);
        clearTierCaseCreate(origin, role);
      });
    });
  }

  //* Tier Case Created?
  if (getField('subtierRqstQ')) {
    subTierRequest(role, origin, 'event').forEach((elem) => {
      elem.addEventListener('click', (e) => {
        answer = e.target.value;
        msgTierCaseCreate(answer);
      });
    });
  }

  //* Requested By AOR Radio
  ele(`${role}${origin}rqstByQAORbadge`)?.addEventListener('click', () => {
    togglepplSafeBadge();
  });

  // //* Priority
  priority(role, origin, 'event').forEach((elem) => {
    elem.addEventListener('click', (e) => {
      answer = e.target.value;
      // toggleIndication(origin, role, answer);
      msgPriority(origin, role, answer);
    });
  });

  prospectiveReview(role, origin, 'event').forEach((elem) => {
    elem.addEventListener('click', (e) => {
      answer = e.target.value;
      if (answer === "Yes"){
        msgDecision(origin, role, decisionRouting(role, origin, 'value'));
      }
    });
  });

  //* Drug and Qty/DS field
  drugName(role, origin, 'event').addEventListener('change', (e) => {
    answer = e.target.value;
    toggleSmartMed(origin, role, answer);
    toggleHIVMed(origin, role, answer);
  });

  //AMN 5/31/23 - May 2023 Enhancements - #125: Add red note for drug name field
  if (getField('clientQsel')) {
    //* Client
    client(role, origin, 'event').addEventListener('change', (e) => {
      answer = e.target.value;
      // avoiding clearing drugNameValue with client value change
      // clearDrugs(origin, role);
    });
  }

  //* Diagnosis
  diagnosisbtn(role, origin, 'event').addEventListener('click', (e) => {
    const eventType = e.type;
    setDiagDLTNA(origin, role, eventType);
    hideallCompendia(origin, role);
  });
  diagnosis(role, origin, 'event').addEventListener('change', (e) => {
    answer = e.target.value;
    if(!(sessionStorage.getItem('dltAutomatedApprovableDiagnosisFieldAns'))) {
      clearDLTrdo(origin, role);
    }
    // Always run so approveDiagoQ fieldset is enabled/disabled based on current diagnosis value,
    // even when automation has already answered approveDiagoQ.
    setDiagDLTNA(origin, role, answer);
    hideallCompendia(origin, role);
  });

  //* outbound
  outbound(role, origin, 'event').forEach((elem) => {
    elem.addEventListener('click', (e) => {
      answer = e.target.value;
      import(
        /* webpackPrefetch: true */ /* webpackChunkName: "OBC" */ '../outbound/outbound'
      ).then((module) => {
        module.default(origin, role);
      });

      toggleOBdetails(origin, role, answer, `${role}${origin}subobPurposeQPA`);
    });
  });

  //* outbound
  outboundalt(role, origin, 'event').forEach((elem) => {
    elem.addEventListener('click', (e) => {
      answer = e.target.value;
      import(
        /* webpackPrefetch: true */ /* webpackChunkName: "OBC" */ '../outbound/outbound'
      ).then((module) => {
        module.default(origin, role, true);
      });

      toggleOBdetails(origin, role, answer, `${role}${origin}subobPurposeQaltPA`, true);
    });
  });

  // Auto Note Phase 4.0 -> Disabling Add/Remove OBC buttons as per new requirements while saving obc notes with Update PA APIs.
  // //* Generate OBC Note Button
  // ShowOBCNote(origin, role);
  // //* Generate Alt OBC Note Button for RPH - Queue & IBC - RFI TAT Case reviewed field
  // ShowOBCNote(origin, role, true);

  //* Confirmed letter template contains all necessary verbiage, is complete, and formatted appropriately
  letterPreview(role, origin, 'event').forEach((elem) => {
    elem.addEventListener('click', (e) => {
      answer = e.target.value;
      msgLetterPreview(role, origin, answer);
      if (answer === 'No' && origin !== 'SR') clearLetterPreview(origin, role);
    });
  });

  //* Confirmed member outbound call was completed and documented on the Contacts Tab
  if (getField('obcCompleted')) {
    obcCompleted(role, origin, 'event').forEach((elem) => {
      elem.addEventListener('click', (e) => {
        answer = e.target.value;
        msgOBCDone(answer);
      });
    });
  }
}
