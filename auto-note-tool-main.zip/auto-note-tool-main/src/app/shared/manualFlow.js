import toggleDrugNameWSearchQ from '../dlt_guidelines/display';

// Per role+origin event handler registry - prevents duplicate listeners
const _handlers = {};

/**
 * Returns true when no medhok GPI is available (manual flow - no case ID entered).
 */
export function isManualFlow() {
  const medhok = JSON.parse(sessionStorage.getItem('originalMedhokResponse') || 'null');
  return !medhok?.gpiCode;
}

/**
 * Registers a drug-selection listener that invokes `onSelected(gpi, drugName)`.
 * Display of Q187 is owned by manualFormTemplate (shown on Fill Manually click).
 * If a drug was already selected before this callback was registered, fires immediately.
 *
 * Safe to call multiple times - replaces any previous listener for this role+origin.
 */
export function setupManualDrugSearch(role, origin, onSelected) {
  const key = `${role}${origin}`;
  const container = document.getElementById(`${role}${origin}drugNameWSearchQ`);
  if (!container) return;

  if (_handlers[key]) {
    container.removeEventListener('drugSelected', _handlers[key]);
  }

  const handler = (e) => {
    const medhokNow = JSON.parse(sessionStorage.getItem('originalMedhokResponse') || 'null');
    if (medhokNow?.gpiCode) return;
    onSelected(e.detail.gpi, e.detail.drugName);
  };

  _handlers[key] = handler;
  container.addEventListener('drugSelected', handler);

  // If a valid drug was already selected before this callback was registered, fire immediately
  const existingGpi = sessionStorage.getItem('gpiSelectedWDrugNameSearch');
  const existingDrugName = document.getElementById(`${role}${origin}drugNameQtxt`)?.value?.trim();
  if (existingGpi && existingGpi !== 'Other' && existingDrugName) {
    const medhokNow = JSON.parse(sessionStorage.getItem('originalMedhokResponse') || 'null');
    if (!medhokNow?.gpiCode) {
      onSelected(existingGpi, existingDrugName);
    }
  }
}

/**
 * Removes the drug-selection listener.
 * Does NOT change Q187 visibility - display is managed by manualFormTemplate and hideManualDrugSearch.
 */
export function teardownManualDrugSearch(role, origin) {
  const key = `${role}${origin}`;
  const container = document.getElementById(`${role}${origin}drugNameWSearchQ`);
  if (container && _handlers[key]) {
    container.removeEventListener('drugSelected', _handlers[key]);
  }
  delete _handlers[key];
}

/**
 * Hides the searchable drug field and restores the plain text drug name field.
 * Called when medhok loads (automated flow) to hand drug-name display back to the prefill path.
 */
export function hideManualDrugSearch(role, origin) {
  toggleDrugNameWSearchQ(role, origin, 'disable');
}
