/**
 * Mapping of routing choices to MHK system status and statusReason (status and statusReason should be exact as in MHK system for updates)
 */
export const STATUS_MAPPING = {
    Approved: {
        status: "Approved",
        statusReason: "Criteria Met",
    },
    Denied: {
        status: "Denied",
        statusReason: "",
    },
    "Send to Tech Review": {
        status: "In Progress",
        statusReason: "Pending Review",
    },
    Dismissed: {
        status: "",
        statusReason: "",
    },
    "Sent to RFI": {
        status: "In Progress",
        statusReason: "Pending Additional Information",
    },
    "Tolling Case": {
        status: "",
        statusReason: "",
    },
    "Send to MD": {
        status: "",
        statusReason: "",
    },
    "Send to Secondary for review": {
        status: "In Progress",
        statusReason: "Pending Secondary Review",
    },
    "Forward to Clinical": {
        status: "In Progress",
        statusReason: "Pending Clinical Review",
    },
    "Pending TAT RPH Review": {
        status: "In Progress",
        statusReason: "Pending Clinical Review",
    },
    "Transferred to Pharmacist": {
        status: "In Progress",
        statusReason: "Pending Clinical Review",
    },
    "Returned to Intake": {
        status: "Dismiss",
        statusReason: "Sent Back to Intake",
    },
    "Pending Appointment of Representative": {
        status: "",
        statusReason: "",
    },
    "Pending Dismissal Validation": {
        status: "",
        statusReason: "",
    },
    "Send to Organization Determination": {
        status: "",
        statusReason: "",
    },
};
