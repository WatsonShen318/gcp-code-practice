/* eslint-disable no-useless-return */
/* eslint-disable consistent-return */
/* eslint-disable prefer-destructuring */
import axios from 'axios';
// eslint-disable-next-line import/no-extraneous-dependencies
import axiosRetry from 'axios-retry';
import { getEnvironmentVariables } from '../../../../environment/config';

// Configure axios to retry requests
axiosRetry(axios, {
    retries: 2,
    retryCondition: (error) => error?.response?.status >= 500,
    retryDelay: (retryCount) => {
        console.log(`Adding outbound contact - Retry attempt: ${retryCount}`);
        return retryCount * 2000; // Exponential backoff
    },
});

async function addOutboundContact(outboundContact, rxPAId){
    let currentToken = "";
    let tokenStartTime = "";

    if (sessionStorage.getItem('currentToken') || sessionStorage.getItem('currentToken') !== ""){
        currentToken = sessionStorage.getItem('currentToken');
    };

    if (sessionStorage.getItem('tokenStartTime') || sessionStorage.getItem('tokenStartTime') !== ""){
        tokenStartTime = sessionStorage.getItem('tokenStartTime');
    };

    const userInfo = JSON.parse(sessionStorage.getItem('userInfo') || '{}');

    const medhokPayload = {
        "rxPAId": String(rxPAId),
        "outboundContact": outboundContact,
        "currentToken": currentToken,
        "tokenStartTime": tokenStartTime,
        "userId": userInfo?.userId,
    };

    const { AUTO_NOTE_BACKEND } = getEnvironmentVariables();

    // Frontend-level retry: retry ONLY on 555, which the backend returns exclusively
    // when the contact was never sent (token stage failed) — safe, no duplicate. We
    // do NOT retry on a timeout / network error (no response), because a lost
    // response could mean the contact was actually created. The module-level
    // axios-retry is disabled per-request so it can't add an uncontrolled retry.
    const MAX_ATTEMPTS = 2;      // 1 initial attempt + 1 retry
    const RETRY_DELAY_MS = 1000; // wait ~1s before retrying

    let medhokResponse;

    for (let attempt = 1; attempt <= MAX_ATTEMPTS; attempt += 1) {
        try {
            console.log(`Attempting to add outbound contact (attempt ${attempt}/${MAX_ATTEMPTS}).`);
            medhokResponse = await axios.post(`${AUTO_NOTE_BACKEND}/medhok/add-outboundcontact`, medhokPayload, { timeout: 10000, 'axios-retry': { retries: 0 } });
            break; // success -> stop retrying
        } catch (error) {
            console.error(`Error adding outbound contact (attempt ${attempt}/${MAX_ATTEMPTS}): `, error);
            // Retry ONLY the safe 555 (contact not sent). Anything else — including a
            // timeout with no response — is left as a failure to avoid a duplicate.
            if (error?.response?.status !== 555 || attempt >= MAX_ATTEMPTS) {
                break;
            }
            // eslint-disable-next-line no-await-in-loop
            await new Promise((resolve) => setTimeout(resolve, RETRY_DELAY_MS));
        }
    }

    if (medhokResponse) {
        sessionStorage.setItem('currentToken', medhokResponse?.data?.currentToken || '');
        sessionStorage.setItem('tokenStartTime', medhokResponse?.data?.tokenStartTime || '');

        sessionStorage.setItem("MHK_OBC_CONTACT_TYPE", outboundContact?.callType || "");
        sessionStorage.setItem("MHK_OBC_CONTACT_OUTCOME", outboundContact?.outcome || "");
        sessionStorage.setItem("MHK_OBC_CONTACT_NOTES", outboundContact?.notes || "");

        return medhokResponse?.data;
    }

    return;
};

export default addOutboundContact;
