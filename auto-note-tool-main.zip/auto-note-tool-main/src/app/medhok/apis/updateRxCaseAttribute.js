/* eslint-disable no-useless-return */
/* eslint-disable consistent-return */
/* eslint-disable prefer-destructuring */
import axios from 'axios';
// eslint-disable-next-line import/no-extraneous-dependencies
import axiosRetry from 'axios-retry';
import { getEnvironmentVariables } from '../../../../environment/config';
import { getMedhokStatusMapping, getFinalStatusReason, getYesOrNoByAddlInfoRequired, getFinalStatus, getYesOrNoBySupportingStatementRequired } from '../helpers';
import { drugName } from '../../qsets/fields';

// Configure axios to retry requests
axiosRetry(axios, {
    retries: 2,
    retryCondition: (error) => error?.response?.status >= 500,
    retryDelay: (retryCount) => {
        console.log(`Updating Rx case attribute - Retry attempt: ${retryCount}`);
        return retryCount * 1000; // Exponential backoff
    },
});

async function updateRxCaseAttribute(role, origin, rxId, rxPAId, internal, routingValue, requestTypeValue, supportingStatementValue, subSpprtStatementValue){
    let currentToken = "";
    let tokenStartTime = "";

    if (sessionStorage.getItem('currentToken') || sessionStorage.getItem('currentToken') !== ""){
        currentToken = sessionStorage.getItem('currentToken');
    };

    if (sessionStorage.getItem('tokenStartTime') || sessionStorage.getItem('tokenStartTime') !== ""){
        tokenStartTime = sessionStorage.getItem('tokenStartTime');
    };

    const userInfo = JSON.parse(sessionStorage.getItem('userInfo') || '{}');

    const {
        status,
        statusReason
    } = getMedhokStatusMapping(routingValue);

    const finalStatus = getFinalStatus(status, routingValue, supportingStatementValue, subSpprtStatementValue);
    let finalStatusReason = getFinalStatusReason(routingValue, requestTypeValue, statusReason, supportingStatementValue, subSpprtStatementValue);
    const yesOrNoByAddlInfoRequired = getYesOrNoByAddlInfoRequired(finalStatusReason);
    const yesOrNoBySupportingStatementRequired = getYesOrNoBySupportingStatementRequired(finalStatusReason);

    const caseVerbiage = sessionStorage.getItem('CASE_VERBIAGE_GENERATED') || '';
    const rfiReason    = sessionStorage.getItem('RFI_REASON_SELECTED')     || '';
    const denialReason    = sessionStorage.getItem('DENIAL_REASON_SELECTED')     || '';

    // Build routing-specific verbiage fields:
    //   Approved           → letterTemplateDescription (approval letter)
    //   Denied             → letterTemplateDescription (denial letter) + override finalStatusReason
    //                        Skipped entirely when denialReason = "Other" (preserve existing MHK verbiage)
    //   Sent to RFI        → externalTemplate (RFI reason) + externalTemplateDescription (RFI verbiage)
    //                        Skipped for RPh (RPh does not save RFI letters to MHK)
    //                        Skipped when rfiReason = "Other" (preserve existing MHK verbiage)
    const verbiageFields = {};
    if (routingValue === 'Approved' && caseVerbiage) {
        const drugNameValue = drugName(role, origin, 'value')?.toLowerCase();
        // TODO: Remove this skip once Wegovy/Zepbound specific approval verbiage is added in approval.js (see TODO there).
        const isWegovyOrZepbound = drugNameValue?.includes('zepbound') || drugNameValue?.includes('wegovy');
        verbiageFields.letterTemplateDescription = isWegovyOrZepbound ? '' : caseVerbiage;
    } else if (routingValue === 'Denied' && caseVerbiage) {
        if (denialReason && denialReason !== "Other") {
            finalStatusReason = denialReason;
            verbiageFields.letterTemplateDescription = caseVerbiage;
        }
    } else if (routingValue === 'Sent to RFI' && caseVerbiage) {
        if (role !== "rph" && rfiReason && rfiReason !== "Other") {
            verbiageFields.externalTemplate            = rfiReason;
            verbiageFields.externalTemplateDescription = caseVerbiage;
        }
    }

    console.log(`updateRxCaseAttribute - routingValue: ${routingValue}, requestTypeValue: ${requestTypeValue}, supportingStatementValue: ${supportingStatementValue}, subSpprtStatementValue: ${subSpprtStatementValue}, status:${status}, statusReason: ${statusReason}, finalStatus: ${finalStatus}, finalStatusReason: ${finalStatusReason}, yesOrNoByAddlInfoRequired: ${yesOrNoByAddlInfoRequired}, yesOrNoBySupportingStatementRequired: ${yesOrNoBySupportingStatementRequired}`);

    const medhokPayload = {
        "rxId": String(rxId),
        "medhokId": Number(rxPAId),
        "internal": internal,
        "status": finalStatus,
        "statusReason": finalStatusReason,
        "yesOrNoByAddlInfoRequired": yesOrNoByAddlInfoRequired,
        "yesOrNoBySupportingStatementRequired": yesOrNoBySupportingStatementRequired,
        "currentToken": currentToken,
        "tokenStartTime": tokenStartTime,
        "userId": userInfo?.userId,
        ...verbiageFields,
    };

    const { AUTO_NOTE_BACKEND } = getEnvironmentVariables();

    // Frontend-level retry for this WRITE is intentionally limited: retry ONLY on
    // 555, which the backend returns exclusively when the update was never sent
    // upstream (the token stage failed). We do NOT retry on a timeout / network
    // error (no response), because a lost response could mean the update actually
    // applied — retrying then would double-apply it.
    const MAX_ATTEMPTS = 2;      // 1 initial attempt + 1 retry
    const RETRY_DELAY_MS = 1000; // wait ~1s before retrying

    let medhokResponse;

    for (let attempt = 1; attempt <= MAX_ATTEMPTS; attempt += 1) {
        try {
            console.log(`Attempting to update Rx case attribute (attempt ${attempt}/${MAX_ATTEMPTS}).`);
            // Disable the module-level axios-retry for this call: its `status >= 500`
            // condition would otherwise auto-retry the write on 555 (and other 5xx),
            // risking a double-apply. This explicit loop is the sole, 555-only retry.
            medhokResponse = await axios.post(`${AUTO_NOTE_BACKEND}/medhok/update-rxcaseattribute`, medhokPayload, { timeout: 10000, 'axios-retry': { retries: 0 } });
            break; // success -> stop retrying
        } catch (error) {
            console.error(`Error updating Rx case attribute (attempt ${attempt}/${MAX_ATTEMPTS}): `, error);
            // Retry ONLY the safe 555 (write not attempted). Anything else — including
            // a timeout with no response — is left as a failure to avoid double-apply.
            if (error?.response?.status !== 555 || attempt >= MAX_ATTEMPTS) {
                break;
            }
            // eslint-disable-next-line no-await-in-loop
            await new Promise((resolve) => setTimeout(resolve, RETRY_DELAY_MS));
        }
    }

    if (medhokResponse) {
        sessionStorage.setItem('currentToken', medhokResponse?.data?.currentToken || '');
        sessionStorage.setItem('tokenStartTime', medhokResponse?.data?.tokenStartTime || '');

        sessionStorage.setItem("MHK_STATUS", finalStatus || "");
        sessionStorage.setItem("MHK_STATUS_REASON", finalStatusReason || "");
        sessionStorage.setItem("MHK_FINAL_NOTE", internal || "");
        sessionStorage.setItem("MHK_ADDL_INFO_REQUIRED", yesOrNoByAddlInfoRequired || "");
        sessionStorage.setItem("MHK_SUPP_STMT_REQUIRED", yesOrNoBySupportingStatementRequired || "");
        sessionStorage.setItem("MHK_LETTER_TEMPLATE_DESC",  verbiageFields.letterTemplateDescription  || "");
        sessionStorage.setItem("MHK_EXTERNAL_TEMPLATE",     verbiageFields.externalTemplate            || "");
        sessionStorage.setItem("MHK_EXTERNAL_TEMPLATE_DESC", verbiageFields.externalTemplateDescription || "");

        return medhokResponse?.data;
    }

    return;
};

export default updateRxCaseAttribute;
