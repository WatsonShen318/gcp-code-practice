/* eslint-disable no-useless-return */
/* eslint-disable consistent-return */
/* eslint-disable prefer-destructuring */
import axios from 'axios';
// eslint-disable-next-line import/no-extraneous-dependencies
import axiosRetry from 'axios-retry';
import { getEnvironmentVariables } from '../../../../environment/config';
import { AlertService } from '../../modal/alert.service';
// import { mockMedhokResponse } from '../../../mockData/mhk/mockMedhokResponse';
// import { mockMedhokResponse } from '../../../mockData/mhk/mockMedhokResponse-apprvDiag';
// import { mockMedhokResponse } from '../../../mockData/mhk/mockMedhokResponse-insulinPumpList';
// import { mockMedhokResponse } from '../../../mockData/mhk/mockMedhokResponse-licsNroa';
// import { mockMedhokResponse } from '../../../mockData/mhk/mockMedhokResponse-rejectwA6';
// import { mockMedhokResponse } from '../../../mockData/mhk/mockMedhokResponse-quantityLimit';
// import { mockMedhokResponse } from '../../../mockData/mhk/mockMedhokResponse-aetnaSpecificQuestions';

// Configure axios to retry requests
axiosRetry(axios, {
    retries: 2,
    retryCondition: (error) => error?.response?.status >= 500,
    retryDelay: (retryCount) => {
        console.log(`Retrieving case details - Retry attempt: ${retryCount}.`);
        return retryCount * 2000; // Exponential backoff
    },
});

async function retrieveCaseDetails(caseId){
    let currentToken = "";
    let tokenStartTime = "";
    if (sessionStorage.getItem('currentToken') ||  sessionStorage.getItem('currentToken') !== ""){
        currentToken = sessionStorage.getItem('currentToken');

    };

    if (sessionStorage.getItem('tokenStartTime') || sessionStorage.getItem('tokenStartTime') !== ""){
        tokenStartTime = sessionStorage.getItem('tokenStartTime');
    };

    const userInfo = JSON.parse(sessionStorage.getItem('userInfo') || '{}');

    const medhokPayload = {
        "caseId" : String(caseId),
        "currentToken": currentToken,
        "tokenStartTime": tokenStartTime,
        "userId": userInfo?.userId,
    };

    const { AUTO_NOTE_BACKEND } = getEnvironmentVariables();

    // Frontend-level retry: even after the backend has exhausted its own retries,
    // give the whole call another chance after a short pause, in case a transient
    // upstream outage clears between attempts. Applied to this READ only (safe to
    // repeat); write endpoints are NOT retried here to avoid double-applying.
    const MAX_ATTEMPTS = 4;      // 1 initial attempt + 3 retries
    const RETRY_DELAY_MS = 3000; // wait ~3s before retrying (~9s total retry window)

    let medhokResponse;
    let lastError;

    for (let attempt = 1; attempt <= MAX_ATTEMPTS; attempt += 1) {
        try {
            console.log(`Attempting to get the medhok response (attempt ${attempt}/${MAX_ATTEMPTS})................`);
            // Disable the module-level axios-retry for this call: 555 matches its
            // `status >= 500` condition, which would double-retry (with 2s/4s
            // delays) on top of this explicit loop. This loop is the sole retry.
            medhokResponse = await axios.post(`${AUTO_NOTE_BACKEND}/medhok/retrieve-casedetails`, medhokPayload, { timeout: 15000, 'axios-retry': { retries: 0 } });

            // if (window.location.href.includes('localhost')) {
            //     medhokResponse = mockMedhokResponse;
            // }

            lastError = undefined;
            break; // success -> stop retrying
        } catch (error) {
            lastError = error;
            console.error(`Error fetching Medhok data (attempt ${attempt}/${MAX_ATTEMPTS}): `, error);

            // Retry ONLY transient failures: the backend signals upstream/connection
            // issues with 555 (and infra like GKE ingress may emit other 5xx), while
            // a frontend-side timeout/network error has no response at all.
            // Deterministic failures (400/404) are NOT retried.
            const status = error?.response?.status;
            const isRetryable = status >= 500 || !error?.response;
            if (!isRetryable || attempt >= MAX_ATTEMPTS) {
                break;
            }
            await new Promise((resolve) => setTimeout(resolve, RETRY_DELAY_MS));
        }
    }

    // Only record the FINAL outcome to the audit data: a success logs :200 and
    // no error; a failure is logged only after every attempt has failed.
    if (medhokResponse) {
        sessionStorage.setItem('currentToken', medhokResponse?.data?.currentToken || '');
        sessionStorage.setItem('tokenStartTime', medhokResponse?.data?.tokenStartTime || '');

        const medhokStatusList = JSON.parse(sessionStorage.getItem('medhokStatus'));
        medhokStatusList.push(`${String(caseId)}:200`);
        sessionStorage.setItem('medhokStatus', JSON.stringify(medhokStatusList));

        const medhokBackendResponseList = JSON.parse(sessionStorage.getItem('medhokBackendResponse'));
        medhokBackendResponseList.push('Successful retrieval from Medhok, Response too long to add in BT table.');
        sessionStorage.setItem('medhokBackendResponse', JSON.stringify(medhokBackendResponseList));

        return medhokResponse?.data;
    }

    // All attempts failed — log the failure once.
    const medhokStatusList = JSON.parse(sessionStorage.getItem('medhokStatus'));
    medhokStatusList.push(`${String(caseId)}:${lastError?.response?.status ?? lastError?.code ?? 'ERR'}`);
    sessionStorage.setItem('medhokStatus', JSON.stringify(medhokStatusList));

    const medhokBackendResponseList = JSON.parse(sessionStorage.getItem('medhokBackendResponse'));
    if (lastError?.response?.data){
        medhokBackendResponseList.push(lastError.response.data);
    }
    sessionStorage.setItem('medhokBackendResponse', JSON.stringify(medhokBackendResponseList));

    if (lastError?.status === 404){
        AlertService('MedhokRetrieveCaseDetailsWrongCaseId');
    } else {
        AlertService('MedhokRetrieveCaseDetailsAPIFailure');
    }
    return;
};

export default retrieveCaseDetails;
