import { AlertService } from "../modal/alert.service";
import {
    outbound,
    outboundSubMade,
    subobSpokeFN,
    subobSpokeLN,
    subobSpokeTitle,
    subobinfoGather,
    subobcalloutco,
    outboundalt,
    outboundSubMadeAlt,
    additionalOutboundCallNeeded,
    subobSpokeFNAlt,
    subobSpokeLNAlt,
    subobSpokeTitleAlt,
    subobinfoGatherAlt,
    subobcalloutcoAlt,
    decisionRouting,
} from "../qsets/fields";
import addOutboundContactAPI from "./apis/addOutboundContact";
import updateRxCaseAttributeAPI from "./apis/updateRxCaseAttribute";

async function addOutboundContact(role, origin, rxPAId) {
    const additionalOutboundCallNeededValue = additionalOutboundCallNeeded(role, origin, "value");
    if (role === "rph" && ["Queue", "IBC"].includes(origin) && additionalOutboundCallNeededValue === "Yes") {
        const outboundAltValue = outboundalt(role, origin, "value");

        // "Outbound Call Made and Documented on the Contacts Tab" = No → no API trigger
        if (outboundAltValue !== "Yes") return;

        const outboundSubMadeAltValue = outboundSubMadeAlt(role, origin, "value");
        const spokeFNValue = subobSpokeFNAlt(role, origin, "value");
        const spokeLNValue = subobSpokeLNAlt(role, origin, "value");
        const spokeTitleValue = subobSpokeTitleAlt(role, origin, "value");
        const infoGatherValue = subobinfoGatherAlt(role, origin, "value");
        const calloutcoValue = subobcalloutcoAlt(role, origin, "value");

        let outboundContact;

        if (outboundSubMadeAltValue === "Yes - Spoke with") {
            // Contact made with MDO -> Successful Outbound
            outboundContact = {
                callType: "Provider",
                firstName: spokeFNValue || "",
                lastName: spokeLNValue || "",
                title: spokeTitleValue || "",
                notes: infoGatherValue || "",
                outcome: "Successful Outbound",
            };
        } else {
            // Contact not made -> outcome from Unsuccessful dropdown
            outboundContact = {
                callType: "Provider",
                // notes: infoGatherValue || "",
                outcome: calloutcoValue || "",
            };
        }

        const addOutboundContactAPIResponse = await addOutboundContactAPI(outboundContact, rxPAId);
        return addOutboundContactAPIResponse;
    } else {
        const outboundValue = outbound(role, origin, "value");

        // "Outbound Call Made and Documented on the Contacts Tab" = No → no API trigger
        if (outboundValue !== "Yes") return;

        const outboundSubMadeValue = outboundSubMade(role, origin, "value");
        const spokeFNValue = subobSpokeFN(role, origin, "value");
        const spokeLNValue = subobSpokeLN(role, origin, "value");
        const spokeTitleValue = subobSpokeTitle(role, origin, "value");
        const infoGatherValue = subobinfoGather(role, origin, "value");
        const calloutcoValue = subobcalloutco(role, origin, "value");

        let outboundContact;

        if (outboundSubMadeValue === "Yes - Spoke with") {
            // Contact made with MDO -> Successful Outbound
            outboundContact = {
                callType: "Provider",
                firstName: spokeFNValue || "",
                lastName: spokeLNValue || "",
                title: spokeTitleValue || "",
                notes: infoGatherValue || "",
                outcome: "Successful Outbound",
            };
        } else {
            // Contact not made -> outcome from Unsuccessful dropdown
            outboundContact = {
                callType: "Provider",
                // notes: infoGatherValue || "",
                outcome: calloutcoValue || "",
            };
        }

        const addOutboundContactAPIResponse = await addOutboundContactAPI(outboundContact, rxPAId);
        return addOutboundContactAPIResponse;
    }
}

async function updateRxCaseAttribute(role, origin, rxId, rxPAId, finalNote, routingValue, requestTypeValue, supportingStatementValue, subSpprtStatementValue) {
    const updateRxCaseAttributeAPIResponse = await updateRxCaseAttributeAPI(role, origin, rxId, rxPAId, finalNote, routingValue, requestTypeValue, supportingStatementValue, subSpprtStatementValue);
    return updateRxCaseAttributeAPIResponse;
}

export async function saveDataToMedhok(role, origin, rxPAId, rxId, finalNote, routingValue, requestTypeValue, supportingStatementValue, subSpprtStatementValue) {
    let savedOutboundContact = false;
    let updatedRxCaseAttribute = false;
    // Saving outbound contact to Medhok
    if(!rxPAId){
        console.error("rxPAId/medhokId is not available from MHK/ESL response. Cannot add outbound contact.");
    } else {
        const addOutboundContactResponse = await addOutboundContact(role, origin, rxPAId);
        if(addOutboundContactResponse){
            console.log("Successfully added outbound contact to Medhok.");
            savedOutboundContact = true;
        } else {
            console.error("Failed to add outbound contact to Medhok.");
        }
    }

    // Updating Rx case attribute(internal, status, statusReason) in Medhok
    if(!rxId){
        console.error("rxId is not available from MHK/ESL response. Cannot update Rx case attribute.");
    } else {
        const updateRxCaseAttributeResponse = await updateRxCaseAttribute(role, origin, rxId, rxPAId, finalNote, routingValue, requestTypeValue, supportingStatementValue, subSpprtStatementValue);
        if(updateRxCaseAttributeResponse){
            console.log("Successfully updated Rx case attribute in Medhok.");
            updatedRxCaseAttribute = true;
        } else {
            console.error("Failed to update Rx case attribute in Medhok.");
        }
    }

    if(savedOutboundContact || updatedRxCaseAttribute){
        AlertService("transferredInfoToMHK");
    }
}

export default saveDataToMedhok;
