import { STATUS_MAPPING } from "./constants";

/**
 * Get the MHK system status and statusReason for a given routing label
 * @param {string} routingLabel - The routing choice label
 * @returns {Object} Object with status and statusReason properties
 */
export function getMedhokStatusMapping(routingValue) {
  const mapping = STATUS_MAPPING[routingValue];
  if (!mapping) {
    console.warn(`No MHK status mapping found for routing value: ${routingValue}.`);
    return {
      status: "",
      statusReason: ""
    };
  }
  return mapping;
}

/*
  For cases routed to Tolling Case, if the supporting statement is "No" and the sub-supporting statement is either "Tolled Case" or "Tolled case and resent RFI letter with updated due date/time.", then the status must be set to "In Progress" instead of "Toll Pending".
*/
export function getFinalStatus(status, routingValue, supportingStatementValue, subSpprtStatementValue) {
  if(supportingStatementValue === "No" && ["Tolled Case", "Tolled case and resent RFI letter with updated due date/time."].includes(subSpprtStatementValue) && routingValue === "Tolling Case"){
    return "In Progress";
  }
  
  return status;
}

/*
  Redetermination cases routed to RFI must use 'Pending Submission of Evidence' instead of
  'Pending Additional Information' per MHK requirements.
*/
export function getFinalStatusReason(routingValue, requestTypeValue, statusReason, supportingStatementValue, subSpprtStatementValue) {
  if (["Redetermination", "RD"].includes(requestTypeValue) && statusReason === "Pending Additional Information") {
    return "Pending Submission of Evidence";
  }

  if(supportingStatementValue === "No" && ["Tolled Case", "Tolled case and resent RFI letter with updated due date/time."].includes(subSpprtStatementValue) && (statusReason === "Pending Additional Information" || routingValue === "Tolling Case")){
    return "Pending Supp Stmt/Hospice";
  }

  return statusReason;
}

export function getYesOrNoByAddlInfoRequired(finalStatusReason) {
  if (["Pending Additional Information", "Pending Submission of Evidence"].includes(finalStatusReason)) {
    return "Yes";
  }

  return "";
}

export function getYesOrNoBySupportingStatementRequired(finalStatusReason) {
  if (["Pending Supp Stmt/Hospice"].includes(finalStatusReason)) {
    return "No";
  }

  return "";
}
