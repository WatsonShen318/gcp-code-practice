import resetNote from '../reset/notetool.reset';
import showTool from '../utils/showTool';

export function SaveInfo(data) {
  sessionStorage.setItem('InternalNoteUserRole', data);
}

export function RoleChange() {
  const Nav = document.getElementById('navbarNavDropdown');
  Nav.querySelectorAll("ul>li>a[id*='Roletab']").forEach((elem) => {
    elem.addEventListener('click', (evt) => {
      const r = evt.target.id;
      showTool();
      document.getElementById('userRole').setAttribute('value', r);
      resetNote();
      SaveInfo(r);
    });
  });
}

// //*Create get location information for returning users
export function ReturnToSession() {
  if (sessionStorage.getItem('InternalNoteUserRole')) {
    const r = sessionStorage.getItem('InternalNoteUserRole');
    const list = document.querySelectorAll(`fieldset[aria-labelledby=${r}]`);
    document.getElementById(r).classList.add('active');
    document.getElementById('userRole').setAttribute('value', r);
    list.forEach((s) => s.classList.add('active', 'show'));
    showTool();
  }
}

/**
 * * Capture current Role and Origin of the tool
 */

export function currentProfile() {
  const r = document.querySelector('ul.nav > li.nav-item > a.active');
  const role = r?.getAttribute('data-role').toLowerCase();
  const preQ = document.querySelector(
    'label[for*="origin"].active, btn, nav-item'
  );
  const profile = {
    role: r.getAttribute('data-role').toLowerCase(),
    origin: role === 'intake' ? '' : preQ?.getAttribute('data-value'),
  };
  return profile;
}
