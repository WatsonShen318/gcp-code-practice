import { GeneralModal } from '../modal/alert.service';
import { bold } from './font.formatter';

export default function msgDeniedRD(a) {
  if (a === 'No') {
    GeneralModal({
      message: bold(
        'Most redetermination denials must be reviewed by a Medical Director. Continue to MD template.'
      ),
      icon: 'notification_important',
    });
  }
}
