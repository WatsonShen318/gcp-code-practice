import { toggleDisplay } from './notetool.display';

export default function toggleExceptionRdo(o, r, a) {
  const status = a === 'Sent to RFI' ? 'disable' : 'enable';
  toggleDisplay('solo', [`${r}${o}exceptionRdoQ`], status);
}
