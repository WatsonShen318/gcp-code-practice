import { decisionRouting, requestType } from '../qsets/fields';
import { toggleDisplay } from './notetool.display';

export default function toggleRecommand(o, r) {
  const deci = decisionRouting(r, o, 'value');
  const rt = requestType(r, o, 'value');
  if (deci.includes('Forward to Clinical') && rt === 'RD') {
    toggleDisplay('solo', [`${r}${o}rdRecommandQ`], 'enable');
  } else {
    toggleDisplay('solo', [`${r}${o}rdRecommandQ`], 'disable');
  }
}
