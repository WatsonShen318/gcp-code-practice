let date;
let day;
let month;
let year;

export function getLastDate(days) {
  date = new Date();
  const last = new Date(date.getTime() - days * 24 * 60 * 60 * 1000);
  day = last.getDate();
  month = last.getMonth() + 1;
  year = last.getFullYear();

  return `${days} days in the past was ${month}/${day}/${year}`;
}

export function getForwardDate(days) {
  date = new Date();
  const curyear = date.getFullYear();
  const forward = new Date(date.getTime() + days * 24 * 60 * 60 * 1000);
  day = forward.getDate();
  month = forward.getMonth() + 1;
  year = forward.getFullYear();

  return `${days} days from today is <b>${month}/${day}/${year}</b> <br/>If Q4 (October through December) use 12/31/${curyear}`;
}

export function getFoward90daysDate() {
  date = new Date();
  const forward = new Date(date.getTime() + 90 * 24 * 60 * 60 * 1000);
  day = forward.getDate();
  month = forward.getMonth() + 1;
  year = forward.getFullYear();

  return `${month}/${day}/${year}`;
}

//AMN 9/14/22 - #107: Prospective Review for last quarter
/*
export function getLastQtr() {
  date = new Date();
  month = date.getMonth() + 1;
  let out = ['noshow'];
  if (month > 9) {
    out = ['IBC', 'Queue', 'SR', 'TAT'];
    return out;
  }
  return out;
}
*/
export function getLastQtr() {
  date = new Date();
  month = date.getMonth() + 1;
  day = date.getDate();
  let out = ['noshow'];
  //if ((month > 9) || (month == 9 && day > 15)) { //AMN 9/14/22 - #107: For UAT Testing Only. Comment out for Prod
  if ((month > 10) || (month == 10 && day >= 15)) { //AMN 9/14/22 - #107: Uncomment for PROD
    out = ['IBC', 'Queue', 'SR', 'TAT'];
    return out;
  }
  return out;
}

export function getToday() {
  date = new Date();
  day = `0${date.getDate()}`.slice(-2);
  month = `0${date.getMonth() + 1}`.slice(-2);
  year = date.getFullYear();
  const today = `${month}/${day}/${year}`;

  return today;
}

export function getNextYear() {
  date = new Date();
  year = date.getFullYear() + 1;
  return year;
}

export function getCurrentYear() {
  date = new Date();
  year = date.getFullYear();
  return year;
}
