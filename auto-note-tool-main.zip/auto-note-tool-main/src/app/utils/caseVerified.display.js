import { isFlowAutomated } from '../prefill/helpers';
import { toggleDisplay } from './notetool.display';

export default function toggleCaseVeri(o, r, a) {
  switch (a) {
    case 'Not found':
    case 'highlighted in blue':
      toggleDisplay('solo', [`${r}${o}caseVerifiedQ`], 'disable');

      break;

    default:
      if(!isFlowAutomated()) {
        toggleDisplay('solo', [`${r}${o}caseVerifiedQ`], 'enable');
      }
      break;
  }
}
