import Cleave from 'cleave.js';

export default function InputFormat() {
  document.querySelectorAll('.input-date').forEach((f) => {
    new Cleave(f, {
      date: true,
      datePattern: ['m', 'd', 'Y'],
      delimiter: '/',
    });
  });

  document.querySelectorAll('.input-ph').forEach((p) => {
    new Cleave(p, {
      numericOnly: true,
      blocks: [3, 3, 4],
      delimiter: '-',
    });
  });

  document.querySelectorAll('.input-dt').forEach((t) => {
    new Cleave(t, {
      numericOnly: true,
      delimiters: ['/', '/', ' ', ':'],
      blocks: [2, 2, 4, 2, 2],
    });
  });

  document.querySelectorAll('.input-numbers').forEach((n) => {
    new Cleave(n, {
      numeral: true,
      numeralDecimalMark: '',
      delimiter: '',
    });
  });

  //* Do not allow users to put in specific special characters
  document.querySelectorAll('textarea, input[type="text"]').forEach((t) => {
    t.addEventListener('change', (e) => {
      const field = e.target;
      const input = e.target.value;
      const bullets = `['\u25A0-\u25FF'|'\u2022'|'\uF0A7'|'\u00A7'|'\uF076'|'\u{F0FC}'|'\u{25BA}'|'\u{AF}'|'\u{D8}'|'\u{9C}'|'\u{9D}'|'\u{B7}']`;
      const speicalChars = `[{}~&^<>"]`;
      const sanitized = input.replace(
        new RegExp(
          `//^\\s*(?:[\\dA-Z]+\\.|[a-z]\\)|•)\\s+|${speicalChars}|(${bullets})\t|(\t${bullets}\\s+)`,
          'gm'
        ),
        ''
      );
      field.value = sanitized;
    });
  });
}

export function toTitleCase(str) {
  return str.replace(
    /\w\S*/g,
    (txt) => txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase()
  );
}
