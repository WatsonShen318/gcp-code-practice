import { toggleDisplay } from './notetool.display';

export default function resetFillIntake(role, origin) {
    toggleDisplay('solo', [`${role}${origin}claimQPA`, `${role}${origin}claimQ`,
        `${role}${origin}subclaimTodayDQPA`, `${role}${origin}subclaimTodayDQ`,
        `${role}${origin}claim90dQPA`, `${role}${origin}claim90dQ`,
        `${role}${origin}subclaim90dQPA`, `${role}${origin}subclaim90dQ`,
        `${role}${origin}spprSatementQPA`, `${role}${origin}spprSatementQ`
      ], 'enable'); 
  }
  

