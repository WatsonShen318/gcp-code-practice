import { toggleDisplay } from './notetool.display';

export default function toggleDeniedOutreach(o, r, a) {
  const status = a === 'Denied' ? 'enable' : 'disable';
  toggleDisplay('solo', [`${r}${o}suffOutreachQ`], status);
}
