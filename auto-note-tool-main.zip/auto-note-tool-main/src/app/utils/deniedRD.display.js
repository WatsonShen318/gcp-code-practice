import { decisionRouting, mdReview, requestType } from '../qsets/fields';
import { toggleDisplay } from './notetool.display';

export function toggledeniedRD(o, r) {
  const decision = decisionRouting(r, o, 'value');
  const rt = requestType(r, o, 'value');
  const status = rt === 'RD' && decision === 'Denied' ? 'enable' : 'disable';
  toggleDisplay('solo', [`${r}${o}mdReviewQ`], status);
}

export function toggledeniedRDrphDecision(o, r) {
  const decision = decisionRouting(r, o, 'value');
  const mdR = mdReview(r, o, 'value');
  let status;
  if (o !== 'TAT') {
    status = mdR === 'Yes' && decision === 'Denied' ? 'enable' : 'disable';
  }
  if (o === 'TAT') {
    status = mdR === 'Yes' ? 'enable' : 'disable';
  }
  toggleDisplay('solo', [`${r}${o}rphDecisionQ`], status);
}
