import { automateDLTGuidelines } from '../dlt_guidelines/automation';
import {
  approvedDiagnosis,
  clientKeyIn,
  diagnosis,
  guideline,
  guidelineRationale,
  mdRationale,
  rationale,
  requestBy,
  requestType,
  subInquiryCaller,
  subInquiryRejectCode,
  subInquiryTR,
  subMemberWAOR,
  subRequestByCaller,
  subRequestInfo,
  triedFail,
} from '../qsets/fields';
import { toggleDisable, toggleDisplay } from './notetool.display';

let rdo = null;

export function setTriedFail(o, r, picked) {
  const gl = {
    'Opioid Quantity Limit - 925': '',
    'Prior Authorization': `N/A`,
    'Safety Edit': `N/A`,
  };
  triedFail(r, o, 'element').value = gl[picked] || '';
}

export function setRqstByRdo(o, r, v) {
  rdo = document.getElementById(`${r}${o}rqstByQ${v}`);
  rdo?.click();
}

export function setRqstByCallerRdo(o, r, v) {
  rdo = document.getElementById(`${r}${o}subrqstByCallerQ${v}`);
  rdo.click();
}

export function setInqryCaller(o, r, a) {
  const rqstBy = requestBy(r, o, 'value');
  const behalf = subRequestByCaller(r, o, 'value');
  const inqryCaller = subInquiryCaller(r, o, 'element');
  if (a === 'Yes' && rqstBy === 'Prescriber') {
    inqryCaller.value = `${rqstBy} -  ${subRequestInfo(r, o, 'value')}`;
  } else if (a === 'Yes' && rqstBy !== 'Prescriber' && behalf === 'No') {
    inqryCaller.value = `${rqstBy} - ${subRequestInfo(r, o, 'value')}`;
  } else if (a === 'Yes' && rqstBy !== 'Prescriber' && behalf === 'Yes') {
    inqryCaller.value = `${rqstBy} - ${subMemberWAOR(r, o, 'value')}`;
  }
}

export function setDiagDLTNA(o, r, a) {
  const diag = diagnosis(r, o, 'element');
  const DLT = document.getElementById(`${r}${o}approveDiagoQNA`); // if only for other origins
  const possible = ['na', 'n/a', 'notapplicable', 'notavailable'];
  const input = a.toLowerCase().trim().replace(/\s/g, '');
  if (possible.includes(input) || a === 'click') diag.value = 'N/A';
  if (a === 'click') diag.value = 'N/A';
  if (o !== 'SR') {
    DLT.checked = true;
    toggleDisable([`${r}${o}approveDiagoQ`], 'disable');
    if (!possible.includes(input) && a !== 'click') {
      DLT.checked = false;
      toggleDisable([`${r}${o}approveDiagoQ`], 'enable');
    }
  }
}

export function setTriedFailNA(o, r) {
  triedFail(r, o, 'element').value = 'N/A';
}

export function setClientNA(o, r) {
  clientKeyIn(r, o, 'element').value = 'N/A';
}

export function setinqRejectCodeNA(o, r) {
  subInquiryRejectCode(r, o, 'element').value = 'N/A';
}

export function setinqRqstReasonNA(o, r) {
  subInquiryTR(r, o, 'element').value = 'N/A';
}

/**
 * $ Based on request reason answers, Automatically select Guideline. IF Guideline is N/A, Question Answers marked as N/A
 * @param {origin} o
 * @param {role} r
 * @param {answer} a
 */
export function setGuideline(o, r, a) {
  const gl = guideline(r, o, 'element');
  const glanswer = guidelineRationale(r, o, 'element');
  switch (a) {
    case 'Quantity Opioid 7 Day':
      gl.value = 'Opioid Quantity Limit - 925';
      glanswer.value = '';
      toggleDisplay('solo', [`${r}${o}guidelineQbtn`], 'enable');
      break;
    case 'Quantity Limit':
      gl.value = 'Quantity Limit Exception';
      glanswer.value = '';
      toggleDisplay('solo', [`${r}${o}guidelineQbtn`], 'enable');
      break;
    case 'Step Therapy':
    case 'Tier Change':
    case 'Prior Authorization':
    case 'Safety Edit':
      /* [Automated flow only] Skipping setting N/A DLT guideline fields for Phase-3.0 and later changes */
      const workFlow = sessionStorage.getItem("workFlow");
      if(workFlow !== 'Automated'){
        gl.value = 'N/A';
        glanswer.value = 'N/A';
      }
      break;
    default:
      gl.value = '';
      glanswer.value = '';
      toggleDisplay('solo', [`${r}${o}guidelineQbtn`], 'disable');
      break;
  }
}

/**
 * $ [DLT Guideline forms automation] Based on Mapped Guideline FOrm, Automatically select Guideline if guideline is in scope for automation for Dec'25 Phase 3.0
 * This might be altered for future releases 3.5(Jan'26), 4.0(Apr'26) or later
 * @param {origin} o
 * @param {role} r
 * @param {mappedGuideline} mappedGuideline
 */
export function setGuidelineFromMapper(o, r, mappedGuideline) {
  const gl = guideline(r, o, 'element');
  const glanswer = guidelineRationale(r, o, 'element');
  console.log('Mapped Guideline for automation:', mappedGuideline);
  if(mappedGuideline) {
    gl.value = mappedGuideline;
    glanswer.value = '';
    toggleDisplay('solo', [`${r}${o}guidelineQbtn`], 'enable');
    return;
  }
}

/* Helper to reset DLT Guideline if Other selected from Drug Dropdown */
export function resetDLTGuideline(o, r) {
  const gl = guideline(r, o, 'element');
  const glanswer = guidelineRationale(r, o, 'element');
  gl.value = '';
  glanswer.value = '';
  toggleDisplay('solo', [`${r}${o}guidelineQbtn`], 'disable');
  return;
}

export function setSupprtStatement(o, r, a, q) {
  const supportNA = document.getElementById(`${r}${o}spprSatementQNA`);
  const supportY = document.getElementById(`${r}${o}spprSatementQYes`);
  const supportN = document.getElementById(`${r}${o}spprSatementQNo`);
  if (q === 'RequestReason') {
    switch (a) {
      case 'Step Therapy':
      case 'Prior Authorization':
      case 'Safety Edit':
        supportNA.checked = true;
        supportN.disabled = true;
        supportY.disabled = true;
        toggleDisplay(
          "solo",
          [`${r}${o}subspprSatementLocationQ`, `${r}${o}subspprSatementQ`],
          "disable"
        );
        break;
      default:
        supportNA.checked = false;
        supportN.disabled = false;
        supportY.disabled = false;
        break;
    }
  }
  if (q === 'comdenpia') {
    switch (a) {
      case 'Yes':
      case 'No':
        supportY.checked = true;
        toggleDisplay(
          "solo",
          [`${r}${o}subspprSatementLocationQ`, `${r}${o}subspprSatementQ`],
          "enable"
        );
        toggleDisplay(
          "solo",
          [`${r}${o}subspprSatementQ`],
          "disable"
        );
        break;
      default:
        supportN.disabled = false;
        supportY.disabled = false;
        supportNA.checked = false;
        supportN.checked = false;
        supportY.checked = false;
        toggleDisplay(
          "solo",
          [`${r}${o}subspprSatementLocationQ`, `${r}${o}subspprSatementQ`],
          "disable"
        );
        break;
    }
  }
}

export function setSourceMDO(o, r) {
  const mdo = document.getElementById(`${r}${o}mdoInfoQlt`);
  const ePA = document.getElementById(`${r}${o}memberidsQePAchb`).checked;

  if (mdo) {
    if (o === 'Queue' && ePA && !mdo.value.includes('ePA')) {
      mdo.value += ' ePA';
    }
    if (o === 'Queue' && !ePA) {
      mdo.value = mdo.value.replace(/ePA/gm, '').trim();
    }
  }
}

export function setMDnewInfo(o, r) {
  const newInfoNA = document.getElementById(`${r}${o}mdNewInfoQNA`);
  const rt = requestType(r, o, 'value');
  if (rt === 'CD') {
    // newInfoNA.disabled = false;
    // newInfoNA.checked = true;
    toggleDisplay('solo', [`${r}${o}mdNewInfoQ`], 'disable');
  } else {
    toggleDisplay('solo', [`${r}${o}mdNewInfoQ`], 'enable');
    // newInfoNA.checked = false;
    // newInfoNA.disabled = true;
  }
}

export function setMDrational(o, r) {
  const rational = rationale(r, o, 'value');
  const MDrational = mdRationale(r, o, 'element');

  MDrational.value = rational;
}

export function setCAREAgent(o, r) {
  const care = document.getElementById(`${r}${o}careAgentQNo`);
  care.checked = true;
}

export function setOBCSendingtoRFINA(o, r, id = '', alt=false) {
  const altsfx = alt ? 'alt' : '';
  const field =
    id === ''
      ? document.getElementById(`${r}${o}subobRFIQ${altsfx}txt`)
      : document.getElementById(`${r}${o}subobRFIQ${altsfx}txt${id}`);
  field.value = 'N/A';
}

/**
 * $ This function is only for Rph TAT.
 * $ When MD Template is visiable, or Approvalbe Diagonosis is clicked, it will run this function
 * @param {origin} o
 * @param {role} r
 */
export function setMDdxNo(o, r) {
  const diag = approvedDiagnosis(r, o, 'value');
  const fdaNo = document.getElementById(`${r}${o}mdFDAQNo`);
  const Compdenia = document.getElementById(`${r}${o}mdOffLabelQNo`);
  if (diag === 'No') {
    fdaNo.checked = true;
    Compdenia.checked = true;
  } else {
    fdaNo.checked = false;
    Compdenia.checked = false;
  }
}

export function setMDoffLabelCompendiaNA(o, r, a) {
  const compendia = document.getElementById(`${r}${o}mdOffLabelQNA`);
  const compendiaY = document.getElementById(`${r}${o}mdOffLabelQYes`);
  compendia.checked = a === 'Yes';
  compendiaY.disabled = a === 'Yes';
}

export function setMDoffLabelCompendiaNo(o, r, a) {
  const compendia = document.getElementById(`${r}${o}mdOffLabelQNo`);
  if (a === 'Yes') {
    compendia.checked = false;
    compendia.disabled = true;
  } else {
    compendia.disabled = false;
  }
}

/*
  Helper to reset DLT Guideline fields for scenarios where Request Reason is manually changed by User
*/
export async function resetDLTGuidelineFields(role, origin, answer) {
  const originalMedhokResponse = JSON.parse(sessionStorage.getItem("originalMedhokResponse"));
  if(answer === "Non-formulary") {
    sessionStorage.setItem("lastDLTAutomatedAnswer", answer);
    let gpiSelected = sessionStorage.getItem("gpiSelectedWDrugNameSearch");
    if(gpiSelected) { // this applies for Tech IBC - Searchable Drug Name dropdown selections
      const updatedMedhokeResponse = {...originalMedhokResponse, gpiCode: gpiSelected};
      await automateDLTGuidelines(role, origin, updatedMedhokeResponse, gpiSelected);
    } else {
      if(originalMedhokResponse?.gpiCode) {
        await automateDLTGuidelines(role, origin, originalMedhokResponse);
      }
    }
  } else if (answer.includes('Quantity')) {
    sessionStorage.setItem("lastDLTAutomatedAnswer", answer);
    // Quantity Limit / Quantity Opioid 7 Day: automate QL guideline form using the real GPI.
    // Override requestReason so parseQLRequestReason activates the QL path inside automateDLTGuidelineForm.
    let gpiSelected = sessionStorage.getItem("gpiSelectedWDrugNameSearch");
    if (gpiSelected) {
      const updatedMedhokeResponse = {...originalMedhokResponse, gpiCode: gpiSelected, requestReason: answer};
      await automateDLTGuidelines(role, origin, updatedMedhokeResponse, gpiSelected);
    } else if (originalMedhokResponse?.gpiCode) {
      const updatedMedhokeResponse = {...originalMedhokResponse, requestReason: answer};
      await automateDLTGuidelines(role, origin, updatedMedhokeResponse);
    }
  } else {
    sessionStorage.removeItem("lastDLTAutomatedAnswer");
    // Removing DLT Guideline fields when Request Reason is not "Non-formulary" or Quantity Limit
    const gpiSelected = 'Other';
    console.log("Resetting DLT Guideline for", role, origin);
    resetDLTGuideline(origin, role);
    const updatedMedhokeResponse = {...originalMedhokResponse, gpiCode: gpiSelected};
    await automateDLTGuidelines(role, origin, updatedMedhokeResponse, gpiSelected);
  }

  /* toggling dlt guideline dropdown visibility based on request reason */
  if(!(["Non-formulary", "Quantity Limit", "Quantity Opioid 7 Day"].includes(answer))) {
    toggleDisplay(
      "solo",
      [`${role}${origin}guidelineQ`, `${role}${origin}subguidelineQ`],
      "disable"
    );
  }
}

export function filterDLTGuidelineOptions(role, origin, answer) {
  const guidelineQsel = guideline(role, origin, 'element');

  if(answer.includes("Quantity")) {
    // Show options only related to Quantity Limit and hide others 
    Array.from(guidelineQsel.options).forEach(option => {
      if(option.value.includes("Quantity Limit") || option.value === "N/A") {
        option.style.display = 'block';
      } else {
        option.style.display = 'none';
      }
    });
  } else {
    // Show all options
    Array.from(guidelineQsel.options).forEach(option => {
      option.style.display = 'block';
    });
  }
}

