import { toggleDisplay } from './notetool.display';

export default function toggleTechSuper(o, r, a) {
  if (a === 'Approved') {
    toggleDisplay('solo', [`${r}${o}techSupUserQ`], 'enable');
  } else {
    toggleDisplay('solo', [`${r}${o}techSupUserQ`], 'disable');
  }
}
