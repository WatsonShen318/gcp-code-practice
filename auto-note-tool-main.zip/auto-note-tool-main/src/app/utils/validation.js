export default function togglePartialValidation(o, r, a) {
  const rest = document.querySelectorAll(
    `div.tab-content>fieldset[id=${r}${o}].active > fieldset:not([data-tag*="${a}"])`
  );
  const notetool = document.getElementById('notetool');

  if (a === 'outboundcall' || a === 'outboundcallalt') {
    rest.forEach((o) => (o.disabled = true));
  } else {
    rest.forEach((o) => (o.disabled = false));
    notetool.classList.remove('was-validated');
  }
}
