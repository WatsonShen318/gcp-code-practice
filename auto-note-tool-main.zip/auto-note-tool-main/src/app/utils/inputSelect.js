export function rdoBtn(n) {
  const rb = document
    .getElementById(`${n}`)
    .querySelectorAll(`input[name="${n}rdo"]`);
  return rb;
}

export function ele(n, i) {
  const ii = i || '';
  const t = document.getElementById(`${n}${ii}`);
  return t;
}

export function checkbox(n) {
  const rb = document
    .getElementById(`${n}`)
    .querySelectorAll(`input[id*=${n}][type="checkbox"]`);
  return rb;
}

export function eventElement(type, field) {
  let t;
  if (type === 'radio') t = document.querySelectorAll(`input[name="${field}"]`);
  if (type === 'text' || type === 'select' || type === 'button')
    t = document.getElementById(field);
  if (type === 'check')
    t = document
      .getElementById(`${field}`)
      .querySelectorAll(`input[id*=${field}][type="checkbox"]`);
  return t;
}
