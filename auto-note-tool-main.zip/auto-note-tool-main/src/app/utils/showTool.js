import { skipPrefilling } from "../prefill/prefillHandler";
import { toggleDisplay } from "./notetool.display";
import resetSessionStorage from './resetSessionStorage';

export default function showTool() {
  const r = document.querySelector("ul.nav > li.nav-item > a.active");
  const rActive = r ? r.classList.value.length : 0;
  const notetool = document.getElementById("notetool");

  if (rActive > 0) {
    resetSessionStorage();
    notetool.style.display = "block";
    notetool.classList.remove("ihide");

    if (r.id === "TechRoletab") {
      toggleDisplay("tool", ["TechNote"], "enable");
      toggleDisplay("tool", ["IntakeNote", "RphNote"], "disable");
    } else if (r.id === "RphRoletab") {
      toggleDisplay("tool", ["RphNote"], "enable");
      toggleDisplay("tool", ["IntakeNote", "TechNote"], "disable");
    } else if (r.id === "IntakeRoletab") {
      toggleDisplay("tool", ["IntakeNote"], "enable");
      toggleDisplay("tool", ["TechNote", "RphNote"], "disable");
    }
  }

  toggleDisplay(
    "solo",
    [
      "alertPopupBtn",
      "alertPopup",
      "techQueuemanualTemplateBtn",
      "techQueuemanualTemplateAboveTxt",
      "techSRmanualTemplateBtn",
      "techSRmanualTemplateAboveTxt",
      "rphQueuemanualTemplateBtn",
      "rphQueuemanualTemplateAboveTxt",
    ],
    "disable"
  );
}

export function originChange(role, origin) {
  resetSessionStorage();
  // Remove dynamically injected elements left over from a previous origin session
  document.querySelectorAll('.plan-ql-ref').forEach(el => el.remove());
  document.querySelectorAll('.ant-ql-claim-info').forEach(el => el.remove());
  if (role === "tech" && origin === "SR") {
    toggleDisplay("tool", [`${role}SR`], "enable");
    toggleDisplay("tool", [`${role}IBC`, `${role}Queue`, `${role}TAT`], "disable");

    // Skip prefilling and show manual templates for holdout users
    skipPrefilling(role, origin);
  }
  if (role === "tech" && origin === "IBC") {
    toggleDisplay("tool", [`${role}IBC`], "enable");
    toggleDisplay("tool", [`${role}SR`, `${role}Queue`, `${role}TAT`], "disable");

    // Skip prefilling and show manual templates for holdout users
    skipPrefilling(role, origin);
  }
  if (role === "tech" && origin === "Queue") {
    toggleDisplay("tool", [`${role}Queue`], "enable");
    toggleDisplay("tool", [`${role}IBC`, `${role}SR`, `${role}TAT`], "disable");
    
    // Skip prefilling and show manual templates for holdout users
    skipPrefilling(role, origin);
  }
  if (role === "tech" && origin === "TAT") {
    toggleDisplay("tool", [`${role}TAT`], "enable");
    toggleDisplay("tool", [`${role}IBC`, `${role}Queue`, `${role}SR`], "disable");

    // Skip prefilling and show manual templates for holdout users
    skipPrefilling(role, origin);
  }
  if (role === "rph" && origin === "TAT") {
    toggleDisplay("tool", [`${role}TAT`], "enable");
    toggleDisplay("tool", [`${role}IBC`, `${role}Queue`], "disable");

    // Skip prefilling and show manual templates for holdout users
    skipPrefilling(role, origin);
  }
  if (role === "rph" && origin === "IBC") {
    toggleDisplay("tool", [`${role}IBC`], "enable");
    toggleDisplay("tool", [`${role}TAT`, `${role}Queue`], "disable");

    // Skip prefilling and show manual templates for holdout users
    skipPrefilling(role, origin);
  }
  if (role === "rph" && origin === "Queue") {
    toggleDisplay("tool", [`${role}Queue`], "enable");
    toggleDisplay("tool", [`${role}IBC`, `${role}TAT`], "disable");
    toggleDisplay("solo", [`${role}${origin}rationalQ`, `${role}${origin}routingQ`, `${role}${origin}LetterPreviewQ`, `${role}${origin}mdReviewQ`], "disable");
  
    // Skip prefilling and show manual templates for holdout users
    skipPrefilling(role, origin);
  }
  toggleDisplay(
    "solo",
    [
      "alertPopupBtn",
      "alertPopup",
      `${role}${origin}manualTemplateBtn`,
      `${role}${origin}manualTemplateAboveTxt`,
    ],
    "disable"
  );
}
