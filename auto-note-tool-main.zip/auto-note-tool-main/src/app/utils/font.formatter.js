export function bold(t) {
  return `<span class="text-primary fw-bold">${t}</span>`;
}
