/* eslint-disable no-param-reassign */
/* eslint-disable no-return-assign */
export function HideAll() {
  const hideQs = document.querySelectorAll('.ihide');
  const showQs = document.querySelectorAll('.defaultShow');
  hideQs.forEach((h) => (h.style.display = 'none'));
  showQs.forEach((s) => (s.style.display = 'block'));
  hideQs.forEach((h) => (h.disabled = true));
  showQs.forEach((s) => (s.disabled = false));
}

export function toggleDisable(value, status) {
  let i;
  const v = value.length;

  for (i = 0; i < v; i++) {
    if (status === 'disable') {
      document.getElementById(value[i]).disabled = true;
    } else {
      document.getElementById(value[i]).disabled = false;
    }
  }
}

export function toggleDisplay(type, value, status, role) {
  let el = null;
  let i;

  const roles = role || null;

  if (type === 'tag') {
    if (status === 'disable') {
      value.forEach((s) => (s.style.display = 'none'));
      value.forEach((d) => (d.disabled = true));
    } else {
      value.forEach((s) => (s.style.display = 'block'));
      value.forEach((d) => (d.disabled = false));
    }
  }

  if (type === 'rest') {
    el = document.querySelectorAll(`${value} ~ fieldset`); //! only accept element ID
    if (status === 'disable') {
      el.forEach((s) => (s.style.display = 'none'));
      el.forEach((d) => (d.disabled = true));
    } else {
      el.forEach((s) => (s.style.display = 'block'));
      el.forEach((d) => (d.disabled = false));
    }
  }

  if (type === 'role') {
    el = document.querySelectorAll(`[data-role*=${value}]`);
    const l = el.length;
    if (status === 'disable') {
      for (i = 0; i < l; i++) {
        el[i].style.display = 'none';
        el[i].disabled = true;
      }
    } else {
      for (i = 0; i < l; i++) {
        el[i].style.display = 'block';
        el[i].disabled = false;
      }
    }
  }
  if (type === 'origin') {
    el = document.querySelectorAll(
      `option[data-origin*=${value}], div.custom-control[data-origin*=${value}]`
    );
    const nel = document.querySelectorAll(
      `option[data-origin*=${value}]:not([data-role=${roles}]), div.custom-control[data-origin*=${value}]:not([data-role=${roles}])`
    );
    if (status === 'disable') {
      el.forEach((s) => (s.style.display = 'none'));
      el.forEach((d) => (d.disabled = true));
    } else {
      el.forEach((s) => (s.style.display = 'block'));
      el.forEach((d) => (d.disabled = false));
      nel.forEach((s) => (s.style.display = 'none'));
      nel.forEach((d) => (d.disabled = true));
    }
  }

  if (type === 'solo' || type === 'button' || type === 'tool') {
    const v = value.length;
    for (i = 0; i < v; i++) {
      const element = document.getElementById(value[i])
      if(element) {
        if (status === 'disable') {
          element.style.display = 'none';
          element.disabled = true;
        } else {
          element.style.display = 'block';
          element.disabled = false;
        }
      }
    }
  }
}
