export default function copyToClipBoard(text) {
  if (!navigator.clipboard) {
    // use old commandExec() way
    document.execCommand('copy');
  } else {
    navigator.clipboard.writeText(text);
  }
}
