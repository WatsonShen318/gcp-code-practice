import { clearFormAltsCache } from '../form_alts/formAlts';

export default function resetSessionStorage() {
  const timestamp = new Date().toISOString();
  sessionStorage.setItem("startTime", timestamp);
  sessionStorage.setItem("cdrdStartTime", "");
  sessionStorage.setItem("cdrdEndTime", "");
  sessionStorage.setItem("cdrdPredOutcome", "");
  sessionStorage.setItem("dltGuidelineStartTime", "");
  sessionStorage.setItem("dltGuidelineEndTime", "");
  sessionStorage.setItem("dltGuidelineName", "");
  sessionStorage.setItem("eslRsp", "");
  sessionStorage.setItem("medhokStatus", JSON.stringify([]));
  sessionStorage.setItem("medhokBackendResponse", JSON.stringify([]));
  sessionStorage.setItem("cdrdStatus", JSON.stringify([]));
  sessionStorage.setItem("cdrdBackendResponse", JSON.stringify([]));
  sessionStorage.setItem("caseIdInputTimeList", JSON.stringify([]));
  sessionStorage.setItem("workFlow", "Manual");
  // Clear Case Decision Routing session storage
  sessionStorage.setItem("RECOMMENDED_CASE_DCSN_ROUTING", "");
  sessionStorage.setItem("FINAL_CASE_DCSN_ROUTING", "");
  // Clear RFI / Denial / Approval session storage
  sessionStorage.setItem("RFI_REASON_SELECTED", "");
  sessionStorage.setItem("DENIAL_REASON_SELECTED", "");
  sessionStorage.setItem("CASE_VERBIAGE_GENERATED", "");
  // Clear Data being saved to MHK session storage
  sessionStorage.setItem("MHK_OBC_CONTACT_TYPE", "");
  sessionStorage.setItem("MHK_OBC_CONTACT_OUTCOME", "");
  sessionStorage.setItem("MHK_OBC_CONTACT_NOTES", "");
  sessionStorage.setItem("MHK_STATUS", "");
  sessionStorage.setItem("MHK_STATUS_REASON", "");
  sessionStorage.setItem("MHK_FINAL_NOTE", "");
  sessionStorage.setItem("MHK_ADDL_INFO_REQUIRED", "");
  sessionStorage.setItem("MHK_SUPP_STMT_REQUIRED", "");
  sessionStorage.setItem("MHK_LETTER_TEMPLATE_DESC", "");
  sessionStorage.setItem("MHK_EXTERNAL_TEMPLATE", "");
  sessionStorage.setItem("MHK_EXTERNAL_TEMPLATE_DESC", "");
  // clear DLT Guideline related session storage
  sessionStorage.removeItem("lastDLTAutomatedAnswer");
  sessionStorage.setItem("isDLTGuidelineFormAutomated", false);
  sessionStorage.setItem("dltAutomatedGuidelineForm", "");
  sessionStorage.setItem("dltAutomatedLICSAndROAFieldAns", "");
  sessionStorage.setItem("dltAutomatedRejectWithA6FieldAns", "");
  sessionStorage.setItem("dltAutomatedInsulinPumpMedicationFieldAns", "");
  sessionStorage.setItem("dltAutomatedApprovableDiagnosisFieldAns", "");
  sessionStorage.removeItem("indicationBasedApprovableDiagnosis");
  sessionStorage.setItem("dltFinalLICSAndROAFieldAns", "");
  sessionStorage.setItem("dltFinalRejectWithA6FieldAns", "");
  sessionStorage.setItem("dltFinalInsulinPumpMedicationFieldAns", "");
  sessionStorage.setItem("dltFinalApprovableDiagnosisFieldAns", "");
  // sessionStorage.setItem("dltAutomationDrugList", JSON.stringify([]));
  sessionStorage.setItem("originalMedhokResponse", JSON.stringify({}));
  sessionStorage.setItem("gpiSelectedWDrugNameSearch", "");
  // BvD specific session storage
  sessionStorage.setItem("dltAutomatedBvDLICSMemberFieldAns", "");
  sessionStorage.setItem("dltFinalBvDLICSMemberFieldAns", "");
  sessionStorage.setItem("dltAutomatedBvDRejectWithA4orA6FieldAns", "");
  sessionStorage.setItem("dltFinalBvDRejectWithA4orA6FieldAns", "");
  // BvD - ESRD
  sessionStorage.setItem("dltAutomatedBvDESRDInjectableAgentRequestFieldAns", "");
  sessionStorage.setItem("dltFinalBvDESRDInjectableAgentRequestFieldAns", "");
  
  //BvD - Inhalation - Loop through field IDs to reset session storage
  const bvdInhalationFieldIds = [
    "requestForAsthmaOrObstructivePulmonaryDiseaseQ",
    "requestForDornaseAlphaPulmozymeQ",
    "patientHasCysticFibrosisQ",
    "requestForTobramycinInhalationSolutionQ",
    "patientHasCysticFibrosisOrBronchiectasisQ",
    "requestForAcetylcysteineQ",
    "persistentThickPulmonarySecretionsQ",
    "requestForNebupentQ",
    "patientHasHIVPneumocystosisOrComplicationsOfOrganTransplantsQ",
    "requestForTyvasoOrVentavisQ",
    "patientHasPulmonaryArteryHypertensionQ",
    "bvdDiagnosisProvidedQ"
  ];

  bvdInhalationFieldIds.forEach(fieldId => {
    sessionStorage.setItem(`dltAutomatedBvDINHALATION${fieldId}FieldAns`, "");
    sessionStorage.setItem(`dltFinalBvDINHALATION${fieldId}FieldAns`, "");
  });

    
  // BvD - IVIG - Loop through field IDs to reset session storage
  const bvdIVIGFieldIds = [
    "patientReceivingMedicationForPrimaryImmuneDeficiencyDiseaseQ",
    "requestForHizentraOrHyQviaQ",
    "patientReceivingMedicationForCIDPQ",
    "bvdDiagnosisProvidedIVIGQ"
  ];

  bvdIVIGFieldIds.forEach(fieldId => {
    sessionStorage.setItem(`dltAutomatedBvDIVIG${fieldId}FieldAns`, "");
    sessionStorage.setItem(`dltFinalBvDIVIG${fieldId}FieldAns`, "");
  });

  // BvD - Oral Antiemetics - Loop through field IDs to reset session storage
  const bvdOralAntiemeticsFieldIds = [
    "requestForVarubiEmendOrAkynzeoQ",
    "requestForAkynzeoQ"
  ];

  bvdOralAntiemeticsFieldIds.forEach(fieldId => {
    sessionStorage.setItem(`dltAutomatedBvDORALANTIEMETICS${fieldId}FieldAns`, "");
    sessionStorage.setItem(`dltFinalBvDORALANTIEMETICS${fieldId}FieldAns`, "");
  });


  // DLT Guideline Automation based on Form Alts;
  sessionStorage.setItem("dltAutomatedShow0TFAltsQAnswer", "");
  sessionStorage.setItem("dltFinalShow0TFAltsQAnswer", "");
  sessionStorage.setItem("dltAutomatedPrescriberIndicatedQlIneffectiveFieldAns", ""); // placeholder - field not automated
  sessionStorage.setItem("dltFinalPrescriberIndicatedQlIneffectiveFieldAns", "");
  sessionStorage.setItem("dltAutomatedTriedNFailedFormAltsQAnswer", "");
  sessionStorage.setItem("dltFinalTriedNFailedFormAltsQAnswer", "");
  sessionStorage.setItem("dltAutomatedTriedNFailedMedicationsAnswer", "");
  sessionStorage.setItem("dltFinalTriedNFailedMedicationsAnswer", "");

  // Clear FormAlts session storage and in-memory init cache
  sessionStorage.setItem('formAltsResolveResult', '');
  sessionStorage.setItem('formAltsLookupResult', '');
  sessionStorage.setItem('formAltsFormularyId', '');
  sessionStorage.setItem('formAltsDrugName', '');
  sessionStorage.setItem('formAltsAutomatedIndication', '');
  sessionStorage.removeItem('formAltsFinalIndication');
  sessionStorage.removeItem('formAltsNfActive');
  sessionStorage.setItem('formAltsFetchResult', '');
  sessionStorage.setItem('formAltsFetchSubmitted', '');
  // Manual drug selection shared by FormAlts and QL (SS_MANUAL_DRUG = 'manualFlowDrug')
  sessionStorage.removeItem('manualFlowDrug');
  clearFormAltsCache();

  // Clear Quantity Limit session storage
  sessionStorage.removeItem('qlActive');
  sessionStorage.removeItem('qlQualifyingClaim');
  sessionStorage.removeItem('qlHasQualifyingClaims');
  sessionStorage.setItem('qlLookupResult', '');
  sessionStorage.setItem('qlAutomatedDrugAndRequestedQl', '');
  sessionStorage.setItem('qlAutomatedDrugAndPlanQl', '');
  sessionStorage.setItem('qlAutomatedPlanQl', '');
  sessionStorage.setItem('qlFinalDrugAndRequestedQl', '');
  sessionStorage.setItem('qlFinalDrugAndPlanQl', '');
  sessionStorage.setItem('qlFinalPlanQl', '');
  // Clear FormAlts and QL audit tracking
  sessionStorage.setItem('formAltsAudit', '');
  sessionStorage.setItem('qlAudit', '');
  sessionStorage.setItem('formularyIdSource', '');
}
