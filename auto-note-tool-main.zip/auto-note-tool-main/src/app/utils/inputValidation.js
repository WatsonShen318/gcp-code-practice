/**
 * Helper Method to validate caseId input
 * @param {string} caseIdInput raw caseId input
 * @returns {boolean} represnting given caseIdInput is matching caseIdRegex or not
 */
export function validateCaseId(caseIdInput) {
    // CaseID regex (11 char long, starts with alphabet, 2nd & 3rd char represent last 2 digits of year - e.g., M24R7FYPL9Z)
    const caseIdRegex = new RegExp(`^[A-Za-z][0-9]{2}[A-Za-z0-9]{8}$`)

    return caseIdRegex.test(caseIdInput);
}