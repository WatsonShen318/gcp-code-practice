export function clearInput(type, field) {
  let inputCtrl;
  let i;
  const r = field;
  if (type === 'radio') {
    for (let t = 0; t < r.length; t += 1) {
      inputCtrl = document.getElementsByName(r[t]);
      for (i = 0; i < inputCtrl.length; i += 1) {
        if (inputCtrl[i].checked)
          document.getElementById(inputCtrl[i].id).checked = false;
      }
    }
  } else if (type === 'text' || type === 'textarea' || type === 'select') {
    for (i = 0; i < field.length; i += 1) {
      document.getElementById(field[i]).value = '';
    }
  }
}

export function clearInputs(array, type) {
  let i;
  const aLength = array.length;
  if (type === 'radio' || type === 'check') {
    for (i = 0; i < aLength; i += 1) {
      if (array[i].checked)
        document.getElementById(array[i].id).checked = false;
    }
  } else if (type === 'text' || type === 'textarea' || type === 'select') {
    for (i = 0; i < aLength; i += 1) {
      document.getElementById(array[i].id).value = '';
    }
  }
}
