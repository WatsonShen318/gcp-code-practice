import { isFlowAutomated } from '../prefill/helpers';
import { toggleDisplay } from './notetool.display';

/**
 * Toggle Was the case successfully created through ePA based on answer.
 * @param {origin} o
 * @param {role} r
 * @param {answer} a
 */
export default function toggleRobotic(o, r, a) {
  switch (a) {
    case 'Not found':
    case 'highlighted in blue':
      toggleDisplay('solo', [`${r}${o}ePAQ`], 'disable');

      break;

    default:
      if(!isFlowAutomated()) {
        toggleDisplay('solo', [`${r}${o}ePAQ`], 'enable');
      }
      break;
  }
}
