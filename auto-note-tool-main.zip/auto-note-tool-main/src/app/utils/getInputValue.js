/**
 * $ Get input values of input controls as array then return array
 * @param {input type} type
 * @param {input name} name
 * @returns {Object}
 */
export default function getInputValue(type, name) {
  let value;
  let i;
  const Qval = [];
  if (type === 'radio') {
    for (i = 0; i < name.length; i++) {
      const t = document.querySelectorAll(
        `input[type="radio"][name=${name[i]}]:checked`
      );
      value = t.length === 0 ? '' : t[0].value;
      Qval[`${name[i]}`] = value;
    }
  } else if (type === 'text') {
    let te;
    for (i = 0; i < name.length; i++) {
      te = document.getElementById(name[i]).value;
      if (te === null) te = '';
      Qval[`${name[i]}`] = te;
    }
  }
  return Qval;
}

export function getValue(type, name) {
  let i;
  let val;
  const nameLength = name.length;
  if (type === 'radio') {
    const t = document.querySelectorAll(
      `input[type="radio"][name=${name}]:checked`
    );
    for (i = 0; i < nameLength; i++) {
      val = t.length === 0 ? '' : t[0]?.value || '';
    }
  }
  if (type === 'text' || type === 'select') {
    const te = document.getElementById(name)?.value || '';
    val = te.length === 0 ? '' : te;
  }
  return val;
}

export function getRepeatSectionVals(role, origin, alt=false) {
  const altsfx = alt ? 'alt' : '';
  const orgGrp = `div.tab-content>fieldset[id="${role}${origin}"].active > fieldset[data-tag*="groups outboundcall${altsfx}"][id*='obPurposeQ${altsfx}'] fieldset:not([disabled])`;
  const cloneGrp = `div.tab-content>fieldset[id="${role}${origin}"].active > div[id*="outboundcall${altsfx}anc"]>fieldset[data-tag*="groups outboundcall${altsfx}"][id*='obPurposeQ${altsfx}'] fieldset:not([disabled])`;

  const fields = document.querySelectorAll(
    `${orgGrp} input[type="text"], ${orgGrp} input[type="radio"]:checked, ${cloneGrp} input[type="text"], ${cloneGrp} input[type="radio"]:checked`
  );
  const cc = [].map.call(fields, ({ id, value }) =>
    [
      document
        .getElementById(id)
        .parentNode.closest('fieldset>div')
        .querySelector('legend>div').textContent,
      value,
    ].join(': ')
  );
  const words = [
    '\r\nNotate the first name, last initial, and title of MDO contact: ',
  ];
  const space = ['What was the purpose of the call'];

  const output = cc
    .join('\r\n')
    .replace(new RegExp(`(\\b)(${words.join('|')})(\\b)`, 'gm'), ' ')
    .replace(
      new RegExp(`(\\b)(${space.join('|')})(\\b)`, 'gm'),
      `\r\n${space[0]}`
    );
  return output;
}

export function getCompendiaChecks(role, origin) {
  const chks = document.querySelectorAll(
    `input[id*=${role}${origin}subcompendiaRefsQ][type="checkbox"]:checked`
  );
  const cc = [].map.call(chks, ({ value }) => value);
  if (cc.length > 0) {
    return `, ${cc.join(', ')}`;
  }
  return '';
}

export function getDurgdexChecks(role, origin) {
  const drugdexc = document.querySelectorAll(
    `input[id*=${role}${origin}subcompendiaRefsDdexQ][type="checkbox"]:checked`
  );
  const dd = [].map.call(drugdexc, ({ value }) => value);
  if (dd.length > 0) {
    return `, (Referenced ${dd.join(', ')} in Drugdex)`;
  }
  return '';
}

export function getMembers(role, origin) {
  const member = document.querySelectorAll(
    `input[id*=${role}${origin}memberidsQ][type="checkbox"]:checked`
  );
  return `Member: ${[].map.call(member, ({ value }) => value).join(', ')}`;
}
