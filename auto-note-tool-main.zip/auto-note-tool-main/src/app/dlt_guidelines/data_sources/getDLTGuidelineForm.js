import axios from "axios";
// eslint-disable-next-line import/no-extraneous-dependencies
import axiosRetry from "axios-retry";
import { getEnvironmentVariables } from "../../../../environment/config";

// import { mockGuidelineFormForGPIResponse } from "../../../mockData/dlt/mockGuidelineFormForGPI";

// Configure axios to retry requests
axiosRetry(axios, {
  retries: 2,
  retryCondition: (error) => error.response.status >= 500,
  retryDelay: (retryCount) => {
    console.log(`Fetching Guideline Form - Retry attempt: ${retryCount}`);
    return retryCount * 1000; // Exponential backoff
  },
});

/* Helper to get DLT Guideline Form*/
async function getDLTGuidelineForm(gpiCode) {
  try {
    if(!gpiCode || gpiCode === "Other") {
      console.warn("No GPI code provided for fetching guideline form.");
      return null;
    }

    console.log("Attempting to get the guideline form response.");
    const { AUTO_NOTE_BACKEND } = getEnvironmentVariables();
    const guidelineFormResponse = await axios.get(
      `${AUTO_NOTE_BACKEND}/drug-guideline-mapping/${gpiCode}`,
      { timeout: 60000 }
    );

    let guidelineFormResponseData = guidelineFormResponse?.data || null;

    if(window.location.href.includes("localhost")) {
      // TODO: this is only for local testing, remove when done testing
      // guidelineFormResponseData = mockGuidelineFormForGPIResponse;
    }

    const guidelineForm = guidelineFormResponseData?.data?.[0]?.guideline_form || null;
    
    return guidelineForm;
  } catch (error) {
    console.error("Error fetching guideline form data: ", error);
    return null;
  }
}

export default getDLTGuidelineForm;
