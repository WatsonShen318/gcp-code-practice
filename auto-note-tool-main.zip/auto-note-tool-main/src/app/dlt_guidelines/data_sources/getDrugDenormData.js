import axios from "axios";
// eslint-disable-next-line import/no-extraneous-dependencies
import axiosRetry from "axios-retry";
import { getEnvironmentVariables } from "../../../../environment/config";

// import { mockDrugDenormDataForNDCResponse } from "../../../mockData/dlt/mockDrugDenormDataForNDC";
// import { RTE_ADMIN_CD_LIST } from "../constants";

// Configure axios to retry requests
axiosRetry(axios, {
  retries: 2,
  retryCondition: (error) => error.response.status >= 500,
  retryDelay: (retryCount) => {
    console.log(`Fetching Drug Denorm Data - Retry attempt: ${retryCount}`);
    return retryCount * 1000; // Exponential backoff
  },
});

/*
Helper to get Drug Denorm Data for NDC
(currently only returns RTEAdminCode but same method can be used for returning all data for matched NDC)
*/
async function getDrugDenormData(ndc) {
  try {
     if(!ndc) {
      console.warn("No NDC provided for fetching Drug Denorm Data.");
      return null;
    }

    console.log("Attempting to get the drug denorm data.");
    const { AUTO_NOTE_BACKEND } = getEnvironmentVariables();
    const drugDenormResponse = await axios.get(
      `${AUTO_NOTE_BACKEND}/drug-denorm-data/${ndc}`,
      { timeout: 60000 }
    );

    let drugDenormResponseData = drugDenormResponse?.data || null;

    if(window.location.href.includes("localhost")) {
      // TODO: this is only for local testing, remove when done testing
      // drugDenormResponseData = mockDrugDenormDataForNDCResponse;
    }

    const drugDenormRecord = JSON.parse(drugDenormResponseData?.data?.[0]?.data.replace(/'/g, '"')) || null;

    const rteAdminCodeFullNm = drugDenormRecord?.RTE_ADMIN_CD || null;

    return rteAdminCodeFullNm;
  } catch (error) {
    console.error("Error fetching guideline form data: ", error);

    return null;
  }
}

export default getDrugDenormData;
