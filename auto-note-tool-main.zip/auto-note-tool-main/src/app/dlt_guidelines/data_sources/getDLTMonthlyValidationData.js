import axios from "axios";
// eslint-disable-next-line import/no-extraneous-dependencies
import axiosRetry from "axios-retry";
import { getEnvironmentVariables } from "../../../../environment/config";
// import { mockDLTMonthlyValidationDataResponse } from "../../../mockData/dlt/mockDLTMonthlyValidationData";

// Configure axios to retry requests
axiosRetry(axios, {
  retries: 2,
  retryCondition: (error) => error.response.status >= 500,
  retryDelay: (retryCount) => {
    console.log(`Fetching Guideline Form - Retry attempt: ${retryCount}`);
    return retryCount * 1000; // Exponential backoff
  },
});

/* Helper to get DLT Monthly Validation Data - ICD Code*/
async function getDLTMonthlyValidationICDCode(gpiCode) {
  try {
    if(!gpiCode) {
      console.warn("No GPI code provided for fetching Monthly Validation ICD Codes.");
      return null;
    }

    console.log("Attempting to get the DLT Monthly Validation Data.");
    const { AUTO_NOTE_BACKEND } = getEnvironmentVariables();
    const dltMonthlyValidationDataResponse = await axios.get(
      `${AUTO_NOTE_BACKEND}/dlt-monthly-validation-data/${gpiCode}`,
      { timeout: 60000 }
    );

    let dltMonthlyValidationDataResponseData = dltMonthlyValidationDataResponse?.data || null;

    if(window.location.href.includes("localhost")) {
      // TODO: this is only for local testing, remove when done testing
      // dltMonthlyValidationDataResponseData = mockDLTMonthlyValidationDataResponse;
    }

    const dltValidationICDCode = dltMonthlyValidationDataResponseData?.data?.[0]?.dlt_validation_icd_code || null;

    return dltValidationICDCode;
  } catch (error) {
    console.error("Error fetching DLT Monthly Validation Data: ", error);

    return null;
  }
}

export default getDLTMonthlyValidationICDCode;
