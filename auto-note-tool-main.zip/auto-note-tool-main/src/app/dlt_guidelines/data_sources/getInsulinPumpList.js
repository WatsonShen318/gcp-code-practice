import axios from "axios";
// eslint-disable-next-line import/no-extraneous-dependencies
import axiosRetry from "axios-retry";
import { getEnvironmentVariables } from "../../../../environment/config";
// import { mockInsulinPumpTargetListResponse } from "../../../mockData/dlt/mockInsulinPumpTargetList";

// Configure axios to retry requests
axiosRetry(axios, {
  retries: 2,
  retryCondition: (error) => error.response.status >= 500,
  retryDelay: (retryCount) => {
    console.log(`Fetching Insuling Pump List Form - Retry attempt: ${retryCount}`);
    return retryCount * 1000; // Exponential backoff
  },
});

/* Helper to get Insulin Pump List*/
async function getInsulinPumpList() {
  try {
    console.log("Attempting to get the Insuling Pump List response.");
    const { AUTO_NOTE_BACKEND } = getEnvironmentVariables();
    const insulinPumpListResponse = await axios.get(
      `${AUTO_NOTE_BACKEND}/insulin-pump-target-list`,
      { timeout: 60000 }
    );

    let insulinPumpListResponseData = insulinPumpListResponse?.data || null;

    if(window.location.href.includes("localhost")) {
      // TODO: this is only for local testing, remove when done testing
      // insulinPumpListResponseData = mockInsulinPumpTargetListResponse;
    }

    const insulinPumpList = insulinPumpListResponseData?.data || [];

    return insulinPumpList;
  } catch (error) {
    console.error("Error fetching insulin pump list data: ", error);

    return null;
  }
}

export default getInsulinPumpList;
