import axios from "axios";
// eslint-disable-next-line import/no-extraneous-dependencies
import axiosRetry from "axios-retry";
import { getEnvironmentVariables } from "../../../../environment/config";
// import { mockSearchDrugListResponse } from "../../../mockData/dlt/mockSearchDrugList";

// Configure axios to retry requests
axiosRetry(axios, {
  retries: 2,
  retryCondition: (error) => error.response.status >= 500,
  retryDelay: (retryCount) => {
    console.log(`Fetching Drug List - Retry attempt: ${retryCount}`);
    return retryCount * 1000; // Exponential backoff
  },
});

/* Helper to get Drug List Form for handling edge cases where no guideline is mapped */
async function getDrugList(searchStr) {
  try {
     if(!searchStr) {
      console.warn("No search string provided for fetching drug list.");
      return null;
    }

    console.log("Attempting to get the drug list response.");
    const { AUTO_NOTE_BACKEND } = getEnvironmentVariables();
    const drugListResponse = await axios.post(
      `${AUTO_NOTE_BACKEND}/drug-guideline-mapping/search-drug-list`,
      {
        searchDrugName: searchStr 
      },
      { timeout: 60000 }
    );

    let drugListResponseData = drugListResponse?.data || null;

    if(window.location.href.includes("localhost")) {
      // TODO: this is only for local testing, remove when done testing
      // drugListResponseData = mockSearchDrugListResponse;
    }

    const drugList = drugListResponseData?.data || [];

    // Commenting out session storage for drug list as it's not being used currently
    // sessionStorage.setItem("dltAutomationDrugList", JSON.stringify(drugList));

    return drugList;
  } catch (error) {
    console.error("Error fetching drug list data: ", error);

    // Commenting out session storage for drug list as it's not being used currently
    // sessionStorage.setItem("dltAutomationDrugList", null);
    return null;
  }
}

export default getDrugList;
