import { setDecisionRoutingForGLFields } from "../guidelines/guideline.display";
import { approvedDiagnosis, decisionRouting, diagnosis, prescriberIndicatedFormAltsLessEff, prescriberIndicatedFormAltsProduceAdvAffects } from "../qsets/fields";
import { clearInput } from "../utils/clearInput";
import { toggleDisplay } from "../utils/notetool.display";
import { routeTechCasesToRFI } from "./helpers";
import { suppressNextMsgDecision, clearSuppressNextMsgDecision } from "../decision/decision.dialog";

export function handleApproveDiagoQ(role, origin, answer) {
  if (sessionStorage.getItem("isDLTGuidelineFormAutomated") === "true") {
    if (role === "tech" && ["Queue", "TAT"].includes(origin)) {
      if (answer === "No") {
        setDecisionRoutingForGLFields(role, origin, "Forward to Clinical", false);
        toggleFollowupDLTQuestions(role, origin, "disable", "approveDiagoQ");
      } else {
        setDecisionRoutingForGLFields(role, origin, "");
        toggleFollowupDLTQuestions(role, origin, "enable", "approveDiagoQ");
      }
    } else if (role === "tech" && origin === "IBC") {
      if (answer === "No") {
        setDecisionRoutingForGLFields(role, origin, "Forward to Clinical", false);
        toggleFollowupDLTQuestions(role, origin, "disable", "approveDiagoQ");
      } else {
        setDecisionRoutingForGLFields(role, origin, "");
        toggleFollowupDLTQuestions(role, origin, "enable", "approveDiagoQ");
      }
    }
    sessionStorage.setItem("dltFinalApprovableDiagnosisFieldAns", answer);
  }
}

export function handleLicsAndROA(role, origin, answer) {
  // If yes, skip to question 3. If no, continue to question 2
  if (answer === "Yes") {
    toggleDisplay("solo", [`${role}${origin}rejectWithA6Q`], "disable");
  } else if (answer === "No") {
    toggleDisplay("solo", [`${role}${origin}rejectWithA6Q`], "enable");
  }
  sessionStorage.setItem("dltFinalLICSAndROAFieldAns", answer);
}

export function handleRejectWithA6(role, origin, answer) {
  if (answer === "No") {
    toggleDisplay(
      "solo",
      [`${role}${origin}drugFromPhysicianStockQ`],
      "disable"
    );
  } else if (answer === "Yes") {
    toggleDisplay(
      "solo",
      [`${role}${origin}drugFromPhysicianStockQ`],
      "enable"
    );
  }
  sessionStorage.setItem("dltFinalRejectWithA6FieldAns", answer);
}

export function handleDrugFromPhysicianStock(role, origin, answer) {
  if (answer === "Yes") {
    setDecisionRoutingForGLFields(role, origin, "Forward to Clinical");
    toggleFollowupDLTQuestions(
      role,
      origin,
      "disable",
      "drugFromPhysicianStockQ"
    );
  } else if (answer === "No") {
    setDecisionRoutingForGLFields(role, origin, "");
    toggleFollowupDLTQuestions(
      role,
      origin,
      "enable",
      "drugFromPhysicianStockQ"
    );
  }
}

export function handleInsulinPumpMedication(role, origin, answer) {
  if (answer === "Yes") {
    setDecisionRoutingForGLFields(role, origin, "Forward to Clinical");
    toggleFollowupDLTQuestions(
      role,
      origin,
      "disable",
      "insulinPumpMedicationQ"
    );
  } else if (answer === "No") {
    setDecisionRoutingForGLFields(role, origin, "");
    toggleFollowupDLTQuestions(
      role,
      origin,
      "enable",
      "insulinPumpMedicationQ"
    );
  }
  sessionStorage.setItem("dltFinalInsulinPumpMedicationFieldAns", answer);
}

/* Tech IBC specific handler */
export function handleCallerProvidedClinicalInfo(role, origin, answer) {
  // callerProvidedClinicalInfoQ is not associated with dltGuideline tag, so not toggling followup DLT questions for now
  if (answer === "No") {
    setDecisionRoutingForGLFields(role, origin, "Sent to RFI");
    // toggleFollowupDLTQuestions(
    //   role,
    //   origin,
    //   "disable",
    //   "callerProvidedClinicalInfoQ"
    // );
  } else if (answer === "Yes") {
    const decisionRoutingValue = decisionRouting(role, origin, "value");
    // Resetting Decision Routing value only if automated value is 'Sent to RFI' when it was automated by "Is the caller able to provide Clinical information?"
    if (decisionRoutingValue === "Sent to RFI") {
      setDecisionRoutingForGLFields(role, origin, "");
    }

    // toggleFollowupDLTQuestions(
    //   role,
    //   origin,
    //   "enable",
    //   "callerProvidedClinicalInfoQ"
    // );
  }
}

export function handleDltShow0TFAlts(role, origin, answer) {
  sessionStorage.setItem("dltFinalShow0TFAltsQAnswer", answer || "");
  if(answer === "Yes") {
    const diagnosisValue = diagnosis(role, origin, "value");
    const approveDiagValue = approvedDiagnosis(role, origin, "value");
    if(!diagnosisValue || diagnosisValue === "N/A") {
      setDecisionRoutingForGLFields(role, origin, "Sent to RFI", false);
    } else if (diagnosisValue) {
      if(approveDiagValue === "Yes") {
        setDecisionRoutingForGLFields(role, origin, "Approved", false);
      } else if(approveDiagValue === "No") {
        setDecisionRoutingForGLFields(role, origin, "Forward to Clinical", false);
      } else if(approveDiagValue === "N/A") {
        setDecisionRoutingForGLFields(role, origin, "Sent to RFI", false);
      }
      // Empty approveDiag means the field is pending — don't change routing
    }
    toggleDisplay("solo", [`${role}${origin}spprtStmtRDxRequired`], "enable");
    toggleFollowupDLTQuestions(
      role,
      origin,
      "disable",
      "dltShow0TFAltsQ"
    );
  } else {
    const decisionRoutingValue = decisionRouting(role, origin, "value");
    if(["Approved", "Forward to Clinical", "Sent to RFI"].includes(decisionRoutingValue)) {
      setDecisionRoutingForGLFields(role, origin, "");
    }
    toggleDisplay("solo", [`${role}${origin}spprtStmtRDxRequired`], "disable");
    toggleFollowupDLTQuestions(
      role,
      origin,
      "enable",
      "dltShow0TFAltsQ"
    );
  }
}

export function handlePrescriberProvidedSpprtStmt(role, origin, answer) {
  // Placeholder for future logic
}

/* Tech IBC specific handler */
export function handleClinicalCallerProvidedSpprtStmt(role, origin, answer) {
  // Placeholder for future logic
}

export function handlePatientIsStableOnRqstDrug(role, origin, answer) {
  if (answer === "Yes") {
    setDecisionRoutingForGLFields(role, origin, "Approved");
    toggleFollowupDLTQuestions(
      role,
      origin,
      "disable",
      "patientIsStableOnRqstDrugQ"
    );
  } else if (answer === "No") {
    const decisionRoutingValue = decisionRouting(role, origin, "value");
    // Resetting Decision Routing value only if automated value is 'Approved' when it was automated by "Has the prescriber indicated that the patient is stable on the requested drug?"
    if (decisionRoutingValue === "Approved") {
      setDecisionRoutingForGLFields(role, origin, "");
    }
    toggleFollowupDLTQuestions(
      role,
      origin,
      "enable",
      "patientIsStableOnRqstDrugQ"
    );
  }
}

export function handleMemberTakingPlavix(role, origin, answer) {
  // If yes, continue to question 11. If no, skip to question 12.
  if (answer === "Yes") {
    toggleDisplay(
      "solo",
      [`${role}${origin}triedExclOmprzlOrEsmprzlQ`],
      "enable"
    );
  } else if (answer === "No") {
    toggleDisplay(
      "solo",
      [`${role}${origin}triedExclOmprzlOrEsmprzlQ`],
      "disable"
    );
  }
}

export function handleTriedExclOmprzlOrEsmprzl(role, origin, answer) {
  if (answer === "Yes") {
    setDecisionRoutingForGLFields(role, origin, "Approved");
    toggleFollowupDLTQuestions(
      role,
      origin,
      "disable",
      "triedExclOmprzlOrEsmprzlQ"
    );
  } else if (answer === "No") {
    const decisionRoutingValue = decisionRouting(role, origin, "value");
    // Resetting Decision Routing value only if automated value is 'Approved' when it was automated by "If the member is taking Plavix..  field?"
    if (decisionRoutingValue === "Approved") {
      setDecisionRoutingForGLFields(role, origin, "");
    }
    toggleFollowupDLTQuestions(
      role,
      origin,
      "enable",
      "triedExclOmprzlOrEsmprzlQ"
    );
  }
}

export function handleMemberIsStableOnRqstDrug(role, origin, answer) {
  // If yes, Approve case. If no, continue to question 14.
  if (answer === "Yes") {
    setDecisionRoutingForGLFields(role, origin, "Approved");
    toggleFollowupDLTQuestions(
      role,
      origin,
      "disable",
      "memberIsStableOnRqstDrugQ"
    );
  } else if (answer === "No") {
    const decisionRoutingValue = decisionRouting(role, origin, "value");
    // Resetting Decision Routing value only if automated value is 'Approved' when it was automated by "Has the prescriber indicated that the member is stable on the requested drug?"
    if (decisionRoutingValue === "Approved") {
      setDecisionRoutingForGLFields(role, origin, "");
    }
    toggleFollowupDLTQuestions(
      role,
      origin,
      "enable",
      "memberIsStableOnRqstDrugQ"
    );
  }
}

export function handleInfectionIsDrugRstnt(role, origin, answer) {
  // If yes, Approve case. If no, continue to question 15.
  if (answer === "Yes") {
    setDecisionRoutingForGLFields(role, origin, "Approved");
    toggleFollowupDLTQuestions(
      role,
      origin,
      "disable",
      "infectionIsDrugRstntQ"
    );
  } else if (answer === "No") {
    const decisionRoutingValue = decisionRouting(role, origin, "value");
    // Resetting Decision Routing value only if automated value is 'Approved' when it was automated by "Has the prescriber indicated that the infection is drug resistant OR the infection is not sensitive to other drugs, as verified by culture study?"
    if (decisionRoutingValue === "Approved") {
      setDecisionRoutingForGLFields(role, origin, "");
    }
    toggleFollowupDLTQuestions(role, origin, "enable", "infectionIsDrugRstntQ");
  }
}

export function handleMedicationGreaterThan7DaySupply(role, origin, answer) {
  // If yes, continue to question 8. If no, Forward to Clinical Review. If N/A, Forward to RFI
  if (answer === "No") {
    setDecisionRoutingForGLFields(role, origin, "Forward to Clinical");
    toggleFollowupDLTQuestions(
      role,
      origin,
      "disable",
      "medicationGreaterThan7DaySupplyQ"
    );
  } else if (answer === "N/A") {
    setDecisionRoutingForGLFields(role, origin, "Sent to RFI");
    toggleFollowupDLTQuestions(
      role,
      origin,
      "disable",
      "medicationGreaterThan7DaySupplyQ"
    );
  } else if (answer === "Yes") {
    const decisionRoutingValue = decisionRouting(role, origin, "value");
    // Resetting Decision Routing value only if automated value is 'Forward to Clinical' or 'Sent to RFI' when it was automated by "Is greater than a 7 day supply of this medication medically necessary for this patient?"
    if (["Forward to Clinical", "Sent to RFI"].includes(decisionRoutingValue)) {
      setDecisionRoutingForGLFields(role, origin, "");
    }
    toggleFollowupDLTQuestions(
      role,
      origin,
      "enable",
      "medicationGreaterThan7DaySupplyQ"
    );
  }
}

export function handleOralChemotherapyUsedForCancer(role, origin, answer) {
  // If yes, continue to question 2. If no, skip to question 3.
  if (answer === "Yes") {
    toggleDisplay(
      "solo",
      [`${role}${origin}oralChemotherapyUsedForSameIndicationQ`],
      "enable"
    );
  } else if (answer === "No") {
    toggleDisplay(
      "solo",
      [`${role}${origin}oralChemotherapyUsedForSameIndicationQ`],
      "disable"
    );
  }
}

export function handleOralChemotherapyUsedForSameIndication(
  role,
  origin,
  answer
) {
  // If yes, Forward to Clinical Review. If no, continue to question 3.
  if (answer === "Yes") {
    setDecisionRoutingForGLFields(role, origin, "Forward to Clinical");
    toggleFollowupDLTQuestions(
      role,
      origin,
      "disable",
      "oralChemotherapyUsedForSameIndicationQ"
    );
  } else if (answer === "No") {
    const decisionRoutingValue = decisionRouting(role, origin, "value");
    // Resetting Decision Routing value only if automated value is 'Approved' when it was automated by "Has the prescriber indicated that the patient is currently taking and is stable on the requested drug?"
    if (decisionRoutingValue === "Forward to Clinical") {
      setDecisionRoutingForGLFields(role, origin, "");
    }
    toggleFollowupDLTQuestions(
      role,
      origin,
      "enable",
      "oralChemotherapyUsedForSameIndicationQ"
    );
  }
}

export function handlePatientIsTakingNStableOnRqstDrug(role, origin, answer) {
  // If yes, Approve case. If no, continue to question 11.
  if (answer === "Yes") {
    setDecisionRoutingForGLFields(role, origin, "Approved");
    toggleFollowupDLTQuestions(
      role,
      origin,
      "disable",
      "patientIsTakingNStableOnRqstDrugQ"
    );
  } else if (answer === "No") {
    const decisionRoutingValue = decisionRouting(role, origin, "value");
    // Resetting Decision Routing value only if automated value is 'Approved' when it was automated by "Has the prescriber indicated that the patient is currently taking and is stable on the requested drug?"
    if (decisionRoutingValue === "Approved") {
      setDecisionRoutingForGLFields(role, origin, "");
    }
    toggleFollowupDLTQuestions(
      role,
      origin,
      "enable",
      "patientIsTakingNStableOnRqstDrugQ"
    );
  }
}

export function handlePrescriberIndicatedFormAltsLessEff(role, origin, answer) {
  if (answer === "Yes") {
    if(routeTechCasesToRFI(role, origin)) {
      setDecisionRoutingForGLFields(role, origin, "Sent to RFI");
    } else {
      setDecisionRoutingForGLFields(role, origin, "Approved");
    }
    toggleFollowupDLTQuestions(
      role,
      origin,
      "disable",
      "prescriberIndicatedFormAltsLessEffQ"
    );
  } else if (answer === "No" || answer === "N/A") {
    const decisionRoutingValue = decisionRouting(role, origin, "value");
    // Resetting Decision Routing value only if automated value is 'Approved' when it was automated by "Has the prescriber specifically indicated that the formulary alternatives would be less effective than the requested drug?"
    if (["Approved", "Sent to RFI", "Forward to Clinical"].includes(decisionRoutingValue)) {
      setDecisionRoutingForGLFields(role, origin, "");
    }
    toggleFollowupDLTQuestions(
      role,
      origin,
      "enable",
      "prescriberIndicatedFormAltsLessEffQ"
    );
  }
}

export function handlePrescriberIndicatedFormAltsProduceAdvAffects(
  role,
  origin,
  answer
) {
  if (answer === "Yes") {
    if(routeTechCasesToRFI(role, origin)) {
      setDecisionRoutingForGLFields(role, origin, "Sent to RFI");
    } else {
      setDecisionRoutingForGLFields(role, origin, "Approved");
    }
    toggleFollowupDLTQuestions(
      role,
      origin,
      "disable",
      "prescriberIndicatedFormAltsProduceAdvAffectsQ"
    );
  } else if (answer === "No" || answer === "N/A") {
    const decisionRoutingValue = decisionRouting(role, origin, "value");
    // Resetting Decision Routing value only if automated value is 'Approved' when it was automated by "Has the prescriber specifically indicated that the formulary alternatives would likely produce ANY adverse effects for the member?"
    if (["Approved", "Sent to RFI", "Forward to Clinical"].includes(decisionRoutingValue)) {
      setDecisionRoutingForGLFields(role, origin, "");
    }
    toggleFollowupDLTQuestions(
      role,
      origin,
      "enable",
      "prescriberIndicatedFormAltsProduceAdvAffectsQ"
    );
  }
}

export function handleTriedNFailedFormAlts(role, origin, answer) {
  sessionStorage.setItem("dltFinalTriedNFailedFormAltsQAnswer", answer || "");
  if(routeTechCasesToRFI(role, origin)) {
    setDecisionRoutingForGLFields(role, origin, "Sent to RFI");
    toggleFollowupDLTQuestions(
      role,
      origin,
      "disable",
      "triedNFailedFormAltsQ"
    );
    return;
  }

  if (answer === "Yes") {
    setDecisionRoutingForGLFields(role, origin, "Approved", false);
    toggleFollowupDLTQuestions(
      role,
      origin,
      "disable",
      "triedNFailedFormAltsQ"
    );
  } else if (answer === "No") {
    const decisionRoutingValue = decisionRouting(role, origin, "value");
    // Resetting Decision Routing value only if automated value is 'Approved' when it was automated by "Has the member tried and failed a sufficient number of formulary alternatives for approval?"
    if (["Approved", "Sent to RFI", "Forward to Clinical"].includes(decisionRoutingValue)) {
      setDecisionRoutingForGLFields(role, origin, "");
    }
    toggleFollowupDLTQuestions(role, origin, "enable", "triedNFailedFormAltsQ");
  } else if (answer === "N/A") {
    const decisionRoutingValue = decisionRouting(role, origin, "value");
    const prescriberIndicatedFormAltsLessEffValue = prescriberIndicatedFormAltsLessEff(role, origin, "value");
    const prescriberIndicatedFormAltsProduceAdvAffectsValue = prescriberIndicatedFormAltsProduceAdvAffects(role, origin, "value");
    if(prescriberIndicatedFormAltsLessEffValue === "N/A" && prescriberIndicatedFormAltsProduceAdvAffectsValue === "N/A") {
      setDecisionRoutingForGLFields(role, origin, "Sent to RFI");
    } else {
      setDecisionRoutingForGLFields(role, origin, "");
    }
  }
}

export function handleTypeOfQlReview(role, origin, answer) {
  // No logic yet — future: automate approved QL questions based on MDD paid claims data
}

export function handlePrescriberIndicatedApprovedFormularyQuantityLimitIneffective(role, origin, answer) {
  // Capture final answer for audit - field is not DLT-automated; automated key stays as placeholder ''
  sessionStorage.setItem("dltFinalPrescriberIndicatedQlIneffectiveFieldAns", answer || "");
  // If yes, Approve case. If no, continue to question 8.
  if (answer === "Yes") {
    setDecisionRoutingForGLFields(role, origin, "Approved");
    toggleFollowupDLTQuestions(
      role,
      origin,
      "disable",
      "prescriberIndicatedApprovedFormularyQuantityLimitIneffectiveQ"
    );
  } else if (answer === "No") {
    const decisionRoutingValue = decisionRouting(role, origin, "value");
    if (["Approved"].includes(decisionRoutingValue)) {
      setDecisionRoutingForGLFields(role, origin, "");
    }
    toggleFollowupDLTQuestions(
      role,
      origin,
      "enable",
      "prescriberIndicatedApprovedFormularyQuantityLimitIneffectiveQ"
    );
  }
}

export function handlePrescriberIndicatedApprovedDosesIneffective(role, origin, answer) {
  // If yes, Approve case. If no, continue to question 9
  if (answer === "Yes") {
    setDecisionRoutingForGLFields(role, origin, "Approved");
    toggleFollowupDLTQuestions(
      role,
      origin,
      "disable",
      "prescriberIndicatedApprovedDosesIneffectiveQ"
    );
  } else if (answer === "No") {
    const decisionRoutingValue = decisionRouting(role, origin, "value");
    if (["Approved"].includes(decisionRoutingValue)) {
      setDecisionRoutingForGLFields(role, origin, "");
    }
    toggleFollowupDLTQuestions(
      role,
      origin,
      "enable",
      "prescriberIndicatedApprovedDosesIneffectiveQ"
    );
  }
}

/* Helper function to determine if a field should be skipped */
function shouldSkipField(
  field,
  guidelineForm,
  bvdHepB,
  bvdImmuno,
  bvdESRDInfusion,
  bvdESRDOnly,
  bvdInfusionOnly,
  bvdParenteral,
  bvdInhalation,
  bvdIVIG,
  bvdOralAntiemetics,
  mode,
  role,
  origin
) {
  // Standard guideline checks
  if (
    guidelineForm !== "Standard Non-Formulary Exception Guideline" &&
    field === "insulinPumpMedicationQ"
  ) {
    return true;
  }

  if (
    ![
      "Protected Drug Class Non-Formulary Exception Guideline",
      "Diagnosis Required Protected Drug Classes Non-Formulary Exception Guideline",
    ].includes(guidelineForm) &&
    field === "patientIsStableOnRqstDrugQ"
  ) {
    return true;
  }

  if (
    guidelineForm !==
      "Proton Pump Inhibitor Non-Formulary Exception Guideline" &&
    ["memberTakingPlavixQ", "triedExclOmprzlOrEsmprzlQ"].includes(field)
  ) {
    return true;
  }

  if (
    guidelineForm !== "Antibacterials Non-Formulary Exception Guideline" &&
    ["memberIsStableOnRqstDrugQ", "infectionIsDrugRstntQ"].includes(field)
  ) {
    return true;
  }

  if (
    ![
      "Opioid Non-Formulary Guideline",
      "Diagnosis Required Opioid Non-Formulary Exception Guideline",
      "Opioid Quantity Limit - 925 Guideline",
    ].includes(guidelineForm) &&
    field === "medicationGreaterThan7DaySupplyQ"
  ) {
    return true;
  }

  if (
    ![
      "High Risk Drug Class Non-Formulary Exception Guideline",
      "Diagnosis Required Oral Chemotherapy Non-Formulary Exception Guideline",
    ].includes(guidelineForm) &&
    field === "patientIsTakingNStableOnRqstDrugQ"
  ) {
    return true;
  }

  if (
    ![
      "Diagnosis Required Oral Chemotherapy Non-Formulary Exception Guideline",
      "BvD Non-Formulary (Oral Chemotherapy) Exception Guideline",
    ].includes(guidelineForm) &&
    [
      "oralChemotherapyUsedForCancerQ",
      "oralChemotherapyUsedForSameIndicationQ",
    ].includes(field)
  ) {
    return true;
  }

  // BvD guideline checks
  if (
    guidelineForm.includes("BvD Non-Formulary") &&
    ["licsAndROAQ", "rejectWithA6Q", "drugFromPhysicianStockQ"].includes(field)
  ) {
    return true;
  }

  if (
    !guidelineForm.includes("BvD Non-Formulary") &&
    ["licsMemberQ", "rejectWithA4orA6Q"].includes(field)
  ) {
    return true;
  }

  // BvD specific template checks
  if (
    guidelineForm.includes("BvD Non-Formulary") &&
    [...bvdHepB, ...bvdImmuno].includes(field) &&
    mode === "enable"
  ) {
    return true;
  }

  if (
    !(
      guidelineForm.includes("BvD Non-Formulary (ESRD)") ||
      guidelineForm.includes("BvD Non-Formulary (Infusion)")
    ) &&
    bvdESRDInfusion.includes(field)
  ) {
    return true;
  }

  if (
    !guidelineForm.includes("BvD Non-Formulary (ESRD)") &&
    guidelineForm.includes("BvD Non-Formulary (Infusion)") &&
    bvdESRDOnly.includes(field)
  ) {
    return true;
  }

  if (
    !guidelineForm.includes("BvD Non-Formulary (Hepatitis B)") &&
    bvdHepB.includes(field)
  ) {
    return true;
  }

  if (
    !guidelineForm.includes("BvD Non-Formulary (Immunosuppressant)") &&
    bvdImmuno.includes(field)
  ) {
    return true;
  }

  if (
    !guidelineForm.includes("BvD Non-Formulary (Parenteral Nutrition)") &&
    bvdParenteral.includes(field)
  ) {
    return true;
  }

  if (
    !guidelineForm.includes("BvD Non-Formulary (Inhalation)") &&
    bvdInhalation.includes(field)
  ) {
    return true;
  }

  if (
    !guidelineForm.includes("BvD Non-Formulary (IVIG)") &&
    bvdIVIG.includes(field)
  ) {
    return true;
  }

  if (
    !guidelineForm.includes("BvD Non-Formulary (Oral Antiemetics)") &&
    bvdOralAntiemetics.includes(field)
  ) {
    return true;
  }

  // Skip questions not relevant to quantity limit guidelines
  if(guidelineForm.includes("Quantity") && ["licsMemberQ", "rejectWithA4orA6Q",  "licsAndROAQ", "rejectWithA6Q", "drugFromPhysicianStockQ", "prescriberIndicatedFormAltsLessEffQ", "prescriberIndicatedFormAltsProduceAdvAffectsQ", "triedNFailedFormAltsQ", "dltShow0TFAltsQ"].includes(field)) {
    return true;
  } else if(guidelineForm.includes("Opioid") && ["typeOfQlReviewQ", "prescriberIndicatedApprovedFormularyQuantityLimitIneffectiveQ", "prescriberIndicatedApprovedDosesIneffectiveQ"].includes(field)) {
    return true;
  } else if(!guidelineForm.includes("Quantity") && ["typeOfQlReviewQ", "prescriberIndicatedApprovedFormularyQuantityLimitIneffectiveQ", "prescriberIndicatedApprovedDosesIneffectiveQ"].includes(field)) {
    return true;
  }

  // QL-specific fields must only appear when request reason is Quantity Limit
  if (["typeOfQlReviewQ", "prescriberIndicatedApprovedFormularyQuantityLimitIneffectiveQ", "prescriberIndicatedApprovedDosesIneffectiveQ"].includes(field)) {
    const rqstReason = (document.getElementById(`${role}${origin}rqstReasonQsel`)?.value || '').toLowerCase();
    if (!rqstReason.includes('quantity limit')) return true;
  }

  return false;
}

/* Helper function to get automation action for a field */
function getAutomationAction(field, role, origin) {
  if (field === "licsAndROAQ") {
    const answer = sessionStorage.getItem("dltAutomatedLICSAndROAFieldAns");
    if (["Yes", "No"].includes(answer)) {
      return {
        field,
        execute: () => {
          const fieldElem = document.getElementById(`${role}${origin}${field}`);
          const answerElem = document.getElementById(
            `${role}${origin}${field}${answer}`
          );
          if (answerElem) {
            answerElem.click();
            fieldElem.disabled = true;
          }
        },
      };
    }
  } else if (field === "rejectWithA6Q") {
    const answer = sessionStorage.getItem("dltAutomatedRejectWithA6FieldAns");
    if (["Yes", "No"].includes(answer)) {
      return {
        field,
        execute: () => {
          const answerElem = document.getElementById(
            `${role}${origin}${field}${answer}`
          );
          if (answerElem) {
            answerElem.click();
          }
        },
      };
    }
  } else if (field === "insulinPumpMedicationQ") {
    const answer = sessionStorage.getItem(
      "dltAutomatedInsulinPumpMedicationFieldAns"
    );
    if (["Yes", "No"].includes(answer)) {
      return {
        field,
        shouldStopTreeBuilding: answer === "Yes",
        execute: () => {
          const fieldElem = document.getElementById(`${role}${origin}${field}`);
          const answerElem = document.getElementById(
            `${role}${origin}${field}${answer}`
          );
          if (answerElem) {
            answerElem.click();
            fieldElem.disabled = answer !== "Yes";
          }
        },
      };
    }
  } else if (field === "licsMemberQ") {
    const answer = sessionStorage.getItem("dltAutomatedBvDLICSMemberFieldAns");
    if (["Yes", "No"].includes(answer)) {
      return {
        field,
        execute: () => {
          const fieldElem = document.getElementById(`${role}${origin}${field}`);
          const answerElem = document.getElementById(
            `${role}${origin}${field}${answer}`
          );
          if (answerElem) {
            answerElem.click();
            fieldElem.disabled = false;
          }
        },
      };
    }
  } else if (field === "rejectWithA4orA6Q") {
    const licsMemberAnswer = sessionStorage.getItem(
      "dltAutomatedBvDLICSMemberFieldAns"
    );
    if (licsMemberAnswer === "No") {
      const answer = sessionStorage.getItem(
        "dltAutomatedBvDRejectWithA4orA6FieldAns"
      );
      if (["Yes", "No"].includes(answer)) {
        return {
          field,
          execute: () => {
            const answerElem = document.getElementById(
              `${role}${origin}${field}${answer}`
            );
            if (answerElem) {
              answerElem.click();
            }
          },
        };
      }
    }
  } else if (field === "injectableAgentRequestQ") {
    const answer = sessionStorage.getItem(
      "dltAutomatedBvDESRDInjectableAgentRequestFieldAns"
    );
    if (["Yes", "No"].includes(answer)) {
      return {
        field,
        execute: () => {
          const answerElem = document.getElementById(
            `${role}${origin}${field}${answer}`
          );
          if (answerElem) {
            answerElem.click();
          }
        },
      };
    }
  } else if (
    [
      "requestForAsthmaOrObstructivePulmonaryDiseaseQ",
      "requestForDornaseAlphaPulmozymeQ",
      "patientHasCysticFibrosisQ",
      "requestForTobramycinInhalationSolutionQ",
      "patientHasCysticFibrosisOrBronchiectasisQ",
      "requestForAcetylcysteineQ",
      "persistentThickPulmonarySecretionsQ",
      "requestForNebupentQ",
      "patientHasHIVPneumocystosisOrComplicationsOfOrganTransplantsQ",
      "requestForTyvasoOrVentavisQ",
      "patientHasPulmonaryArteryHypertensionQ",
      "bvdDiagnosisProvidedQ",
    ].includes(field)
  ) {
    const answer = sessionStorage.getItem(
      `dltAutomatedBvDINHALATION${field}FieldAns`
    );
    if (["Yes", "No"].includes(answer)) {
      return {
        field,
        execute: () => {
          const answerElem = document.getElementById(
            `${role}${origin}${field}${answer}`
          );
          const elem = document.getElementById(
            `${role}${origin}${field}`
          );
          if (answerElem) {
            answerElem.click();
            if([
              "requestForDornaseAlphaPulmozymeQ",
              "requestForTobramycinInhalationSolutionQ",
              "requestForAcetylcysteineQ",
              "requestForNebupentQ",
              "requestForTyvasoOrVentavisQ",
            ].includes(field)){
              elem.disabled = true;
            }
          }
        },
      };
    }
  } else if (
    [
      "patientReceivingMedicationForPrimaryImmuneDeficiencyDiseaseQ",
      "requestForHizentraOrHyQviaQ",
      "patientReceivingMedicationForCIDPQ",
      "bvdDiagnosisProvidedIVIGQ",
    ].includes(field)
  ) {
    const answer = sessionStorage.getItem(
      `dltAutomatedBvDIVIG${field}FieldAns`
    );
    if (["Yes", "No"].includes(answer)) {
      return {
        field,
        execute: () => {
          const answerElem = document.getElementById(
            `${role}${origin}${field}${answer}`
          );
          const elem = document.getElementById(
            `${role}${origin}${field}`
          );
          if (answerElem) {
            answerElem.click();
            if([
              "requestForHizentraOrHyQviaQ",
            ].includes(field)){
              elem.disabled = true;
            }
          }
        },
      };
    }
  } else if (
    [
     "requestForVarubiEmendOrAkynzeoQ",
      "requestForAkynzeoQ"
    ].includes(field)
  ) {
    const answer = sessionStorage.getItem(
      `dltAutomatedBvDORALANTIEMETICS${field}FieldAns`
    );
    if (["Yes", "No"].includes(answer)) {
      return {
        field,
        execute: () => {
          const answerElem = document.getElementById(
            `${role}${origin}${field}${answer}`
          );
          const elem = document.getElementById(
            `${role}${origin}${field}`
          );
          if (answerElem) {
            answerElem.click();
            elem.disabled = true;
          }
        },
      };
    }
  } else if (field === "dltShow0TFAltsQ") {
    const answer = sessionStorage.getItem("dltAutomatedShow0TFAltsQAnswer");
    if (["Yes", "No"].includes(answer)) {
      return {
        field,
        execute: () => {
          const answerElem = document.getElementById(`${role}${origin}${field}${answer}`);
          if (answerElem) {
            answerElem.click();
          }
        },
      };
    }
  } else if (field === "triedNFailedFormAltsQ") {
    const answer = sessionStorage.getItem("dltAutomatedTriedNFailedFormAltsQAnswer");
    if (["Yes", "No"].includes(answer)) {
      return {
        field,
        execute: () => {
          const answerElem = document.getElementById(`${role}${origin}${field}${answer}`);
          if (answerElem) {
            answerElem.checked = true;
            // Suppress the next message decision to prevent unnecessary alerts
            suppressNextMsgDecision();
            handleTriedNFailedFormAlts(role, origin, answer);
            clearSuppressNextMsgDecision();
          }
        },
      };
    }
  } else if (field === "prescriberIndicatedApprovedFormularyQuantityLimitIneffectiveQ") {
    const answer = sessionStorage.getItem("dltAutomatedPrescriberIndicatedQlIneffectiveFieldAns");
    if (answer === "Yes") {
      return {
        field,
        execute: () => {
          const answerElem = document.getElementById(`${role}${origin}${field}${answer}`);
          if (answerElem) {
            answerElem.click();
          }
        },
      };
    }
  }

  return null;
}

/* Helper function to execute automation actions sequentially */
function executeAutomationActions(actions) {
  actions.forEach((action) => {
    if (action.execute) {
      action.execute();
    }
  });
}

/* Helper to toggle follow-up DLT questions if there are any scenarios to automate Case Decision/Routing */
function _syncPlanQlRef(role, origin, fieldId, mode) {
  const refId = `${role}${origin}planQlRef`;
  const existing = document.getElementById(refId);
  if (mode !== 'enable') {
    if (existing) existing.remove();
    return;
  }
  const planQlValue = document.getElementById(`${role}${origin}qlPlanQlQtxt`)?.value?.trim();
  if (!planQlValue) return;

  let drugName = '';
  try {
    const qlResult = JSON.parse(sessionStorage.getItem('qlLookupResult') || '{}');
    drugName = qlResult?.selectedOption?.drugNameFormStrength
      || qlResult?.options?.[0]?.drugNameFormStrength
      || '';
    if (!drugName) {
      const medhok = JSON.parse(sessionStorage.getItem('originalMedhokResponse') || '{}');
      drugName = medhok?.drugName || '';
    }
    if (!drugName) {
      const manualDrug = JSON.parse(sessionStorage.getItem('manualFlowDrug') || '{}');
      drugName = manualDrug?.drugName || '';
    }
  } catch (_) {}

  const refEl = existing || document.createElement('div');
  if (!existing) {
    refEl.id = refId;
    document.getElementById(fieldId)?.insertAdjacentElement('beforebegin', refEl);
  }
  refEl.className = 'plan-ql-ref';
  refEl.innerHTML = `
    <div class="plan-ql-ref__header">Drug: <strong>${drugName || 'N/A'}</strong></div>
    <div class="plan-ql-ref__row">
      <span class="plan-ql-ref__label">Drug Status:</span>
      <span class="plan-ql-ref__cell">Quantity Limit</span>
    </div>
    <div class="plan-ql-ref__row">
      <span class="plan-ql-ref__label">Quantity Limit:</span>
      <span class="plan-ql-ref__cell">${planQlValue}</span>
    </div>
  `;
}

// Called from quantityLimit.js after verbiage is filled, to handle the case where
// the DLT field was already visible when the QL picker had no value yet.
export function syncPlanQlRefIfVisible(role, origin) {
  const fieldId = `${role}${origin}prescriberIndicatedApprovedFormularyQuantityLimitIneffectiveQ`;
  const fieldset = document.getElementById(fieldId);
  if (!fieldset || fieldset.style.display === 'none') return;
  _syncPlanQlRef(role, origin, fieldId, 'enable');
}

// Called from quantityLimit.js when QL results are reset (drug/formulary change or
// request-reason change) so the ref doesn't show stale data above the prescriber Q.
export function clearPlanQlRef(role, origin) {
  document.getElementById(`${role}${origin}planQlRef`)?.remove();
  document.getElementById(`${role}${origin}qlClaimInfoBanner`)?.remove();
}

export function toggleFollowupDLTQuestions(role, origin, mode, currentId) {
  const bvdHepatitisbFieldsForToggling = ["patientRiskHepatitisBQ"];
  const bvdImmunosuppressantFieldsForToggling = ["transplantIndicatorPresentQ"];
  const bvdESRDOnlyFieldsForToggling = [
    "drugPrescribedBySpecialistQ",
    "drugForESRDQ",
    "injectableAgentRequestQ",
  ];
  const bvdInfusionOnlyFieldsForToggling = [
    "drugAdminViaInfusionPumpQ",
    "drugAdminViaInfusionPumpHomeQ",
    "patientInSkilledNursingFacilityQ",
    "medicarePartAPayingFacilityBedQ",
    "narcoticAnalgesicNonCancerDxQ",
    "drugFromPhysicianStockBvDQ",
  ];
  const bvdESRDNInfusionFieldsForToggling = [
    "drugPrescribedBySpecialistQ",
    "drugForESRDQ",
    "drugAdminViaInfusionPumpQ",
    "drugAdminViaInfusionPumpHomeQ",
    "patientInSkilledNursingFacilityQ",
    "medicarePartAPayingFacilityBedQ",
    "narcoticAnalgesicNonCancerDxQ",
    "injectableAgentRequestQ",
    "drugFromPhysicianStockBvDQ",
  ];
  const bvdParenteralNutritionFieldsForToggling = [
    "parenteralNutritionRequestQ",
    "permanentDysfunctionDigestiveTractQ",
  ];

  const bvdInhalationFieldsForToggling = [
    "patientResidenceCodeQ",
    "patientUsingMedWithNebulizerQ",
    "requestForBetaAgonistSteroidInhalantAnticholinergicOrPDEInhibitorQ",
    "requestForAsthmaOrObstructivePulmonaryDiseaseQ",
    "requestForDornaseAlphaPulmozymeQ",
    "patientHasCysticFibrosisQ",
    "requestForTobramycinInhalationSolutionQ",
    "patientHasCysticFibrosisOrBronchiectasisQ",
    "requestForAcetylcysteineQ",
    "persistentThickPulmonarySecretionsQ",
    "requestForNebupentQ",
    "patientHasHIVPneumocystosisOrComplicationsOfOrganTransplantsQ",
    "requestForTyvasoOrVentavisQ",
    "patientHasPulmonaryArteryHypertensionQ",
    "bvdDiagnosisProvidedQ",
  ];

  const bvdIVIGFieldsForToggling = [
    "medicationReceivedInHomeQ",
    "patientReceivingMedicationForPrimaryImmuneDeficiencyDiseaseQ",
    "requestForHizentraOrHyQviaQ",
    "medicationGivenSubcutaneouslyQ",
    "patientReceivingMedicationForCIDPQ",
    "patientReceivingMedicationInMedicalOfficeOrInfusionCenterQ",
    "requestedDrugSuppliedFromPhysicianOfficeStockIVIGQ",
    "patientResidesInSNFOrSkilledCareFacilityQ",
    "medicarePartAPayingForLTCFacilityBedQ",
    "bvdDiagnosisProvidedIVIGQ",
  ];

  const bvdOralAntiemeticsFieldsForToggling = [
    "requestForVarubiEmendOrAkynzeoQ",
    "oralAntiemeticUsedInChemotherapyQ",
    "oralAntiemeticUsedInChemotherapyReplacementQ",
    "patientRequiresOneOfFollowingQ",
    "requestForAkynzeoQ",
    "requestedDrugUsedInCancerChemotherapyQ",
    "oralAntiemeticFullTherapeuticReplacementQ",
    "oralCorticosteroidAnd5HT3ReceptorAntagonistQ",
    "patientReceivingChemotherapeuticAgentsQ",
    "akynzeoUsedInCancerChemotherapyRegimenQ",
    "oralAntiemeticFullTherapeuticReplacementAkynzeoQ",
    "oralCorticosteroidRegimenQ",
    "patientReceivingChemotherapeuticAgentsAkynzeoQ",
  ];

  const listOfDLTFieldsForToggling = [
    "approveDiagoQ",
    "licsAndROAQ",
    "licsMemberQ",
    "rejectWithA6Q",
    "rejectWithA4orA6Q",
    "drugFromPhysicianStockQ",
    "insulinPumpMedicationQ",
    "dltShow0TFAltsQ",
    "prescriberProvidedSpprtStmtQ",
    ...bvdHepatitisbFieldsForToggling,
    ...bvdImmunosuppressantFieldsForToggling,
    ...bvdESRDNInfusionFieldsForToggling,
    ...bvdParenteralNutritionFieldsForToggling,
    ...bvdInhalationFieldsForToggling,
    ...bvdIVIGFieldsForToggling,
    ...bvdOralAntiemeticsFieldsForToggling,
    "patientIsStableOnRqstDrugQ",
    "memberTakingPlavixQ",
    "triedExclOmprzlOrEsmprzlQ",
    "memberIsStableOnRqstDrugQ",
    "infectionIsDrugRstntQ",
    "medicationGreaterThan7DaySupplyQ",
    "oralChemotherapyUsedForCancerQ",
    "oralChemotherapyUsedForSameIndicationQ",
    "patientIsTakingNStableOnRqstDrugQ",
    "prescriberIndicatedFormAltsLessEffQ",
    "prescriberIndicatedFormAltsProduceAdvAffectsQ",
    "triedNFailedFormAltsQ",
    "typeOfQlReviewQ",
    "prescriberIndicatedApprovedFormularyQuantityLimitIneffectiveQ",
    "prescriberIndicatedApprovedDosesIneffectiveQ",
    "clinicalCallerProvidedSpprtStmtQ",
  ];

  const dltAutomationGuidelineForm = sessionStorage.getItem(
    "dltAutomatedGuidelineForm"
  );
  const isDLTGuidelineFormAutomated = sessionStorage.getItem(
    "isDLTGuidelineFormAutomated"
  );

  if (!isDLTGuidelineFormAutomated) return; // No automation, no toggling needed

  const idx = listOfDLTFieldsForToggling.indexOf(currentId);
  if (idx === -1) return; // currentId not found

  // Collect automation actions to execute after tree building is complete
  const automationActions = [];
  let shouldStopTreeBuilding = false;

  // Loop through the remaining fields and toggle them
  for (let i = idx + 1; i < listOfDLTFieldsForToggling.length; i++) {
    const field = listOfDLTFieldsForToggling[i];
    const fieldId = `${role}${origin}${field}`;

    // Check if field should be skipped based on guideline form
    if (
      shouldSkipField(
        field,
        dltAutomationGuidelineForm,
        bvdHepatitisbFieldsForToggling,
        bvdImmunosuppressantFieldsForToggling,
        bvdESRDNInfusionFieldsForToggling,
        bvdESRDOnlyFieldsForToggling,
        bvdInfusionOnlyFieldsForToggling,
        bvdParenteralNutritionFieldsForToggling,
        bvdInhalationFieldsForToggling,
        bvdIVIGFieldsForToggling,
        bvdOralAntiemeticsFieldsForToggling,
        mode,
        role,
        origin
      )
    ) {
      continue;
    }

    clearInput("radio", [`${fieldId}rdo`]);
    // Toggle display and clear input
    toggleDisplay("solo", [fieldId], mode);

    // Clear dltFinal values for automated fields so audit trail reflects the cleared state
    if (field === "dltShow0TFAltsQ") {
      sessionStorage.setItem("dltFinalShow0TFAltsQAnswer", "");
    } else if (field === "triedNFailedFormAltsQ") {
      sessionStorage.setItem("dltFinalTriedNFailedFormAltsQAnswer", "");
    } else if (field === "typeOfQlReviewQ") {
      // Clearing typeOfQlReviewQ invalidates the MDD-based automation for prescriberIndicatedApprovedFormularyQuantityLimitIneffectiveQ.
      // Remove the automation key so getAutomationAction does not re-apply 'Yes' when that field is re-enabled.
      sessionStorage.removeItem("dltAutomatedPrescriberIndicatedQlIneffectiveFieldAns");
      sessionStorage.removeItem("dltFinalPrescriberIndicatedQlIneffectiveFieldAns");
    }

    if (field === "prescriberIndicatedApprovedFormularyQuantityLimitIneffectiveQ") {
      _syncPlanQlRef(role, origin, fieldId, mode);
    }

    // Collect automation actions if mode is enable
    if (mode === "enable") {
      const automationAction = getAutomationAction(field, role, origin);
      if (automationAction) {
        automationActions.push(automationAction);

        // Check if this action should stop tree building
        if (automationAction.shouldStopTreeBuilding) {
          shouldStopTreeBuilding = true;
          break;
        }
      }
    }
  }

  // Execute all automation actions after tree building is complete
  if (automationActions.length > 0 && mode === "enable") {
    // Use setTimeout to ensure DOM updates are complete and prevent overlapping recursive calls
    setTimeout(() => {
      executeAutomationActions(automationActions);
    }, 100);
  }
}
