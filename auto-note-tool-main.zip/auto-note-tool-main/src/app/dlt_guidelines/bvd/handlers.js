import { setDecisionRoutingForGLFields } from "../../guidelines/guideline.display";
import { decisionRouting } from "../../qsets/fields";
import { toggleDisplay } from "../../utils/notetool.display";
import { toggleFollowupDLTQuestions } from "../dlt_guideline.display";
import { toggleBvDDLTGuidelineFields, toggleBvDFieldsInRange } from "./display";

/* BVD Non-Formulary common handlers */
export function handleLicsMember(role, origin, answer) {
  toggleFollowupDLTQuestions(
    role,
    origin,
    "enable",
    "licsMemberQ"
  );
  // If yes, select BvD guideline below, refer to DLT to identify what should be selected. If no continue to Next Question.
  if (answer === "Yes") {
    toggleDisplay("solo", [`${role}${origin}rejectWithA4orA6Q`], "disable");
    // TODO: Show BvD guideline fields
    toggleBvDDLTGuidelineFields(true, role, origin);
  } else if (answer === "No") {
    toggleDisplay("solo", [`${role}${origin}rejectWithA4orA6Q`], "enable");
    // TODO: remove BvD guideline fields
    toggleBvDDLTGuidelineFields(false, role, origin);
  }

  sessionStorage.setItem("dltFinalBvDLICSMemberFieldAns", answer);
}

export function handleRejectWithA4orA6(role, origin, answer) {
  toggleFollowupDLTQuestions(
    role,
    origin,
    "enable",
    "rejectWithA4orA6Q"
  );
  // If yes, select BvD guideline below, refer to DLT to identify what should be selected. If no continue to Next Question.
  if (answer === "Yes") {
    // TODO: Show BvD guideline fields
    toggleBvDDLTGuidelineFields(true, role, origin);
  } else if (answer === "No") {
    const dltAutomationGuidelineForm = sessionStorage.getItem(
      "dltAutomatedGuidelineForm"
    );
    // if mapped guideline is "BVD NON-FORMULARY (INHALATION)", show inhalation related questions else continue to additional questions
    if (
      dltAutomationGuidelineForm?.includes("BvD Non-Formulary (Inhalation)")
    ) {
      toggleBvDDLTGuidelineFields(true, role, origin);
    } else {
      toggleBvDDLTGuidelineFields(false, role, origin);
    }
  }

  
  sessionStorage.setItem("dltFinalBvDRejectWithA4orA6FieldAns", answer);
}

/* BVD NON-FORMULARY (ESRD) specific handlers */
export function handleDrugPrescribedBySpecialist(role, origin, answer) {
  // If yes skip to question 3. If no, continue to question 2.
  toggleFollowupDLTQuestions(
    role,
    origin,
    "enable",
    "drugPrescribedBySpecialistQ"
  );
  if (answer === "Yes") {
    toggleDisplay("solo", [`${role}${origin}drugForESRDQ`], "disable");
  } else if (answer === "No") {
    toggleDisplay("solo", [`${role}${origin}drugForESRDQ`], "enable");
  }
}

export function handleDrugForESRD(role, origin, answer) {
  // If yes, Forward to Clinical Review. If no, continue to question 3.
  if (answer === "Yes") {
    setDecisionRoutingForGLFields(role, origin, "Forward to Clinical");
    toggleFollowupDLTQuestions(
      role,
      origin,
      "disable",
      "drugForESRDQ"
    );
  } else if (answer === "No") {
    const decisionRoutingValue = decisionRouting(role, origin, "value");
    if (decisionRoutingValue === "Forward to Clinical") {
      setDecisionRoutingForGLFields(role, origin, "");
    }
    toggleFollowupDLTQuestions(
      role,
      origin,
      "enable",
      "drugForESRDQ"
    );
  }
}

export function handleDrugAdminViaInfusionPump(role, origin, answer) {
  const dltAutomationGuidelineForm = sessionStorage.getItem(
    "dltAutomatedGuidelineForm"
  );
  // Enabling follow-up questions regardless of the answer as per latest guidelines to reset answers if user changes option in the middle
  toggleFollowupDLTQuestions(
    role,
    origin,
    "enable",
    "drugAdminViaInfusionPumpQ"
  );
  if(dltAutomationGuidelineForm.includes('BvD Non-Formulary (ESRD)')) {
    // If yes, continue to Question 4. If no, skip to question 9.
    if (answer === "Yes") {
    } else if (answer === "No") {
      toggleDisplay("solo", [
        `${role}${origin}drugAdminViaInfusionPumpHomeQ`,
        `${role}${origin}patientInSkilledNursingFacilityQ`,
        `${role}${origin}medicarePartAPayingFacilityBedQ`,
        `${role}${origin}narcoticAnalgesicNonCancerDxQ`,
      ], "disable");
    }
  } else if(dltAutomationGuidelineForm.includes('BvD Non-Formulary (Infusion)')) {
    // If yes, continue to Question 2. If no, skip to the additional questions in the box below.
    if (answer === "Yes") {
    } else if (answer === "No") {
      toggleDisplay("solo", [
        `${role}${origin}drugAdminViaInfusionPumpHomeQ`,
        `${role}${origin}patientInSkilledNursingFacilityQ`,
        `${role}${origin}medicarePartAPayingFacilityBedQ`,
        `${role}${origin}narcoticAnalgesicNonCancerDxQ`,
        `${role}${origin}drugFromPhysicianStockBvDQ`,
      ], "disable");
    }
  } 
}

export function handleDrugAdminViaInfusionPumpHome(role, origin, answer) {
  const dltAutomationGuidelineForm = sessionStorage.getItem(
    "dltAutomatedGuidelineForm"
  );
  // Enabling follow-up questions regardless of the answer as per latest guidelines to reset answers if user changes option in the middle
  toggleFollowupDLTQuestions(
    role,
    origin,
    "enable",
    "drugAdminViaInfusionPumpHomeQ"
  );

  if(dltAutomationGuidelineForm.includes('BvD Non-Formulary (ESRD)')) {
    // If yes, skip to Question 8. If no, continue to Question 5.
    if (answer === "Yes") {
      toggleDisplay("solo", [
        `${role}${origin}patientInSkilledNursingFacilityQ`,
        `${role}${origin}medicarePartAPayingFacilityBedQ`,
      ], "disable");
    } else if (answer === "No") {
    }
  } else if(dltAutomationGuidelineForm.includes('BvD Non-Formulary (Infusion)')) {
    // If yes, skip to Question 6. If no, continue to Question 3.
    if (answer === "Yes") {
      toggleDisplay("solo", [
        `${role}${origin}patientInSkilledNursingFacilityQ`,
        `${role}${origin}medicarePartAPayingFacilityBedQ`,
        `${role}${origin}drugFromPhysicianStockBvDQ`,
      ], "disable");
    } else if (answer === "No") {
    }
  }
}

export function handlePatientInSkilledNursingFacility(role, origin, answer) {
  // (ESRD): If yes, continue to question 6. If no, skip to Question 7.
  // (Infusion): If yes, continue to question 4. If no, skip to Question 5.
  toggleFollowupDLTQuestions(
    role,
    origin,
    "enable",
    "patientInSkilledNursingFacilityQ"
  );
  if (answer === "Yes") {
    toggleDisplay("solo", [`${role}${origin}medicarePartAPayingFacilityBedQ`], "enable");
  } else if (answer === "No") {
    toggleDisplay("solo", [
      `${role}${origin}medicarePartAPayingFacilityBedQ`,
      `${role}${origin}narcoticAnalgesicNonCancerDxQ`,
      `${role}${origin}injectableAgentRequestQ`
    ], "disable");
  }
}

export function handleMedicarePartAPayingFacilityBed(role, origin, answer) {
  // If yes, forward to Clinical Review. If no, skip to the additional questions in the box below.
  if (answer === "Yes") {
    setDecisionRoutingForGLFields(role, origin, "Forward to Clinical");
    toggleFollowupDLTQuestions(
      role,
      origin,
      "disable",
      "medicarePartAPayingFacilityBedQ"
    );
  } else if (answer === "No") {
    const decisionRoutingValue = decisionRouting(role, origin, "value");
    if (decisionRoutingValue === "Forward to Clinical") {
      setDecisionRoutingForGLFields(role, origin, "");
    }
    toggleFollowupDLTQuestions(
      role,
      origin,
      "enable",
      "medicarePartAPayingFacilityBedQ"
    );
    // Skipping to additional questions, so disabling this question's follow-ups
    toggleDisplay("solo", [
      `${role}${origin}narcoticAnalgesicNonCancerDxQ`,
      `${role}${origin}injectableAgentRequestQ`,
      `${role}${origin}drugFromPhysicianStockBvDQ`,
    ], "disable");
  }
}

export function handleNarcoticAnalgesicNonCancerDx(role, origin, answer) {
  // If yes, continue to the additional questions in the box below. If no, forward to Clinical Review.
  if (answer === "No") {
    setDecisionRoutingForGLFields(role, origin, "Forward to Clinical");
    toggleFollowupDLTQuestions(
      role,
      origin,
      "disable",
      "narcoticAnalgesicNonCancerDxQ"
    );
  } else if (answer === "Yes") {
    const decisionRoutingValue = decisionRouting(role, origin, "value");
    if (decisionRoutingValue === "Forward to Clinical") {
      setDecisionRoutingForGLFields(role, origin, "");
    }
    toggleFollowupDLTQuestions(
      role,
      origin,
      "enable",
      "narcoticAnalgesicNonCancerDxQ"
    );
    // Skipping to additional questions, so disabling this question's follow-ups
    toggleDisplay("solo", [
      `${role}${origin}injectableAgentRequestQ`,
      `${role}${origin}drugFromPhysicianStockBvDQ`,
    ], "disable");
  }
}

export function handleInjectableAgentRequest(role, origin, answer) {
  // If yes, continue to Question 10. If no, skip to the additional questions in the box below.
  toggleFollowupDLTQuestions(
    role,
    origin,
    "enable",
    "injectableAgentRequestQ"
  );
  if (answer === "Yes") {
  } else if (answer === "No") {
    toggleDisplay("solo", [`${role}${origin}drugFromPhysicianStockBvDQ`], "disable");
  }

  sessionStorage.setItem("dltFinalBvDESRDInjectableAgentRequestFieldAns", answer);
}

export function handleDrugFromPhysicianStockBvD(role, origin, answer) {
  // If yes, Forward to Clinical Review. If no, continue to the additional questions in the box below.
  if (answer === "Yes") {
    setDecisionRoutingForGLFields(role, origin, "Forward to Clinical");
    toggleFollowupDLTQuestions(
      role,
      origin,
      "disable",
      "drugFromPhysicianStockBvDQ"
    );
  } else if (answer === "No") {
    const decisionRoutingValue = decisionRouting(role, origin, "value");
    if (decisionRoutingValue === "Forward to Clinical") {
      setDecisionRoutingForGLFields(role, origin, "");
    }
    toggleFollowupDLTQuestions(
      role,
      origin,
      "enable",
      "drugFromPhysicianStockBvDQ"
    );
    // Skipping to additional questions, so disabling this question's follow-ups
    toggleDisplay("solo", [
      `${role}${origin}narcoticAnalgesicNonCancerDxQ`,
      `${role}${origin}injectableAgentRequestQ`,
    ], "disable");
  }
}

/* BVD NON-FORMULARY (HEPATITIS B) specific handlers */
export function handlePatientRiskHepatitisB(role, origin, answer) {
  // If yes, Forward to Clinical Review If no, continue to the additional questions in the box below.
  if (answer === "Yes") {
    setDecisionRoutingForGLFields(role, origin, "Forward to Clinical");
    toggleFollowupDLTQuestions(
      role,
      origin,
      "disable",
      "patientRiskHepatitisBQ"
    );
  } else if (answer === "No") {
    const decisionRoutingValue = decisionRouting(role, origin, "value");
    if (decisionRoutingValue === "Forward to Clinical") {
      setDecisionRoutingForGLFields(role, origin, "");
    }
    toggleFollowupDLTQuestions(
      role,
      origin,
      "enable",
      "patientRiskHepatitisBQ"
    );
  }
}

/* BVD NON-FORMULARY (IMMUNOSUPPRESSANT) specific handlers */
export function handleTransplantIndicatorPresent(role, origin, answer) {
  // If yes, Forward to Clinical Review If no, continue to the additional questions in the box below.
  if (answer === "Yes") {
    setDecisionRoutingForGLFields(role, origin, "Forward to Clinical");
    toggleFollowupDLTQuestions(
      role,
      origin,
      "disable",
      "transplantIndicatorPresentQ"
    );
  } else if (answer === "No") {
    const decisionRoutingValue = decisionRouting(role, origin, "value");
    if (decisionRoutingValue === "Forward to Clinical") {
      setDecisionRoutingForGLFields(role, origin, "");
    }
    toggleFollowupDLTQuestions(
      role,
      origin,
      "enable",
      "transplantIndicatorPresentQ"
    );
  }
}

/* BVD NON-FORMULARY (PARENTERAL NUTRITION) specific handlers */
export function handleParenteralNutritionRequest(role, origin, answer) {
  // If yes, continue to Question 2. If no, forward to Clinical Review.
  if (answer === "No") {
    setDecisionRoutingForGLFields(role, origin, "Forward to Clinical");
    toggleFollowupDLTQuestions(
      role,
      origin,
      "disable",
      "parenteralNutritionRequestQ"
    );
  } else if (answer === "Yes") {
    const decisionRoutingValue = decisionRouting(role, origin, "value");
    if (decisionRoutingValue === "Forward to Clinical") {
      setDecisionRoutingForGLFields(role, origin, "");
    }
    toggleFollowupDLTQuestions(
      role,
      origin,
      "enable",
      "parenteralNutritionRequestQ"
    );
  }
}

export function handlePermanentDysfunctionDigestiveTract(role, origin, answer) {
  // If yes, Forward to Clinical Review. If no, continue to the additional questions in the box below.
  if (answer === "Yes") {
    setDecisionRoutingForGLFields(role, origin, "Forward to Clinical");
    toggleFollowupDLTQuestions(
      role,
      origin,
      "disable",
      "permanentDysfunctionDigestiveTractQ"
    );
  } else if (answer === "No") {
    const decisionRoutingValue = decisionRouting(role, origin, "value");
    if (decisionRoutingValue === "Forward to Clinical") {
      setDecisionRoutingForGLFields(role, origin, "");
    }
    toggleFollowupDLTQuestions(
      role,
      origin,
      "enable",
      "permanentDysfunctionDigestiveTractQ"
    );
  }
}

/* BVD NON-FORMULARY (INHALATION) specific handlers */
export function handlePatientResidenceCode(role, origin, answer) {
  // If yes, continue to question 15. If no, continue to question 2.
  toggleFollowupDLTQuestions(
    role,
    origin,
    "enable",
    "patientResidenceCodeQ"
  );
  if(answer === "Yes") {
    toggleBvDFieldsInRange(false, role, origin, "INHALATION", "patientResidenceCodeQ", "bvdDiagnosisProvidedQ");
  } else {

  }
}

export function handlePatientUsingMedWithNebulizer(role, origin, answer) {
  // If yes, continue to question 3. If no, skip to question 15.
  toggleFollowupDLTQuestions(
    role,
    origin,
    "enable",
    "patientUsingMedWithNebulizerQ"
  );
  if(answer === "Yes") {
  } else {
    toggleBvDFieldsInRange(false, role, origin, "INHALATION", "patientUsingMedWithNebulizerQ", "bvdDiagnosisProvidedQ");
  }
}

export function handleRequestForBetaAgonistSteroidInhalantAnticholinergicOrPDEInhibitor(role, origin, answer) {
  // If yes, continue to question 4. If no, skip to question 5.
  toggleFollowupDLTQuestions(
    role,
    origin,
    "enable",
    "requestForBetaAgonistSteroidInhalantAnticholinergicOrPDEInhibitorQ"
  );
  if(answer === "Yes") {
    toggleDisplay("solo", [`${role}${origin}requestForAsthmaOrObstructivePulmonaryDiseaseQ`], "enable");
  } else {
    toggleDisplay("solo", [`${role}${origin}requestForAsthmaOrObstructivePulmonaryDiseaseQ`], "disable");
  }
}

export function handleRequestForAsthmaOrObstructivePulmonaryDisease(role, origin, answer) {
  // If yes, Forward to Clinical Review. If no, skip to question 15.
  if (answer === "Yes") {
    setDecisionRoutingForGLFields(role, origin, "Forward to Clinical");
    toggleFollowupDLTQuestions(
      role,
      origin,
      "disable",
      "requestForAsthmaOrObstructivePulmonaryDiseaseQ"
    );
  } else if (answer === "No") {
    const decisionRoutingValue = decisionRouting(role, origin, "value");
    if (decisionRoutingValue === "Forward to Clinical") {
      setDecisionRoutingForGLFields(role, origin, "");
    }
    toggleFollowupDLTQuestions(
      role,
      origin,
      "enable",
      "requestForAsthmaOrObstructivePulmonaryDiseaseQ"
    );
    toggleBvDFieldsInRange(false, role, origin, "INHALATION", "requestForAsthmaOrObstructivePulmonaryDiseaseQ", "bvdDiagnosisProvidedQ");
  }

  sessionStorage.setItem("dltFinalBvDINHALATIONrequestForAsthmaOrObstructivePulmonaryDiseaseQFieldAns", answer);
}

export function handleRequestForDornaseAlphaPulmozyme(role, origin, answer) {
  // If yes, continue to question 6. If no, skip to question 7.
  toggleFollowupDLTQuestions(
    role,
    origin,
    "enable",
    "requestForDornaseAlphaPulmozymeQ"
  );
  if(answer === "Yes") {
    toggleDisplay("solo", [`${role}${origin}patientHasCysticFibrosisQ`], "enable");
  } else {
    toggleDisplay("solo", [`${role}${origin}patientHasCysticFibrosisQ`], "disable");
  }
  sessionStorage.setItem("dltFinalBvDINHALATIONrequestForDornaseAlphaPulmozymeQFieldAns", answer);
}

export function handlePatientHasCysticFibrosis(role, origin, answer) {
  // If yes, Forward to Clinical Review. If no, skip to question 15.
  if (answer === "Yes") {
    setDecisionRoutingForGLFields(role, origin, "Forward to Clinical");
    toggleFollowupDLTQuestions(
      role,
      origin,
      "disable",
      "patientHasCysticFibrosisQ"
    );
  } else if (answer === "No") {
    const decisionRoutingValue = decisionRouting(role, origin, "value");
    if (decisionRoutingValue === "Forward to Clinical") {
      setDecisionRoutingForGLFields(role, origin, "");
    }
    toggleFollowupDLTQuestions(
      role,
      origin,
      "enable",
      "patientHasCysticFibrosisQ"
    );
    toggleBvDFieldsInRange(false, role, origin, "INHALATION", "patientHasCysticFibrosisQ", "bvdDiagnosisProvidedQ");
  }
  sessionStorage.setItem("dltFinalBvDINHALATIONpatientHasCysticFibrosisQFieldAns", answer);
}

export function handleRequestForTobramycinInhalationSolution(role, origin, answer) {
  // If yes, continue to question 8. If no, skip to question 9.
  toggleFollowupDLTQuestions(
    role,
    origin,
    "enable",
    "requestForTobramycinInhalationSolutionQ"
  );
  if(answer === "Yes") {
    toggleDisplay("solo", [`${role}${origin}patientHasCysticFibrosisOrBronchiectasisQ`], "enable");
  } else {
    toggleDisplay("solo", [`${role}${origin}patientHasCysticFibrosisOrBronchiectasisQ`], "disable");
  }
  sessionStorage.setItem("dltFinalBvDINHALATIONrequestForTobramycinInhalationSolutionQFieldAns", answer);
}

export function handlePatientHasCysticFibrosisOrBronchiectasis(role, origin, answer) {
  // If yes, Forward to Clinical Review. If no, skip to question 15.
  if (answer === "Yes") {
    setDecisionRoutingForGLFields(role, origin, "Forward to Clinical");
    toggleFollowupDLTQuestions(
      role,
      origin,
      "disable",
      "patientHasCysticFibrosisOrBronchiectasisQ"
    );
  } else if (answer === "No") {
    const decisionRoutingValue = decisionRouting(role, origin, "value");
    if (decisionRoutingValue === "Forward to Clinical") {
      setDecisionRoutingForGLFields(role, origin, "");
    }
    toggleFollowupDLTQuestions(
      role,
      origin,
      "enable",
      "patientHasCysticFibrosisOrBronchiectasisQ"
    );
    toggleBvDFieldsInRange(false, role, origin, "INHALATION", "patientHasCysticFibrosisOrBronchiectasisQ", "bvdDiagnosisProvidedQ");
  }
  sessionStorage.setItem("dltFinalBvDINHALATIONpatientHasCysticFibrosisOrBronchiectasisQFieldAns", answer);
}

export function handleRequestForAcetylcysteine(role, origin, answer) {
  // If yes, continue to question 10. If no, skip to question 11.
  toggleFollowupDLTQuestions(
    role,
    origin,
    "enable",
    "requestForAcetylcysteineQ"
  );
  if(answer === "Yes") {
    toggleDisplay("solo", [`${role}${origin}persistentThickPulmonarySecretionsQ`], "enable");
  } else {
    toggleDisplay("solo", [`${role}${origin}persistentThickPulmonarySecretionsQ`], "disable");
  }
  sessionStorage.setItem("dltFinalBvDINHALATIONrequestForAcetylcysteineQFieldAns", answer);
}

export function handlePersistentThickPulmonarySecretions(role, origin, answer) {
  // If yes, Forward to Clinical Review. If no, skip to question 15.
  if (answer === "Yes") {
    setDecisionRoutingForGLFields(role, origin, "Forward to Clinical");
    toggleFollowupDLTQuestions(
      role,
      origin,
      "disable",
      "persistentThickPulmonarySecretionsQ"
    );
  } else if (answer === "No") {
    const decisionRoutingValue = decisionRouting(role, origin, "value");
    if (decisionRoutingValue === "Forward to Clinical") {
      setDecisionRoutingForGLFields(role, origin, "");
    }
    toggleFollowupDLTQuestions(
      role,
      origin,
      "enable",
      "persistentThickPulmonarySecretionsQ"
    );
    toggleBvDFieldsInRange(false, role, origin, "INHALATION", "persistentThickPulmonarySecretionsQ", "bvdDiagnosisProvidedQ");
  }
  sessionStorage.setItem("dltFinalBvDINHALATIONpersistentThickPulmonarySecretionsQFieldAns", answer);
}

export function handleRequestForNebupent(role, origin, answer) {
  // If yes, continue to question 12. If no, skip to question 13.
  toggleFollowupDLTQuestions(
    role,
    origin,
    "enable",
    "requestForNebupentQ"
  );
  if(answer === "Yes") {
    toggleDisplay("solo", [`${role}${origin}patientHasHIVPneumocystosisOrComplicationsOfOrganTransplantsQ`], "enable");
  } else {
    toggleDisplay("solo", [`${role}${origin}patientHasHIVPneumocystosisOrComplicationsOfOrganTransplantsQ`], "disable");
  }
  sessionStorage.setItem("dltFinalBvDINHALATIONrequestForNebupentQFieldAns", answer);
}

export function handlePatientHasHIVPneumocystosisOrComplicationsOfOrganTransplants(role, origin, answer) {
  // If yes, Forward to Clinical Review. If no, skip to question 15.
  if (answer === "Yes") {
    setDecisionRoutingForGLFields(role, origin, "Forward to Clinical");
    toggleFollowupDLTQuestions(
      role,
      origin,
      "disable",
      "patientHasHIVPneumocystosisOrComplicationsOfOrganTransplantsQ"
    );
  } else if (answer === "No") {
    const decisionRoutingValue = decisionRouting(role, origin, "value");
    if (decisionRoutingValue === "Forward to Clinical") {
      setDecisionRoutingForGLFields(role, origin, "");
    }
    toggleFollowupDLTQuestions(
      role,
      origin,
      "enable",
      "patientHasHIVPneumocystosisOrComplicationsOfOrganTransplantsQ"
    );
    toggleBvDFieldsInRange(false, role, origin, "INHALATION", "patientHasHIVPneumocystosisOrComplicationsOfOrganTransplantsQ", "bvdDiagnosisProvidedQ");
  }
  sessionStorage.setItem("dltFinalBvDINHALATIONpatientHasHIVPneumocystosisOrComplicationsOfOrganTransplantsQFieldAns", answer);
}

export function handleRequestForTyvasoOrVentavis(role, origin, answer) {
  // If yes, continue to question 14. If no, skip to question 15.
  toggleFollowupDLTQuestions(
    role,
    origin,
    "enable",
    "requestForTyvasoOrVentavisQ"
  );
  if(answer === "Yes") {
    toggleDisplay("solo", [`${role}${origin}patientHasPulmonaryArteryHypertensionQ`], "enable");
  } else {
    toggleDisplay("solo", [`${role}${origin}patientHasPulmonaryArteryHypertensionQ`], "disable");
  }
  sessionStorage.setItem("dltFinalBvDINHALATIONrequestForTyvasoOrVentavisQFieldAns", answer);
}

export function handlePatientHasPulmonaryArteryHypertension(role, origin, answer) {
  // If yes, Forward to Clinical Review. If no, skip to question 15.
  if (answer === "Yes") {
    setDecisionRoutingForGLFields(role, origin, "Forward to Clinical");
    toggleFollowupDLTQuestions(
      role,
      origin,
      "disable",
      "patientHasPulmonaryArteryHypertensionQ"
    );
  } else if (answer === "No") {
    const decisionRoutingValue = decisionRouting(role, origin, "value");
    if (decisionRoutingValue === "Forward to Clinical") {
      setDecisionRoutingForGLFields(role, origin, "");
    }
    toggleFollowupDLTQuestions(
      role,
      origin,
      "enable",
      "patientHasPulmonaryArteryHypertensionQ"
    );
    toggleBvDFieldsInRange(false, role, origin, "INHALATION", "patientHasPulmonaryArteryHypertensionQ", "bvdDiagnosisProvidedQ");
  }
  sessionStorage.setItem("dltFinalBvDINHALATIONpatientHasPulmonaryArteryHypertensionQFieldAns", answer);
}

export function handleBvdDiagnosisProvided(role, origin, answer) {
  // Continue to the additional questions in the box below.
  toggleFollowupDLTQuestions(
    role,
    origin,
    "enable",
    "bvdDiagnosisProvidedQ"
  );
  sessionStorage.setItem("dltFinalBvDINHALATIONbvdDiagnosisProvidedQFieldAns", answer);
}

/* BVD NON-FORMULARY (IVIG) specific handlers */
export function handleMedicationReceivedInHome(role, origin, answer) {
  // If yes, continue to question 2. If no, skip to question 6.
  toggleFollowupDLTQuestions(
    role,
    origin,
    "enable",
    "medicationReceivedInHomeQ"
  );
  if(answer === "Yes") {
  } else {
    toggleBvDFieldsInRange(false, role, origin, "IVIG", "medicationReceivedInHomeQ", "patientReceivingMedicationInMedicalOfficeOrInfusionCenterQ");
  }
}

export function handlePatientReceivingMedicationForPrimaryImmuneDeficiencyDisease(role, origin, answer) {
  // If yes, Forward to Clinical Review. If no, skip to question 3.
  if (answer === "Yes") {
    setDecisionRoutingForGLFields(role, origin, "Forward to Clinical");
    toggleFollowupDLTQuestions(
      role,
      origin,
      "disable",
      "patientReceivingMedicationForPrimaryImmuneDeficiencyDiseaseQ"
    );
  } else if (answer === "No") {
    const decisionRoutingValue = decisionRouting(role, origin, "value");
    if (decisionRoutingValue === "Forward to Clinical") {
      setDecisionRoutingForGLFields(role, origin, "");
    }
    toggleFollowupDLTQuestions(
      role,
      origin,
      "enable",
      "patientReceivingMedicationForPrimaryImmuneDeficiencyDiseaseQ"
    );
  }
  sessionStorage.setItem("dltFinalBvDIVIGpatientReceivingMedicationForPrimaryImmuneDeficiencyDiseaseQFieldAns", answer);
}

export function handleRequestForHizentraOrHyQvia(role, origin, answer) {
  // If yes, continue to question 4. If no, skip to question 10.
  toggleFollowupDLTQuestions(
    role,
    origin,
    "enable",
    "requestForHizentraOrHyQviaQ"
  );
  if(answer === "Yes") {
  } else {
    toggleBvDFieldsInRange(false, role, origin, "IVIG", "requestForHizentraOrHyQviaQ", "bvdDiagnosisProvidedIVIGQ");
  }
  sessionStorage.setItem("dltFinalBvDIVIGrequestForHizentraOrHyQviaQFieldAns", answer);
}

export function handleMedicationGivenSubcutaneously(role, origin, answer) {
  // If yes, continue to question 5. If no, skip to question 10.
  toggleFollowupDLTQuestions(
    role,
    origin,
    "enable",
    "medicationGivenSubcutaneouslyQ"
  );
  if(answer === "Yes") {
  } else {
    toggleBvDFieldsInRange(false, role, origin, "IVIG", "medicationGivenSubcutaneouslyQ", "bvdDiagnosisProvidedIVIGQ");
  }
}

export function handlePatientReceivingMedicationForCIDP(role, origin, answer) {
  // If yes, Forward to Clinical Review. If no, skip to question 10
  if (answer === "Yes") {
    setDecisionRoutingForGLFields(role, origin, "Forward to Clinical");
    toggleFollowupDLTQuestions(
      role,
      origin,
      "disable",
      "patientReceivingMedicationForCIDPQ"
    );
  } else if (answer === "No") {
    const decisionRoutingValue = decisionRouting(role, origin, "value");
    if (decisionRoutingValue === "Forward to Clinical") {
      setDecisionRoutingForGLFields(role, origin, "");
    }
    toggleFollowupDLTQuestions(
      role,
      origin,
      "enable",
      "patientReceivingMedicationForCIDPQ"
    );
    toggleBvDFieldsInRange(false, role, origin, "IVIG", "patientReceivingMedicationForCIDPQ", "bvdDiagnosisProvidedIVIGQ");
  }
  sessionStorage.setItem("dltFinalBvDIVIGpatientReceivingMedicationForCIDPQFieldAns", answer);
}

export function handlePatientReceivingMedicationInMedicalOfficeOrInfusionCenter(role, origin, answer) {
  // If yes, continue to question 7. If no, skip to question 8.
  toggleFollowupDLTQuestions(
    role,
    origin,
    "enable",
    "patientReceivingMedicationInMedicalOfficeOrInfusionCenterQ"
  );
  if(answer === "Yes") {
  } else {
    toggleDisplay("solo", [`${role}${origin}requestedDrugSuppliedFromPhysicianOfficeStockIVIGQ`], "disable");
  }
}

export function handleRequestedDrugSuppliedFromPhysicianOfficeStockIVIG(role, origin, answer) {
  // If yes, Forward to Clinical Review. If no, continue to question 8.
  if (answer === "Yes") {
    setDecisionRoutingForGLFields(role, origin, "Forward to Clinical");
    toggleFollowupDLTQuestions(
      role,
      origin,
      "disable",
      "requestedDrugSuppliedFromPhysicianOfficeStockIVIGQ"
    );
  } else if (answer === "No") {
    const decisionRoutingValue = decisionRouting(role, origin, "value");
    if (decisionRoutingValue === "Forward to Clinical") {
      setDecisionRoutingForGLFields(role, origin, "");
    }
    toggleFollowupDLTQuestions(
      role,
      origin,
      "enable",
      "requestedDrugSuppliedFromPhysicianOfficeStockIVIGQ"
    );
  }
}

export function handlePatientResidesInSNFOrSkilledCareFacility(role, origin, answer) {
  // If yes, continue to question 9. If no, skip to question 10.
  toggleFollowupDLTQuestions(
    role,
    origin,
    "enable",
    "patientResidesInSNFOrSkilledCareFacilityQ"
  );
  if(answer === "Yes") {
  } else {
    toggleDisplay("solo", [`${role}${origin}medicarePartAPayingForLTCFacilityBedQ`], "disable");
  }
}

export function handleMedicarePartAPayingForLTCFacilityBed(role, origin, answer) {
  // If yes, Forward to Clinical Review. If no, continue to question 10.
  if (answer === "Yes") {
    setDecisionRoutingForGLFields(role, origin, "Forward to Clinical");
    toggleFollowupDLTQuestions(
      role,
      origin,
      "disable",
      "medicarePartAPayingForLTCFacilityBedQ"
    );
  } else if (answer === "No") {
    const decisionRoutingValue = decisionRouting(role, origin, "value");
    if (decisionRoutingValue === "Forward to Clinical") {
      setDecisionRoutingForGLFields(role, origin, "");
    }
    toggleFollowupDLTQuestions(
      role,
      origin,
      "enable",
      "medicarePartAPayingForLTCFacilityBedQ"
    );
  }
}

export function handleBvdDiagnosisProvidedIVIG(role, origin, answer) {
  // Continue to the additional questions in the box below.
  toggleFollowupDLTQuestions(
    role,
    origin,
    "enable",
    "bvdDiagnosisProvidedIVIGQ"
  );
  sessionStorage.setItem("dltFinalBvDIVIGbvdDiagnosisProvidedIVIGQFieldAns", answer);
}

/* BVD NON-FORMULARY (ORAL ANTIEMETICS) specific handlers */
export function handleRequestForVarubiEmendOrAkynzeo(role, origin, answer) {
  // If yes, skip to Question 5. If no, continue to Question 2.
  toggleFollowupDLTQuestions(
    role,
    origin,
    "enable",
    "requestForVarubiEmendOrAkynzeoQ"
  );
  if(answer === "Yes") {
    toggleBvDFieldsInRange(false, role, origin, "ORAL ANTIEMETICS", "requestForVarubiEmendOrAkynzeoQ", "requestForAkynzeoQ");
  } else {
  }
}

export function handleOralAntiemeticUsedInChemotherapy(role, origin, answer) {
  // If yes, continue to Question 3. If no, skip to the additional questions in the box below.
  toggleFollowupDLTQuestions(
    role,
    origin,
    "enable",
    "oralAntiemeticUsedInChemotherapyQ"
  );
  if(answer === "Yes") {
  } else {
    toggleBvDFieldsInRange(false, role, origin, "ORAL ANTIEMETICS", "oralAntiemeticUsedInChemotherapyQ");
  }
}

export function handleOralAntiemeticUsedInChemotherapyReplacement(role, origin, answer) {
  // If yes, continue to question 4. If no, skip to the additional questions in the box below.
  toggleFollowupDLTQuestions(
    role,
    origin,
    "enable",
    "oralAntiemeticUsedInChemotherapyReplacementQ"
  );
  if(answer === "Yes") {
  } else {
    toggleBvDFieldsInRange(false, role, origin, "ORAL ANTIEMETICS", "oralAntiemeticUsedInChemotherapyReplacementQ");
  }
}

export function handlePatientRequiresOneOfFollowing(role, origin, answer) {
  // If yes, skip to the additional questions in the box below. If no, forward to Clinical Review.
  if (answer === "Yes") {
    const decisionRoutingValue = decisionRouting(role, origin, "value");
    if (decisionRoutingValue === "Forward to Clinical") {
      setDecisionRoutingForGLFields(role, origin, "");
    }
    toggleFollowupDLTQuestions(
      role,
      origin,
      "enable",
      "patientRequiresOneOfFollowingQ"
    );
    toggleBvDFieldsInRange(false, role, origin, "ORAL ANTIEMETICS", "patientRequiresOneOfFollowingQ");
  } else if (answer === "No") {
    setDecisionRoutingForGLFields(role, origin, "Forward to Clinical");
    toggleFollowupDLTQuestions(
      role,
      origin,
      "disable",
      "patientRequiresOneOfFollowingQ"
    );
  }
}

export function handleRequestForAkynzeo(role, origin, answer) {
  // If yes, skip to Question 10. If no, continue to Question 6.
  toggleFollowupDLTQuestions(
    role,
    origin,
    "enable",
    "requestForAkynzeoQ"
  );
  if(answer === "Yes") {
    toggleBvDFieldsInRange(false, role, origin, "ORAL ANTIEMETICS", "requestForAkynzeoQ", "akynzeoUsedInCancerChemotherapyRegimenQ");
  } else {
  }
}

export function handleRequestedDrugUsedInCancerChemotherapy(role, origin, answer) {
  // If yes, continue to Question 7. If no, skip to the additional questions in the box below.
  toggleFollowupDLTQuestions(
    role,
    origin,
    "enable",
    "requestedDrugUsedInCancerChemotherapyQ"
  );
  if(answer === "Yes") {
  } else {
    toggleBvDFieldsInRange(false, role, origin, "ORAL ANTIEMETICS", "requestedDrugUsedInCancerChemotherapyQ");
  }
}

export function handleOralAntiemeticFullTherapeuticReplacement(role, origin, answer) {
  // If yes, continue to Question 8. If no, skip to the additional questions in the box below.
  toggleFollowupDLTQuestions(
    role,
    origin,
    "enable",
    "oralAntiemeticFullTherapeuticReplacementQ"
  );
  if(answer === "Yes") {
  } else {
    toggleBvDFieldsInRange(false, role, origin, "ORAL ANTIEMETICS", "oralAntiemeticFullTherapeuticReplacementQ");
  }
}

export function handleOralCorticosteroidAnd5HT3ReceptorAntagonist(role, origin, answer) {
  // If yes, continue to Question 9. If no, skip to the additional questions in the box below.
  toggleFollowupDLTQuestions(
    role,
    origin,
    "enable",
    "oralCorticosteroidAnd5HT3ReceptorAntagonistQ"
  );
  if(answer === "Yes") {
  } else {
    toggleBvDFieldsInRange(false, role, origin, "ORAL ANTIEMETICS", "oralCorticosteroidAnd5HT3ReceptorAntagonistQ");
  }
}

export function handlePatientReceivingChemotherapeuticAgents(role, origin, answer) {
  // If yes, Forward to Clinical Review. If no, continue to the additional questions in the box below.
  if (answer === "Yes") {
    setDecisionRoutingForGLFields(role, origin, "Forward to Clinical");
    toggleFollowupDLTQuestions(
      role,
      origin,
      "disable",
      "patientReceivingChemotherapeuticAgentsQ"
    );
  } else if (answer === "No") {
    const decisionRoutingValue = decisionRouting(role, origin, "value");
    if (decisionRoutingValue === "Forward to Clinical") {
      setDecisionRoutingForGLFields(role, origin, "");
    }
    toggleFollowupDLTQuestions(
      role,
      origin,
      "enable",
      "patientReceivingChemotherapeuticAgentsQ"
    );
    toggleBvDFieldsInRange(false, role, origin, "ORAL ANTIEMETICS", "patientReceivingChemotherapeuticAgentsQ");
  }
}

export function handleAkynzeoUsedInCancerChemotherapyRegimen(role, origin, answer) {
  // If yes, continue to Question 11. If no, skip to the additional questions in the box below
  toggleFollowupDLTQuestions(
    role,
    origin,
    "enable",
    "akynzeoUsedInCancerChemotherapyRegimenQ"
  );
  if(answer === "Yes") {
  } else {
    toggleBvDFieldsInRange(false, role, origin, "ORAL ANTIEMETICS", "akynzeoUsedInCancerChemotherapyRegimenQ");
  }
}

export function handleOralAntiemeticFullTherapeuticReplacementAkynzeo(role, origin, answer) {
  // If yes, continue to Question 12. If no, skip to the additional questions in the box below.
  toggleFollowupDLTQuestions(
    role,
    origin,
    "enable",
    "oralAntiemeticFullTherapeuticReplacementAkynzeoQ"
  );
  if(answer === "Yes") {
  } else {
    toggleBvDFieldsInRange(false, role, origin, "ORAL ANTIEMETICS", "oralAntiemeticFullTherapeuticReplacementAkynzeoQ");
  }
}

export function handleOralCorticosteroidRegimen(role, origin, answer) {
  // If yes, continue to Question 13. If no, skip to the additional questions in the box below.
  toggleFollowupDLTQuestions(
    role,
    origin,
    "enable",
    "oralCorticosteroidRegimenQ"
  );
  if(answer === "Yes") {
  } else {
    toggleBvDFieldsInRange(false, role, origin, "ORAL ANTIEMETICS", "oralCorticosteroidRegimenQ");
  }
}

export function handlePatientReceivingChemotherapeuticAgentsAkynzeo(role, origin, answer) {
  // If yes, Forward to Clinical Review. If no, continue to the additional questions in the box below.
  if (answer === "Yes") {
    setDecisionRoutingForGLFields(role, origin, "Forward to Clinical");
    toggleFollowupDLTQuestions(
      role,
      origin,
      "disable",
      "patientReceivingChemotherapeuticAgentsAkynzeoQ"
    );
  } else if (answer === "No") {
    const decisionRoutingValue = decisionRouting(role, origin, "value");
    if (decisionRoutingValue === "Forward to Clinical") {
      setDecisionRoutingForGLFields(role, origin, "");
    }
    toggleFollowupDLTQuestions(
      role,
      origin,
      "enable",
      "patientReceivingChemotherapeuticAgentsAkynzeoQ"
    );
  }
}
