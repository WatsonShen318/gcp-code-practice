import { clearInput } from "../../utils/clearInput";
import { toggleDisplay } from "../../utils/notetool.display";

/* Function to toggle display for all fields with data-tag="dltGuideline BvD <BvD Type>" */
function toggleBvDGuidelineSpecificFields(show, role, origin, BvDType) {
    const elements = document.querySelectorAll(
        `[data-tag="dltGuideline BvD ${BvDType}"]`
    );
    elements.forEach((element) => {
        if (element.id?.includes(`${role}${origin}`)) {
            element.style.display = show ? "block" : "none";
            element.disabled = !show;
            clearInput("radio", [`${element.id}rdo`]);
        } else {
            element.style.display = "none";
            element.disabled = true;
        }
    });
}

export function toggleBvDOralChemotherapyFields(show, role, origin) {
    toggleDisplay(
      'solo',
      [`${role}${origin}oralChemotherapyUsedForCancerQ`, `${role}${origin}oralChemotherapyUsedForSameIndicationQ`],
      show ? 'enable' : 'disable'
    );
}

export function toggleBvDDLTGuidelineFields(show, role, origin) {
    const dltAutomationGuidelineForm = sessionStorage.getItem(
        "dltAutomatedGuidelineForm"
    );
    if (dltAutomationGuidelineForm?.includes("BvD Non-Formulary (ESRD)")) {
        toggleBvDGuidelineSpecificFields(show, role, origin, "ESRD Only");
        toggleBvDGuidelineSpecificFields(show, role, origin, "ESRD Infusion");
    } else if (dltAutomationGuidelineForm?.includes("BvD Non-Formulary (Hepatitis B)")) {
        toggleBvDGuidelineSpecificFields(show, role, origin, "HEPATITIS B");
    } else if (dltAutomationGuidelineForm?.includes("BvD Non-Formulary (Immunosuppressant)")) {
        toggleBvDGuidelineSpecificFields(show, role, origin, "IMMUNOSUPPRESSANT");
    } else if (dltAutomationGuidelineForm?.includes("BvD Non-Formulary (Infusion)")) {
        toggleBvDGuidelineSpecificFields(show, role, origin, "ESRD Infusion");
    } else if (dltAutomationGuidelineForm?.includes("BvD Non-Formulary (Oral Chemotherapy)")) {
        toggleBvDOralChemotherapyFields(show, role, origin);
    } else if (dltAutomationGuidelineForm?.includes("BvD Non-Formulary (Parenteral Nutrition)")) {
        toggleBvDGuidelineSpecificFields(show, role, origin, "PARENTERAL NUTRITION");
    } else if (dltAutomationGuidelineForm?.includes("BvD Non-Formulary (Inhalation)")) {
        toggleBvDGuidelineSpecificFields(show, role, origin, "INHALATION");
    } else if (dltAutomationGuidelineForm?.includes("BvD Non-Formulary (IVIG)")) {
        toggleBvDGuidelineSpecificFields(show, role, origin, "IVIG");
    } else if (dltAutomationGuidelineForm?.includes("BvD Non-Formulary (Oral Antiemetics)")) {
        toggleBvDGuidelineSpecificFields(show, role, origin, "ORAL ANTIEMETICS");
    }
}

/* Toggling BvD fields in a specific range */
// Note:
// - fromField and toField are the field IDs that define the range (exclusive)
// - If toField is not provided, it will toggle till the end
export function toggleBvDFieldsInRange(show, role, origin, BvDType, fromField, toField) {
    const elements = document.querySelectorAll(
        `[data-tag="dltGuideline BvD ${BvDType}"]`
    );
    
    let toggle = false;
    const fieldIds = [];
    
    elements.forEach((element) => {
        if (element.id?.includes(`${role}${origin}`)) {
            const elementId = element.id;
            
            // Start collecting after fromField
            if (!toggle && elementId.includes(fromField)) {
                toggle = true;
                return; // Skip fromField itself
            }
            
            // Stop collecting before toField
            if (toField && elementId.includes(toField)) {
                toggle = false;
                return; // Skip toField itself
            }
            
            if (toggle) {
                fieldIds.push(elementId);
                if(!show) {
                    clearInput("radio", [`${elementId}rdo`]);
                }
            }
        }
    });
    
    // Apply toggleDisplay on collected field IDs
    if (fieldIds.length > 0) {
        toggleDisplay('solo', fieldIds, show ? 'enable' : 'disable');
    }
}
