import {
  bvdDiagnosisProvided,
  drugAdminViaInfusionPump,
  drugAdminViaInfusionPumpHome,
  drugForESRD,
  drugFromPhysicianStockBvD,
  drugPrescribedBySpecialist,
  injectableAgentRequest,
  licsMember,
  medicarePartAPayingFacilityBed,
  narcoticAnalgesicNonCancerDx,
  parenteralNutritionRequest,
  patientHasCysticFibrosis,
  patientHasCysticFibrosisOrBronchiectasis,
  patientHasHIVPneumocystosisOrComplicationsOfOrganTransplants,
  patientHasPulmonaryArteryHypertension,
  patientInSkilledNursingFacility,
  patientResidenceCode,
  patientRiskHepatitisB,
  patientUsingMedWithNebulizer,
  permanentDysfunctionDigestiveTract,
  persistentThickPulmonarySecretions,
  rejectWithA4orA6,
  requestForAcetylcysteine,
  requestForAsthmaOrObstructivePulmonaryDisease,
  requestForBetaAgonistSteroidInhalantAnticholinergicOrPDEInhibitor,
  requestForDornaseAlphaPulmozyme,
  requestForNebupent,
  requestForTobramycinInhalationSolution,
  requestForTyvasoOrVentavis,
  transplantIndicatorPresent,
  medicationReceivedInHome,
  patientReceivingMedicationForPrimaryImmuneDeficiencyDisease,
  requestForHizentraOrHyQvia,
  medicationGivenSubcutaneously,
  patientReceivingMedicationForCIDP,
  patientReceivingMedicationInMedicalOfficeOrInfusionCenter,
  requestedDrugSuppliedFromPhysicianOfficeStockIVIG,
  patientResidesInSNFOrSkilledCareFacility,
  medicarePartAPayingForLTCFacilityBed,
  bvdDiagnosisProvidedIVIG,
  requestForVarubiEmendOrAkynzeo,
  oralAntiemeticUsedInChemotherapy,
  oralAntiemeticUsedInChemotherapyReplacement,
  patientRequiresOneOfFollowing,
  requestForAkynzeo,
  requestedDrugUsedInCancerChemotherapy,
  oralAntiemeticFullTherapeuticReplacement,
  oralCorticosteroidAnd5HT3ReceptorAntagonist,
  patientReceivingChemotherapeuticAgents,
  akynzeoUsedInCancerChemotherapyRegimen,
  oralAntiemeticFullTherapeuticReplacementAkynzeo,
  oralCorticosteroidRegimen,
  patientReceivingChemotherapeuticAgentsAkynzeo,
} from "../../qsets/fields";
import {
  handleBvdDiagnosisProvided,
  handleDrugAdminViaInfusionPump,
  handleDrugAdminViaInfusionPumpHome,
  handleDrugForESRD,
  handleDrugFromPhysicianStockBvD,
  handleDrugPrescribedBySpecialist,
  handleInjectableAgentRequest,
  handleLicsMember,
  handleMedicarePartAPayingFacilityBed,
  handleNarcoticAnalgesicNonCancerDx,
  handleParenteralNutritionRequest,
  handlePatientHasCysticFibrosis,
  handlePatientHasCysticFibrosisOrBronchiectasis,
  handlePatientHasHIVPneumocystosisOrComplicationsOfOrganTransplants,
  handlePatientHasPulmonaryArteryHypertension,
  handlePatientInSkilledNursingFacility,
  handlePatientResidenceCode,
  handlePatientRiskHepatitisB,
  handlePatientUsingMedWithNebulizer,
  handlePermanentDysfunctionDigestiveTract,
  handlePersistentThickPulmonarySecretions,
  handleRejectWithA4orA6,
  handleRequestForAcetylcysteine,
  handleRequestForAsthmaOrObstructivePulmonaryDisease,
  handleRequestForBetaAgonistSteroidInhalantAnticholinergicOrPDEInhibitor,
  handleRequestForDornaseAlphaPulmozyme,
  handleRequestForNebupent,
  handleRequestForTobramycinInhalationSolution,
  handleRequestForTyvasoOrVentavis,
  handleTransplantIndicatorPresent,
  handleMedicationReceivedInHome,
  handlePatientReceivingMedicationForPrimaryImmuneDeficiencyDisease,
  handleRequestForHizentraOrHyQvia,
  handleMedicationGivenSubcutaneously,
  handlePatientReceivingMedicationForCIDP,
  handlePatientReceivingMedicationInMedicalOfficeOrInfusionCenter,
  handleRequestedDrugSuppliedFromPhysicianOfficeStockIVIG,
  handlePatientResidesInSNFOrSkilledCareFacility,
  handleMedicarePartAPayingForLTCFacilityBed,
  handleBvdDiagnosisProvidedIVIG,
  handleRequestForVarubiEmendOrAkynzeo,
  handleOralAntiemeticUsedInChemotherapy,
  handleOralAntiemeticUsedInChemotherapyReplacement,
  handlePatientRequiresOneOfFollowing,
  handleRequestForAkynzeo,
  handleRequestedDrugUsedInCancerChemotherapy,
  handleOralAntiemeticFullTherapeuticReplacement,
  handleOralCorticosteroidAnd5HT3ReceptorAntagonist,
  handlePatientReceivingChemotherapeuticAgents,
  handleAkynzeoUsedInCancerChemotherapyRegimen,
  handleOralAntiemeticFullTherapeuticReplacementAkynzeo,
  handleOralCorticosteroidRegimen,
  handlePatientReceivingChemotherapeuticAgentsAkynzeo,
} from "./handlers";

export default function BvDListeners(origin, role) {
  let answer = "";

  /* BvD Non-Formulary common handlers */
  licsMember(role, origin, "event").forEach((elem) => {
    elem.addEventListener("click", (e) => {
      answer = e.target.value;
      handleLicsMember(role, origin, answer);
    });
  });

  rejectWithA4orA6(role, origin, "event").forEach((elem) => {
    elem.addEventListener("click", (e) => {
      answer = e.target.value;
      handleRejectWithA4orA6(role, origin, answer);
    });
  });

  /* BVD NON-FORMULARY (ESRD) specific handlers */
  drugPrescribedBySpecialist(role, origin, "event").forEach((elem) => {
    elem.addEventListener("click", (e) => {
      answer = e.target.value;
      handleDrugPrescribedBySpecialist(role, origin, answer);
    });
  });

  drugForESRD(role, origin, "event").forEach((elem) => {
    elem.addEventListener("click", (e) => {
      answer = e.target.value;
      handleDrugForESRD(role, origin, answer);
    });
  });

  drugAdminViaInfusionPump(role, origin, "event").forEach((elem) => {
    elem.addEventListener("click", (e) => {
      answer = e.target.value;
      handleDrugAdminViaInfusionPump(role, origin, answer);
    });
  });

  drugAdminViaInfusionPumpHome(role, origin, "event").forEach((elem) => {
    elem.addEventListener("click", (e) => {
      answer = e.target.value;
      handleDrugAdminViaInfusionPumpHome(role, origin, answer);
    });
  });

  patientInSkilledNursingFacility(role, origin, "event").forEach((elem) => {
    elem.addEventListener("click", (e) => {
      answer = e.target.value;
      handlePatientInSkilledNursingFacility(role, origin, answer);
    });
  });

  medicarePartAPayingFacilityBed(role, origin, "event").forEach((elem) => {
    elem.addEventListener("click", (e) => {
      answer = e.target.value;
      handleMedicarePartAPayingFacilityBed(role, origin, answer);
    });
  });

  narcoticAnalgesicNonCancerDx(role, origin, "event").forEach((elem) => {
    elem.addEventListener("click", (e) => {
      answer = e.target.value;
      handleNarcoticAnalgesicNonCancerDx(role, origin, answer);
    });
  });

  injectableAgentRequest(role, origin, "event").forEach((elem) => {
    elem.addEventListener("click", (e) => {
      answer = e.target.value;
      handleInjectableAgentRequest(role, origin, answer);
    });
  });

  drugFromPhysicianStockBvD(role, origin, "event").forEach((elem) => {
    elem.addEventListener("click", (e) => {
      answer = e.target.value;
      handleDrugFromPhysicianStockBvD(role, origin, answer);
    });
  });

  /* BVD NON-FORMULARY (HEPATITIS B) specific handlers */
  patientRiskHepatitisB(role, origin, "event").forEach((elem) => {
    elem.addEventListener("click", (e) => {
      answer = e.target.value;
      handlePatientRiskHepatitisB(role, origin, answer);
    });
  });

  /* BVD NON-FORMULARY (IMMUNOSUPPRESSANT) specific handlers */
  transplantIndicatorPresent(role, origin, "event").forEach((elem) => {
    elem.addEventListener("click", (e) => {
      answer = e.target.value;
      handleTransplantIndicatorPresent(role, origin, answer);
    });
  });

  /* BVD NON-FORMULARY (PARENTERAL NUTRITION) specific handlers */
  parenteralNutritionRequest(role, origin, "event").forEach((elem) => {
    elem.addEventListener("click", (e) => {
      answer = e.target.value;
      handleParenteralNutritionRequest(role, origin, answer);
    });
  });

  permanentDysfunctionDigestiveTract(role, origin, "event").forEach((elem) => {
    elem.addEventListener("click", (e) => {
      answer = e.target.value;
      handlePermanentDysfunctionDigestiveTract(role, origin, answer);
    });
  });

  /* BVD NON-FORMULARY (INHALATION) specific handlers */
  patientResidenceCode(role, origin, "event").forEach((elem) => {
    elem.addEventListener("click", (e) => {
      answer = e.target.value;
      handlePatientResidenceCode(role, origin, answer);
    });
  });

  patientUsingMedWithNebulizer(role, origin, "event").forEach((elem) => {
    elem.addEventListener("click", (e) => {
      answer = e.target.value;
      handlePatientUsingMedWithNebulizer(role, origin, answer);
    });
  });

  requestForBetaAgonistSteroidInhalantAnticholinergicOrPDEInhibitor(role, origin, "event").forEach((elem) => {
    elem.addEventListener("click", (e) => {
      answer = e.target.value;
      handleRequestForBetaAgonistSteroidInhalantAnticholinergicOrPDEInhibitor(role, origin, answer);
    });
  });

  requestForAsthmaOrObstructivePulmonaryDisease(role, origin, "event").forEach((elem) => {
    elem.addEventListener("click", (e) => {
      answer = e.target.value;
      handleRequestForAsthmaOrObstructivePulmonaryDisease(role, origin, answer);
    });
  });

  requestForDornaseAlphaPulmozyme(role, origin, "event").forEach((elem) => {
    elem.addEventListener("click", (e) => {
      answer = e.target.value;
      handleRequestForDornaseAlphaPulmozyme(role, origin, answer);
    });
  });

  patientHasCysticFibrosis(role, origin, "event").forEach((elem) => {
    elem.addEventListener("click", (e) => {
      answer = e.target.value;
      handlePatientHasCysticFibrosis(role, origin, answer);
    });
  });

  requestForTobramycinInhalationSolution(role, origin, "event").forEach((elem) => {
    elem.addEventListener("click", (e) => {
      answer = e.target.value;
      handleRequestForTobramycinInhalationSolution(role, origin, answer);
    });
  });

  patientHasCysticFibrosisOrBronchiectasis(role, origin, "event").forEach((elem) => {
    elem.addEventListener("click", (e) => {
      answer = e.target.value;
      handlePatientHasCysticFibrosisOrBronchiectasis(role, origin, answer);
    });
  });

  requestForAcetylcysteine(role, origin, "event").forEach((elem) => {
    elem.addEventListener("click", (e) => {
      answer = e.target.value;
      handleRequestForAcetylcysteine(role, origin, answer);
    });
  });

  persistentThickPulmonarySecretions(role, origin, "event").forEach((elem) => {
    elem.addEventListener("click", (e) => {
      answer = e.target.value;
      handlePersistentThickPulmonarySecretions(role, origin, answer);
    });
  });

  requestForNebupent(role, origin, "event").forEach((elem) => {
    elem.addEventListener("click", (e) => {
      answer = e.target.value;
      handleRequestForNebupent(role, origin, answer);
    });
  });

  patientHasHIVPneumocystosisOrComplicationsOfOrganTransplants(role, origin, "event").forEach((elem) => {
    elem.addEventListener("click", (e) => {
      answer = e.target.value;
      handlePatientHasHIVPneumocystosisOrComplicationsOfOrganTransplants(role, origin, answer);
    });
  });

  requestForTyvasoOrVentavis(role, origin, "event").forEach((elem) => {
    elem.addEventListener("click", (e) => {
      answer = e.target.value;
      handleRequestForTyvasoOrVentavis(role, origin, answer);
    });
  });

  patientHasPulmonaryArteryHypertension(role, origin, "event").forEach((elem) => {
    elem.addEventListener("click", (e) => {
      answer = e.target.value;
      handlePatientHasPulmonaryArteryHypertension(role, origin, answer);
    });
  });

  bvdDiagnosisProvided(role, origin, "event").forEach((elem) => {
    elem.addEventListener("click", (e) => {
      answer = e.target.value;
      handleBvdDiagnosisProvided(role, origin, answer);
    });
  });

  /* BVD NON-FORMULARY (IVIG) specific handlers */
  medicationReceivedInHome(role, origin, "event").forEach((elem) => {
    elem.addEventListener("click", (e) => {
      answer = e.target.value;
      handleMedicationReceivedInHome(role, origin, answer);
    });
  });

  patientReceivingMedicationForPrimaryImmuneDeficiencyDisease(role, origin, "event").forEach((elem) => {
    elem.addEventListener("click", (e) => {
      answer = e.target.value;
      handlePatientReceivingMedicationForPrimaryImmuneDeficiencyDisease(role, origin, answer);
    });
  });

  requestForHizentraOrHyQvia(role, origin, "event").forEach((elem) => {
    elem.addEventListener("click", (e) => {
      answer = e.target.value;
      handleRequestForHizentraOrHyQvia(role, origin, answer);
    });
  });

  medicationGivenSubcutaneously(role, origin, "event").forEach((elem) => {
    elem.addEventListener("click", (e) => {
      answer = e.target.value;
      handleMedicationGivenSubcutaneously(role, origin, answer);
    });
  });

  patientReceivingMedicationForCIDP(role, origin, "event").forEach((elem) => {
    elem.addEventListener("click", (e) => {
      answer = e.target.value;
      handlePatientReceivingMedicationForCIDP(role, origin, answer);
    });
  });

  patientReceivingMedicationInMedicalOfficeOrInfusionCenter(role, origin, "event").forEach((elem) => {
    elem.addEventListener("click", (e) => {
      answer = e.target.value;
      handlePatientReceivingMedicationInMedicalOfficeOrInfusionCenter(role, origin, answer);
    });
  });

  requestedDrugSuppliedFromPhysicianOfficeStockIVIG(role, origin, "event").forEach((elem) => {
    elem.addEventListener("click", (e) => {
      answer = e.target.value;
      handleRequestedDrugSuppliedFromPhysicianOfficeStockIVIG(role, origin, answer);
    });
  });

  patientResidesInSNFOrSkilledCareFacility(role, origin, "event").forEach((elem) => {
    elem.addEventListener("click", (e) => {
      answer = e.target.value;
      handlePatientResidesInSNFOrSkilledCareFacility(role, origin, answer);
    });
  });

  medicarePartAPayingForLTCFacilityBed(role, origin, "event").forEach((elem) => {
    elem.addEventListener("click", (e) => {
      answer = e.target.value;
      handleMedicarePartAPayingForLTCFacilityBed(role, origin, answer);
    });
  });

  bvdDiagnosisProvidedIVIG(role, origin, "event").forEach((elem) => {
    elem.addEventListener("click", (e) => {
      answer = e.target.value;
      handleBvdDiagnosisProvidedIVIG(role, origin, answer);
    });
  });

  /* BVD NON-FORMULARY (ORAL ANTIEMETICS) specific handlers */
  requestForVarubiEmendOrAkynzeo(role, origin, "event").forEach((elem) => {
    elem.addEventListener("click", (e) => {
      answer = e.target.value;
      handleRequestForVarubiEmendOrAkynzeo(role, origin, answer);
    });
  });

  oralAntiemeticUsedInChemotherapy(role, origin, "event").forEach((elem) => {
    elem.addEventListener("click", (e) => {
      answer = e.target.value;
      handleOralAntiemeticUsedInChemotherapy(role, origin, answer);
    });
  });

  oralAntiemeticUsedInChemotherapyReplacement(role, origin, "event").forEach((elem) => {
    elem.addEventListener("click", (e) => {
      answer = e.target.value;
      handleOralAntiemeticUsedInChemotherapyReplacement(role, origin, answer);
    });
  });

  patientRequiresOneOfFollowing(role, origin, "event").forEach((elem) => {
    elem.addEventListener("click", (e) => {
      answer = e.target.value;
      handlePatientRequiresOneOfFollowing(role, origin, answer);
    });
  });

  requestForAkynzeo(role, origin, "event").forEach((elem) => {
    elem.addEventListener("click", (e) => {
      answer = e.target.value;
      handleRequestForAkynzeo(role, origin, answer);
    });
  });

  requestedDrugUsedInCancerChemotherapy(role, origin, "event").forEach((elem) => {
    elem.addEventListener("click", (e) => {
      answer = e.target.value;
      handleRequestedDrugUsedInCancerChemotherapy(role, origin, answer);
    });
  });

  oralAntiemeticFullTherapeuticReplacement(role, origin, "event").forEach((elem) => {
    elem.addEventListener("click", (e) => {
      answer = e.target.value;
      handleOralAntiemeticFullTherapeuticReplacement(role, origin, answer);
    });
  });

  oralCorticosteroidAnd5HT3ReceptorAntagonist(role, origin, "event").forEach((elem) => {
    elem.addEventListener("click", (e) => {
      answer = e.target.value;
      handleOralCorticosteroidAnd5HT3ReceptorAntagonist(role, origin, answer);
    });
  });

  patientReceivingChemotherapeuticAgents(role, origin, "event").forEach((elem) => {
    elem.addEventListener("click", (e) => {
      answer = e.target.value;
      handlePatientReceivingChemotherapeuticAgents(role, origin, answer);
    });
  });

  akynzeoUsedInCancerChemotherapyRegimen(role, origin, "event").forEach((elem) => {
    elem.addEventListener("click", (e) => {
      answer = e.target.value;
      handleAkynzeoUsedInCancerChemotherapyRegimen(role, origin, answer);
    });
  });

  oralAntiemeticFullTherapeuticReplacementAkynzeo(role, origin, "event").forEach((elem) => {
    elem.addEventListener("click", (e) => {
      answer = e.target.value;
      handleOralAntiemeticFullTherapeuticReplacementAkynzeo(role, origin, answer);
    });
  });

  oralCorticosteroidRegimen(role, origin, "event").forEach((elem) => {
    elem.addEventListener("click", (e) => {
      answer = e.target.value;
      handleOralCorticosteroidRegimen(role, origin, answer);
    });
  });

  patientReceivingChemotherapeuticAgentsAkynzeo(role, origin, "event").forEach((elem) => {
    elem.addEventListener("click", (e) => {
      answer = e.target.value;
      handlePatientReceivingChemotherapeuticAgentsAkynzeo(role, origin, answer);
    });
  });
}
