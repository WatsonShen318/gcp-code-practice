import { INJ_OR_IV_RTE_ADMIN_CD_LIST, LICS_INDICATOR_LIST } from "../constants";
import {
  BVD_INHALATION_DRUG_NAMES_LIST_FOR_requestForAcetylcysteineQ,
  BVD_INHALATION_DRUG_NAMES_LIST_FOR_requestForDornaseAlphaPulmozymeQ,
  BVD_INHALATION_DRUG_NAMES_LIST_FOR_requestForNebupentQ,
  BVD_INHALATION_DRUG_NAMES_LIST_FOR_requestForTobramycinInhalationSolutionQ,
  BVD_INHALATION_DRUG_NAMES_LIST_FOR_requestForTyvasoOrVentavisQ,
  BVD_INHALATION_ICD_CODES_LIST_FOR_patientHasCysticFibrosisOrBronchiectasisQ,
  BVD_INHALATION_ICD_CODES_LIST_FOR_patientHasCysticFibrosisQ,
  BVD_INHALATION_ICD_CODES_LIST_FOR_patientHasHIVPneumocystosisOrComplicationsOfOrganTransplantsQ,
  BVD_INHALATION_ICD_CODES_LIST_FOR_patientHasPulmonaryArteryHypertensionQ,
  BVD_INHALATION_ICD_CODES_LIST_FOR_persistentThickPulmonarySecretionsQ,
  BVD_INHALATION_ICD_CODES_LIST_FOR_requestForAsthmaOrObstructivePulmonaryDiseaseQ,
  BVD_IVIG_DRUG_NAMES_LIST_FOR_requestForAkynzeoQ,
  BVD_IVIG_DRUG_NAMES_LIST_FOR_requestForHizentraOrHyQviaQ,
  BVD_IVIG_DRUG_NAMES_LIST_FOR_requestForVarubiEmendOrAkynzeoQ,
  BVD_IVIG_ICD_CODES_LIST_FOR_patientReceivingMedicationForCIDPQ,
  BVD_IVIG_ICD_CODES_LIST_FOR_patientReceivingMedicationForPrimaryImmuneDeficiencyDiseaseQ,
} from "./constants";

/* Automation Logic for prefilling "Is this request for a LICS member?" */
export async function automateBvDLICSMemberField(licsIndicator, role, origin) {
  if (!licsIndicator) {
    return "";
  }

  const isBvDLICSMember = LICS_INDICATOR_LIST.includes(Number(licsIndicator));
  let dltAutomatedBvDLICSMemberFieldAns = "";

  let LICSMemberQRadioBtn = "";

  if (isBvDLICSMember) {
    LICSMemberQRadioBtn = document.getElementById(
      `${role}${origin}licsMemberQYes`
    );
    dltAutomatedBvDLICSMemberFieldAns = "Yes";
  } else if (licsIndicator) {
    LICSMemberQRadioBtn = document.getElementById(
      `${role}${origin}licsMemberQNo`
    );
    dltAutomatedBvDLICSMemberFieldAns = "No";
  }

  if (LICSMemberQRadioBtn) {
    LICSMemberQRadioBtn.checked = true;
    LICSMemberQRadioBtn.click();
    LICSMemberQRadioBtn.disabled = false;
    sessionStorage.setItem(
      "dltAutomatedBvDLICSMemberFieldAns",
      dltAutomatedBvDLICSMemberFieldAns
    );
    sessionStorage.setItem(
      "dltFinalBvDLICSMemberFieldAns",
      dltAutomatedBvDLICSMemberFieldAns
    );
  }

  return dltAutomatedBvDLICSMemberFieldAns;
}

/* Automation Logic for prefilling "Is the requested drug rejecting with an 'A4' or 'A6' reject code OR is there messaging indicating the medication may be covered under Part D or B, indicating a BvD review is needed?" */
export async function automateBvDRejectWithA4orA6QField(
  rejectCodes,
  role,
  origin
) {
  if (!rejectCodes) {
    return "";
  }
  const isRejectWithA6 = rejectCodes
    ?.split(";")
    .map((code) => code.trim())
    .includes("A6");

  const isRejectWithA4 = rejectCodes
    ?.split(";")
    .map((code) => code.trim())
    .includes("A4");

  let rejectWithA4orA6QRadioBtn = "";
  let dltAutomationBvDRejectWithA4orA6FieldAns = "";

  if (isRejectWithA6 || isRejectWithA4) {
    rejectWithA4orA6QRadioBtn = document.getElementById(
      `${role}${origin}rejectWithA4orA6QYes`
    );
    dltAutomationBvDRejectWithA4orA6FieldAns = "Yes";
  } else if (rejectCodes) {
    rejectWithA4orA6QRadioBtn = document.getElementById(
      `${role}${origin}rejectWithA4orA6QNo`
    );
    dltAutomationBvDRejectWithA4orA6FieldAns = "No";
  }

  if (rejectWithA4orA6QRadioBtn) {
    rejectWithA4orA6QRadioBtn.checked = true;
    rejectWithA4orA6QRadioBtn.click();
    sessionStorage.setItem(
      "dltAutomatedBvDRejectWithA4orA6FieldAns",
      dltAutomationBvDRejectWithA4orA6FieldAns
    );
    sessionStorage.setItem(
      "dltFinalBvDRejectWithA4orA6FieldAns",
      dltAutomationBvDRejectWithA4orA6FieldAns
    );
  }

  return dltAutomationBvDRejectWithA4orA6FieldAns;
}

/* Automation Logic for prefilling "Is the request for an injectable agent?" */
export async function automateBvDInjectableAgentRequestQField(
  roa,
  role,
  origin
) {
  if (!roa) {
    return "";
  }
  const isInjectableAgentRequest = INJ_OR_IV_RTE_ADMIN_CD_LIST.includes(
    roa?.toUpperCase()
  );

  let injectableAgentRequestQRadioBtn = "";
  let dltAutomationBvDInjectableAgentRequestFieldAns = "";

  if (isInjectableAgentRequest) {
    injectableAgentRequestQRadioBtn = document.getElementById(
      `${role}${origin}injectableAgentRequestQYes`
    );
    dltAutomationBvDInjectableAgentRequestFieldAns = "Yes";
  } else if (roa) {
    injectableAgentRequestQRadioBtn = document.getElementById(
      `${role}${origin}injectableAgentRequestQNo`
    );
    dltAutomationBvDInjectableAgentRequestFieldAns = "No";
  }

  if (injectableAgentRequestQRadioBtn) {
    injectableAgentRequestQRadioBtn.checked = true;
    injectableAgentRequestQRadioBtn.click();
    sessionStorage.setItem(
      "dltAutomatedBvDESRDInjectableAgentRequestFieldAns",
      dltAutomationBvDInjectableAgentRequestFieldAns
    );
    sessionStorage.setItem(
      "dltFinalBvDESRDInjectableAgentRequestFieldAns",
      dltAutomationBvDInjectableAgentRequestFieldAns
    );
  }

  return dltAutomationBvDInjectableAgentRequestFieldAns;
}

/* automate BvD - Inhalation/IVIG - bvdDiagnosisProvidedQ field */
export async function automateBvdDiagnosisProvidedQField(
  role,
  origin,
  fieldId,
  BvDType
) {
  let diagnosisValue = document.getElementById(
    `${role}${origin}diagnosisQlt`
  ).value;

  let fieldRadioBtn = "";
  let automatedFieldAns = "";

  if (diagnosisValue && diagnosisValue.trim() !== "") {
    fieldRadioBtn = document.getElementById(`${role}${origin}${fieldId}Yes`);
    automatedFieldAns = "Yes";
  } else {
    fieldRadioBtn = document.getElementById(`${role}${origin}${fieldId}No`);
    automatedFieldAns = "No";
  }

  if (fieldRadioBtn) {
    fieldRadioBtn.checked = true;
    fieldRadioBtn.click();
    sessionStorage.setItem(
      `dltAutomatedBvD${BvDType}${fieldId}FieldAns`,
      automatedFieldAns
    );
    sessionStorage.setItem(
      `dltFinalBvD${BvDType}${fieldId}FieldAns`,
      automatedFieldAns
    );
  }

  return automatedFieldAns;
}

/* Automation logic for BvD Inhalation Guidelines */

/* Generic helper function for automating drug name-based fields */
export async function automateDrugNameBasedField({
  drugNamesList,
  drugName,
  role,
  origin,
  fieldId,
  BvDType,
}) {
  if (!drugName) {
    return "";
  }

  // Convert drugName to uppercase for case-insensitive comparison
  const upperCaseDrugName = drugName.trim().toUpperCase();

  // Check if any drug name from the list is present in the drugName
  const isDrugNameMatch = drugNamesList.some((drugNameInList) => {
    const upperCaseDrugNameInList = drugNameInList.toUpperCase();
    return upperCaseDrugName.includes(upperCaseDrugNameInList);
  });

  let fieldRadioBtn = "";
  let automatedFieldAns = "";
  let field = document.getElementById(`${role}${origin}${fieldId}`);

  if (isDrugNameMatch) {
    fieldRadioBtn = document.getElementById(`${role}${origin}${fieldId}Yes`);
    automatedFieldAns = "Yes";
  } else if (drugName) {
    fieldRadioBtn = document.getElementById(`${role}${origin}${fieldId}No`);
    automatedFieldAns = "No";
  }

  if (fieldRadioBtn) {
    fieldRadioBtn.checked = true;
    fieldRadioBtn.click();
    field.disabled = true;
    sessionStorage.setItem(
      `dltAutomatedBvD${BvDType.replace(/ /g, "")}${fieldId}FieldAns`,
      automatedFieldAns
    );
    sessionStorage.setItem(
      `dltFinalBvD${BvDType.replace(/ /g, "")}${fieldId}FieldAns`,
      automatedFieldAns
    );
  }

  return automatedFieldAns;
}

/* Generic helper function for automating ICD code-based fields */
export async function automateICDCodeBasedField({
  icdCodesList,
  diagnosis,
  role,
  origin,
  fieldId,
  BvDType,
}) {
  if (
    !(diagnosis?.diagnosis1 || diagnosis?.diagnosis2 || diagnosis?.diagnosis3)
  ) {
    return "";
  }

  // Extract diagnosis1, diagnosis2, diagnosis3 from diagnosis object/variable
  const diagnosis1 = diagnosis?.diagnosis1?.trim().toUpperCase() || "";
  const diagnosis2 = diagnosis?.diagnosis2?.trim().toUpperCase() || "";
  const diagnosis3 = diagnosis?.diagnosis3?.trim().toUpperCase() || "";

  // Convert ICD codes list to uppercase for case-insensitive comparison
  const upperCaseICDCodesList = icdCodesList.map((code) => code.toUpperCase());

  // Check if any diagnosis is present in the ICD codes list
  const isDiagnosisMatch =
    (diagnosis1 && upperCaseICDCodesList.includes(diagnosis1)) ||
    (diagnosis2 && upperCaseICDCodesList.includes(diagnosis2)) ||
    (diagnosis3 && upperCaseICDCodesList.includes(diagnosis3));

  let fieldRadioBtn = "";
  let automatedFieldAns = "";

  if (isDiagnosisMatch) {
    fieldRadioBtn = document.getElementById(`${role}${origin}${fieldId}Yes`);
    automatedFieldAns = "Yes";
  } else if (diagnosis1 || diagnosis2 || diagnosis3) {
    fieldRadioBtn = document.getElementById(`${role}${origin}${fieldId}No`);
    automatedFieldAns = "No";
  }

  if (fieldRadioBtn) {
    fieldRadioBtn.checked = true;
    fieldRadioBtn.click();
    sessionStorage.setItem(
      `dltAutomatedBvD${BvDType}${fieldId}FieldAns`,
      automatedFieldAns
    );
    sessionStorage.setItem(
      `dltFinalBvD${BvDType}${fieldId}FieldAns`,
      automatedFieldAns
    );
  }

  return automatedFieldAns;
}

/* Automation Logic for prefilling BvD Inhalation fields */
export async function automateBvDInhalationFields(
  drugName,
  diagnosis,
  role,
  origin
) {
  console.log(
    "Automating BvD Inhalation Fields with drugName:",
    drugName,
    "and diagnosis:",
    diagnosis
  );

  /* Automate "Is the requested drug being prescribed for the management of asthma or obstructive pulmonary disease?" */
  const dltAutomatedBvDINHALATIONrequestForAsthmaOrObstructivePulmonaryDiseaseQFieldAns =
    await automateICDCodeBasedField({
      icdCodesList:
        BVD_INHALATION_ICD_CODES_LIST_FOR_requestForAsthmaOrObstructivePulmonaryDiseaseQ,
      diagnosis,
      role,
      origin,
      fieldId: "requestForAsthmaOrObstructivePulmonaryDiseaseQ",
      BvDType: "INHALATION",
    });

  /* Automate "Is the request for dornase alpha (Pulmozyme)?" */
  const dltAutomatedBvDINHALATIONrequestForDornaseAlphaPulmozymeQFieldAns =
    await automateDrugNameBasedField({
      drugNamesList:
        BVD_INHALATION_DRUG_NAMES_LIST_FOR_requestForDornaseAlphaPulmozymeQ,
      drugName: drugName,
      role,
      origin,
      fieldId: "requestForDornaseAlphaPulmozymeQ",
      BvDType: "INHALATION",
    });

  /* Automate "Does the patient have a diagnosis of cystic fibrosis?" */
  const dltAutomatedBvDINHALATIONpatientHasCysticFibrosisQFieldAns =
    await automateICDCodeBasedField({
      icdCodesList: BVD_INHALATION_ICD_CODES_LIST_FOR_patientHasCysticFibrosisQ,
      diagnosis,
      role,
      origin,
      fieldId: "patientHasCysticFibrosisQ",
      BvDType: "INHALATION",
    });

  /* Automate "Is the request for Tobramycin inhalation solution, TOBI nebulizer solution, Bethkis or Kitabis Pak?" */
  const dltAutomatedBvDINHALATIONrequestForTobramycinInhalationSolutionQFieldAns =
    await automateDrugNameBasedField({
      drugNamesList:
        BVD_INHALATION_DRUG_NAMES_LIST_FOR_requestForTobramycinInhalationSolutionQ,
      drugName: drugName,
      role,
      origin,
      fieldId: "requestForTobramycinInhalationSolutionQ",
      BvDType: "INHALATION",
    });

  /* Automate "Does the patient have a diagnosis of cystic fibrosis or bronchiectasis?" */
  const dltAutomatedBvDINHALATIONpatientHasCysticFibrosisOrBronchiectasisQFieldAns =
    await automateICDCodeBasedField({
      icdCodesList:
        BVD_INHALATION_ICD_CODES_LIST_FOR_patientHasCysticFibrosisOrBronchiectasisQ,
      diagnosis,
      role,
      origin,
      fieldId: "patientHasCysticFibrosisOrBronchiectasisQ",
      BvDType: "INHALATION",
    });

  /* Automate "Is the request for acetylcysteine?" */
  const dltAutomatedBvDINHALATIONrequestForAcetylcysteineQFieldAns =
    await automateDrugNameBasedField({
      drugNamesList:
        BVD_INHALATION_DRUG_NAMES_LIST_FOR_requestForAcetylcysteineQ,
      drugName: drugName,
      role,
      origin,
      fieldId: "requestForAcetylcysteineQ",
      BvDType: "INHALATION",
    });

  /* Automate "Does the patient have a diagnosis of persistent thick or tenacious pulmonary secretions associated with following ICD-10 diagnosis codes?" */
  const dltAutomatedBvDINHALATIONpersistentThickPulmonarySecretionsQFieldAns =
    await automateICDCodeBasedField({
      icdCodesList:
        BVD_INHALATION_ICD_CODES_LIST_FOR_persistentThickPulmonarySecretionsQ,
      diagnosis,
      role,
      origin,
      fieldId: "persistentThickPulmonarySecretionsQ",
      BvDType: "INHALATION",
    });

  /* Automate "Is the request for Nebupent (pentamide)?" */
  const dltAutomatedBvDINHALATIONrequestForNebupentQFieldAns =
    await automateDrugNameBasedField({
      drugNamesList: BVD_INHALATION_DRUG_NAMES_LIST_FOR_requestForNebupentQ,
      drugName: drugName,
      role,
      origin,
      fieldId: "requestForNebupentQ",
      BvDType: "INHALATION",
    });

  /* Automate "Does the patient have a diagnosis of human immunodeficiency virus (HIV) or pneumocystosis or complications of organ transplants?" */
  const dltAutomatedBvDINHALATIONpatientHasHIVPneumocystosisOrComplicationsOfOrganTransplantsQFieldAns =
    await automateICDCodeBasedField({
      icdCodesList:
        BVD_INHALATION_ICD_CODES_LIST_FOR_patientHasHIVPneumocystosisOrComplicationsOfOrganTransplantsQ,
      diagnosis,
      role,
      origin,
      fieldId: "patientHasHIVPneumocystosisOrComplicationsOfOrganTransplantsQ",
      BvDType: "INHALATION",
    });

  /* Automate "Is the request for Tyvaso or Ventavis?" */
  const dltAutomatedBvDINHALATIONrequestForTyvasoOrVentavisQFieldAns =
    await automateDrugNameBasedField({
      drugNamesList:
        BVD_INHALATION_DRUG_NAMES_LIST_FOR_requestForTyvasoOrVentavisQ,
      drugName: drugName,
      role,
      origin,
      fieldId: "requestForTyvasoOrVentavisQ",
      BvDType: "INHALATION",
    });

  /* Automate "Does the patient have a diagnosis of pulmonary artery hypertension?" */
  const dltAutomatedBvDINHALATIONpatientHasPulmonaryArteryHypertensionQFieldAns =
    await automateICDCodeBasedField({
      icdCodesList:
        BVD_INHALATION_ICD_CODES_LIST_FOR_patientHasPulmonaryArteryHypertensionQ,
      diagnosis,
      role,
      origin,
      fieldId: "patientHasPulmonaryArteryHypertensionQ",
      BvDType: "INHALATION",
    });

  /* Automate "Is a BvD diagnosis provided?" */
  const dltAutomatedBvDINHALATIONbvdDiagnosisProvidedQFieldAns =
    await automateBvdDiagnosisProvidedQField(
      role,
      origin,
      "bvdDiagnosisProvidedQ",
      "INHALATION"
    );

  console.log("Completed Automating BvD Inhalation Fields.", {
    dltAutomatedBvDINHALATIONrequestForAsthmaOrObstructivePulmonaryDiseaseQFieldAns,
    dltAutomatedBvDINHALATIONrequestForDornaseAlphaPulmozymeQFieldAns,
    dltAutomatedBvDINHALATIONpatientHasCysticFibrosisQFieldAns,
    dltAutomatedBvDINHALATIONrequestForTobramycinInhalationSolutionQFieldAns,
    dltAutomatedBvDINHALATIONpatientHasCysticFibrosisOrBronchiectasisQFieldAns,
    dltAutomatedBvDINHALATIONrequestForAcetylcysteineQFieldAns,
    dltAutomatedBvDINHALATIONpersistentThickPulmonarySecretionsQFieldAns,
    dltAutomatedBvDINHALATIONrequestForNebupentQFieldAns,
    dltAutomatedBvDINHALATIONpatientHasHIVPneumocystosisOrComplicationsOfOrganTransplantsQFieldAns,
    dltAutomatedBvDINHALATIONrequestForTyvasoOrVentavisQFieldAns,
    dltAutomatedBvDINHALATIONpatientHasPulmonaryArteryHypertensionQFieldAns,
    dltAutomatedBvDINHALATIONbvdDiagnosisProvidedQFieldAns,
  });
}

/* Automation Logic for prefilling BvD IVIG fields */
export async function automateBvDIVIGFields(drugName, diagnosis, role, origin) {
  console.log(
    "Automating BvD IVIG Fields with drugName:",
    drugName,
    "and diagnosis:",
    diagnosis
  );

  /* Automate "Is the patient receiving the requested medication for the diagnosis of primary immune deficiency disease for one of the following ICD-10 codes?:" */
  const dltAutomatedBvDIVIGpatientReceivingMedicationForPrimaryImmuneDeficiencyDiseaseQFieldAns =
    await automateICDCodeBasedField({
      icdCodesList:
        BVD_IVIG_ICD_CODES_LIST_FOR_patientReceivingMedicationForPrimaryImmuneDeficiencyDiseaseQ,
      diagnosis,
      role,
      origin,
      fieldId: "patientReceivingMedicationForPrimaryImmuneDeficiencyDiseaseQ",
      BvDType: "IVIG",
    });

  /* Automate "Is the request for Hizentra or HyQvia?" */
  const dltAutomatedBvDIVIGrequestForHizentraOrHyQviaQFieldAns =
    await automateDrugNameBasedField({
      drugNamesList: BVD_IVIG_DRUG_NAMES_LIST_FOR_requestForHizentraOrHyQviaQ,
      drugName: drugName,
      role,
      origin,
      fieldId: "requestForHizentraOrHyQviaQ",
      BvDType: "IVIG",
    });

  /* Automate "Is the patient receiving the requested medication for the diagnosis of chronic inflammatory demyelinating polyneuropathy (CIDP) (ICD-10 code G61.81)?" */
  const dltAutomatedBvDIVIGpatientReceivingMedicationForCIDPQFieldAns =
    await automateICDCodeBasedField({
      icdCodesList:
        BVD_IVIG_ICD_CODES_LIST_FOR_patientReceivingMedicationForCIDPQ,
      diagnosis,
      role,
      origin,
      fieldId: "patientReceivingMedicationForCIDPQ",
      BvDType: "IVIG",
    });

  /* Automate "Was a diagnosis provided as part of the above BvD review?" */
  const dltAutomatedBvDIVIGbvdDiagnosisProvidedIVIGQFieldAns =
    await automateBvdDiagnosisProvidedQField(
      role,
      origin,
      "bvdDiagnosisProvidedIVIGQ",
      "IVIG"
    );

  console.log("Completed Automating BvD IVIG Fields.", {
    dltAutomatedBvDIVIGpatientReceivingMedicationForPrimaryImmuneDeficiencyDiseaseQFieldAns,
    dltAutomatedBvDIVIGrequestForHizentraOrHyQviaQFieldAns,
    dltAutomatedBvDIVIGpatientReceivingMedicationForCIDPQFieldAns,
    dltAutomatedBvDIVIGbvdDiagnosisProvidedIVIGQFieldAns,
  });
}

/* Automation Logic for prefilling BvD ORAL ANTIEMETICS fields */
export async function automateBvDOralAntiemeticsFields(drugName, diagnosis, role, origin) {
  console.log(
    "Automating BvD ORAL ANTIEMETICS Fields with drugName:",
    drugName
  );

  /* Automate "Is the request for Varubi or Emend (aprepitant) or Akynzeo?" */
  const dltAutomatedBvDORALANTIEMETICSrequestForVarubiEmendOrAkynzeoQFieldAns =
    await automateDrugNameBasedField({
      drugNamesList: BVD_IVIG_DRUG_NAMES_LIST_FOR_requestForVarubiEmendOrAkynzeoQ,
      drugName: drugName,
      role,
      origin,
      fieldId: "requestForVarubiEmendOrAkynzeoQ",
      BvDType: "ORAL ANTIEMETICS",
    });

  /* Automate "Is the request for Akynzeo?" */
  const dltAutomatedBvDORALANTIEMETICSrequestForAkynzeoQFieldAns =
    await automateDrugNameBasedField({
      drugNamesList: BVD_IVIG_DRUG_NAMES_LIST_FOR_requestForAkynzeoQ,
      drugName: drugName,
      role,
      origin,
      fieldId: "requestForAkynzeoQ",
      BvDType: "ORAL ANTIEMETICS",
    });


  console.log("Completed Automating BvD ORAL ANTIEMETICS Fields.", {
    dltAutomatedBvDORALANTIEMETICSrequestForVarubiEmendOrAkynzeoQFieldAns,
    dltAutomatedBvDORALANTIEMETICSrequestForAkynzeoQFieldAns,
  });
}
