import { approvedDiagnosis, insulinPumpMedication, licsAndROA, rejectWithA6 } from "../qsets/fields";

/* Helper to update session storage for manually Final DLT guideline automated fields */
function updateSSDLTFinalApprovableDiagnosisFieldAns(role, origin) {
    const approvedDiagValue = approvedDiagnosis(role, origin, 'value');
    sessionStorage.setItem(
        "dltFinalApprovableDiagnosisFieldAns",
        approvedDiagValue
    );
}

function updateSSDLTFinalInsulinPumpMedicationFieldAns(role, origin) {
    const approvedInsulinPumpValue = insulinPumpMedication(role, origin, 'value');
    sessionStorage.setItem(
        "dltFinalInsulinPumpMedicationFieldAns",
        approvedInsulinPumpValue
    );
}

function updateSSDLTFinalRejectWithA6FieldAns(role, origin) {
    const approvedRejectWithA6Value = rejectWithA6(role, origin, 'value');
    sessionStorage.setItem(
        "dltFinalRejectWithA6FieldAns",
        approvedRejectWithA6Value
    );
}

function updateSSDLTFinalLICSAndROAFieldAns(role, origin) {
    const approvedLICSAndROAValue = licsAndROA(role, origin, 'value');
    sessionStorage.setItem(
        "dltFinalLICSAndROAFieldAns",
        approvedLICSAndROAValue
    );
}

/* Parent function to update all DLT guideline automated fields in session storage */
export function updateSSDLTGuidelineAutomatedFields(role, origin) {
    updateSSDLTFinalApprovableDiagnosisFieldAns(role, origin);
    updateSSDLTFinalInsulinPumpMedicationFieldAns(role, origin);
    updateSSDLTFinalRejectWithA6FieldAns(role, origin);
    updateSSDLTFinalLICSAndROAFieldAns(role, origin);
}