export const DLT_GUIDELINE_FORMS_IN_SCOPE = [
  "STANDARD NON-FORMULARY",
  "DIAGNOSIS REQUIRED STANDARD NON-FORMULARY",
  "PROTECTED DRUG CLASS NON-FORMULARY",
  "PROTON PUMP INHIBITOR NON-FORMULARY",
  "ANTIBACTERIALS NON-FORMULARY",
  "OPIOID NON-FORMULARY",
  "HIGH RISK DRUG CLASS NON-FORMULARY",
  "DIAGNOSIS REQUIRED OPIOID NON-FORMULARY",
  "PROTECTED DRUG CLASS INFUSION NON-FORMULARY",
  "DIAGNOSIS REQUIRED ORAL CHEMOTHERAPY NON-FORMULARY",
  "BVD NON-FORMULARY (ESRD)",
  "BVD NON-FORMULARY (HEPATITIS B)",
  "BVD NON-FORMULARY (IMMUNOSUPPRESSANT)",
  "BVD NON-FORMULARY (INFUSION)",
  "BVD NON-FORMULARY (INHALATION)",
  "BVD NON-FORMULARY (IVIG)",
  "BVD NON-FORMULARY (ORAL ANTIEMETICS)",
  "BVD NON-FORMULARY (ORAL CHEMOTHERAPY)",
  "BVD NON-FORMULARY (ORAL CHEMOTHERAPY) - FOR AETNA MAPD CARRIERS SEE NOTE BELOW",
  "BVD NON-FORMULARY (PARENTERAL NUTRITION)",
  "QUANTITY LIMIT",
  "OPIOID QUANTITY LIMIT",
];

/* List of LICS Indicator values */
export const LICS_INDICATOR_LIST = [1, 2, 3, 4];

/* List of Route of Administration (ROA) values */
export const ROA_LIST = ["INJ", "IV"];

/* List of RTE_ADMIN_CD from drug denorm  for which "route of administration of the requested medication is injection (INJ) or intravenous (IV)?" can be automated to "Yes" */
export const INJ_OR_IV_RTE_ADMIN_CD_LIST = [
  "EPIDURAL",
  "HEMODIALYSIS",
  "IMPLANT",
  "INJECTION",
  "INTRA ARTERIAL",
  "INTRA ARTICULAR",
  "INTRADERMAL",
  "INTRALESIONAL",
  "INTRAMUSCULAR INJECTION",
  "INTRAOCULAR",
  "INTRAPERITONEAL",
  "INTRAPLEURAL",
  "INTRASPINAL",
  "INTRATHECAL INJECTION",
  "INTRATRACHEAL",
  "INTRATYMPANIC",
  "INTRAUTERINE",
  "INTRAVENOUS INJECTION",
  "INTRAVENTRIC",
  "INTRAVESICAL",
  "INTRAVITREAL",
  "IONTOPHORESIS",
  "IRRIGATION",
  "PERFUSION",
  "PERIARTICULAR",
  "SUBCUTANEOUS INJECTION",
  "URETERAL",
  "URETHRAL"
];

/* DLT Guideline Mapper between mapped guideline to GPI and dropdown options in UI */
export const DLT_GUIDELINE_OPTIONS_MAPPER = {
  "STANDARD NON-FORMULARY": "Standard Non-Formulary Exception",
  "DIAGNOSIS REQUIRED STANDARD NON-FORMULARY": "Diagnosis Required Standard Non-Formulary Exception",
  "PROTECTED DRUG CLASS NON-FORMULARY": "Protected Drug Class Non-Formulary Exception",
  "PROTON PUMP INHIBITOR NON-FORMULARY": "Proton Pump Inhibitor Non-Formulary Exception",
  "HIGH RISK DRUG CLASS NON-FORMULARY": "High Risk Drug Class Non-Formulary Exception",
  "OPIOID NON-FORMULARY": "Opioid Non-Formulary",
  "PROTECTED DRUG CLASS INFUSION NON-FORMULARY": "Diagnosis Required Protected Drug Classes Non-Formulary Exception",
  "DIAGNOSIS REQUIRED OPIOID NON-FORMULARY": "Diagnosis Required Opioid Non-Formulary Exception",
  "DIAGNOSIS REQUIRED ORAL CHEMOTHERAPY NON-FORMULARY": "Diagnosis Required Oral Chemotherapy Non-Formulary Exception",
  "ANTIBACTERIALS NON-FORMULARY": "Antibacterials Non-Formulary Exception",
  "BVD NON-FORMULARY (ESRD)": "BvD Non-Formulary (ESRD) Exception",
  "BVD NON-FORMULARY (HEPATITIS B)": "BvD Non-Formulary (Hepatitis B) Exception",
  "BVD NON-FORMULARY (IMMUNOSUPPRESSANT)": "BvD Non-Formulary (Immunosuppressant) Exception",
  "BVD NON-FORMULARY (INFUSION)": "BvD Non-Formulary (Infusion) Exception",
  "BVD NON-FORMULARY (INHALATION)": "BvD Non-Formulary (Inhalation) Exception",
  "BVD NON-FORMULARY (IVIG)": "BvD Non-Formulary (IVIG) Exception",
  "BVD NON-FORMULARY (ORAL ANTIEMETICS)": "BvD Non-Formulary (Oral Antiemetics) Exception",
  "BVD NON-FORMULARY (ORAL CHEMOTHERAPY)": "BvD Non-Formulary (Oral Chemotherapy) Exception",
  "BVD NON-FORMULARY (ORAL CHEMOTHERAPY) - FOR AETNA MAPD CARRIERS SEE NOTE BELOW": "BvD Non-Formulary (Oral Chemotherapy) Exception",
  "BVD NON-FORMULARY (PARENTERAL NUTRITION)": "BvD Non-Formulary (Parenteral Nutrition) Exception",
  "QUANTITY LIMIT": "Quantity Limit Exception",
  "OPIOID QUANTITY LIMIT": "Opioid Quantity Limit - 925",
}


