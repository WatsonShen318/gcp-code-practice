import { approvedDiagnosis } from "../qsets/fields";

/* Helper to extract GPI code from Medhok response */
export const extractGPIFromMHKResponse = (medhokResponse) => {
  const gpiCode = medhokResponse?.gpiCode?.trim();

  return gpiCode;
};

/* Helper to extract NDC from Medhok response */
export const extractNDCFromMHKResponse = (medhokResponse) => {
  const ndc = medhokResponse?.ndc?.trim();

  return ndc;
};

/* Helper to extract Reject Codes from Medhok response */
export const extractRejectCodesFromMHKResponse = (medhokResponse) => {
  const rejectCodes = medhokResponse?.rejectCodes || null;

  return rejectCodes;
};

/* Helper to extract LICS Indicator from Medhok response */
export const extractLICSIndicatorFromMHKResponse = (medhokResponse) => {
  const licsIndicator = medhokResponse?.memberEligibility?.subsidyLevel || null;

  return licsIndicator;
};

/* Helper to extract Drug Name from Medhok response */
export const extractDrugNameFromMHKResponse = (medhokResponse) => {
  const drugName = medhokResponse?.drugName?.trim();

  return drugName;
};

/* Helper to extract Diagnosis from Medhok response */
export const extractDiagnosisFromMHKResponse = (medhokResponse) => {
  let diagnosis1 = null;
  if(medhokResponse?.diagnosis1?.trim() !== "Not Available"){
    diagnosis1 = medhokResponse?.diagnosis1?.trim();
  }
  let diagnosis2 = null;
  if(medhokResponse?.diagnosis2?.trim() !== "Not Available"){
    diagnosis2 = medhokResponse?.diagnosis2?.trim();
  }
  let diagnosis3 = null;
  if(medhokResponse?.diagnosis3?.trim() !== "Not Available"){
    diagnosis3 = medhokResponse?.diagnosis3?.trim();
  }

  return { diagnosis1, diagnosis2, diagnosis3 };
};

/* Helper to extract Request Reason */
export const extractRequestReasonFromMHKResponse = (medhokResponse) => {
  const requestReason = medhokResponse?.requestReason?.trim() || null;
  return requestReason;
};

/* Helper to parse QL type from Request Reason */
export const parseQLRequestReason = (requestReason) => {
  const normalized = requestReason?.toUpperCase() || "";
  const hasQuantity = normalized.includes("QUANTITY");
  const hasOpioid = normalized.includes("OPIOID");

  if (hasQuantity && hasOpioid) {
    return { isRequestReasonQL: true, qlGuidelineForm: "OPIOID QUANTITY LIMIT" };
  }
  if (hasQuantity) {
    return { isRequestReasonQL: true, qlGuidelineForm: "QUANTITY LIMIT" };
  }
  return { isRequestReasonQL: false, qlGuidelineForm: "" };
};

/* DLT Guideline Automation helpers */
/*
  Context:
  It was identified an update is needed for the Part D Tech Auto Note (case queue and IBC) when the guideline is “Diagnosis Required Non-Formulary” to help guide technicians to route cases to RFI vs Clinical Review. 
  Updates:
  When Approvable Diagnosis question = N/A then any answer to formulary alternative questions will provide Auto Note Recommendation as “Send to RFI”
  All 3 formulary questions must be answered – recommendation displays immediately after final question
  If any of the formulary questions are answered as ‘Yes’ – then recommendation to “Send to RFI” is displayed rather than “approved”
*/

export const routeTechCasesToRFI = (role, origin) => {
  const approvedDiagnosisValue = approvedDiagnosis(role, origin, "value");
  const dltGuidelineName = sessionStorage.getItem("dltGuidelineName");
  if(approvedDiagnosisValue === "N/A" && dltGuidelineName === "Diagnosis Required Standard Non-Formulary Exception Guideline" && role === "tech" && ["Queue", "IBC"].includes(origin)) {
    return true;
  }

  return false;
};
