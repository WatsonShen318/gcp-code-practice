import { toggleDisplay } from "../utils/notetool.display";

export default function toggleDrugNameWSearchQ(
    role,
    origin,
    action
) {
    console.log("Toggling Drug Name With Search Q:", role, origin, action);
    if (action === "disable") {
        toggleDisplay("solo", [`${role}${origin}drugNameWSearchQ`], "disable");
        /* Enabling (actual) Drug Name field without search to allow user to enter manual drug entry */
        toggleDisplay("solo", [`${role}${origin}drugNameQ`], "enable");
    } else {
        toggleDisplay("solo", [`${role}${origin}drugNameWSearchQ`], "enable");
        /* Hiding (actual) Drug Name field without search to avoid confusion to the User */
        toggleDisplay("solo", [`${role}${origin}drugNameQ`], "disable");
    }
}
