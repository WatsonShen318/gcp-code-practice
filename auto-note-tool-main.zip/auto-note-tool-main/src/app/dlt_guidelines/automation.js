import getDLTGuidelineForm from "./data_sources/getDLTGuidelineForm";
import getInsulinPumpList from "./data_sources/getInsulinPumpList";
import getDLTMonthlyValidationICDCode from "./data_sources/getDLTMonthlyValidationData";
import {
  DLT_GUIDELINE_FORMS_IN_SCOPE,
  DLT_GUIDELINE_OPTIONS_MAPPER,
  INJ_OR_IV_RTE_ADMIN_CD_LIST,
  LICS_INDICATOR_LIST,
} from "./constants";
import { toggleDisplay } from "../utils/notetool.display";
import {
  extractDiagnosisFromMHKResponse,
  extractDrugNameFromMHKResponse,
  extractGPIFromMHKResponse,
  extractLICSIndicatorFromMHKResponse,
  extractNDCFromMHKResponse,
  extractRejectCodesFromMHKResponse,
  extractRequestReasonFromMHKResponse,
  parseQLRequestReason,
} from "./helpers";
import getDrugDenormData from "./data_sources/getDrugDenormData";
import { setGuidelineFromMapper } from "../utils/automation";
import toggleDrugNameWSearchQ from "./display";
import { clearInput } from "../utils/clearInput";
import { automateBvDInhalationFields, automateBvDInjectableAgentRequestQField, automateBvDIVIGFields, automateBvDLICSMemberField, automateBvDOralAntiemeticsFields, automateBvDRejectWithA4orA6QField } from "./bvd/automation";
import { typeOfQlReview } from '../qsets/fields';

/* Function to toggle display for all fields with data-tag="dltGuideline" */
function toggleAllDLTGuidelineFields(show, role, origin) {
  const elements = document.querySelectorAll('[data-tag="dltGuideline"]');
  elements.forEach((element) => {
    if (element.id?.includes(`${role}${origin}`)) {
      element.style.display = show ? "block" : "none";
      element.disabled = !show;
    } else {
      element.style.display = "none";
      element.disabled = true;
    }
  });

  /* Show "Prescriber, Member, AOR, Pharmacy" field for Tech IBC automation flow to cover DLT guidelines */
  // TODO: currently this is enabled for automated Tech IBC fields, need to confirm if this is expected
  // Instead of inqcallerQ - existing field(for manual tech ibc flow), added a new field for tech ibc automated flow for "Is the caller a Prescriber/MDO or a Member/AOR?"
  // if(role === "tech" && origin === "IBC") {
  //   toggleDisplay("solo", [`${role}${origin}inqcallerQ`], "enable");
  // }
}

/* Function to clear all fields with data-tag="dltGuideline" */
function clearAllDLTGuidelineFields(role, origin) {
  const elements = document.querySelectorAll('[data-tag^="dltGuideline"]');
  elements.forEach((element) => {
    if (element.id?.includes(`${role}${origin}`)) {
      element.style.display = "none";
      element.disabled = true;
      clearInput("radio", [`${element.id}rdo`]);
    }
  });

  /* Show "Prescriber, Member, AOR, Pharmacy" field for Tech IBC automation flow to cover DLT guidelines */
  // TODO: currently this is enabled for automated Tech IBC fields, need to confirm if this is expected
  // Instead of inqcallerQ - existing field(for manual tech ibc flow), added a new field for tech ibc automated flow for "Is the caller a Prescriber/MDO or a Member/AOR?"
  // if(role === "tech" && origin === "IBC") {
  //   toggleDisplay("solo", [`${role}${origin}inqcallerQ`], "enable");
  // }
}

/* Helper to toggle Guideline specific fields */
function toggleGuidelineSpecificFields(role, origin, dltGuidelineForm) {
  if (!(dltGuidelineForm === "STANDARD NON-FORMULARY")) {
    toggleDisplay(
      "solo",
      [`${role}${origin}insulinPumpMedicationQ`],
      "disable"
    );
  }

  if (!(["PROTECTED DRUG CLASS NON-FORMULARY", "PROTECTED DRUG CLASS INFUSION NON-FORMULARY"].includes(dltGuidelineForm))) {
    toggleDisplay(
      "solo",
      [`${role}${origin}patientIsStableOnRqstDrugQ`],
      "disable"
    );
  }

  if (!(dltGuidelineForm === "PROTON PUMP INHIBITOR NON-FORMULARY")) {
    toggleDisplay(
      "solo",
      [
        `${role}${origin}memberTakingPlavixQ`,
        `${role}${origin}triedExclOmprzlOrEsmprzlQ`,
      ],
      "disable"
    );
  }

  if (!(dltGuidelineForm === "ANTIBACTERIALS NON-FORMULARY")) {
    toggleDisplay(
      "solo",
      [
        `${role}${origin}memberIsStableOnRqstDrugQ`,
        `${role}${origin}infectionIsDrugRstntQ`,
      ],
      "disable"
    );
  }

  if (!(["OPIOID NON-FORMULARY", "DIAGNOSIS REQUIRED OPIOID NON-FORMULARY", "OPIOID QUANTITY LIMIT"].includes(dltGuidelineForm))) {
    toggleDisplay(
      "solo",
      [
        `${role}${origin}medicationGreaterThan7DaySupplyQ`,
      ],
      "disable"
    );
  }

  if (!(["HIGH RISK DRUG CLASS NON-FORMULARY", "DIAGNOSIS REQUIRED ORAL CHEMOTHERAPY NON-FORMULARY"].includes(dltGuidelineForm))) {
    toggleDisplay(
      "solo",
      [
        `${role}${origin}patientIsTakingNStableOnRqstDrugQ`,
      ],
      "disable"
    );
  }

  if (!(["DIAGNOSIS REQUIRED ORAL CHEMOTHERAPY NON-FORMULARY", "BVD NON-FORMULARY (ORAL CHEMOTHERAPY)", "BVD NON-FORMULARY (ORAL CHEMOTHERAPY) - FOR AETNA MAPD CARRIERS SEE NOTE BELOW"].includes(dltGuidelineForm))) {
    toggleDisplay(
      "solo",
      [
        `${role}${origin}oralChemotherapyUsedForCancerQ`,
        `${role}${origin}oralChemotherapyUsedForSameIndicationQ`
      ],
      "disable"
    );
  }

  if(!(["QUANTITY LIMIT"].includes(dltGuidelineForm))) {
    toggleDisplay(
      "solo",
      [
        `${role}${origin}typeOfQlReviewQ`,
        `${role}${origin}prescriberIndicatedApprovedFormularyQuantityLimitIneffectiveQ`,
        `${role}${origin}prescriberIndicatedApprovedDosesIneffectiveQ`
      ],
      "disable"
    );
  }

  if(dltGuidelineForm?.includes("QUANTITY")) {
    toggleDisplay('solo', [`${role}${origin}licsMemberQ`, `${role}${origin}rejectWithA4orA6Q`, `${role}${origin}licsAndROAQ`, `${role}${origin}rejectWithA6Q` ,`${role}${origin}drugFromPhysicianStockQ`, `${role}${origin}prescriberIndicatedFormAltsLessEffQ`, `${role}${origin}prescriberIndicatedFormAltsProduceAdvAffectsQ`, `${role}${origin}triedNFailedFormAltsQ`, `${role}${origin}dltShow0TFAltsQ`], 'disable');
  } else if(!dltGuidelineForm?.startsWith("BVD NON-FORMULARY")) { /* BVD Non-Formulary guidelines */
    toggleDisplay('solo', [`${role}${origin}licsMemberQ`, `${role}${origin}rejectWithA4orA6Q`], 'disable');
  } else {
    toggleDisplay('solo', [`${role}${origin}licsAndROAQ`, `${role}${origin}rejectWithA6Q` ,`${role}${origin}drugFromPhysicianStockQ`], 'disable');
  }
}

/* Automation Logic for showing DLT Guideline fields in main templates and removing existing DLT guideline drop down*/
async function automateDLTGuidelineForm(gpiCode, role, origin, requestReason=null, gpiSelected=null) {
  let dltAutomationGuidelineForm = await getDLTGuidelineForm(gpiCode);
  const { isRequestReasonQL, qlGuidelineForm } = parseQLRequestReason(requestReason);
  let isDLTGuidelineFormAutomated = false;
  // Clear any prior "drug not supported" alert before re-running (drug may have changed)
  document.getElementById(`${role}${origin}guidelineQ`)
    ?.parentElement?.querySelector('.ant-drug-unsupported-alert')?.remove();

  if (DLT_GUIDELINE_FORMS_IN_SCOPE.includes(dltAutomationGuidelineForm) && !isRequestReasonQL) {
    toggleAllDLTGuidelineFields(true, role, origin);
    toggleDisplay(
      "solo",
      [`${role}${origin}guidelineQ`, `${role}${origin}subguidelineQ`],
      "disable"
    );
    /* Toggle Guideline specific fields */
    toggleGuidelineSpecificFields(role, origin, dltAutomationGuidelineForm);
    isDLTGuidelineFormAutomated = true;
  } else if(isRequestReasonQL && qlGuidelineForm) {
    dltAutomationGuidelineForm = qlGuidelineForm;
    toggleAllDLTGuidelineFields(true, role, origin);
    toggleDisplay(
      "solo",
      [`${role}${origin}guidelineQ`, `${role}${origin}subguidelineQ`],
      "disable"
    );
    /* Toggle Guideline specific fields */
    toggleGuidelineSpecificFields(role, origin, dltAutomationGuidelineForm);
    isDLTGuidelineFormAutomated = true;
  } else {
    toggleAllDLTGuidelineFields(false);
    toggleDisplay(
      "solo",
      [`${role}${origin}guidelineQ`, `${role}${origin}subguidelineQ`],
      "enable"
    );

    /* Automate DLT Guideline dropdown with the mapped Guideline - commenting this as from Phase 3.5 all DLT Guidelines will be automated */
    // if (DLT_GUIDELINE_OPTIONS_MAPPER[dltAutomationGuidelineForm?.toUpperCase()]) {
    //   setGuidelineFromMapper(
    //     origin,
    //     role,
    //     DLT_GUIDELINE_OPTIONS_MAPPER[dltAutomationGuidelineForm?.toUpperCase()]
    //   );
    // }

    /*
      Show Q187 (drug search) only when medhok returned no GPI, no drug name, and no guideline form -
      i.e. the automated flow has nothing to pre-fill, so the user needs to search manually.
      If drugName is present, Q44 is already populated and the search field is not needed.
    */
    const _medhokForDrugCheck = JSON.parse(sessionStorage.getItem("originalMedhokResponse") || 'null');
    const _drugNameFromMedhok = _medhokForDrugCheck ? extractDrugNameFromMHKResponse(_medhokForDrugCheck) : null;
    if(!gpiSelected && !(gpiCode || dltAutomationGuidelineForm) && !_drugNameFromMedhok) {
      console.log("No GPI code, drug name, or DLT Guideline Form returned from Medhok, enabling Drug Name search field for manual selection of DLT guideline.");
      toggleDrugNameWSearchQ(role, origin);
    }
  }

  const dltGuidelineName = DLT_GUIDELINE_OPTIONS_MAPPER[dltAutomationGuidelineForm?.toUpperCase()];
  const dltGuidelineNameWithSuffix = dltGuidelineName && `${dltGuidelineName} Guideline` || '';
  sessionStorage.setItem(
    "dltAutomatedGuidelineForm",
    dltGuidelineNameWithSuffix
  );
  /*
  Updated dltGuidelineName to store mapped guideline name in session storage
  dltGuidelineName will be helpful for distinguishing between automated vs manual DLT guideline form
  */
  sessionStorage.setItem(
    "dltGuidelineName",
    dltGuidelineNameWithSuffix
  );
  sessionStorage.setItem(
    "isDLTGuidelineFormAutomated",
    isDLTGuidelineFormAutomated
  );

  return { dltAutomationGuidelineForm, isDLTGuidelineFormAutomated };
}

/* Automation Logic for prefilling "Is this request for a LICS member AND the route of administration of the requested medication is injection (INJ) or intravenous (IV)?" */
async function automateLICSAndROAField(licsIndicator, ROA, role, origin) {
  const isLICSMember = LICS_INDICATOR_LIST.includes(Number(licsIndicator));
  const isInjectionOrIV = INJ_OR_IV_RTE_ADMIN_CD_LIST.includes(ROA?.toUpperCase());
  let dltAutomationLICSAndROAFieldAns = "";

  let LICSAndROAQRadioBtn = "";

  let LICSAndROAQ = document.getElementById(`${role}${origin}licsAndROAQ`);

  if (isLICSMember && isInjectionOrIV) {
    LICSAndROAQRadioBtn = document.getElementById(
      `${role}${origin}licsAndROAQYes`
    );
    dltAutomationLICSAndROAFieldAns = "Yes";
  } else if (licsIndicator && ROA) {
    LICSAndROAQRadioBtn = document.getElementById(
      `${role}${origin}licsAndROAQNo`
    );
    dltAutomationLICSAndROAFieldAns = "No";
  }

  if (LICSAndROAQRadioBtn) {
    LICSAndROAQRadioBtn.checked = true;
    LICSAndROAQRadioBtn.click();
    LICSAndROAQ.disabled = true; // Disable the field after automation
    sessionStorage.setItem(
      "dltAutomatedLICSAndROAFieldAns",
      dltAutomationLICSAndROAFieldAns
    );
    sessionStorage.setItem(
      "dltFinalLICSAndROAFieldAns",
      dltAutomationLICSAndROAFieldAns
    );
  }

  return { isLICSMember, isInjectionOrIV, isLICSMemberNInjectionOrIV: dltAutomationLICSAndROAFieldAns };
}

/* Automation Logic for prefilling "Is the requested drug rejecting with an 'A6' reject code, indicating a BvD review is needed?" */
async function automateRejectWithA6Field(rejectCodes, role, origin) {
  const isRejectWithA6 = rejectCodes
    ?.split(";")
    .map((code) => code.trim())
    .includes("A6");

  let rejectWithA6QRadioBtn = "";
  let dltAutomationRejectWithA6FieldAns = "";

  if (isRejectWithA6) {
    rejectWithA6QRadioBtn = document.getElementById(
      `${role}${origin}rejectWithA6QYes`
    );
    dltAutomationRejectWithA6FieldAns = "Yes";
  } else {
    rejectWithA6QRadioBtn = document.getElementById(
      `${role}${origin}rejectWithA6QNo`
    );
    dltAutomationRejectWithA6FieldAns = "No";
  }

  if (rejectWithA6QRadioBtn) {
    rejectWithA6QRadioBtn.checked = true;
    rejectWithA6QRadioBtn.click();
    sessionStorage.setItem(
      "dltAutomatedRejectWithA6FieldAns",
      dltAutomationRejectWithA6FieldAns
    );
    sessionStorage.setItem(
      "dltFinalRejectWithA6FieldAns",
      dltAutomationRejectWithA6FieldAns
    );
  }

  return dltAutomationRejectWithA6FieldAns;
}

/* Automation Logic for prefilling "Is the requested medication one of the following insulins to be used in an insulin pump?" */
async function automateInsulinPumpMedicationField(gpiCode, role, origin) {
  const dltAutomationInsulinPumpListGPIs = await getInsulinPumpList();
  const insulinPumpGPIList = dltAutomationInsulinPumpListGPIs?.map(
    (item) => item.GPI
  );
  const isInsulinPumpMedication = insulinPumpGPIList?.includes(gpiCode);

  let insulinPumpMedicationQRadioBtn = "";
  let dltAutomatedInsulinPumpMedicationFieldAns = "";

  let insulinPumpMedicationQ = document.getElementById(
    `${role}${origin}insulinPumpMedicationQ`
  );

  if (isInsulinPumpMedication) {
    insulinPumpMedicationQRadioBtn = document.getElementById(
      `${role}${origin}insulinPumpMedicationQYes`
    );
    dltAutomatedInsulinPumpMedicationFieldAns = "Yes";
  } else {
    insulinPumpMedicationQRadioBtn = document.getElementById(
      `${role}${origin}insulinPumpMedicationQNo`
    );
    dltAutomatedInsulinPumpMedicationFieldAns = "No";
  }

  if (insulinPumpMedicationQRadioBtn) {
    insulinPumpMedicationQRadioBtn.checked = true;
    insulinPumpMedicationQRadioBtn.click();
    // Disable the field after automated as only No option will be available for non-insulin pump medications and editable for insulin pump medications
    if(isInsulinPumpMedication) {
      insulinPumpMedicationQ.disabled = false;
    } else {
      insulinPumpMedicationQ.disabled = true;
    }
    sessionStorage.setItem(
      "dltAutomatedInsulinPumpMedicationFieldAns",
      dltAutomatedInsulinPumpMedicationFieldAns
    );
    sessionStorage.setItem(
      "dltFinalInsulinPumpMedicationFieldAns",
      dltAutomatedInsulinPumpMedicationFieldAns
    );
  }

  return dltAutomatedInsulinPumpMedicationFieldAns;
}

/* Automation Logic for prefilling "Approvable diagnosis per drug lookup tool (DLT) or decision tree?" */
async function automateApprovableDiagnosis(gpiCode, diagnosis, role, origin) {
  // If the user explicitly selected an indication, that choice takes priority over the ICD-10 check.
  // Key is set by formAlts.js indication onChange and cleared by resetFormAltsDLTFields on each change.
  const _indicationAns = sessionStorage.getItem('indicationBasedApprovableDiagnosis');
  if (_indicationAns) {
    const _suffix = _indicationAns === 'Yes' ? 'approveDiagoQYes'
                  : _indicationAns === 'No'  ? 'approveDiagoQNo'
                  : 'approveDiagoQNA';
    const _btn = document.getElementById(`${role}${origin}${_suffix}`);
    if (_btn) { _btn.checked = true; _btn.click(); }
    sessionStorage.setItem('dltAutomatedApprovableDiagnosisFieldAns', _indicationAns);
    sessionStorage.setItem('dltFinalApprovableDiagnosisFieldAns', _indicationAns);
    return _indicationAns;
  }

  const dltAutomationApprovableDiagnosisICDCodes =
    await getDLTMonthlyValidationICDCode(gpiCode);
  const approvableDiagnosisICDCodesList =
    dltAutomationApprovableDiagnosisICDCodes
      ?.split(",")
      .map((item) => item?.trim()) || [];

  let isApprovableDiagnosis = false;
  let dltAutomatedApprovableDiagnosisFieldAns = "";

  if (diagnosis?.diagnosis1 && !isApprovableDiagnosis) {
    isApprovableDiagnosis = approvableDiagnosisICDCodesList?.includes(
      diagnosis?.diagnosis1?.trim()
    );
  }

  if (diagnosis?.diagnosis2 && !isApprovableDiagnosis) {
    isApprovableDiagnosis = approvableDiagnosisICDCodesList?.includes(
      diagnosis?.diagnosis2?.trim()
    );
  }

  if (diagnosis?.diagnosis3 && !isApprovableDiagnosis) {
    isApprovableDiagnosis = approvableDiagnosisICDCodesList?.includes(
      diagnosis?.diagnosis3?.trim()
    );
  }

  let approvableDiagnosisQRadioBtn = "";

  if (isApprovableDiagnosis) {
    approvableDiagnosisQRadioBtn = document.getElementById(
      `${role}${origin}approveDiagoQYes`
    );
    dltAutomatedApprovableDiagnosisFieldAns = "Yes";
  } else if (
    !(diagnosis?.diagnosis1 || diagnosis?.diagnosis2 || diagnosis?.diagnosis3)
  ) {
    approvableDiagnosisQRadioBtn = document.getElementById(
      `${role}${origin}approveDiagoQNA`
    );
    dltAutomatedApprovableDiagnosisFieldAns = "N/A";
  }

  if (approvableDiagnosisQRadioBtn) {
    approvableDiagnosisQRadioBtn.checked = true;
    approvableDiagnosisQRadioBtn.click();
    sessionStorage.setItem(
      "dltAutomatedApprovableDiagnosisFieldAns",
      dltAutomatedApprovableDiagnosisFieldAns
    );
    sessionStorage.setItem(
      "dltFinalApprovableDiagnosisFieldAns",
      dltAutomatedApprovableDiagnosisFieldAns
    );
  }

  return dltAutomatedApprovableDiagnosisFieldAns;
}


/**
 * Automate TF Required = 0 field
 * If TF required is 0, set to "Yes"; otherwise set to "No"
 */
export function automateDLTShow0TFAltsQ(tfRequired, role, origin) {
  let dltShow0TFAltsQAnswer = "";
  let dltShow0TFAltsQRadioBtn = null;

  try {
    if (tfRequired === 0) {
      dltShow0TFAltsQRadioBtn = document.getElementById(`${role}${origin}dltShow0TFAltsQYes`);
      dltShow0TFAltsQAnswer = "Yes";
    } else {
      dltShow0TFAltsQRadioBtn = document.getElementById(`${role}${origin}dltShow0TFAltsQNo`);
      dltShow0TFAltsQAnswer = "No";
    }

    // Store BEFORE clicking so any click-triggered toggleFollowupDLTQuestions reads the fresh value
    sessionStorage.setItem("dltAutomatedShow0TFAltsQAnswer", dltShow0TFAltsQAnswer);
    sessionStorage.setItem("dltFinalShow0TFAltsQAnswer", dltShow0TFAltsQAnswer);

    if (dltShow0TFAltsQRadioBtn) {
      dltShow0TFAltsQRadioBtn.checked = true;
      dltShow0TFAltsQRadioBtn.click();
    } else {
      console.warn(`Element not found for dltShow0TFAltsQ with role=${role}, origin=${origin}`);
    }
  } catch (error) {
    console.error("Error automating dltShow0TFAltsQ:", error);
  }

  return dltShow0TFAltsQAnswer;
}

/**
 * Automate Tried and Failed Formulary Alternatives field
 * Compare unique GPI10 count with TF required:
 * - If unique GPI10 count > TF required: "Yes"
 * - If unique GPI10 count < TF required: "No"
 * - Otherwise: leave in pending state
 */
function automateTriedNFailedFormAltsQ(rfiChecked, tfRequired, role, origin) {
  let triedNFailedFormAltsQAnswer = "";
  let triedNFailedFormAltsQRadioBtn = null;
  let uniqueGPI10Count = 0;

  try {
    // Get unique GPI10 values
    const uniqueGPI10Set = new Set(rfiChecked?.map((item) => item?.gpi10) || []);
    uniqueGPI10Count = uniqueGPI10Set.size;

    if (uniqueGPI10Count >= tfRequired) {
      triedNFailedFormAltsQRadioBtn = document.getElementById(`${role}${origin}triedNFailedFormAltsQYes`);
      triedNFailedFormAltsQAnswer = "Yes";
    } else if (uniqueGPI10Count < tfRequired) {
      triedNFailedFormAltsQRadioBtn = document.getElementById(`${role}${origin}triedNFailedFormAltsQNo`);
      triedNFailedFormAltsQAnswer = "No";
    }

    // Store BEFORE clicking so any click-triggered toggleFollowupDLTQuestions reads the fresh value
    if (triedNFailedFormAltsQAnswer) {
      sessionStorage.setItem("dltAutomatedTriedNFailedFormAltsQAnswer", triedNFailedFormAltsQAnswer);
      sessionStorage.setItem("dltFinalTriedNFailedFormAltsQAnswer", triedNFailedFormAltsQAnswer);
    }

    if (triedNFailedFormAltsQRadioBtn) {
      triedNFailedFormAltsQRadioBtn.checked = true;
      triedNFailedFormAltsQRadioBtn.click();
    } else if (triedNFailedFormAltsQAnswer) {
      console.warn(`Radio button not found for triedNFailedFormAltsQ with role=${role}, origin=${origin}, answer=${triedNFailedFormAltsQAnswer}`);
    }
  } catch (error) {
    console.error("Error automating triedNFailedFormAltsQ:", error);
  }

  return { triedNFailedFormAltsQAnswer, uniqueGPI10Count };
}

/**
 * Automate Tried Failed Queue field (text input)
 * Populate with comma-separated formulary alternative values from rfiChecked
 */
function automateTriedNFailedMedications(rfiChecked, role, origin) {
  let triedFailedQueueAnswer = "";

  try {
    if (rfiChecked && Array.isArray(rfiChecked)) {
      // Extract formulary alternatives and join with commas
      triedFailedQueueAnswer = rfiChecked
        .map((item) => item?.formularyAlternative)
        .filter(Boolean)
        .join(", ");

      const triedFailedQueueField = document.getElementById(`${role}${origin}treidFailQtxt`);

      if (triedFailedQueueField) {
        triedFailedQueueField.value = triedFailedQueueAnswer || '';
      } else {
        console.warn(`Text input field not found for triedFailedQueue with role=${role}, origin=${origin}`);
      }

      // Always store the answer even if element not found
      sessionStorage.setItem("dltAutomatedTriedNFailedMedicationsAnswer", triedFailedQueueAnswer);
      sessionStorage.setItem("dltFinalTriedNFailedMedicationsAnswer", triedFailedQueueAnswer);
    }
  } catch (error) {
    console.error("Error automating triedFailedQueue:", error);
  }

  return triedFailedQueueAnswer;
}

/**
 * Main function to automate DLT Guideline fields based on Form Alternatives data
 * This function orchestrates the automation of three related fields:
 * 1. TF Required = 0 field (Yes/No)
 * 2. Tried and Failed Formulary Alternatives (Yes/No/N/A)
 * 3. Tried Failed Queue (comma-separated alternatives)
 */
export function automateDLTGuidelineFieldsBasedOnFormAlts(role, origin) {
  try {
    // Retrieve form alternatives data from session storage
    const formAltsFetchSubmitted = JSON.parse(
      sessionStorage.getItem("formAltsFetchSubmitted") || "null"
    );

    if (!formAltsFetchSubmitted) {
      console.log("No form alternatives data found in session storage");
      return {
        dltShow0TFAltsQAnswer: "",
        triedNFailedFormAltsQAnswer: "",
        triedFailedQueueAnswer: "",
      };
    }

    const { rfiChecked, tfRequired } = formAltsFetchSubmitted;

    // Skip dltShow0TFAltsQ and triedNFailedFormAltsQ automation when tfRequired is not a
    // valid finite number — covers null (field absent from API response), undefined, or NaN.
    // automateTriedNFailedMedications (the tried-meds queue) is independent of tfRequired
    // and still runs so the medication list is always populated.
    const tfRequiredIsValid = tfRequired !== null && tfRequired !== undefined && Number.isFinite(tfRequired);
    if (!tfRequiredIsValid) {
      console.warn("[FormAlts] tfRequired not available — skipping triedNFailedFormAltsQ automation");
      // Clear stale triedNFailed values so a previous valid automation doesn't linger.
      // dltShow0TFAltsQ keys are managed at fetch time in _renderList.
      sessionStorage.removeItem("dltAutomatedTriedNFailedFormAltsQAnswer");
      sessionStorage.removeItem("dltFinalTriedNFailedFormAltsQAnswer");
      const triedFailedQueueAnswer = automateTriedNFailedMedications(rfiChecked, role, origin);
      return { dltShow0TFAltsQAnswer: "", triedNFailedFormAltsQAnswer: "", triedFailedQueueAnswer };
    }

    // Disabling this check to allow 0 RFI Formulary Alternatives selection to be handled
    // if (!rfiChecked || rfiChecked.length === 0) {
    //   console.log("No RFI checked items found in form alternatives data");
    //   return {
    //     dltShow0TFAltsQAnswer: "",
    //     triedNFailedFormAltsQAnswer: "",
    //     triedFailedQueueAnswer: "",
    //   };
    // }

    // Automate the two save-time fields (dltShow0TFAltsQ is handled at fetch time in _renderList)
    const { triedNFailedFormAltsQAnswer } = automateTriedNFailedFormAltsQ(
      rfiChecked,
      tfRequired,
      role,
      origin
    );
    const triedFailedQueueAnswer = automateTriedNFailedMedications(rfiChecked, role, origin);

    return {
      dltShow0TFAltsQAnswer: "",
      triedNFailedFormAltsQAnswer,
      triedFailedQueueAnswer,
    };
  } catch (error) {
    console.error("Error automating DLT Guideline fields based on Form Alternatives:", error);
    return {
      dltShow0TFAltsQAnswer: "",
      triedNFailedFormAltsQAnswer: "",
      triedFailedQueueAnswer: "",
    };
  }
}

/**
 * Automate "Prescriber indicated approved formulary quantity limit is ineffective?" field.
 * When the member has qualifying paid claims (hasQualifyingClaims = true), auto-answers "Yes".
 * When false, no automation — field stays blank for manual entry.
 * Tracks answer in sessionStorage following the same pattern as other DLT field automation.
 */
export function automatePrescriberIndicatedQlIneffectiveField(hasQualifyingClaims, role, origin) {
  let answer = '';

  try {
    const isMDD = typeOfQlReview(role, origin, 'value') === 'MDD';

    if (hasQualifyingClaims && isMDD) {
      const rdos = document.querySelectorAll(
        `[name="${role}${origin}prescriberIndicatedApprovedFormularyQuantityLimitIneffectiveQrdo"]`
      );
      const yesRdo = [...rdos].find(r => r.value === 'Yes');
      if (yesRdo) {
        yesRdo.checked = true;
        yesRdo.click();
      }
      answer = 'Yes';
    }
    sessionStorage.setItem('dltAutomatedPrescriberIndicatedQlIneffectiveFieldAns', answer);
    sessionStorage.setItem('dltFinalPrescriberIndicatedQlIneffectiveFieldAns', answer);
  } catch (error) {
    console.error('Error automating prescriberIndicatedQlIneffective:', error);
  }

  return answer;
}

/**
 * Clears DLT fields set by automatePrescriberIndicatedQlIneffectiveField.
 * Call from resetQl and _resetQlResults whenever QL results are wiped — prevents
 * a stale "Yes" answer persisting after drug or formulary changes within the same session.
 */
export function resetQlDLTFields(role, origin) {
  ['dltAutomatedPrescriberIndicatedQlIneffectiveFieldAns',
   'dltFinalPrescriberIndicatedQlIneffectiveFieldAns'].forEach(key => sessionStorage.removeItem(key));

  document.querySelectorAll(
    `[name="${role}${origin}prescriberIndicatedApprovedFormularyQuantityLimitIneffectiveQrdo"]`
  ).forEach(r => { r.checked = false; });
}

/**
 * Clears DLT fields set by automateDLTGuidelineFieldsBasedOnFormAlts.
 * Must be called whenever upstream data changes (drug, indication, formulary, client)
 * after a formAlts Save — prevents stale automation answers from affecting case decisioning.
 */
export function resetFormAltsDLTFields(role, origin) {
  [
    'dltAutomatedShow0TFAltsQAnswer',
    'dltFinalShow0TFAltsQAnswer',
    'dltAutomatedTriedNFailedFormAltsQAnswer',
    'dltFinalTriedNFailedFormAltsQAnswer',
    'dltAutomatedTriedNFailedMedicationsAnswer',
    'dltFinalTriedNFailedMedicationsAnswer',
    'indicationBasedApprovableDiagnosis',
  ].forEach(key => sessionStorage.removeItem(key));

  ['dltShow0TFAltsQYes', 'dltShow0TFAltsQNo',
   'triedNFailedFormAltsQYes', 'triedNFailedFormAltsQNo'].forEach(suffix => {
    const el = document.getElementById(`${role}${origin}${suffix}`);
    if (el) el.checked = false;
  });

  const treidFail = document.getElementById(`${role}${origin}treidFailQtxt`);
  if (treidFail) treidFail.value = '';
}

/*
- Helper to automate DLT Guidelines.
- This is the entry point for DLT Guidelines automation 
*/
export async function automateDLTGuidelines(role, origin, medhokData, gpiSelected=null) {
  /* Clear all DLT Guideline fields at the start of automation */
  clearAllDLTGuidelineFields(role, origin);

  let dltGuidelinesAutomationData = {
    dltAutomationGuidelineForm: "",
    isDLTGuidelineFormAutomated: false,
    dltAutomatedApprovableDiagnosisFieldAns: "",
    dltAutomationLICSAndROAFieldAns: "",
    dltAutomationRejectWithA6FieldAns: "",
    dltAutomatedInsulinPumpMedicationFieldAns: "",
    dltAutomatedBvDLICSMemberFieldAns: "",
    dltAutomatedBvDRejectWithA4orA6FieldAns: "",
    dltAutomationBvDInjectableAgentRequestFieldAns: "",
    dltDrugList: [],
  };
  const gpiCode = extractGPIFromMHKResponse(medhokData);
  const ndc = extractNDCFromMHKResponse(medhokData);
  const requestReason = extractRequestReasonFromMHKResponse(medhokData);

  /* Automation Logic for prefilling DLT Guideline Form */
  const { dltAutomationGuidelineForm, isDLTGuidelineFormAutomated } =
    await automateDLTGuidelineForm(gpiCode, role, origin, requestReason, gpiSelected);

  dltGuidelinesAutomationData = {
    ...dltGuidelinesAutomationData,
    dltAutomationGuidelineForm,
    isDLTGuidelineFormAutomated,
  };

  // TODO: revert this change after testing if it's !isDLTGuidelineFormAutomated
  if (isDLTGuidelineFormAutomated) {
    /* Automation Logic for prefilling "Approvable diagnosis per drug lookup tool (DLT) or decision tree?" */
    const diagnosis = extractDiagnosisFromMHKResponse(medhokData);
    const drugName = extractDrugNameFromMHKResponse(medhokData);
    const dltAutomatedApprovableDiagnosisFieldAns =
      await automateApprovableDiagnosis(gpiCode, diagnosis, role, origin);

    const licsIndicator = extractLICSIndicatorFromMHKResponse(medhokData);
    const roa = await getDrugDenormData(ndc);
    const rejectCodes = extractRejectCodesFromMHKResponse(medhokData);

    let dltAutomationLICSAndROAFieldAns = "";
    let dltAutomationRejectWithA6FieldAns = "";

    let dltAutomatedBvDLICSMemberFieldAns = "";
    let dltAutomatedBvDRejectWithA4orA6FieldAns = "";

    let dltAutomationBvDInjectableAgentRequestFieldAns = "";
    if(!dltAutomationGuidelineForm.startsWith("BVD NON-FORMULARY")) {
      // Skip Automating LICS and ROA field and Reject with A6 field for Quantity limit guidelines as these fields are not applicable for quantity limit guidelines and will not be shown for those guidelines. This is to handle edge cases where MHK returned a quantity limit guideline form due to missing GPI code and we don't want to automate LICS and ROA field and Reject with A6 field for those cases as well.
      if(!dltAutomationGuidelineForm.includes("QUANTITY")) {
        /* Automation Logic for prefilling "Is this request for a LICS member AND the route of administration of the requested medication is injection (INJ) or intravenous (IV)?" */
        dltAutomationLICSAndROAFieldAns = await automateLICSAndROAField(
          licsIndicator,
          roa,
          role,
          origin
        );

        /* Automation Logic for prefilling "Is the requested drug rejecting with an 'A6' reject code, indicating a BvD review is needed?" */
        dltAutomationRejectWithA6FieldAns = await automateRejectWithA6Field(
          rejectCodes,
          role,
          origin
        );
      }
    } else {
      /* BvD overall field answers */
      console.log("Automating BvD specific fields", licsIndicator, rejectCodes);
      dltAutomatedBvDLICSMemberFieldAns = await automateBvDLICSMemberField(licsIndicator, role, origin);
      if(dltAutomatedBvDLICSMemberFieldAns === "No") {
        dltAutomatedBvDRejectWithA4orA6FieldAns = await automateBvDRejectWithA4orA6QField(
          rejectCodes,
          role,
          origin
        );
      }

      if(["BVD NON-FORMULARY (ESRD)"].includes(dltAutomationGuidelineForm)) {
        dltAutomationBvDInjectableAgentRequestFieldAns = await automateBvDInjectableAgentRequestQField(roa, role, origin);
      } else {
        sessionStorage.setItem("dltAutomatedBvDESRDInjectableAgentRequestFieldAns","");
        sessionStorage.setItem("dltFinalBvDESRDInjectableAgentRequestFieldAns","");
      }

      if(["BVD NON-FORMULARY (INHALATION)"].includes(dltAutomationGuidelineForm)) {
        dltAutomationBvDInjectableAgentRequestFieldAns = await automateBvDInhalationFields(drugName, diagnosis, role, origin);
      } else {
         const bvdInhalationFieldIds = [
          "requestForAsthmaOrObstructivePulmonaryDiseaseQ",
          "requestForDornaseAlphaPulmozymeQ",
          "patientHasCysticFibrosisQ",
          "requestForTobramycinInhalationSolutionQ",
          "patientHasCysticFibrosisOrBronchiectasisQ",
          "requestForAcetylcysteineQ",
          "persistentThickPulmonarySecretionsQ",
          "requestForNebupentQ",
          "patientHasHIVPneumocystosisOrComplicationsOfOrganTransplantsQ",
          "requestForTyvasoOrVentavisQ",
          "patientHasPulmonaryArteryHypertensionQ",
          "bvdDiagnosisProvidedQ"
        ];

        bvdInhalationFieldIds.forEach(fieldId => {
          sessionStorage.setItem(`dltAutomatedBvDINHALATION${fieldId}FieldAns`, "");
          sessionStorage.setItem(`dltFinalBvDINHALATION${fieldId}FieldAns`, "");
        });
      }

      if(["BVD NON-FORMULARY (IVIG)"].includes(dltAutomationGuidelineForm)) {
        dltAutomationBvDInjectableAgentRequestFieldAns = await automateBvDIVIGFields(drugName, diagnosis, role, origin);
      } else {
         const bvdIVIGFieldIds = [
          "patientReceivingMedicationForPrimaryImmuneDeficiencyDiseaseQ",
          "requestForHizentraOrHyQviaQ",
          "patientReceivingMedicationForCIDPQ",
          "bvdDiagnosisProvidedIVIGQ"
        ];

        bvdIVIGFieldIds.forEach(fieldId => {
          sessionStorage.setItem(`dltAutomatedBvDIVIG${fieldId}FieldAns`, "");
          sessionStorage.setItem(`dltFinalBvDIVIG${fieldId}FieldAns`, "");
        });
      }

      if(["BVD NON-FORMULARY (ORAL ANTIEMETICS)"].includes(dltAutomationGuidelineForm)) {
        await automateBvDOralAntiemeticsFields(drugName, diagnosis, role, origin);
      } else {
         const bvdOralAntiemeticsFieldIds = [
          "requestForVarubiEmendOrAkynzeoQ",
          "requestForAkynzeoQ"
        ];

        bvdOralAntiemeticsFieldIds.forEach(fieldId => {
          sessionStorage.setItem(`dltAutomatedBvDORALANTIEMETICS${fieldId}FieldAns`, "");
          sessionStorage.setItem(`dltFinalBvDORALANTIEMETICS${fieldId}FieldAns`, "");
        });
      }
    }

    let dltAutomatedInsulinPumpMedicationFieldAns = "";
    /* Automate Insulin Pump Medication field only for STANDARD NON-FORMULARY guideline as it'll be not shown for other guidelines */
    if(dltAutomationGuidelineForm === "STANDARD NON-FORMULARY") {
      /* Automation Logic for prefilling "Is the requested medication one of the following insulins to be used in an insulin pump?" */
      // 27104002002022
      // const dltAutomatedInsulinPumpMedicationFieldAns =
      //   await automateInsulinPumpMedicationField("27104002002022", role, origin);
      dltAutomatedInsulinPumpMedicationFieldAns =
        await automateInsulinPumpMedicationField(gpiCode, role, origin);
    }

    dltGuidelinesAutomationData = {
      ...dltGuidelinesAutomationData,
      dltAutomatedApprovableDiagnosisFieldAns,
      dltAutomationLICSAndROAFieldAns,
      dltAutomationRejectWithA6FieldAns,
      dltAutomatedInsulinPumpMedicationFieldAns,
      dltAutomatedBvDLICSMemberFieldAns,
      dltAutomatedBvDRejectWithA4orA6FieldAns,
      dltAutomationBvDInjectableAgentRequestFieldAns
    };
  }

  console.log(
    "dltGuidelinesAutomationData - test log",
    dltGuidelinesAutomationData
  );
}
