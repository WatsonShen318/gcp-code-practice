/* eslint-disable import/no-extraneous-dependencies */
import * as Snackbar from "node-snackbar";
import Modal from "bootstrap/js/dist/modal";

export function AlertService(type) {
  const note = {
    reset: "Internal Note Tool has been Reset",
    finalnote: "Final Note is copied",
    transferredInfoToMHK: "Auto Note has transferred information to MHK. To see the updates in MHK, cancel case and reopen.",
    outboundcall: "Outbound Call Note is copied",
    outboundcallalt: "Outbound Call Note is copied",
    inquiry: "Inquiry Note is copied",
    EAG: "EAG Note is copied",
    AAFNR: "AAFNR Note is copied",
    MedhokRetrieveCaseDetailsAPIFailure:
      "Medhok data pre-fill failed. Please proceed filling fields manually.",
    MedhokRetrieveCaseDetailsWrongCaseId:
      "Invalid CASE ID. Please re-enter. If failed multiple times, proceed notes manually.",
  };

  const alertVariantByType = {
    reset: "success",
    finalnote: "success",
    transferredInfoToMHK: "success",
    outboundcall: "success",
    outboundcallalt: "success",
    inquiry: "success",
    EAG: "success",
    AAFNR: "success",
    MedhokRetrieveCaseDetailsAPIFailure: "error",
    MedhokRetrieveCaseDetailsWrongCaseId: "warning",
  };

  const alertVariant = alertVariantByType[type] || "info";
  const message = note[type] || "Action completed.";

  Snackbar.show({
    text: message,
    pos: "top-center",
    backgroundColor: "#ffffff",
    textColor: "#1f2937",
    actionText: "Dismiss",
    actionTextColor: "#6b7280",
    customClass: `note-snackbar note-snackbar--${alertVariant}`,
    alertScreenReader: true,
    duration: ["MedhokRetrieveCaseDetailsWrongCaseId", "transferredInfoToMHK"].includes(type) ? 10000 : 5000,
  });
}

function removeBackDrop() {
  const bod = document.body;
  const backdrop = document.querySelector("div.modal-backdrop.fade.show");
  bod.classList.remove("modal-open");
  bod.className = "";
  bod.style = "";
  if (backdrop) backdrop.remove();
}

export function GeneralModal(modalData) {
  const prefillStatus = sessionStorage.getItem("prefillStatus");
  if (prefillStatus === "Processing") {
    return;
  }
  const body = modalData.message;
  const bodyIcon = modalData.icon;
  const GLModal = document.getElementById("NoteToolModal");
  const myModal = new Modal(GLModal);

  const modalBody = GLModal.querySelector(".modal-body p");
  const modalIcon = GLModal.querySelector(".modal-body div i");

  modalBody.innerHTML = body;
  modalIcon.textContent = bodyIcon;
  myModal.show();

  // GLModal.addEventListener('hide.bs.modal', () => {
  //   removeBackDrop();
  // });
}

export function closeModal() {
  const noteModal = document.getElementById("NoteToolModal");
  // const glModal = document.getElementById('guidelineModal');

  noteModal.addEventListener("hide.bs.modal", () => {
    removeBackDrop();
  });
  noteModal.addEventListener("hidden.bs.modal", () => {
    removeBackDrop();
  });
  // glModal.addEventListener('hidden.bs.modal', () => {
  //   removeBackDrop();
  // });
}

export function guideline(glData) {
  const GLModal = document.getElementById("guidelineModal");
  const myModal = new Modal(GLModal);
  const glLink = document.getElementById("guideline");
  const glHeader = document.getElementById("guidelineLabel");

  glHeader.innerText = glData.guide;
  glLink.setAttribute("src", glData.link);

  myModal.show();
}

export function closeGuidelineModal(r, o, tool) {
  const grid = window.frames.glFrame;
  const intNoteGL = document.getElementById("guidelineModal");
  const hiddenCDRDAnswer = document.getElementById(
    `${r}${o}rqstTypeDeniedQhidden`
  );
  // const closebtn = document.getElementById('glClose');
  const cdrdAnswer = grid.document.getElementById("cdrdAnswers");
  const sModal = grid.document.getElementById("nextQbtn");
  const rationale = document.getElementById(`${r}${o}subguidelineQlt`);
  const glanswers = grid.document.getElementById("answers");
  const glRationale = grid.document.getElementById("rationale");
  const br = "\r\n";

  function removeFrameContent() {
    const frame = document.getElementById("guideline");
    const frameDoc = frame.contentDocument || frame.contentWindow.document;
    frameDoc.documentElement.innerHTML = "";
  }
  function stopLoading() {
    if (navigator.appName === "Microsoft Internet Explorer") {
      window.frames.glFrame.document.execCommand("Stop");
    } else {
      window.frames.glFrame.stop();
    }
  }

  function unEntity(str) {
    return str
      .replace(/&amp;/g, "&")
      .replace(/&lt;/g, "<")
      .replace(/&gt;/g, ">")
      .replace(/&apos;/g, "'");
  }
  sModal.addEventListener("click", (e) => {
    const a = e.target.getAttribute("href");
    const GLModalI = Modal.getInstance(intNoteGL);
    const regex = /^(#.*?)Q[0-9hold].*/;
    if (!regex.test(a)) {
      GLModalI.hide();
      if (tool.includes("CD/RD")) {
        hiddenCDRDAnswer.value = cdrdAnswer.value;
      }
      if (!tool.includes("CD/RD")) {
        rationale.value =
          glRationale.value === ""
            ? glanswers.value
            : glanswers.value + br + unEntity(glRationale.value);
        // Capturing DLT Exception Guideline End time for auditing
        const timestamp = new Date().toISOString();
        sessionStorage.setItem("dltGuidelineEndTime", timestamp);
      }
    }
  });
  intNoteGL.addEventListener("hidden.bs.modal", () => {
    removeFrameContent();
    removeBackDrop();
    const glLink = document.getElementById("guideline");
    glLink.setAttribute("src", "about:blank");
    stopLoading();
  });
  intNoteGL.addEventListener("hide.bs.modal", () => {
    removeFrameContent();
    removeBackDrop();
    const glLink = document.getElementById("guideline");
    glLink.setAttribute("src", "about:blank");
    stopLoading();
  });
}
