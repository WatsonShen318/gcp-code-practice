import { getValue } from '../utils/getInputValue';
import { eventElement } from '../utils/inputSelect';

let fieldName;
let inputType;
let output;

function popOut(type) {
  let t;
  if (type === 'field') t = fieldName;
  if (type === 'element') t = document.getElementById(fieldName);
  if (type === 'value') t = getValue(inputType, fieldName);
  if (type === 'event') t = eventElement(inputType, fieldName);
  return t;
}

export const sourceMDOInfo = (role, origin, type) => {
  fieldName = `${role}${origin}mdoInfoQlt`;
  inputType = 'text';
  output = popOut(type);

  return output;
};

export const caseIdInfo = (role, origin, type) => {
  fieldName = `${role}${origin}caseIdQbtn`;
  inputType = 'text';
  output = popOut(type);

  return output;
};

export const rationale = (role, origin, type) => {
  fieldName = `${role}${origin}rationalQlt`;
  inputType = 'text';
  output = popOut(type);

  return output;
};

export const subExpediteReason = (role, origin, type) => {
  fieldName = `${role}${origin}subExpReasonQlt`;
  inputType = 'text';
  output = popOut(type);

  return output;
};

export const member = (role, origin, type) => {
  fieldName = `${role}${origin}memberidsQ`;
  inputType = 'check';

  output = popOut(type);
  return output;
};

export const subCompendiaRefs = (role, origin, type) => {
  fieldName = `${role}${origin}subcompendiaRefsQ`;
  inputType = 'check';

  output = popOut(type);
  return output;
};

export const ePA = (role, origin, type) => {
  fieldName = `${role}${origin}ePAQrdo`;
  inputType = 'radio';

  output = popOut(type);
  return output;
};

export const supportingStatement = (role, origin, type) => {
  fieldName = `${role}${origin}spprSatementQrdo`;
  inputType = 'radio';

  output = popOut(type);
  return output;
};

export const subSpprtStatement = (role, origin, type) => {
  fieldName = `${role}${origin}subspprSatementQrdo`;
  inputType = 'radio';

  output = popOut(type);
  return output;
};

export const subspprStatementLocationInfo = (role, origin, type) => {
  fieldName = `${role}${origin}subspprSatementLocationQspprSatementtxt`;
  inputType = 'text';

  output = popOut(type);
  return output;
};

export const careAgent = (role, origin, type) => {
  fieldName = `${role}${origin}careAgentQrdo`;
  inputType = 'radio';

  output = popOut(type);
  return output;
};

export const careAgentInfo = (role, origin, type) => {
  fieldName = `${role}${origin}subcareAgentQcareAgenttxt`;
  inputType = 'text';

  output = popOut(type);
  return output;
};

export const requestType = (role, origin, type) => {
  fieldName = `${role}${origin}rqstTypeQrdo`;
  inputType = 'radio';

  output = popOut(type);
  return output;
};

export const requestBy = (role, origin, type) => {
  fieldName = `${role}${origin}rqstByQrdo`;
  inputType = 'radio';

  output = popOut(type);
  return output;
};

export const mdReview = (role, origin, type) => {
  fieldName = `${role}${origin}mdReviewQrdo`;
  inputType = 'radio';

  output = popOut(type);
  return output;
};

export const subRequestByCaller = (role, origin, type) => {
  fieldName = `${role}${origin}subrqstByCallerQrdo`;
  inputType = 'radio';

  output = popOut(type);

  return output;
};

export const subAORMember = (role, origin, type) => {
  fieldName = `${role}${origin}subrqstByAORmemberQrdo`;
  inputType = 'radio';

  output = popOut(type);

  return output;
};

export const subAORFileLocation = (role, origin, type) => {
  fieldName = `${role}${origin}subAorOnFileQrdo`;
  inputType = 'radio';

  output = popOut(type);

  return output;
};

export const subAORonFileDoc = (role, origin, type) => {
  fieldName = `${role}${origin}subAorOnFileDocQtxt`;
  inputType = 'text';

  output = popOut(type);

  return output;
};

export const subRequestInfo = (role, origin, type) => {
  fieldName = `${role}${origin}subrqstInfoQtxt`;
  inputType = 'text';

  output = popOut(type);

  return output;
};

export const currentTier = (role, origin, type) => {
  fieldName = `${role}${origin}currentTierQsel`;
  inputType = 'select';

  output = popOut(type);

  return output;
};

export const subMemberWAOR = (role, origin, type) => {
  fieldName = `${role}${origin}subMemberWaorQtxt`;
  inputType = 'text';
  output = popOut(type);

  return output;
};

export const triedFail = (role, origin, type) => {
  fieldName = `${role}${origin}treidFailQtxt`;
  inputType = 'text';
  output = popOut(type);

  return output;
};

export const diagnosis = (role, origin, type) => {
  fieldName = `${role}${origin}diagnosisQlt`;
  inputType = 'text';
  output = popOut(type);

  return output;
};

export const client = (role, origin, type) => {
  fieldName = `${role}${origin}clientQsel`;
  inputType = 'select';
  output = popOut(type);

  return output;
};

export const subClientManual = (role, origin, type) => {
  fieldName = `${role}${origin}subegwpQtxt`;
  inputType = 'text';
  output = popOut(type);

  return output;
};

export const clientKeyIn = (role, origin, type) => {
  fieldName = `${role}${origin}clientKeyinQtxt`;
  inputType = 'text';
  output = popOut(type);

  return output;
};

export const decisionRouting = (role, origin, type) => {
  fieldName = `${role}${origin}routingQsel`;
  inputType = 'select';
  output = popOut(type);

  return output;
};

export const requestReason = (role, origin, type) => {
  fieldName = `${role}${origin}rqstReasonQsel`;
  inputType = 'select';
  output = popOut(type);

  return output;
};

export const approvedDiagnosis = (role, origin, type) => {
  fieldName = `${role}${origin}approveDiagoQrdo`;
  inputType = 'radio';
  output = popOut(type);

  return output;
};

export const matchCase = (role, origin, type) => {
  fieldName = `${role}${origin}matchCaseQrdo`;
  inputType = 'radio';
  output = popOut(type);

  return output;
};

export const guideline = (role, origin, type) => {
  fieldName = `${role}${origin}guidelineQsel`;
  inputType = 'select';
  output = popOut(type);

  return output;
};

export const guidelineRationale = (role, origin, type) => {
  fieldName = `${role}${origin}subguidelineQlt`;
  inputType = 'text';
  output = popOut(type);

  return output;
};

// AMN 1/3/23 - January 2023 Enhancement - #114: Remove Question 'Is there a denied case on the member's profile in 2022?'
/* 
export const memberDenied = (role, origin, type) => {
  fieldName = `${role}${origin}memberDeniedCaseQrdo`;
  inputType = 'radio';

  output = popOut(type);
  return output;
};
*/

export const requestDenied = (role, origin, type) => {
  fieldName = `${role}${origin}rqstTypeDeniedQrdo`;
  inputType = 'radio';
  output = popOut(type);

  return output;
};

export const cdrdGridAnswers = (role, origin, type) => {
  fieldName = `${role}${origin}rqstTypeDeniedQhidden`;
  inputType = 'text';
  output = popOut(type);

  return output;
};

export const priority = (role, origin, type) => {
  fieldName = `${role}${origin}iPriorityQrdo`;
  inputType = 'radio';
  output = popOut(type);

  return output;
};

export const validatedMemberQ = (role, origin, type) => {
  fieldName = `${role}${origin}validatedMemberQrdo`;
  inputType = 'radio';
  output = popOut(type);

  return output;
};

export const timeStamp = (role, origin, type) => {
  fieldName = `${role}${origin}timestampQrdo`;
  inputType = 'radio';
  output = popOut(type);

  return output;
};

export const drugName = (role, origin, type) => {
  fieldName = `${role}${origin}drugNameQtxt`;
  inputType = 'text';
  output = popOut(type);

  return output;
};

export const drugNameWSearch = (role, origin, type) => {
  fieldName = `${role}${origin}drugNameWSearchQinput`;
  inputType = 'text';
  output = popOut(type);

  return output;
};

export const drugQty = (role, origin, type) => {
  fieldName = `${role}${origin}qtytxt`;
  inputType = 'text';
  output = popOut(type);

  return output;
};

export const drugDS = (role, origin, type) => {
  fieldName = `${role}${origin}dstxt`;
  inputType = 'text';
  output = popOut(type);

  return output;
};

export const outbound = (role, origin, type) => {
  fieldName = `${role}${origin}outboundQrdo`;
  inputType = 'radio';
  output = popOut(type);

  return output;
};

export const outboundalt = (role, origin, type) => {
  fieldName = `${role}${origin}outboundQaltrdo`;
  inputType = 'radio';
  output = popOut(type);

  return output;
};

export const letterPreview = (role, origin, type) => {
  fieldName = `${role}${origin}LetterPreviewQrdo`;
  inputType = 'radio';
  output = popOut(type);

  return output;
};

export const subTierRequest = (role, origin, type) => {
  fieldName = `${role}${origin}subtierRqstQrdo`;
  inputType = 'radio';
  output = popOut(type);

  return output;
};

export const tierRequest = (role, origin, type) => {
  fieldName = `${role}${origin}tierRqstQrdo`;
  inputType = 'radio';
  output = popOut(type);

  return output;
};

export const approvedTier = (role, origin, type) => {
  fieldName = `${role}${origin}subapprovedTierQrdo`;
  inputType = 'radio';
  output = popOut(type);

  return output;
};

export const prospectiveReview = (role, origin, type) => {
  fieldName = `${role}${origin}prospectiveQrdo`;
  inputType = 'radio';

  output = popOut(type);
  return output;
};

//* * General Buttons*/

export const guidelineBtn = (role, origin, type) => {
  fieldName = `${role}${origin}guidelineQbtn`;
  inputType = 'button';

  output = popOut(type);
  return output;
};

export const triedFailbtn = (role, origin, type) => {
  fieldName = `${role}${origin}treidFailQbtn`;
  inputType = 'button';

  output = popOut(type);
  return output;
};

export const diagnosisbtn = (role, origin, type) => {
  fieldName = `${role}${origin}diagnosisQbtn`;
  inputType = 'button';

  output = popOut(type);
  return output;
};

//* * MD Template Fields */

export const mdPDPMAPD = (role, origin, type) => {
  fieldName = `${role}${origin}mdPDPMAPDQrdo`;
  inputType = 'radio';

  output = popOut(type);
  return output;
};

export const mdSafety = (role, origin, type) => {
  fieldName = `${role}${origin}mdSafetyQrdo`;
  inputType = 'radio';

  output = popOut(type);
  return output;
};

export const mdDiagnosis = (role, origin, type) => {
  fieldName = `${role}${origin}mdDiagnosisQlt`;
  inputType = 'text';

  output = popOut(type);
  return output;
};

export const mdsubSafety = (role, origin, type) => {
  fieldName = `${role}${origin}submdSafetyQtxt`;
  inputType = 'text';

  output = popOut(type);
  return output;
};

export const mdFDA = (role, origin, type) => {
  fieldName = `${role}${origin}mdFDAQrdo`;
  inputType = 'radio';

  output = popOut(type);
  return output;
};

export const mdOffLabel = (role, origin, type) => {
  fieldName = `${role}${origin}mdOffLabelQrdo`;
  inputType = 'radio';

  output = popOut(type);
  return output;
};

export const mdNewInfo = (role, origin, type) => {
  fieldName = `${role}${origin}mdNewInfoQrdo`;
  inputType = 'radio';

  output = popOut(type);
  return output;
};

export const mdsubNewInfo = (role, origin, type) => {
  fieldName = `${role}${origin}submdNewInfoQtxt`;
  inputType = 'text';

  output = popOut(type);
  return output;
};

export const mdConflictInfo = (role, origin, type) => {
  fieldName = `${role}${origin}mdConflictQtxt`;
  inputType = 'text';

  output = popOut(type);
  return output;
};

export const mdClaim = (role, origin, type) => {
  fieldName = `${role}${origin}mdClaimsQtxt`;
  inputType = 'text';

  output = popOut(type);
  return output;
};

export const memberMultiDrug = (role, origin, type) => {
  fieldName = `${role}${origin}memberMultiDrugQrdo`;
  inputType = 'radio';

  output = popOut(type);
  return output;
};

export const memberCaseCount = (role, origin, type) => {
  fieldName = `${role}${origin}caseCounttxt`;
  inputType = 'text';

  output = popOut(type);
  return output;
};

export const memberRqstTotalCount = (role, origin, type) => {
  fieldName = `${role}${origin}rqstCaseTotaltxt`;
  inputType = 'text';

  output = popOut(type);
  return output;
};

export const memberCaseCountBalance = (role, origin, type) => {
  fieldName = `${role}${origin}submemberCaseCountQhidden`;
  inputType = 'text';

  output = popOut(type);
  return output;
};

export const newAttachments = (role, origin, type) => {
  fieldName = `${role}${origin}newAttachQrdo`;
  inputType = 'radio';

  output = popOut(type);
  return output;
};

export const rdRecomand = (role, origin, type) => {
  fieldName = `${role}${origin}rdRecommandQrdo`;
  inputType = 'radio';

  output = popOut(type);
  return output;
};

export const mdResolution = (role, origin, type) => {
  fieldName = `${role}${origin}mdResolutionQrdo`;
  inputType = 'radio';

  output = popOut(type);
  return output;
};

export const mdInfoReview = (role, origin, type) => {
  fieldName = `${role}${origin}mdInfoReviewQrdo`;
  inputType = 'radio';

  output = popOut(type);
  return output;
};

export const mdLetterStatus = (role, origin, type) => {
  fieldName = `${role}${origin}mdLttrStatusQrdo`;
  inputType = 'radio';

  output = popOut(type);
  return output;
};

export const mdRationale = (role, origin, type) => {
  fieldName = `${role}${origin}mdRationaleQlt`;
  inputType = 'text';
  output = popOut(type);

  return output;
};

export const mdTally = (role, origin, type) => {
  fieldName = `${role}${origin}mdTallyQtxt`;
  inputType = 'text';
  output = popOut(type);

  return output;
};

export const mdDateTime = (role, origin, type) => {
  fieldName = `${role}${origin}mdDateTimeQtxt`;
  inputType = 'text';
  output = popOut(type);

  return output;
};

// export const mdNameTitle = (role, origin, type) => {
//   fieldName = `${role}${origin}mdNameTitleQtxt`;
//   inputType = 'text';
//   output = popOut(type);

//   return output;
// };

//* * Outbound Fields */

export const outboundAddBtn = (role, origin, type) => {
  fieldName = `${role}${origin}obbaddbtnbtn`;
  inputType = 'button';
  output = popOut(type);

  return output;
};

export const outboundRemoveBtn = (role, origin, type) => {
  fieldName = `${role}${origin}obbaddbtnrebtn`;
  inputType = 'button';
  output = popOut(type);

  return output;
};

export const outboundSubMade = (role, origin, type) => {
  fieldName = `${role}${origin}subobMadeQrdo`;
  inputType = 'radio';
  output = popOut(type);

  return output;
};

export const subobSpokeFN = (role, origin, type) => {
  fieldName = `${role}${origin}subobSpokeFNQobcContacttxt`;
  inputType = 'text';
  output = popOut(type);

  return output;
};

export const subobSpokeLN = (role, origin, type) => {
  fieldName = `${role}${origin}subobSpokeLNQobcContacttxt`;
  inputType = 'text';
  output = popOut(type);

  return output;
};

export const subobSpokeTitle = (role, origin, type) => {
  fieldName = `${role}${origin}subobSpokeTitleQobcContacttxt`;
  inputType = 'text';
  output = popOut(type);

  return output;
};

export const subobinfoGather = (role, origin, type) => {
  fieldName = `${role}${origin}subobinfoGatherQobcContacttxt`;
  inputType = 'text';
  output = popOut(type);

  return output;
};

export const subobcalloutco = (role, origin, type) => {
  fieldName = `${role}${origin}subobcalloutcoQsel`;
  inputType = 'select';
  output = popOut(type);

  return output;
};

//* * Outbound Alt Fields */

export const outboundAddBtnAlt = (role, origin, type) => {
  fieldName = `${role}${origin}obbaddbtnaltbtn`;
  inputType = 'button';
  output = popOut(type);

  return output;
};

export const outboundRemoveBtnAlt = (role, origin, type) => {
  fieldName = `${role}${origin}obbaddbtnaltrebtn`;
  inputType = 'button';
  output = popOut(type);

  return output;
};

export const outboundSubMadeAlt = (role, origin, type) => {
  fieldName = `${role}${origin}subobMadeQaltrdo`;
  inputType = 'radio';
  output = popOut(type);

  return output;
};

export const subobSpokeFNAlt = (role, origin, type) => {
  fieldName = `${role}${origin}subobSpokeFNQobcContactalttxt`;
  inputType = 'text';
  output = popOut(type);

  return output;
};

export const subobSpokeLNAlt = (role, origin, type) => {
  fieldName = `${role}${origin}subobSpokeLNQobcContactalttxt`;
  inputType = 'text';
  output = popOut(type);

  return output;
};

export const subobSpokeTitleAlt = (role, origin, type) => {
  fieldName = `${role}${origin}subobSpokeTitleQobcContactalttxt`;
  inputType = 'text';
  output = popOut(type);

  return output;
};

export const subobinfoGatherAlt = (role, origin, type) => {
  fieldName = `${role}${origin}subobinfoGatherQobcContactalttxt`;
  inputType = 'text';
  output = popOut(type);

  return output;
};

export const subobcalloutcoAlt = (role, origin, type) => {
  fieldName = `${role}${origin}subobcalloutcoQaltsel`;
  inputType = 'select';
  output = popOut(type);

  return output;
};

//* * EAG AAFNR fields */
export const eag = (role, origin, type) => {
  fieldName = `${role}${origin}eagQrdo`;
  inputType = 'radio';
  output = popOut(type);

  return output;
};

export const subAAFNRTestClaim = (role, origin, type) => {
  fieldName = `${role}${origin}subaafnrTestClaimQtxt`;
  inputType = 'text';
  output = popOut(type);

  return output;
};

export const subEAGTestClaim = (role, origin, type) => {
  fieldName = `${role}${origin}subeagTestClaimQtxt`;
  inputType = 'text';
  output = popOut(type);

  return output;
};

export const subEAGCase = (role, origin, type) => {
  fieldName = `${role}${origin}subeagCaseQrdo`;
  inputType = 'radio';
  output = popOut(type);

  return output;
};

export const subEAGExpire = (role, origin, type) => {
  fieldName = `${role}${origin}subeagExpireQrdo`;
  inputType = 'radio';
  output = popOut(type);

  return output;
};

export const subEAGRxClaim = (role, origin, type) => {
  fieldName = `${role}${origin}subeagRxClaimQrdo`;
  inputType = 'radio';
  output = popOut(type);

  return output;
};
export const subEAGTierRequest = (role, origin, type) => {
  fieldName = `${role}${origin}subeagTierRqstQrdo`;
  inputType = 'radio';
  output = popOut(type);

  return output;
};

export const subAAFNRCase = (role, origin, type) => {
  fieldName = `${role}${origin}subaafnrCaseQrdo`;
  inputType = 'radio';
  output = popOut(type);

  return output;
};

export const subAAFNRMsg = (role, origin, type) => {
  fieldName = `${role}${origin}subaafnrMSGQrdo`;
  inputType = 'radio';
  output = popOut(type);

  return output;
};

export const subAAFNRTierRequest = (role, origin, type) => {
  fieldName = `${role}${origin}subaafnrTierRqstQrdo`;
  inputType = 'radio';
  output = popOut(type);

  return output;
};

export const subAAFNRGpi = (role, origin, type) => {
  fieldName = `${role}${origin}subaafnrGPIQrdo`;
  inputType = 'radio';
  output = popOut(type);

  return output;
};

//* * Inquiry Fields */

export const subInquiryRejectCode = (role, origin, type) => {
  fieldName = `${role}${origin}subinqrejCodeQlt`;
  inputType = 'text';
  output = popOut(type);

  return output;
};

export const subInquiryTR = (role, origin, type) => {
  fieldName = `${role}${origin}subinqreTRQtxt`;
  inputType = 'text';
  output = popOut(type);

  return output;
};

export const subInquiryReason = (role, origin, type) => {
  fieldName = `${role}${origin}subinqReasonQlt`;
  inputType = 'text';
  output = popOut(type);

  return output;
};

export const subInquiryCaller = (role, origin, type) => {
  fieldName = `${role}${origin}subinqcallerQcallertxt`;
  inputType = 'text';
  output = popOut(type);

  return output;
};

export const inquiryCaller = (role, origin, type) => {
  fieldName = `${role}${origin}inqcallerQcallertxt`;
  inputType = 'text';
  output = popOut(type);

  return output;
};

export const subInquiryCMMKey = (role, origin, type) => {
  fieldName = `${role}${origin}subinqCMMdetailQkeytxt`;
  inputType = 'text';
  output = popOut(type);

  return output;
};

export const subInquiryCMMLastName = (role, origin, type) => {
  fieldName = `${role}${origin}subinqCMMdetailQLNtxt`;
  inputType = 'text';
  output = popOut(type);

  return output;
};

export const subInquiryCMMDoB = (role, origin, type) => {
  fieldName = `${role}${origin}subinqCMMdetailQdobtxt`;
  inputType = 'text';
  output = popOut(type);

  return output;
};

export const inquiry = (role, origin, type) => {
  fieldName = `${role}${origin}inquiryQrdo`;
  inputType = 'radio';
  output = popOut(type);

  return output;
};

export const subInquiryCMM = (role, origin, type) => {
  fieldName = `${role}${origin}subinqCMMQrdo`;
  inputType = 'radio';
  output = popOut(type);

  return output;
};

export const subInquiryRjctNAbtn = (role, origin, type) => {
  fieldName = `${role}${origin}subinqrejCodeQbtn`;
  inputType = 'button';
  output = popOut(type);

  return output;
};

export const subInquiryTRNAbtn = (role, origin, type) => {
  fieldName = `${role}${origin}subinqreTRQbtn`;
  inputType = 'button';
  output = popOut(type);

  return output;
};

//* * Claim fields */

export const claimToday = (role, origin, type) => {
  fieldName = `${role}${origin}claimQrdo`;
  inputType = 'radio';
  output = popOut(type);

  return output;
};

export const subClaimTodayRefill = (role, origin, type) => {
  fieldName = `${role}${origin}subclaimTodayRefillQrdo`;
  inputType = 'radio';
  output = popOut(type);

  return output;
};

export const subClaimTodayDate = (role, origin, type) => {
  fieldName = `${role}${origin}subclaimTodayDQtxt`;
  inputType = 'text';
  output = popOut(type);

  return output;
};

export const subClaimTodayCode = (role, origin, type) => {
  fieldName = `${role}${origin}subclaimTodayCodeQtxt`;
  inputType = 'text';
  output = popOut(type);

  return output;
};

export const claim90 = (role, origin, type) => {
  fieldName = `${role}${origin}claim90dQrdo`;
  inputType = 'radio';
  output = popOut(type);

  return output;
};

export const subClaim90Date = (role, origin, type) => {
  fieldName = `${role}${origin}subclaim90dQtxt`;
  inputType = 'text';
  output = popOut(type);

  return output;
};

export const subClaim90RejectCode = (role, origin, type) => {
  fieldName = `${role}${origin}subreject90dQtxt`;
  inputType = 'text';
  output = popOut(type);

  return output;
};

export const additionalClaim = (role, origin, type) => {
  fieldName = `${role}${origin}addTestClaimQrdo`;
  inputType = 'radio';
  output = popOut(type);

  return output;
};

export const subAdditionalDate = (role, origin, type) => {
  fieldName = `${role}${origin}subaddClaimDQtxt`;
  inputType = 'text';
  output = popOut(type);

  return output;
};

export const subAdditionalRejectCode = (role, origin, type) => {
  fieldName = `${role}${origin}subaddTCRjCQtxt`;
  inputType = 'text';
  output = popOut(type);

  return output;
};

// AMN 8/10/22 - #102: New Formulary ID Free Form Text Field for Aenta MAPD Plans
export const subFormularyID = (role, origin, type) => {
  fieldName = `${role}${origin}subFormularyIDQtxt`;
  inputType = 'text';
  output = popOut(type);

  return output;
};

export const obcCompleted = (role, origin, type) => {
  fieldName = `${role}${origin}obcCompletedrdo`;
  inputType = 'radio';
  output = popOut(type);

  return output;
};

export const RFITATCaseReviewed = (role, origin, type) => {
  fieldName = `${role}${origin}RFITATCaseReviewedQrdo`;
  inputType = 'radio';
  output = popOut(type);

  return output;
};

export const additionalOutboundCallNeeded = (role, origin, type) => {
  fieldName = `${role}${origin}subAdditionalOutBoundCallQrdo`;
  inputType = 'radio';
  output = popOut(type);

  return output;
};

export const rfiFaxTemplateQ = (role, origin, type) => {
  fieldName = `${role}${origin}rfiFaxTemplateQrdo`;
  inputType = 'radio';
  output = popOut(type);

  return output;
};

export const threeOutreachAttemptsQ = (role, origin, type) => {
  fieldName = `${role}${origin}threeOutreachAttemptsQrdo`;
  inputType = 'radio';
  output = popOut(type);

  return output;
};

export const failedFaxQ = (role, origin, type) => {
  fieldName = `${role}${origin}failedFaxQrdo`;
  inputType = 'radio';
  output = popOut(type);

  return output;
};

export const inProgressCase = (role, origin, type) => {
  fieldName = `${role}${origin}inProgressCaseQrdo`;
  inputType = 'radio';

  output = popOut(type);
  return output;
};

export const isCaseInRFI = (role, origin, type) => {
  fieldName = `${role}${origin}isCaseInRFIQrdo`;
  inputType = 'radio';
  output = popOut(type);

  return output;
};

export const reviewExternalTemplate = (role, origin, type) => {
  fieldName = `${role}${origin}reviewExternalTemplateQtxt`;
  inputType = 'text';
  output = popOut(type);

  return output;
};

/* DLT Guideline Questions */
export const licsAndROA = (role, origin, type) => {
  fieldName = `${role}${origin}licsAndROAQrdo`;
  inputType = 'radio';
  output = popOut(type);

  return output;
};

export const rejectWithA6 = (role, origin, type) => {
  fieldName = `${role}${origin}rejectWithA6Qrdo`;
  inputType = 'radio';
  output = popOut(type);

  return output;
};

export const drugFromPhysicianStock = (role, origin, type) => {
  fieldName = `${role}${origin}drugFromPhysicianStockQrdo`;
  inputType = 'radio';
  output = popOut(type);

  return output;
};

export const insulinPumpMedication = (role, origin, type) => {
  fieldName = `${role}${origin}insulinPumpMedicationQrdo`;
  inputType = 'radio';
  output = popOut(type);

  return output;
};

export const callerProvidedClinicalInfo = (role, origin, type) => {
  fieldName = `${role}${origin}callerProvidedClinicalInfoQrdo`;
  inputType = 'radio';
  output = popOut(type);

  return output;
};

// export const isCallerPrescriberOrMember = (role, origin, type) => {
//   fieldName = `${role}${origin}isCallerPrescriberOrMemberQrdo`;
//   inputType = 'radio';
//   output = popOut(type);

//   return output;
// };

export const dltShow0TFAlts = (role, origin, type) => {
  fieldName = `${role}${origin}dltShow0TFAltsQrdo`;
  inputType = 'radio';
  output = popOut(type);

  return output;
};

export const prescriberProvidedSpprtStmt = (role, origin, type) => {
  fieldName = `${role}${origin}prescriberProvidedSpprtStmtQrdo`;
  inputType = 'radio';
  output = popOut(type);

  return output;
};

export const clinicalCallerProvidedSpprtStmt = (role, origin, type) => {
  fieldName = `${role}${origin}clinicalCallerProvidedSpprtStmtQrdo`;
  inputType = 'radio';
  output = popOut(type);

  return output;
};

export const prescriberIndicatedFormAltsLessEff = (role, origin, type) => {
  fieldName = `${role}${origin}prescriberIndicatedFormAltsLessEffQrdo`;
  inputType = 'radio';
  output = popOut(type);

  return output;
};

export const prescriberIndicatedFormAltsProduceAdvAffects = (role, origin, type) => {
  fieldName = `${role}${origin}prescriberIndicatedFormAltsProduceAdvAffectsQrdo`;
  inputType = 'radio';
  output = popOut(type);

  return output;
};

export const triedNFailedFormAlts = (role, origin, type) => {
  fieldName = `${role}${origin}triedNFailedFormAltsQrdo`;
  inputType = 'radio';
  output = popOut(type);

  return output;
};

/* PROTECTED DRUG CLASS NON-FORMULARY & PROTECTED DRUG CLASS INFUSION NON-FORMULARY SPECIFIC QUESTIONS */
export const patientIsStableOnRqstDrug = (role, origin, type) => {
  fieldName = `${role}${origin}patientIsStableOnRqstDrugQrdo`;
  inputType = 'radio';
  output = popOut(type);

  return output;
};

/* PROTON PUMP INHIBITOR NON-FORMULARY GUIDELINE SPECIFIC QUESTIONS */
export const memberTakingPlavix = (role, origin, type) => {
  fieldName = `${role}${origin}memberTakingPlavixQrdo`;
  inputType = 'radio';
  output = popOut(type);

  return output;
};

export const triedExclOmprzlOrEsmprzl = (role, origin, type) => {
  fieldName = `${role}${origin}triedExclOmprzlOrEsmprzlQrdo`;
  inputType = 'radio';
  output = popOut(type);

  return output;
};

/* ANTIBACTERIALS NON-FORMULARY GUIDELINE SPECIFIC QUESTIONS */
export const memberIsStableOnRqstDrug = (role, origin, type) => {
  fieldName = `${role}${origin}memberIsStableOnRqstDrugQrdo`;
  inputType = 'radio';
  output = popOut(type);

  return output;
};

export const infectionIsDrugRstnt = (role, origin, type) => {
  fieldName = `${role}${origin}infectionIsDrugRstntQrdo`;
  inputType = 'radio';
  output = popOut(type);

  return output;
};

/* OPIOID NON-FORMULARY GUIDELINE & DIAGNOSIS REQUIRED OPIOID NON-FORMULARY SPECIFIC QUESTIONS */
export const medicationGreaterThan7DaySupply = (role, origin, type) => {
  fieldName = `${role}${origin}medicationGreaterThan7DaySupplyQrdo`;
  inputType = 'radio';
  output = popOut(type);

  return output;
};

/* DIAGNOSIS REQUIRED ORAL CHEMOTHERAPY NON-FORMULARY GUIDELINE SPECIFIC QUESTIONS */
export const oralChemotherapyUsedForCancer = (role, origin, type) => {
  fieldName = `${role}${origin}oralChemotherapyUsedForCancerQrdo`;
  inputType = 'radio';
  output = popOut(type);

  return output;
};

export const oralChemotherapyUsedForSameIndication = (role, origin, type) => {
  fieldName = `${role}${origin}oralChemotherapyUsedForSameIndicationQrdo`;
  inputType = 'radio';
  output = popOut(type);

  return output;
};

/* HIGH RISK DRUG CLASS NON-FORMULARY GUIDELINE & DIAGNOSIS REQUIRED ORAL CHEMOTHERAPY NON-FORMULARY GUIDELINE SPECIFIC QUESTIONS */
export const patientIsTakingNStableOnRqstDrug = (role, origin, type) => {
  fieldName = `${role}${origin}patientIsTakingNStableOnRqstDrugQrdo`;
  inputType = 'radio';
  output = popOut(type);

  return output;
};

/* BvD DLT Guideline Specific Questions */
export const licsMember = (role, origin, type) => {
  fieldName = `${role}${origin}licsMemberQrdo`;
  inputType = 'radio';
  output = popOut(type);

  return output;
};

export const rejectWithA4orA6 = (role, origin, type) => {
  fieldName = `${role}${origin}rejectWithA4orA6Qrdo`;
  inputType = 'radio';
  output = popOut(type);

  return output;
};

/* BVD NON-FORMULARY (ESRD) specific */
export const drugPrescribedBySpecialist = (role, origin, type) => {
  fieldName = `${role}${origin}drugPrescribedBySpecialistQrdo`;
  inputType = 'radio';
  output = popOut(type);

  return output;
};

export const drugForESRD = (role, origin, type) => {
  fieldName = `${role}${origin}drugForESRDQrdo`;
  inputType = 'radio';
  output = popOut(type);

  return output;
};

export const drugAdminViaInfusionPump = (role, origin, type) => {
  fieldName = `${role}${origin}drugAdminViaInfusionPumpQrdo`;
  inputType = 'radio';
  output = popOut(type);

  return output;
};

export const drugAdminViaInfusionPumpHome = (role, origin, type) => {
  fieldName = `${role}${origin}drugAdminViaInfusionPumpHomeQrdo`;
  inputType = 'radio';
  output = popOut(type);

  return output;
};

export const patientInSkilledNursingFacility = (role, origin, type) => {
  fieldName = `${role}${origin}patientInSkilledNursingFacilityQrdo`;
  inputType = 'radio';
  output = popOut(type);

  return output;
};

export const medicarePartAPayingFacilityBed = (role, origin, type) => {
  fieldName = `${role}${origin}medicarePartAPayingFacilityBedQrdo`;
  inputType = 'radio';
  output = popOut(type);

  return output;
};

export const narcoticAnalgesicNonCancerDx = (role, origin, type) => {
  fieldName = `${role}${origin}narcoticAnalgesicNonCancerDxQrdo`;
  inputType = 'radio';
  output = popOut(type);

  return output;
};

export const injectableAgentRequest = (role, origin, type) => {
  fieldName = `${role}${origin}injectableAgentRequestQrdo`;
  inputType = 'radio';
  output = popOut(type);

  return output;
};

export const drugFromPhysicianStockBvD = (role, origin, type) => {
  fieldName = `${role}${origin}drugFromPhysicianStockBvDQrdo`;
  inputType = 'radio';
  output = popOut(type);

  return output;
};

/* BVD NON-FORMULARY (HEPATITIS B) specific */
export const patientRiskHepatitisB = (role, origin, type) => {
  fieldName = `${role}${origin}patientRiskHepatitisBQrdo`;
  inputType = 'radio';
  output = popOut(type);

  return output;
};

/* BVD NON-FORMULARY (IMMUNOSUPPRESSANT) specific */
export const transplantIndicatorPresent = (role, origin, type) => {
  fieldName = `${role}${origin}transplantIndicatorPresentQrdo`;
  inputType = 'radio';
  output = popOut(type);

  return output;
};

/* BVD NON-FORMULARY (PARENTERAL NUTRITION) specific */
export const parenteralNutritionRequest = (role, origin, type) => {
  fieldName = `${role}${origin}parenteralNutritionRequestQrdo`;
  inputType = 'radio';
  output = popOut(type);

  return output;
};

export const permanentDysfunctionDigestiveTract = (role, origin, type) => {
  fieldName = `${role}${origin}permanentDysfunctionDigestiveTractQrdo`;
  inputType = 'radio';
  output = popOut(type);

  return output;
};

/* BVD NON-FORMULARY (INHALATION) fields */
export const patientResidenceCode = (role, origin, type) => {
  fieldName = `${role}${origin}patientResidenceCodeQrdo`;
  inputType = 'radio';
  output = popOut(type);

  return output;
};

export const patientUsingMedWithNebulizer = (role, origin, type) => {
  fieldName = `${role}${origin}patientUsingMedWithNebulizerQrdo`;
  inputType = 'radio';
  output = popOut(type);

  return output;
};

export const requestForBetaAgonistSteroidInhalantAnticholinergicOrPDEInhibitor = (role, origin, type) => {
  fieldName = `${role}${origin}requestForBetaAgonistSteroidInhalantAnticholinergicOrPDEInhibitorQrdo`;
  inputType = 'radio';
  output = popOut(type);

  return output;
};

export const requestForAsthmaOrObstructivePulmonaryDisease = (role, origin, type) => {
  fieldName = `${role}${origin}requestForAsthmaOrObstructivePulmonaryDiseaseQrdo`;
  inputType = 'radio';
  output = popOut(type);

  return output;
};

export const requestForDornaseAlphaPulmozyme = (role, origin, type) => {
  fieldName = `${role}${origin}requestForDornaseAlphaPulmozymeQrdo`;
  inputType = 'radio';
  output = popOut(type);

  return output;
};

export const patientHasCysticFibrosis = (role, origin, type) => {
  fieldName = `${role}${origin}patientHasCysticFibrosisQrdo`;
  inputType = 'radio';
  output = popOut(type);

  return output;
};

export const requestForTobramycinInhalationSolution = (role, origin, type) => {
  fieldName = `${role}${origin}requestForTobramycinInhalationSolutionQrdo`;
  inputType = 'radio';
  output = popOut(type);

  return output;
};

export const patientHasCysticFibrosisOrBronchiectasis = (role, origin, type) => {
  fieldName = `${role}${origin}patientHasCysticFibrosisOrBronchiectasisQrdo`;
  inputType = 'radio';
  output = popOut(type);

  return output;
};

export const requestForAcetylcysteine = (role, origin, type) => {
  fieldName = `${role}${origin}requestForAcetylcysteineQrdo`;
  inputType = 'radio';
  output = popOut(type);

  return output;
};

export const persistentThickPulmonarySecretions = (role, origin, type) => {
  fieldName = `${role}${origin}persistentThickPulmonarySecretionsQrdo`;
  inputType = 'radio';
  output = popOut(type);

  return output;
};

export const requestForNebupent = (role, origin, type) => {
  fieldName = `${role}${origin}requestForNebupentQrdo`;
  inputType = 'radio';
  output = popOut(type);

  return output;
};

export const patientHasHIVPneumocystosisOrComplicationsOfOrganTransplants = (role, origin, type) => {
  fieldName = `${role}${origin}patientHasHIVPneumocystosisOrComplicationsOfOrganTransplantsQrdo`;
  inputType = 'radio';
  output = popOut(type);

  return output;
};

export const requestForTyvasoOrVentavis = (role, origin, type) => {
  fieldName = `${role}${origin}requestForTyvasoOrVentavisQrdo`;
  inputType = 'radio';
  output = popOut(type);

  return output;
};

export const patientHasPulmonaryArteryHypertension = (role, origin, type) => {
  fieldName = `${role}${origin}patientHasPulmonaryArteryHypertensionQrdo`;
  inputType = 'radio';
  output = popOut(type);

  return output;
};

export const bvdDiagnosisProvided = (role, origin, type) => {
  fieldName = `${role}${origin}bvdDiagnosisProvidedQrdo`;
  inputType = 'radio';
  output = popOut(type);

  return output;
};

/* BVD NON-FORMULARY (IVIG) fields */
export const medicationReceivedInHome = (role, origin, type) => {
  fieldName = `${role}${origin}medicationReceivedInHomeQrdo`;
  inputType = 'radio';
  output = popOut(type);

  return output;
};

export const patientReceivingMedicationForPrimaryImmuneDeficiencyDisease = (role, origin, type) => {
  fieldName = `${role}${origin}patientReceivingMedicationForPrimaryImmuneDeficiencyDiseaseQrdo`;
  inputType = 'radio';
  output = popOut(type);

  return output;
};

export const requestForHizentraOrHyQvia = (role, origin, type) => {
  fieldName = `${role}${origin}requestForHizentraOrHyQviaQrdo`;
  inputType = 'radio';
  output = popOut(type);

  return output;
};

export const medicationGivenSubcutaneously = (role, origin, type) => {
  fieldName = `${role}${origin}medicationGivenSubcutaneouslyQrdo`;
  inputType = 'radio';
  output = popOut(type);

  return output;
};

export const patientReceivingMedicationForCIDP = (role, origin, type) => {
  fieldName = `${role}${origin}patientReceivingMedicationForCIDPQrdo`;
  inputType = 'radio';
  output = popOut(type);

  return output;
};

export const patientReceivingMedicationInMedicalOfficeOrInfusionCenter = (role, origin, type) => {
  fieldName = `${role}${origin}patientReceivingMedicationInMedicalOfficeOrInfusionCenterQrdo`;
  inputType = 'radio';
  output = popOut(type);

  return output;
};

export const requestedDrugSuppliedFromPhysicianOfficeStockIVIG = (role, origin, type) => {
  fieldName = `${role}${origin}requestedDrugSuppliedFromPhysicianOfficeStockIVIGQrdo`;
  inputType = 'radio';
  output = popOut(type);

  return output;
};

export const patientResidesInSNFOrSkilledCareFacility = (role, origin, type) => {
  fieldName = `${role}${origin}patientResidesInSNFOrSkilledCareFacilityQrdo`;
  inputType = 'radio';
  output = popOut(type);

  return output;
};

export const medicarePartAPayingForLTCFacilityBed = (role, origin, type) => {
  fieldName = `${role}${origin}medicarePartAPayingForLTCFacilityBedQrdo`;
  inputType = 'radio';
  output = popOut(type);

  return output;
};

export const bvdDiagnosisProvidedIVIG = (role, origin, type) => {
  fieldName = `${role}${origin}bvdDiagnosisProvidedIVIGQrdo`;
  inputType = 'radio';
  output = popOut(type);

  return output;
};

/* BVD NON-FORMULARY (ORAL ANTIEMETICS) fields */
export const requestForVarubiEmendOrAkynzeo = (role, origin, type) => {
  fieldName = `${role}${origin}requestForVarubiEmendOrAkynzeoQrdo`;
  inputType = 'radio';
  output = popOut(type);

  return output;
};

export const oralAntiemeticUsedInChemotherapy = (role, origin, type) => {
  fieldName = `${role}${origin}oralAntiemeticUsedInChemotherapyQrdo`;
  inputType = 'radio';
  output = popOut(type);

  return output;
};

export const oralAntiemeticUsedInChemotherapyReplacement = (role, origin, type) => {
  fieldName = `${role}${origin}oralAntiemeticUsedInChemotherapyReplacementQrdo`;
  inputType = 'radio';
  output = popOut(type);

  return output;
};

export const patientRequiresOneOfFollowing = (role, origin, type) => {
  fieldName = `${role}${origin}patientRequiresOneOfFollowingQrdo`;
  inputType = 'radio';
  output = popOut(type);

  return output;
};

export const requestForAkynzeo = (role, origin, type) => {
  fieldName = `${role}${origin}requestForAkynzeoQrdo`;
  inputType = 'radio';
  output = popOut(type);

  return output;
};

export const requestedDrugUsedInCancerChemotherapy = (role, origin, type) => {
  fieldName = `${role}${origin}requestedDrugUsedInCancerChemotherapyQrdo`;
  inputType = 'radio';
  output = popOut(type);

  return output;
};

export const oralAntiemeticFullTherapeuticReplacement = (role, origin, type) => {
  fieldName = `${role}${origin}oralAntiemeticFullTherapeuticReplacementQrdo`;
  inputType = 'radio';
  output = popOut(type);

  return output;
};

export const oralCorticosteroidAnd5HT3ReceptorAntagonist = (role, origin, type) => {
  fieldName = `${role}${origin}oralCorticosteroidAnd5HT3ReceptorAntagonistQrdo`;
  inputType = 'radio';
  output = popOut(type);

  return output;
};

export const patientReceivingChemotherapeuticAgents = (role, origin, type) => {
  fieldName = `${role}${origin}patientReceivingChemotherapeuticAgentsQrdo`;
  inputType = 'radio';
  output = popOut(type);

  return output;
};

export const akynzeoUsedInCancerChemotherapyRegimen = (role, origin, type) => {
  fieldName = `${role}${origin}akynzeoUsedInCancerChemotherapyRegimenQrdo`;
  inputType = 'radio';
  output = popOut(type);

  return output;
};

export const oralAntiemeticFullTherapeuticReplacementAkynzeo = (role, origin, type) => {
  fieldName = `${role}${origin}oralAntiemeticFullTherapeuticReplacementAkynzeoQrdo`;
  inputType = 'radio';
  output = popOut(type);

  return output;
};

export const oralCorticosteroidRegimen = (role, origin, type) => {
  fieldName = `${role}${origin}oralCorticosteroidRegimenQrdo`;
  inputType = 'radio';
  output = popOut(type);

  return output;
};

export const patientReceivingChemotherapeuticAgentsAkynzeo = (role, origin, type) => {
  fieldName = `${role}${origin}patientReceivingChemotherapeuticAgentsAkynzeoQrdo`;
  inputType = 'radio';
  output = popOut(type);

  return output;
};

/* Quantity Limit Exception Guideline Specific Questions */
export const typeOfQlReview = (role, origin, type) => {
  fieldName = `${role}${origin}typeOfQlReviewQrdo`;
  inputType = 'radio';
  output = popOut(type);

  return output;
};

export const prescriberIndicatedApprovedFormularyQuantityLimitIneffective = (role, origin, type) => {
  fieldName = `${role}${origin}prescriberIndicatedApprovedFormularyQuantityLimitIneffectiveQrdo`;
  inputType = 'radio';
  output = popOut(type);

  return output;
};

export const prescriberIndicatedApprovedDosesIneffective = (role, origin, type) => {
  fieldName = `${role}${origin}prescriberIndicatedApprovedDosesIneffectiveQrdo`;
  inputType = 'radio';
  output = popOut(type);

  return output;
};

/* Formulary Alternatives Fields */

export const formAltsFormularyId = (role, origin, type) => {
  fieldName = `${role}${origin}formAltsFormularyIdQsel`;
  inputType = 'select';
  output = popOut(type);

  return output;
};

export const formAltsDrugPicker = (role, origin, type) => {
  fieldName = `${role}${origin}formAltsDrugPickerQsel`;
  inputType = 'select';
  output = popOut(type);

  return output;
};

export const formAltsIndication = (role, origin, type) => {
  fieldName = `${role}${origin}formAltsIndicationQsel`;
  inputType = 'select';
  output = popOut(type);

  return output;
};

/* Formulary Resolution Fields */
export const formularySubclientQ = (role, origin, type) => {
  fieldName = `${role}${origin}formularySubclientQsel`;
  inputType = 'select';
  output = popOut(type);
  return output;
};

/* QL Verbiage Fields */
export const qlDrugAndRequestedQlQ = (role, origin, type) => {
  fieldName = `${role}${origin}qlDrugAndRequestedQlQtxt`;
  inputType = 'text';
  output = popOut(type);
  return output;
};

export const qlDrugAndPlanQlQ = (role, origin, type) => {
  fieldName = `${role}${origin}qlDrugAndPlanQlQtxt`;
  inputType = 'text';
  output = popOut(type);
  return output;
};

export const qlPlanQlQ = (role, origin, type) => {
  fieldName = `${role}${origin}qlPlanQlQtxt`;
  inputType = 'text';
  output = popOut(type);
  return output;
};

/* RFI / Denial Reason Fields */
export const rfiReasonQ = (role, origin, type) => {
  fieldName = `${role}${origin}rfiReasonSel`;
  inputType = 'select';
  output = popOut(type);
  return output;
};

export const denialReasonQ = (role, origin, type) => {
  fieldName = `${role}${origin}denialReasonSel`;
  inputType = 'select';
  output = popOut(type);
  return output;
};
