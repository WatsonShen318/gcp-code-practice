import { getEnvironmentVariables } from "../../../environment/config";
import resetSessionStorage from "../utils/resetSessionStorage";

const axios = require("axios");

async function sendDataToBigTable(finalNote, role, origin) {
  const userInfo = JSON.parse(sessionStorage.getItem("userInfo") || "{}");
  const startTime = sessionStorage.getItem("startTime");
  const eslRsp = JSON.parse(sessionStorage.getItem("eslRsp") || "{}");

  const workFlow = sessionStorage.getItem("workFlow");

  const medhokStatus = JSON.parse(sessionStorage.getItem("medhokStatus") || "[]");

  const medhokBackendResponse = JSON.parse(
    sessionStorage.getItem("medhokBackendResponse") || "[]"
  );

  const cdrdStatus = JSON.parse(sessionStorage.getItem("cdrdStatus") || "[]");

  const cdrdBackendResponse = JSON.parse(
    sessionStorage.getItem("cdrdBackendResponse") || "[]"
  );

  const caseIdInputTimeList = JSON.parse(
    sessionStorage.getItem("caseIdInputTimeList") || "[]"
  );

  let cdrdEndTime = sessionStorage.getItem("cdrdEndTime");

  let cdrdStartTime = sessionStorage.getItem("cdrdStartTime");

  console.log('cdrdStartTime, cdrdEndTime', cdrdStartTime, cdrdEndTime)

  if (!cdrdEndTime || !cdrdStartTime || cdrdEndTime < cdrdStartTime) {
    cdrdEndTime = ''
    cdrdStartTime = ''
  }

  const cdrdPredOutcome = sessionStorage.getItem("cdrdPredOutcome");

  let dltGuidelineStartTime = sessionStorage.getItem("dltGuidelineStartTime");
  let dltGuidelineEndTime = sessionStorage.getItem("dltGuidelineEndTime");
  let dltGuidelineName = sessionStorage.getItem("dltGuidelineName");

  /* Logic to save DLT Automated and Final Guideline values correctly in BigTable */
  let GL_FIELDS_AUTOMATED = {};
  let GL_FIELDS_FINAL = {};
  const saveDLTGuidelinesAuditData = role === "tech" && ["Queue", "TAT", "IBC"].includes(origin);

  if (dltGuidelineName && saveDLTGuidelinesAuditData) {
    GL_FIELDS_AUTOMATED = {
      dltAutomatedGuidelineForm: sessionStorage.getItem("dltAutomatedGuidelineForm") || "",
      // FormAlts-driven DLT fields - automation.js sets automated = final for all guideline types
      dltAutomatedShow0TFAltsQAnswer:            sessionStorage.getItem("dltAutomatedShow0TFAltsQAnswer")            || "",
      dltAutomatedTriedNFailedFormAltsQAnswer:   sessionStorage.getItem("dltAutomatedTriedNFailedFormAltsQAnswer")   || "",
      dltAutomatedTriedNFailedMedicationsAnswer: sessionStorage.getItem("dltAutomatedTriedNFailedMedicationsAnswer") || "",
    };

    GL_FIELDS_FINAL = {
      dltFinalGuidelineForm: dltGuidelineName,
      // FormAlts-driven DLT fields
      dltFinalShow0TFAltsQAnswer:                sessionStorage.getItem("dltFinalShow0TFAltsQAnswer")                || "",
      dltFinalTriedNFailedFormAltsQAnswer:       sessionStorage.getItem("dltFinalTriedNFailedFormAltsQAnswer")       || "",
      dltFinalTriedNFailedMedicationsAnswer:     sessionStorage.getItem("dltFinalTriedNFailedMedicationsAnswer")     || "",
    };

    if (dltGuidelineName.startsWith("BvD Non-Formulary")) {
      const doesDLTShowBvDNFInhalationAsRecommendedGuidelineFieldAns = dltGuidelineName.startsWith("BvD Non-Formulary (Inhalation)") ? "Yes" : "No";
      GL_FIELDS_AUTOMATED = {
        ...GL_FIELDS_AUTOMATED,
        dltAutomatedBvDLICSMemberFieldAns: sessionStorage.getItem("dltAutomatedBvDLICSMemberFieldAns") || "",
        dltAutomatedBvDRejectWithA4orA6FieldAns: sessionStorage.getItem("dltAutomatedBvDRejectWithA4orA6FieldAns") || "",
        dltAutomatedBvDDoesDLTShowBvDNFInhalationAsRecommendedGuidelineFieldAns: doesDLTShowBvDNFInhalationAsRecommendedGuidelineFieldAns,
      }

      GL_FIELDS_FINAL = {
        ...GL_FIELDS_FINAL,
        dltFinalBvDLICSMemberFieldAns: sessionStorage.getItem("dltFinalBvDLICSMemberFieldAns") || "",
        dltFinalBvDRejectWithA4orA6FieldAns: sessionStorage.getItem("dltFinalBvDRejectWithA4orA6FieldAns") || "",
        dltFinalBvDDoesDLTShowBvDNFInhalationAsRecommendedGuidelineFieldAns: doesDLTShowBvDNFInhalationAsRecommendedGuidelineFieldAns,
      }

      if (dltGuidelineName.startsWith("BvD Non-Formulary (ESRD)")) {
        GL_FIELDS_AUTOMATED = {
          ...GL_FIELDS_AUTOMATED,
          dltAutomatedBvDESRDInjectableAgentRequestFieldAns: sessionStorage.getItem("dltAutomatedBvDESRDInjectableAgentRequestFieldAns") || "",
        }

        GL_FIELDS_FINAL = {
          ...GL_FIELDS_FINAL,
          dltFinalBvDESRDInjectableAgentRequestFieldAns: sessionStorage.getItem("dltFinalBvDESRDInjectableAgentRequestFieldAns") || "",
        }
      } else if (dltGuidelineName.startsWith("BvD Non-Formulary (Inhalation)")) {
        const bvdInhalationFieldIds = [
          "requestForAsthmaOrObstructivePulmonaryDiseaseQ",
          "requestForDornaseAlphaPulmozymeQ",
          "patientHasCysticFibrosisQ",
          "requestForTobramycinInhalationSolutionQ",
          "patientHasCysticFibrosisOrBronchiectasisQ",
          "requestForAcetylcysteineQ",
          "persistentThickPulmonarySecretionsQ",
          "requestForNebupentQ",
          "patientHasHIVPneumocystosisOrComplicationsOfOrganTransplantsQ",
          "requestForTyvasoOrVentavisQ",
          "patientHasPulmonaryArteryHypertensionQ",
          "bvdDiagnosisProvidedQ"
        ];

        const inhalationAutomatedFields = {};
        const inhalationFinalFields = {};

        bvdInhalationFieldIds.forEach(fieldId => {
          inhalationAutomatedFields[`dltAutomatedBvDINHALATION${fieldId}FieldAns`] = sessionStorage.getItem(`dltAutomatedBvDINHALATION${fieldId}FieldAns`) || "";
          inhalationFinalFields[`dltFinalBvDINHALATION${fieldId}FieldAns`] = sessionStorage.getItem(`dltFinalBvDINHALATION${fieldId}FieldAns`) || "";
        });

        GL_FIELDS_AUTOMATED = {
          ...GL_FIELDS_AUTOMATED,
          ...inhalationAutomatedFields
        }

        GL_FIELDS_FINAL = {
          ...GL_FIELDS_FINAL,
          ...inhalationFinalFields
        }
      } else if (dltGuidelineName.startsWith("BvD Non-Formulary (IVIG)")) {
        const bvdIVIGFieldIds = [
          "patientReceivingMedicationForPrimaryImmuneDeficiencyDiseaseQ",
          "requestForHizentraOrHyQviaQ",
          "patientReceivingMedicationForCIDPQ",
          "bvdDiagnosisProvidedIVIGQ"
        ];

        const ivigAutomatedFields = {};
        const ivigFinalFields = {};

        bvdIVIGFieldIds.forEach(fieldId => {
          // Note: removing reduntant 'IVIG' from field names for Audit Data Keys consistency
          ivigAutomatedFields[`dltAutomatedBvDIVIG${fieldId.replace(/IVIGQ/g, "Q")}FieldAns`] = sessionStorage.getItem(`dltAutomatedBvDIVIG${fieldId}FieldAns`) || "";
          ivigFinalFields[`dltFinalBvDIVIG${fieldId.replace(/IVIGQ/g, "Q")}FieldAns`] = sessionStorage.getItem(`dltFinalBvDIVIG${fieldId}FieldAns`) || "";
        });

        GL_FIELDS_AUTOMATED = {
          ...GL_FIELDS_AUTOMATED,
          ...ivigAutomatedFields
        }

        GL_FIELDS_FINAL = {
          ...GL_FIELDS_FINAL,
          ...ivigFinalFields
        }
      } else if (dltGuidelineName.startsWith("BvD Non-Formulary (Oral Antiemetics)")) {
        const bvdOralAntiemeticsFieldIds = [
          "requestForVarubiEmendOrAkynzeoQ",
          "requestForAkynzeoQ"
        ];

        const oralAntiemeticsAutomatedFields = {};
        const oralAntiemeticsFinalFields = {};

        bvdOralAntiemeticsFieldIds.forEach(fieldId => {
          oralAntiemeticsAutomatedFields[`dltAutomatedBvDORALANTIEMETICS${fieldId}FieldAns`] = sessionStorage.getItem(`dltAutomatedBvDORALANTIEMETICS${fieldId}FieldAns`) || "";
          oralAntiemeticsFinalFields[`dltFinalBvDORALANTIEMETICS${fieldId}FieldAns`] = sessionStorage.getItem(`dltFinalBvDORALANTIEMETICS${fieldId}FieldAns`) || "";
        });

        GL_FIELDS_AUTOMATED = {
          ...GL_FIELDS_AUTOMATED,
          ...oralAntiemeticsAutomatedFields
        }

        GL_FIELDS_FINAL = {
          ...GL_FIELDS_FINAL,
          ...oralAntiemeticsFinalFields
        }
      }
    } else {
      GL_FIELDS_AUTOMATED = {
        ...GL_FIELDS_AUTOMATED,
        dltAutomatedLICSAndROAFieldAns:                         sessionStorage.getItem("dltAutomatedLICSAndROAFieldAns")                         || "",
        dltAutomatedRejectWithA6FieldAns:                       sessionStorage.getItem("dltAutomatedRejectWithA6FieldAns")                       || "",
        dltAutomatedInsulinPumpMedicationFieldAns:              sessionStorage.getItem("dltAutomatedInsulinPumpMedicationFieldAns")              || "",
        dltAutomatedApprovableDiagnosisFieldAns:                sessionStorage.getItem("dltAutomatedApprovableDiagnosisFieldAns")                || "",
        dltAutomatedPrescriberIndicatedQlIneffectiveFieldAns:   sessionStorage.getItem("dltAutomatedPrescriberIndicatedQlIneffectiveFieldAns")   || "",
      };

      GL_FIELDS_FINAL = {
        ...GL_FIELDS_FINAL,
        dltFinalLICSAndROAFieldAns:                         sessionStorage.getItem("dltFinalLICSAndROAFieldAns")                         || "",
        dltFinalRejectWithA6FieldAns:                       sessionStorage.getItem("dltFinalRejectWithA6FieldAns")                       || "",
        dltFinalInsulinPumpMedicationFieldAns:              sessionStorage.getItem("dltFinalInsulinPumpMedicationFieldAns")              || "",
        dltFinalApprovableDiagnosisFieldAns:                sessionStorage.getItem("dltFinalApprovableDiagnosisFieldAns")                || "",
        dltFinalPrescriberIndicatedQlIneffectiveFieldAns:   sessionStorage.getItem("dltFinalPrescriberIndicatedQlIneffectiveFieldAns")   || "",
      };
    }
  }

  console.log(`dltGuidelineStartTime: ${dltGuidelineStartTime}, dltGuidelineEndTime: ${dltGuidelineEndTime}, dltGuidelineName: ${dltGuidelineName}`);

  if (!dltGuidelineEndTime || !dltGuidelineStartTime || dltGuidelineEndTime < dltGuidelineStartTime) {
    dltGuidelineEndTime = ''
    dltGuidelineStartTime = ''
    dltGuidelineName = ''
  }

  // Case Decision/Routing Values
  const RECOMMENDED_CASE_DCSN_ROUTING = sessionStorage.getItem("RECOMMENDED_CASE_DCSN_ROUTING");
  const FINAL_CASE_DCSN_ROUTING = sessionStorage.getItem("FINAL_CASE_DCSN_ROUTING");
  // Data saved to MHK
  const MHK_OBC_CONTACT_TYPE = sessionStorage.getItem("MHK_OBC_CONTACT_TYPE");
  const MHK_OBC_CONTACT_OUTCOME = sessionStorage.getItem("MHK_OBC_CONTACT_OUTCOME");
  const MHK_OBC_CONTACT_NOTES = sessionStorage.getItem("MHK_OBC_CONTACT_NOTES");
  const MHK_STATUS = sessionStorage.getItem("MHK_STATUS");
  const MHK_STATUS_REASON = sessionStorage.getItem("MHK_STATUS_REASON");
  const MHK_FINAL_NOTE = sessionStorage.getItem("MHK_FINAL_NOTE");
  const MHK_ADDL_INFO_REQUIRED = sessionStorage.getItem("MHK_ADDL_INFO_REQUIRED");
  const MHK_SUPP_STMT_REQUIRED = sessionStorage.getItem("MHK_SUPP_STMT_REQUIRED");
  const MHK_LETTER_TEMPLATE_DESC  = sessionStorage.getItem("MHK_LETTER_TEMPLATE_DESC");
  const MHK_EXTERNAL_TEMPLATE     = sessionStorage.getItem("MHK_EXTERNAL_TEMPLATE");
  const MHK_EXTERNAL_TEMPLATE_DESC = sessionStorage.getItem("MHK_EXTERNAL_TEMPLATE_DESC");

  const bigTablePayload = {
    caseType: `${role}${origin}`,
    userId: userInfo?.userId,
    userName: userInfo?.userName,
    userGroups: userInfo?.userGroups,
    startTime,
    workFlow,
    medhokStatus,
    medhokBackendResponse,
    cdrdStatus,
    cdrdBackendResponse,
    cdrdStartTime,
    cdrdEndTime,
    cdrdPredOutcome,
    dltGuidelineStartTime,
    dltGuidelineEndTime,
    dltGuidelineName: dltGuidelineName || GL_FIELDS_FINAL?.dltFinalGuidelineForm || '',
    caseIdInputTimeList,
    GL_FIELDS_AUTOMATED,
    GL_FIELDS_FINAL,
    eslRsp,
    finalNote,
    FORM_ALTS_AUDIT: JSON.parse(sessionStorage.getItem('formAltsAudit') || 'null'),
    QL_AUDIT: JSON.parse(sessionStorage.getItem('qlAudit') || 'null'),
    RECOMMENDED_CASE_DCSN_ROUTING,
    FINAL_CASE_DCSN_ROUTING,
    RFI_REASON_SELECTED:    sessionStorage.getItem('RFI_REASON_SELECTED')    || null,
    DENIAL_REASON_SELECTED: sessionStorage.getItem('DENIAL_REASON_SELECTED') || null,
    CASE_VERBIAGE_GENERATED: sessionStorage.getItem('CASE_VERBIAGE_GENERATED') || null,
    MHK_OBC_CONTACT_TYPE,
    MHK_OBC_CONTACT_OUTCOME,
    MHK_OBC_CONTACT_NOTES,
    MHK_STATUS,
    MHK_STATUS_REASON,
    MHK_FINAL_NOTE,
    MHK_ADDL_INFO_REQUIRED,
    MHK_SUPP_STMT_REQUIRED,
    MHK_LETTER_TEMPLATE_DESC,
    MHK_EXTERNAL_TEMPLATE,
    MHK_EXTERNAL_TEMPLATE_DESC
  };

  const { AUTO_NOTE_BACKEND, PROD_AUTO_NOTE_BACKEND } = getEnvironmentVariables();
  resetSessionStorage();

  const pushToBackend = (backendUrl) =>
    axios
      .post(`${backendUrl}/bigtable`, bigTablePayload)
      .then((response) => console.log(`[BigTable] pushed to ${backendUrl}`, response.data))
      .catch((error) => console.error(`[BigTable] push failed for ${backendUrl}`, error));

  pushToBackend(AUTO_NOTE_BACKEND);

  if (PROD_AUTO_NOTE_BACKEND && PROD_AUTO_NOTE_BACKEND !== AUTO_NOTE_BACKEND && userInfo?.isBetaUser) {
    pushToBackend(PROD_AUTO_NOTE_BACKEND);
  }
}

export default sendDataToBigTable;
