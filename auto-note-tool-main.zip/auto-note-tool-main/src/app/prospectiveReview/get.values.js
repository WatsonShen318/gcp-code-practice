import { getLastQtr, getNextYear } from '../utils/calculateDates';
import getInputValue from '../utils/getInputValue';

export default function getProsReviewVal(role, origin) {
  const LastQtr = getLastQtr();
  const NextYr = getNextYear();
  let o = '';
  if (!LastQtr.includes('noshow')) {
    const r = getInputValue('radio', [`${role}${origin}prospectiveQrdo`]);
    if (r[`${role}${origin}prospectiveQrdo`] === 'Yes') {
      o = `This is a ${NextYr} Prospective Review.`;
      return o;
    }
  }
  return o;
}
