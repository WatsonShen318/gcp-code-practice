import { isFlowAutomated } from '../prefill/helpers';
import { toggleDisplay } from '../utils/notetool.display';

export default function makebabies(o, r, alt=false) {
  const altsfx = alt ? 'alt' : '';
  const startNum = document.getElementById(`${r}${o}outboundcall${altsfx}counter`);
  const counter = Number(startNum.value) + 1;
  const clone = document
    .getElementById(`${r}${o}subobPurposeQ${altsfx}PA`)
    ?.cloneNode(true);
  const txt = clone.querySelectorAll('input[type="text"]');
  const rdo = clone.querySelectorAll('input[type="radio"]:checked');

  const nClone = [...clone.querySelectorAll('label, [id]')];

  if (clone.matches('[id]')) {
    nClone.push(clone);
  }
  nClone.forEach((e) => {
    if (e.id) {
      e.id += counter;
    }
    if (e.name) {
      e.name += counter;
    }
    if (e.htmlFor) {
      e.htmlFor += counter;
    }
    if (e.id.includes(`${r}${o}subobSpokeQ${altsfx}${counter}`)) {
      e.style.display = 'none';
      e.disabled = true;
    }
    if(e.id.includes(`${r}${o}subobinfoGatherQ${altsfx}${counter}`)) {
      e.style.display = 'none';
      e.disabled = true;
    }
  });

  clone.classList.remove('ihide');
  clone.classList.add('mt-3');
  clone.removeAttribute('data-note', 'final');
  clone.setAttribute('data-clone', 'cloned');

  rdo.forEach((i) => (i.checked = false));
  txt.forEach((j) => (j.value = ''));

  document.getElementById(`${r}${o}outboundcall${altsfx}anc`).append(clone);
  startNum.value = counter;
  toggleDisplay('solo', [`${r}${o}obbaddbtn${altsfx}rebtn`], 'enable');
}

export function removeItem(o, r, alt=false) {
  const altsfx = alt ? 'alt' : '';
  const anchor = document.getElementById(`${r}${o}outboundcall${altsfx}anc`);
  const counter = document.getElementById(`${r}${o}outboundcall${altsfx}counter`);
  anchor.lastChild.remove();
  counter.value = Number(counter.value) - 1;
  if (anchor.childElementCount === 1) {
    toggleDisplay('solo', [`${r}${o}obbaddbtn${altsfx}rebtn`], 'disable');
  }
}

export function destoryClones(alt=false) {
  const altsfx = alt ? 'alt' : '';
  const clones = document.querySelectorAll('[data-clone="cloned"');
  const counter = document.querySelectorAll(`[id*=outboundcall${altsfx}counter]`);
  counter.forEach((o) => (o.value = 0));
  clones.forEach((o) => o.parentNode.removeChild(o));
}
