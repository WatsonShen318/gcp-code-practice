import { GeneralModal } from '../modal/alert.service';
import { bold } from '../utils/font.formatter';

/**
 * Toggle Modal when Confirmed member outbound call was completed and documented on the Contacts Tab = No
 * @param {*} answer
 * @returns
 */
export default function msgOBCDone(answer) {
  if (answer === 'No') {
    GeneralModal({
      message: bold('Member outbound call is required prior to dismissal'),
      icon: 'notification_important',
    });
  }
}
