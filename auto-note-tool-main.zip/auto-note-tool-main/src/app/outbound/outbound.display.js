import { getClientValue } from "../finalnote/components/get.values";
import { toggleDisplay } from "../utils/notetool.display";
import togglePartialValidation from "../utils/validation";
import {
  additionalOutboundCallNeeded,
  decisionRouting,
  requestBy,
} from "../qsets/fields";
import { isFlowAutomated } from "../prefill/helpers";
import { getObcFieldsToBeRemoved } from "../prefill/removeFields";

const Obs = (i, r, o, alt=false, forDisabling=false) => {
  const altsfx = alt ? 'alt' : '';
  const noShowQuerry = forDisabling ? ` #${i}>fieldset[data-tag='outboundcall${altsfx} noShow'],` : '';
  const outBoundCallTags = document.querySelectorAll(
    `#${i}>fieldset[data-tag='outboundcall${altsfx}'],${noShowQuerry} #${r}${o}btndivobbaddbtn${altsfx}`
  );

  // if (!forDisabling && isFlowAutomated()) {
  // remove "Do not need" fields from manual fields as well
  if (!forDisabling) {
    const obcFieldsToBeRemoved = getObcFieldsToBeRemoved(r, o, alt);
    const filteredOutBoundCallTags = Array.from(outBoundCallTags).filter(
      (element) => !obcFieldsToBeRemoved.includes(element.id)
    );
    return filteredOutBoundCallTags;
  }
  return outBoundCallTags;
};

export function toggleOutbound(o, r, a) {
  const clientSel = getClientValue(r, o);

  const status =
    a === "Pending Appointment of Representative" ||
    (a === "Forward to Clinical" && clientSel === "Oscar Health (21BV)") // ! added for Tech and RPH IBC only
      ? "disable"
      : "enable";
  if (!additionalOutboundCallNeeded(r, o, "value")) {
    toggleDisplay("solo", [`${r}${o}outboundQ`], status);
  }
}

export function toggleOBdetails(o, r, a, id, alt=false) {
  const altsfx = alt ? 'alt' : '';
  if (a === "Yes") {
    toggleDisplay("tag", Obs(id, r, o, alt, false), "enable");
    toggleDisplay("solo", [`${r}${o}buttonobcSubmit${altsfx}`], "enable");
  } else {
    toggleDisplay("tag", Obs(id, r, o, alt, true), "disable");
    toggleDisplay("solo", [`${r}${o}buttonobcSubmit${altsfx}`], "disable");
    togglePartialValidation(o, r, "back");
  }
}

export function toggleOBCMadeDetails(o, r, a, id = "", alt=false) {
  const altsfx = alt ? 'alt' : '';
  let obcMadeDetailsIds = [`${r}${o}subobSpokeFNQ${altsfx}${id || ""}`, `${r}${o}subobSpokeLNQ${altsfx}${id || ""}`, `${r}${o}subobSpokeTitleQ${altsfx}${id || ""}`];
    obcMadeDetailsIds = [
      ...obcMadeDetailsIds,
      `${r}${o}subobinfoGatherQ${altsfx}${id || ""}`,
    ];

  if (a === "Yes - Spoke with") {
    toggleDisplay("solo", obcMadeDetailsIds, "enable");
    toggleDisplay("solo", [`${r}${o}subobcalloutcoQ${altsfx}${id || ""}`], "disable");
  } else {
    toggleDisplay("solo", obcMadeDetailsIds, "disable");
    toggleDisplay("solo", [`${r}${o}subobcalloutcoQ${altsfx}${id || ""}`], "enable");
  }
}

/**
 * * Toggle Question when Request by = AOR and is Dismiss
 * @param {*} role user role
 * @param {*} origin user origin
 */
export function toggleOBCDone(role, origin) {
  const decision = decisionRouting(role, origin, "value");
  const rqstBy = requestBy(role, origin, "value");
  const status =
    decision === "Dismissed" && rqstBy === "AOR" ? "enable" : "disable";
  toggleDisplay("solo", [`${role}${origin}obcCompleted`], status);
}

/* Toggle OBC field based Additional OBC needed selection */
export function toggleOBCFromAdditionalOBCNeeded(o, r, a) {
  if (a == "Yes") {
    toggleDisplay("solo", [`${r}${o}outboundQalt`], "enable");
  } else {
    toggleDisplay("solo", [`${r}${o}outboundQalt`], "disable");
    toggleOBdetails(o, r, '', `${r}${o}subobPurposeQaltPA`, true);
  }
}
