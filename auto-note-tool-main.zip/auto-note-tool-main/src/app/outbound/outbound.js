import makebabies, { removeItem } from './clone';
import { goBackShowTool } from '../buttons/display';
import { toggleOBCMadeDetails } from './outbound.display';
import { setOBCSendingtoRFINA } from '../utils/automation';
import {
  decisionRouting,
  outboundSubMade,
  outboundSubMadeAlt
} from '../qsets/fields';
import { setDecisionRoutingForGLFields } from '../guidelines/guideline.display';

export default function obc(origin, role, alt=false) {
  let answer = null;

  const altsfx = alt ? 'alt' : '';

  // Trying to assign handler to onclick event listener instead of addEventListener method to avoid duplicates in reset scenario
  // Auto Note Phase 4.0 -> Disabling Add/Remove OBC buttons as per new requirements while saving obc notes with Update PA APIs.
  // const addOBCHandler = () => makebabies(origin, role, alt)
  // const outboundAddCurrentBtn = document.getElementById(`${role}${origin}obbaddbtn${altsfx}btn`);
  // outboundAddCurrentBtn?.onclick = addOBCHandler

  // const removeOBCHandler = () => removeItem(origin, role, alt)
  // const outboundRemoveCurrentBtn = document.getElementById(`${role}${origin}obbaddbtn${altsfx}rebtn`);
  // outboundRemoveCurrentBtn?.onclick = removeOBCHandler

  if(alt) {
    //* [Alt] was the conact made with someone at the MDO?
    outboundSubMadeAlt(role, origin, 'event').forEach((elem) => {
      elem.addEventListener('click', (e) => {
        answer = e.target.value;

        toggleOBCMadeDetails(origin, role, answer, "", true);
      });
    });
  } else {
    //* was the conact made with someone at the MDO?
    outboundSubMade(role, origin, 'event').forEach((elem) => {
      elem.addEventListener('click', (e) => {
        answer = e.target.value;

        toggleOBCMadeDetails(origin, role, answer);

        /* Automate Case/Decision Routing in DLT Guideline scenarios */
        if(role === 'tech' && ['Queue', 'TAT', 'IBC'].includes(origin)) {
          if(sessionStorage.getItem("isDLTGuidelineFormAutomated") === 'true') {
            if(answer === 'No') {
              setDecisionRoutingForGLFields(role, origin, "Sent to RFI");
            } else {
              const decisionRoutingValue = decisionRouting(role, origin, "value");
              // Resetting Decision Routing value only if automated value is 'Sent to RFI' when it was automated by "Was contact made with someone at the MDO?"
              if(decisionRoutingValue === 'Sent to RFI') {
                setDecisionRoutingForGLFields(role, origin, "");
              }
            }
          }
        }
      });
    });
  }

  //* When sending to RFI, what information was requested in fax to prescriber's office */
  const main = document.getElementById(`${role}${origin}subobPurposeQ${altsfx}PA`);
  function rfiBtn(e) {
    if (e.target.matches(`[id*=${role}${origin}subobRFIQ${altsfx}btn]`)) {
      setOBCSendingtoRFINA(origin, role, '', alt);
    }
  }
  main?.addEventListener('click', rfiBtn);

  //* repeated - was the conact made with someone at the MDO?
  const repeat = document.getElementById(`${role}${origin}outboundcall${altsfx}anc`);
  function clickHandle(e) {
    if (e.target.matches(`[name*=${role}${origin}subobMadeQ${altsfx}rdo]`)) {
      const rname = e.target.getAttribute('name');
      const idnum = rname.replace(/^\D+/g, '');
      answer = e.target.value;

      toggleOBCMadeDetails(origin, role, answer, idnum, alt);
    }
    if (e.target.matches(`[id*=${role}${origin}subobRFIQ${altsfx}btn]`)) {
      const rname = e.target.id;
      const idnum = rname.replace(/^\D+/g, '');
      answer = e.target.value;

      setOBCSendingtoRFINA(origin, role, idnum, alt);
    }
  }
  repeat.addEventListener('click', clickHandle);

  //* click Go Back from OBC Notes
  document.getElementById('goBack').addEventListener('click', () => {
    goBackShowTool(origin, role);
  });
}
