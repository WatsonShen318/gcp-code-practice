import { GeneralModal } from '../modal/alert.service';
import { decisionRouting } from '../qsets/fields';
import { bold } from '../utils/font.formatter';

export default function msgLetterPreview(r, o, a) {
  const decision = decisionRouting(r, o, 'value');
  const verb = (t) => {
    const w = {
      Dismissed: 'dismissal',
      Approved: 'approval',
      Denied: 'denial',
    };
    return (
      `Previewing the ${w[t]} letter is required` ||
      'Letter Preview is required'
    );
  };
  if (a === 'No' && o !== 'SR') {
    GeneralModal({
      message: bold(verb(decision)),
      icon: 'notification_important',
    });
  }
}
