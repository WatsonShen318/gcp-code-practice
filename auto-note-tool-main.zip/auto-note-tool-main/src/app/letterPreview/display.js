import { toggleDisplay } from '../utils/notetool.display';

export function toggleLtrPreview(o, r) {
  toggleDisplay('solo', [`${r}${o}LetterPreviewQ`], 'disable');
}


export function toggleLtrPreviewNA(o, r, a) {}
