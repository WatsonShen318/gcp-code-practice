import { toggleDisplay } from "../utils/notetool.display";
import { closeGuidelineModal, GeneralModal, guideline } from "../modal/alert.service";
import { copy } from "../../data/filterData";
import { toggleRequestType } from "../requestType/display";
import { clickCD, clickRD } from "../requestType/automation";
import { automateCDRDGridFields } from "../prefill/prefillCDRD";
import { decisionRouting, drugName, requestType } from "../qsets/fields";
import { bold } from "../utils/font.formatter";

const gllinks = require("./guidelines.json");

const grid = window.frames.glFrame;
// const guildelinePrefix = 'cda-internal-note-tool/standard-nf-exception/';
// const guidelinePrefix = 'guidelines/'

export function toggleGuidelinesDrop(o, r, a) {
  switch (a) {
    case "Step Therapy":
    case "Tier Change":
    case "Prior Authorization":
    case "Safety Edit":
      /* [Automated flow only] Skipping disabling DLT guidelines for Phase-3.0 and later changes */
      const workFlow = sessionStorage.getItem("workFlow");
      if(workFlow !== 'Automated'){
        toggleDisplay(
          "solo",
          [`${r}${o}guidelineQ`, `${r}${o}subguidelineQ`],
          "disable"
        );
      }
      break;
    default:
      toggleDisplay(
        "solo",
        [`${r}${o}guidelineQ`, `${r}${o}subguidelineQ`],
        "enable"
      );
      break;
  }
}

export function toggleCDRDGrid(a) {
  if (a === "Yes" || a === "No") {
    guideline({
      guide: "CD/RD Grid",
      link: `_new_CDRD%20Grid.html`,
    });
  }
}

function inputChild(o, r) {
  let a = null;
  const rdobtns = grid.document.querySelectorAll(`[type="radio"]`);

  rdobtns.forEach((elem) => {
    elem.addEventListener("click", (e) => {
      const Qnum = e.target.getAttribute("name");
      a = e.target.value;
      if (Qnum === "Number1Rdo") {
        document.getElementById(`${r}${o}rqstTypeDeniedQ${a}`).checked = true;
      }
      // AMN 1/5/23 - CDRD Grid #4: Update Logic for Q8 and Q9
      /* 
      if (Qnum === 'Number8Rdo') {
        toggleRequestType(o, r, 'Yes');
        clickRD(o, r);
      }
      */
      if (Qnum === "Number9Rdo") {
        toggleRequestType(o, r, "Yes");
        clickRD(o, r);
      }

      // AMN 1/5/23 - CDRD Grid #4: Update Logic for Q8 and Q9
      /* 
      if (Qnum !== 'Number1Rdo' && Qnum !== 'Number8Rdo') {
        if (Qnum === 'Number1aRdo' || a === 'No') {
          toggleRequestType(o, r, 'Yes');
          clickCD(o, r);
        }
      }
      */
      if (Qnum !== "Number1Rdo" && Qnum !== "Number9Rdo") {
        if (
          Qnum === "Number1aRdo" ||
          a === "No" ||
          (Qnum === "Number8Rdo" && a === "Yes")
        ) {
          toggleRequestType(o, r, "Yes");
          clickCD(o, r);
        }
      }
    });
  });
}

export function guidelines(o, r, a) {
  const glFrame = document.getElementById("guideline");
  glFrame.addEventListener("load", () => {
    const gl = grid.document.querySelector("title").innerText;
    if (gl.includes("CD/RD")) {
      const workFlow = sessionStorage.getItem("workFlow");
      const cdrdBackendResponse = JSON.parse(
        sessionStorage.getItem("cdrdBackendResponse")
      )?.[0];
      if (
        workFlow === "Automated" &&
        cdrdBackendResponse &&
        cdrdBackendResponse?.message === "success"
      ) {
        automateCDRDGridFields(grid, cdrdBackendResponse?.cdrdGridAnswers);
      } else {
        const Q1Yes = grid.document.getElementById("Number1RdoYes");
        const Q1No = grid.document.getElementById("Number1RdoNo");

        if (a === "Yes") {
          Q1Yes.click();
        } else {
          Q1No.click();
        }
      }

      // Capturing CDRD start time for auditing
      const timestamp = new Date().toISOString();
      sessionStorage.setItem("cdrdStartTime", timestamp);

      inputChild(o, r);
    } else {
      const navbar = grid.document.getElementById("nav");
      const resetbtn = grid.document.getElementById("buttonSection");
      navbar.style.display = "none";
      resetbtn.style.display = "none";
    }

    closeGuidelineModal(r, o, gl);
  });
}

/**
 * * Display guideline
 * @param {string} g guideline
 */

export function toggleGL(g) {
  const gls = gllinks.items.map(copy).filter((t) => t.name === g);
  const suffix = " Guideline";

  if (g !== "N/A" && g !== "") {
    guideline({
      guide: g + suffix,
      link: `_new_${gls[0].url}`,
    });
    console.log("Guideline displayed: " + g + suffix);
    // Capturing DLT Exception Guideline start time for auditing
    const timestamp = new Date().toISOString();
    sessionStorage.setItem("dltGuidelineStartTime", timestamp);
    sessionStorage.setItem("dltGuidelineName", g + suffix);
  } else {
    sessionStorage.setItem("dltGuidelineStartTime", "");
    sessionStorage.setItem("dltGuidelineName", g);
  }
}

/**
 * Automate Case/Decision Routing field for Guideline related questions
 * @param {*} o origin
 * @param {*} r role
 * @param {*} routingValue routing value to be set
 * @param {*} showAlert whether to display the alert
 */
export function setDecisionRoutingForGLFields(r, o, routingValue, showAlert=true) {
  const decision = decisionRouting(r, o, 'element');

  // pre-check: When case type = Redetermination, always recommend “Forward to Clinical”; however, if approvable based on guideline question, Auto Note Recommendation should state “Forward to Clinical, approvable RD”
  const requestTypeValue = requestType(r, o, 'value');
  let overridenRecommendation = "";
  if(requestTypeValue === 'RD' && routingValue === "Approved") {
    routingValue = "Forward to Clinical";
    overridenRecommendation = "Forward to Clinical, approvable RD";
  }


  // pre-check: When Zepbound or Wegovy is selected the 'send to RFI' recommendation needs to be 'send to clinical review'.  Technicians will not be sending these requests to RFI, only approve or clinical review.
  const drugNameValue = drugName(r, o, 'value')?.toLowerCase();
  if(drugNameValue?.includes('zepbound') || drugNameValue?.includes('wegovy')) {
    if(routingValue === 'Sent to RFI') {
      routingValue = 'Forward to Clinical';
    }
  }

  // skipping automating Case Decision/Routing if it is already populated with the same routingValue
  if(!overridenRecommendation && decision.value === routingValue) {
    return;
  }

  decision.value = routingValue;

  /* Logic to update Auto note recommnedation for Case Decision/Routing */
  // Add Auto Note Recommendation note the Case Decision/Routing dropdown
  const routingRecommendationPreHUP = document.getElementById(`${r}${o}routingRecommendationPreHUP`);
  const routingRecommendationPreHUPtext = document.getElementById(`${r}${o}routingRecommendationPreHUPtext`);

  // Display Auto Note Recommends text for specific routing values
  const allowedRoutingValues = ["Forward to Clinical", "Approved", "Sent to RFI"];

  if(routingRecommendationPreHUP && routingRecommendationPreHUPtext) {
    let finalRecommendation = "";
    if (allowedRoutingValues.includes(routingValue)) {
      routingRecommendationPreHUP.style.display = "block";
      finalRecommendation = `${overridenRecommendation || routingValue}`;
      routingRecommendationPreHUPtext.innerHTML = `<b><span class="text-primary">Auto <span class="fw-bold">Note</span> Recommends: ${finalRecommendation}</span></b>`;
    } else {
      routingRecommendationPreHUP.style.display = "none";
      routingRecommendationPreHUPtext.innerHTML = `<b><span class="text-primary">Auto <span class="fw-bold">Note</span> Recommends: N/A</span></b>`;
    }
    sessionStorage.setItem("RECOMMENDED_CASE_DCSN_ROUTING", finalRecommendation);
  }

  decision.dispatchEvent(new Event('change'));
  // Visual indicator of recommendation of decision/routing
  const ModalMessageMapper = {
    "Forward to Clinical": "Forward to Clinical",
    "Approved": "Recommend Approval",
    "Sent to RFI": "Recommend RFI"
  }
  if((routingValue in ModalMessageMapper) && showAlert){
    GeneralModal({
      message: bold(
        ModalMessageMapper[routingValue] || routingValue
      ),
      icon: 'notification_important',
    });
  }
}
