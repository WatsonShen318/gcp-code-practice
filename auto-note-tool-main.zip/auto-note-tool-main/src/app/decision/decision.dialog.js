import { GeneralModal } from '../modal/alert.service';
import { getLastQtr, getNextYear } from '../utils/calculateDates';
import {
  client,
  prospectiveReview,
  requestReason,
  requestType,
} from '../qsets/fields';
import { bold } from '../utils/font.formatter';

let _suppressOnce = false;
export function suppressNextMsgDecision() { _suppressOnce = true; }
export function clearSuppressNextMsgDecision() { _suppressOnce = false; }

export default function msgDecision(o, r, a) {
  if (_suppressOnce) { _suppressOnce = false; return; }
  if (a === 'Send to MD') {
    const rt = requestType(r, o, 'value');
    if (o !== 'TAT' || (r === 'rph' && o === 'TAT' && rt === 'RD')) {
      GeneralModal({
        message: bold(
          'This should only be used for select medications that require Medical Director review and CDs that were denied by a Medical Director. If this is not the scenario, review the Case Decision/Routing drop down and select the appropriate option.'
        ),
        icon: 'notification_important',
      });
    }
  }
  if (a === 'Denied') {
    if (r === 'rph') {
      const LastQtr = getLastQtr();
      if (!LastQtr.includes('noshow')) {
        const prospective = prospectiveReview(r, o, 'value');
        if (prospective === 'Yes'){
          GeneralModal({
            message: bold(
              `Case is a ${getNextYear()} Prospective Review:<br><p style="color: black; font-weight: normal;">Add the following verbiage to the letter template box "This letter is for a ${getNextYear()} review."</p>`
            ),
            icon: 'notification_important',
          });
        }
      }
    }
  }
  if (a === 'Dismissed') {
    if (r === 'rph') {
      const LastQtr = getLastQtr();
      if (!LastQtr.includes('noshow')) {
        const prospective = prospectiveReview(r, o, 'value');
        if (prospective === 'Yes'){
          GeneralModal({
            message: bold(
              `Case is a ${getNextYear()} Prospective Review:<br><p style="color: black; font-weight: normal;">Add the following verbiage to the letter template box for EAG and AAFNR dismissals ONLY "This letter is for a ${getNextYear()} review."</p>`
            ),
            icon: 'notification_important',
          });
        }
      }
    }
  }
  if (a === 'Approved') {
    const clientT = client(r, o, 'value');
    const rqstReason = requestReason(r, o, 'value');
    const prosReview = () => {
      const LastQtr = getLastQtr();
      if (!LastQtr.includes('noshow')) {
        const prospective = prospectiveReview(r, o, 'value');
        if (prospective === 'Yes')
          return `<br/><br/>For Prospective Review Cases, verify Auth Effective field in MHK is set to 1/1/${getNextYear()}`;
      }
      return '';
    };
    const nonFormulary =
      rqstReason === 'Non-formulary' && r === 'tech'
        ? '<br/><br/>If the case is for Repatha, review the note in the DLT. All Non-Formulary Repatha cases need to be sent to clinical for further review.'
        : '';
    if (clientT === 'EGWP' && rqstReason !== 'Tier Change') {
      GeneralModal({
        message: bold(
          `Refer to EGWP specific instructions to identify whether an override is needed on the secondary plan. Add the secondary override if directed by the EGWP specific instructions.${nonFormulary}${prosReview()}`
        ),
        icon: 'notification_important',
      });
    }
    if (clientT.includes('Clearstone') && rqstReason !== 'Tier Change') {
      GeneralModal({
        message: bold(
          `Refer to the ClearStone Client Specific Job Aid to identify if this is a ClearStone EGWP STCOB plan. Add the secondary override if directed by the Client specific instructions.${nonFormulary}${prosReview()}`
        ),
        icon: 'notification_important',
      });
    }
    if (clientT !== 'EGWP' && !clientT.includes('Clearstone') && nonFormulary) {
      GeneralModal({
        message: bold(nonFormulary.replace(/<br\s*[\/]?>/gm, '')),
        icon: 'notification_important',
      });
    }
    if (clientT !== 'EGWP' && !clientT.includes('Clearstone') && prosReview()) {
      GeneralModal({
        message: bold(prosReview().replace(/<br\s*[\/]?>/gm, '')),
        icon: 'notification_important',
      });
    }
  }
  if (a === 'Transferred to Pharmacist') {
    if(r === 'tech' && o === 'IBC') {
      GeneralModal({
        message: bold(
          'Only specific scenarios require transfer to pharmacist. Please validate against “Representatives: Handling Inbound Calls – Med D CD&A” Work Instruction before transferring.'
        ),
        icon: 'notification_important',
      });
    }
  }
}
