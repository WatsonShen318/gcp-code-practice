import DrugFlag from '../drugs/drugs';
import { client, drugName, requestReason, requestType } from '../qsets/fields';
import { toggleDisplay } from '../utils/notetool.display';

export function deniedCDClient(o, r, decision) {
  const rqstType = requestType(r, o, 'value');
  const clientVal = client(r, o, 'value');
  let status = 'disable';

  if (decision === 'Denied' && rqstType === 'CD' && clientVal !== 'SSI') {
    status = 'enable';
  }
  toggleDisplay('solo', [`${r}${o}DocHUP`], status);
}

export function deniedDrug(o, r, decision) {
  const input = drugName(r, o, 'value');
  const tag = DrugFlag(input);
  let status = 'disable';
  if (decision === 'Denied' && tag === 'Immunosuppressant') {
    status = 'enable';
  }
  toggleDisplay('solo', [`${r}${o}medBHUP`], status);
}
export function sentToRFI(o, r, decision) {
  let status = 'disable';
  if (decision === 'Sent to RFI') {
    status = 'enable';
  }
  toggleDisplay('solo', [`${r}${o}RFIFCrphVerbHUP`], status);
}

/**
 * * Only execute for RPh to display routing reminders
 * @param {string} o  origin
 * @param {string} r  role
 * @param {string} decision decision
 */

export function approvedTierChange(o, r, decision) {
  const rqstReason = requestReason(r, o, 'value');
  const isTAT = o === 'TAT';
  let status = 'disable';
  if (
    r === 'rph' &&
    decision === 'Approved' &&
    !isTAT &&
    rqstReason === 'Tier Change'
  ) {
    status = 'enable';
  }
  if (
    r === 'rph' &&
    decision === 'Approved' &&
    rqstReason !== 'Tier Change' &&
    !isTAT
  ) {
    status = 'disable';
  }
  if (!isTAT) toggleDisplay('solo', [`${r}${o}routingHUP`], status);
}
/**
 * * Execute only when decision routing is approved. Display routing reminders, references
 * @param {string} o  origin
 * @param {string} r  role
 * @param {string} decision decision
 */
export function approved(o, r, decision, workFlow) {
  let status = 'disable';
  const workFlowFromSessionData = workFlow || sessionStorage.getItem("workFlow");
  if (workFlowFromSessionData !== 'Automated' && decision === 'Approved') {
    status = 'enable';
  }
  toggleDisplay(
    'solo',
    [
      `${r}${o}overrideCheck`,
      `${r}${o}overrideCheckHUP`,
      `${r}${o}overrideEntCheck`,
      `${r}${o}overrideEntCheckHUP`,
    ],
    status
  );
}
/**
 * * Execute only when decision routing is dismissed. Display routing reminders, references
 * @param {string} o  origin
 * @param {string} r  role
 * @param {string} decision decision
 */
export function dismiss(o, r, decision) {
  const fields =
    o === 'SR'
      ? [`${r}${o}dismHUP`]
      : [`${r}${o}dismHUP`, `${r}${o}dismisschk`];
  const status = decision === 'Dismissed' ? 'enable' : 'disable';

  toggleDisplay('solo', fields, status);
}

//AMN 9/12/22 - #106: ADD New Note in tool for users when dSNP record 
/**
 * * Execute only when decision routing is denied. Display routing reminders, references
 * @param {string} o  origin
 * @param {string} r  role
 * @param {string} decision decision
 */
 export function denied(o, r, decision) {
  let status = 'disable';
  if (decision === 'Denied') {
    status = 'enable';
  }
  toggleDisplay(
    'solo',
    [
      `${r}${o}overrideDismHUP`,
    ],
    status
  );
}