import * as checks from "./decision.checks";
import * as routes from "./decision.routes";
import getInputValue from "../utils/getInputValue";
import { toggleDisplay } from "../utils/notetool.display";
import { decisionRouting, requestType } from "../qsets/fields";
import { toggleLtrPreview } from "../letterPreview/display";
import { getClientValue } from "../finalnote/components/get.values";
import { setDecisionRoutingForGLFields } from "../guidelines/guideline.display";

export function toggleChecks(o, r) {
  const fields =
    o === "SR"
      ? [`${r}${o}routingQsel`]
      : [`${r}${o}clientQsel`, `${r}${o}routingQsel`];

  const input = getInputValue("text", fields);
  const decision = input[`${r}${o}routingQsel`];
  if (o !== "TAT") {
    if (decision === "Sent to RFI") {
      toggleDisplay("solo", [`${r}${o}RFIFCrphVerbHUP`], "enable");
    } else {
      toggleDisplay("solo", [`${r}${o}RFIFCrphVerbHUP`], "disable");
    }
  }
  checks.approved(o, r, decision);
  checks.dismiss(o, r, decision);
  // AMN 9/12/22 - #106: ADD New Note in tool for users when dSNP record
  if (r === "rph") checks.denied(o, r, decision); // AMN 9/26/22 - #108, #109: Fields [Decision/Routing Rationale] and [Case Decision/Routing] not populating in PROD for Q4 testing

  if (r === "rph") {
    checks.approvedTierChange(o, r, decision);
    checks.deniedCDClient(o, r, decision);
    checks.deniedDrug(o, r, decision);
  }
}

function showRouting(o, r) {
  toggleDisplay("solo", [`${r}${o}routingQ`, `${r}${o}rationalQ`], "enable");
}

export function toggleRoutes(o, r, a) {
  const clientSel = getClientValue(r, o);
  const rqstType = requestType(r, o, "value");

  if (r === "rph" && o !== "TAT" && clientSel !== "Oscar Health (21BV)")
    routes.rphQ(o, r);
  if (r === "rph" && o === "TAT") routes.rphTAT(o, r);
  if (r === "tech" && o === "TAT") routes.techTAT(o, r);
  if (r === "rph" && o === "IBC" && clientSel === "Oscar Health (21BV)")
    routes.rphIBC(o, r);
  if (
    r === "tech" &&
    o === "IBC" &&
    rqstType === "CD" &&
    clientSel !== "Oscar Health (21BV)"
  )
    routes.techIBCcd(o, r);
  if (
    r === "tech" &&
    o === "IBC" &&
    rqstType === "RD" &&
    clientSel !== "Oscar Health (21BV)"
  )
    routes.techIBCrd(o, r);
  if (r === "tech" && o === "IBC" && clientSel === "Oscar Health (21BV)")
    routes.techIBCoscar21bv(o, r);
  if (r === "tech" && o === "SR" && a === "MA") routes.techSRma(o, r);
  if (r === "tech" && o === "SR" && a !== "MA") routes.techSRnonMA(o, r);
  if (r === "tech" && ["Queue"].includes(o) && rqstType === "CD")
    routes.techQcd(o, r);
  if (r === "tech" && ["Queue"].includes(o) && rqstType === "RD")
    routes.techQrd(o, r);

  showRouting(o, r); //* show routing

  /* Remove prefilled Case Decision/Routing if it is not there in the list */
  const routing = document.getElementById(`${r}${o}routingQsel`);
  const visibleOptions = Array.from(routing.options)
    .filter((option) => !option.disabled)
    .map((option) => option.value);

  if (!visibleOptions.includes(routing.value)) {
    routing.value = "";
  }
}

export function toggleSRRef(o, r, a) {
  switch (a) {
    case "Not found":
    case "highlighted in blue":
      toggleDisplay("solo", [`${r}${o}drHUP`], "enable");

      break;

    default:
      toggleDisplay("solo", [`${r}${o}drHUP`], "disable");
      break;
  }
}

export function setDecision(o, r, a, q) {
  const decision = decisionRouting(r, o, "element");
  if (o === "SR") {
    switch (a) {
      case "Not found":
      case "highlighted in blue":
        decision.value = "Dismissed";
        toggleChecks(o, r);
        toggleLtrPreview(o, r);
        break;

      default:
        decision.value = "";
        toggleChecks(o, r);
        toggleLtrPreview(o, r);
        break;
    }
  }
  if (o === "Queue") {
    switch (q) {
      case "POA":
        decision.value =
          a === "No" ? "Pending Appointment of Representative" : "";
        break;
      case "RequestReason":
        decision.value =
          a === "Quantity Limit" || a === "Step Therapy"
            ? "Forward to Clinical"
            : "";
        break;
      case "compendia":
        decision.value = a === "No" ? "Forward to Clinical" : "";
        break;
      default:
        decision.value = "";
        break;
    }
  }
}

export function setDecisionForRequestTypeRD(r, o, requestTypeValue) {
  if (requestTypeValue === "RD") {
    setDecisionRoutingForGLFields(r, o, "Forward to Clinical", false);
  } else if (requestTypeValue === "CD") {
    const decisionRoutingValue = decisionRouting(r, o, "value");
    if (decisionRoutingValue === "Forward to Clinical") {
      setDecisionRoutingForGLFields(r, o, "", false);
    }
  }
}
