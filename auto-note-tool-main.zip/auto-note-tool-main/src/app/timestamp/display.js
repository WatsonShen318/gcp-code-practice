import { toggleDisplay } from '../utils/notetool.display';

/**
 * Toggle reminder when Is request a RM Task? = Yes is selected
 * @param {origin} origin
 * @param {role} role
 * @param {answer} answer
 */
export function toggleRMTaskReminder(origin, role, answer) {
  const status = answer === 'Yes' ? 'enable' : 'disable';
  toggleDisplay('solo', [`${role}${origin}rmTaskHUP`], status);
}

/**
 * Disable MHK option when Is request a RM Task? = Yes is selected
 * @param {origin} origin
 * @param {role} role
 * @param {answer} answer
 */
export function disableMHKoption(origin, role, answer) {
  const status = answer === 'Yes' ? 'disable' : 'enable';
  toggleDisplay('solo', [`${role}${origin}timestampQMHK`], status);
}
