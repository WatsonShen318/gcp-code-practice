import { GeneralModal } from '../modal/alert.service';
import { bold } from '../utils/font.formatter';

export default function msgTimeStamp(o, r, a) {
  if (a === 'Yes') {
    GeneralModal({
      message: bold(
        'Verify the "Manual Received" field has been updated with the correct timestamp in MHK.<br/><br/>Ensure that the timestamp has been converted into Central Time, if needed.<br/><br/>Refer to Work Instruction Fax Time Stamp Job Aid and Timestamp Checklist.'
      ),
      icon: 'notification_important',
    });
  }
}
