import { GeneralModal } from '../modal/alert.service';
import { bold } from '../utils/font.formatter';

/**
 * $ triggered based on New Attachment question for rph TAT only
 * @param {origin} o
 * @param {role} r
 * @param {answer} a
 */
export default function msgAttachment(a) {
  if (a === 'Yes' || a === 'No') {
    GeneralModal({
      message: bold(
        'Refresh MHK Attachments tab and review for new attachments'
      ),
      icon: 'notification_important',
    });
  }
}
