import { toggleDisplay } from '../utils/notetool.display';

export default function toggleAttachment(o, r, a) {
  if (a === 'Pending Appointment of Representative') {
    toggleDisplay('solo', [`${r}${o}newAttachQ`], 'disable');
  } else {
    toggleDisplay('solo', [`${r}${o}newAttachQ`], 'enable');
  }
}
