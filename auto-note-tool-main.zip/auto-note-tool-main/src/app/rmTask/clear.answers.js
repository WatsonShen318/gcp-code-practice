import { clearInputs } from '../utils/clearInput';

/**
 * * Clear all RM Task sub question input fields to be blank
 * @param {string} origin - list of radio name or element id
 * @param {string} role - input type (ex. radio, check, text, textarea)
 */
export function clearRMTaskSubQuestions(origin, role) {
  const tag = `fieldset[data-tag="rmTask"][id*='${role}${origin}']`;
  const textFields = document.querySelectorAll(
    `${tag} input[type="text"], ${tag} textarea`
  );
  clearInputs(textFields, 'text');
}

/**
 * * Clear all RM Task related question input fields to be blank
 * @param {string} origin - list of radio name or element id
 * @param {string} role - input type (ex. radio, check, text, textarea)
 */
export function clearRMTaskRest(origin, role) {
  const fields = document.querySelectorAll(
    `fieldset[data-tag="rmTask"][id*='${role}${origin}'] input[type="radio"]:checked`
  );

  clearInputs(fields, 'radio');
  clearRMTaskSubQuestions(origin, role);
}
