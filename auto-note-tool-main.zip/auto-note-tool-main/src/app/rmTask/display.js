import { toggleRqsterInfo } from '../caller/display';
import clearEAGquestions from '../eag/clear';
import { toggleEAGAAFNRQs } from '../eag/eagAafnr.display';
import clearInquiryQuestion from '../inquiry/clear';
import { toggleInquiry } from '../inquiry/inquiry.display';
import { toggleRMPriorityReminder } from '../priority/displays';
import { disableMHKoption, toggleRMTaskReminder } from '../timestamp/display';
import { toggleDisplay } from '../utils/notetool.display';

/**
 * Toggle Is request a RM Task question when Is the call being transferred to you from a CARE agent? = No is selected
 * @param {origin} origin
 * @param {role} role
 * @param {answer} answer
 */
export function toggleRMtask(origin, role, answer) {
  const status = answer === 'No' ? 'enable' : 'disable';
  toggleDisplay('solo', [`${role}${origin}rmTaskQ`], status);
}

/**
 * Toggle RM Task ID sub question when Is request a RM Task? = Yes is selected
 * @param {origin} origin
 * @param {role} role
 * @param {answer} answer
 */
export function toggleRMtaskID(origin, role, answer) {
  const status = answer === 'Yes' ? 'enable' : 'disable';
  toggleDisplay('solo', [`${role}${origin}rmTaskIDQ`], status);
}

/**
 * Toggle RM Task Notes sub question when Is request a RM Task? = Yes is selected
 * @param {origin} origin
 * @param {role} role
 * @param {answer} answer
 */
export function toggleRMtaskNotes(origin, role, answer) {
  const status = answer === 'Yes' ? 'enable' : 'disable';
  toggleDisplay('solo', [`${role}${origin}rmTaskNotesQ`], status);
}

/**
 * Hide all RM Task related questions when Is the call being transferred to you from a CARE agent? = Yes is selected
 *
 * 1. Click No radio button for Is request a RM Task question to toggle questions
 *    - Hide Reminder for TimeStamp
 *    - Enable to display sub questions for Requested by = Member
 *    - Show Is this an Inquiry ONLY question
 *    - Show CVS ONLY (non CVS select N/A below) Per the test claim guidelines is this an Exception already granted (EAG) case question
 * 2. Hide all RM Task related questions
 * @param {origin} origin
 * @param {role} role
 * @param {answer} answer
 */
export function hideRMTaskQuestions(origin, role, answer) {
  if (answer === 'Yes') {
    const rmTaskNo = document.getElementById(`${role}${origin}rmTaskQNo`);
    rmTaskNo.click();
    toggleRMtaskID(origin, role, 'hide');
    toggleRMtaskNotes(origin, role, 'hide');
    toggleRMTaskReminder(origin, role, 'hide');
    toggleRqsterInfo(origin, role, 'show');
    toggleRMPriorityReminder(origin, role, 'hide');
    toggleInquiry(origin, role, 'No');
    toggleEAGAAFNRQs(origin, role, 'No');
    clearInquiryQuestion(origin, role);
    clearEAGquestions(origin, role);
    disableMHKoption(origin, role, 'enable');
  }
}
