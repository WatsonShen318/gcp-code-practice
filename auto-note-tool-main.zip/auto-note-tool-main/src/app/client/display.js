import { toggleAllClaimQs } from '../claim/claim.display';
import { toggleDisplay } from '../utils/notetool.display';
import * as client from './modules';
import * as origins from '../origin/modules';
import { getValue } from '../utils/getInputValue';

export function toggleRestrict(o, r, a) {
  const status =
    client.isHMSA(a) || client.isPacificSource(a) ? 'enable' : 'disable';
  toggleDisplay('solo', [`${r}${o}restrictC`], status);
}
export function toggleNoforRDHeadsup(o, r, a) {
  if (origins.isQ(o) || origins.isIBC(o)) {
    // AMN 12/8/22 - December 2022 Enhancement - #112: Client Drop Down Updates
    /*  
      const status =
      a === 'Community Care of Oklahoma (CCOK)' ||
      a === 'MMMFlorida' ||
      a === 'KelseyCare'
        ? 'enable'
        : 'disable'; 
    */
    const status =
      a === 'Community Care of Oklahoma (CCOK)' || a === 'MMM Florida' || a === 'Christus Health'
        ? 'enable'
        : 'disable';
    toggleDisplay('solo', [`${r}${o}noForRDHUP`], status);
  }
}

export function toggleClientName(o, r, a) {
  const status = client.isEGWP(a) || client.isOther(a) ? 'enable' : 'disable';
  toggleDisplay('solo', [`${r}${o}subegwpQ`], status);

  // AMN 12/8/22 - December 2022 Enhancement - #112: Client Drop Down Updates
  const bcbsStatus = client.isBCBS(a) ? 'enable' : 'disable';
  toggleDisplay('solo', [`${r}${o}bcbsHUP`], bcbsStatus);

  if (!origins.isTAT(o)) {
    //! HHM 07/14/2023: This shouldn't run for RPH TAT. Added this.
    // AMN 8/10/22 - #102: New Formulary ID Free Form Text Field for Aenta MAPD Plans
    const isAetnaClient = client.isAetna(a) ? 'enable' : 'disable';
    toggleDisplay('solo', [`${r}${o}subFormularyIDQ`], isAetnaClient);
  }

  // AMN 1/3/23 - January 2023 Enhancement - #114: Remove Question 'Is there a denied case on the member's profile in 2022?'
  // const isAetnaMAPD = client.isAetna(a) ? 'disable' : 'enable';
  // toggleDisplay('solo', [`${r}${o}memberDeniedCaseQ`], isAetnaMAPD);
}

/**
 * * Toggle Red Reminder/Gray guide blocks when client is selected in the drop down
 * @param {array} array - list of fields
 * @param {string} origin - origin
 * @param {string} role - role
 */

export function toggleClientHeadsup(o, r, a) {
  let status = null;

  // CAN 2/22/23 - Feb 2023 Enhancement - #116: Client drop down update for HealthFirst
  status = client.isHealthFirst(a) ? 'enable' : 'disable';
  toggleDisplay('solo', [`${r}${o}healthFirstHUP`], status);

  status = client.isNHPRI(a) ? 'enable' : 'disable';
  toggleDisplay('solo', [`${r}${o}nhpriHUP`], status);

  status = client.isCCOK(a) ? 'enable' : 'disable';
  toggleDisplay('solo', [`${r}${o}ccokHUP`], status);

  status = client.isKelseyCare(a) ? 'enable' : 'disable';
  toggleDisplay('solo', [`${r}${o}kelseyCareHUP`], status);

  // AMN 8/8/23 - August 2023 Enhancements - #127: Add red alert message when [Client]=Sharp Health
  status = client.isSharpHealth(a) ? 'enable' : 'disable';
  toggleDisplay('solo', [`${r}${o}sharpHealthHUP`], status);

  // AMN 12/8/22 - December 2022 Enhancement - #112: Client Drop Down Updates
  status = client.isBCBS(a) ? 'enable' : 'disable';
  toggleDisplay('solo', [`${r}${o}bcbsHUP`], status);

  if (!origins.isTAT(o)) {
    status = client.isEGWP(a) ? 'enable' : 'disable';
    toggleDisplay('solo', [`${r}${o}egwpOtherHUP`], status);

    status = client.isPacificSource(a) ? 'enable' : 'disable';
    toggleDisplay('solo', [`${r}${o}pacificSourceHUP`], status);

    status = client.isDevoted(a) ? 'enable' : 'disable';
    toggleDisplay('solo', [`${r}${o}devoteddSNPHUP`], status);
  }

  if (origins.isQ(o) || origins.isTAT(o)) {
    status = client.isFep(a) ? 'enable' : 'disable';
    toggleDisplay('solo', [`${r}${o}fepHUP`], status);
  }

  if (origins.isQ(o)) {
    status = client.isClearStone(a) ? 'enable' : 'disable';
    toggleDisplay('solo', [`${r}${o}cStoneHUP`], status);
  }
  if (origins.isIBC(o)) {
    status = client.isHMSA(a) ? 'enable' : 'disable';
    toggleDisplay('solo', [`${r}${o}hmsatechHUP`], status);

    status = client.isFep(a) ? 'enable' : 'disable';
    toggleDisplay('solo', [`${r}${o}ibcFepHUP`], status);

    if (r === 'tech') {
      status = a === 'Paramount' ? 'enable' : 'disable';
      toggleDisplay('solo', [`${r}${o}paramountHUP`], status);
    }
  }
}

export function toggleNoDecision(o, r, a) {
  const status = client.isSharp(a) || client.isNHPRI(a)
    ? 'enable'
    : 'disable';
  toggleDisplay('solo', [`${r}${o}noDecisionHUP`], status);
}

export function toggleNameTxt(o, r, a) {
  const status =
    a === 'Not found' || a === 'highlighted in blue' ? 'disable' : 'enable';
  toggleDisplay('solo', [`${r}${o}clientKeyinQ`], status);
}

// Uneeded because Oscar Health has termed - 3/11/2024 Leaving incase they need to be re-added later
// export function toggleClients(o, r) {
//   const status = origins.isIBC(o) ? 'enable' : 'disable';
//   if (!origins.isSR(o))
//     toggleDisplay('solo', [`${r}${o}oscarHealth21BV`], status);
// }

/**
 * * Filter out a field from provided array if is RM task
 * @param {array} array - list of fields
 * @param {string} filterField - specific field you want to filter out
 * @param {string} origin - origin
 * @param {string} role - role
 */
const filterArray = (array, filterField, origin, role) => {
  const isRMTask = getValue('radio', `${role}${origin}rmTaskQrdo`);
  let ff = [];
  if (isRMTask) {
    ff = array.filter((d) => d !== filterField);
  } else {
    ff = array;
  }
  return ff;
};

//* Toggle multiple fields when Oscar Health (21BV) is selected

function toggleMultiFieldsTech(origin, role, status) {
  const fields = [
    `${role}${origin}eagQ`,
    // `${role}${origin}memberDeniedCaseQ`, //AMN 1/3/23 - January 2023 Enhancement - #114: Remove Question 'Is there a denied case on the member's profile in 2022?'
    `${role}${origin}rqstTypeDeniedQ`,
    `${role}${origin}tierRqstQ`,
    `${role}${origin}guidelineQ`,
    `${role}${origin}subguidelineQ`,
    `${role}${origin}newAttachQ`,
    `${role}${origin}diagnosisQ`,
    `${role}${origin}treidFailQ`,
    `${role}${origin}approveDiagoQ`,
  ];
  const fieldList = filterArray(fields, `${role}${origin}eagQ`, origin, role);

  toggleDisplay('solo', fieldList, status);
}

function toggleMultiFieldsRph(origin, role, status) {
  toggleDisplay(
    'solo',
    [`${role}${origin}approveDiagoQ`, `${role}${origin}spprSatementQ`],
    status
  );
}

function toggleMultiFieldsCommon(origin, role, status) {
  const fields = [
    `${role}${origin}inquiryQ`,
    `${role}${origin}tierRqstQ`,
    `${role}${origin}matchCaseQ`,
    `${role}${origin}outboundQ`,
    `${role}${origin}outboundQalt`,
    `${role}${origin}newAttachQ`,
    `${role}${origin}diagnosisQ`,
  ];
  const fieldList = filterArray(
    fields,
    `${role}${origin}inquiryQ`,
    origin,
    role
  );

  toggleDisplay('solo', fieldList, status);
  toggleAllClaimQs(origin, role, status);
}

/**
 * * Toggle multiple fields when Oscar Health (21BV) is selected
 * @param {origin} origin
 * @param {role} role
 * @param {answer} answer
 */
// export function toggleMultiFieldsOscar21BV(origin, role, answer) {
//   const status =
//     origins.isIBC(origin) && client.isOscar21BV(answer) ? 'disable' : 'enable';
//   toggleMultiFieldsCommon(origin, role, status);
//   if (role === 'tech') toggleMultiFieldsTech(origin, role, status);
//   if (role === 'rph') toggleMultiFieldsRph(origin, role, status);
// }