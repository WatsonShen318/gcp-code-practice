export const isEGWP = (answer) => {
  const output = answer === 'EGWP';
  return output;
};
export const isAetna = (answer) => {
  const output = answer === 'Aetna MAPD';
  return output;
};
export const isNHPRI = (answer) => {
  const output = answer === 'Neighborhood Health Plan Rhode Island';
  return output;
};
export const isOther = (answer) => {
  const output = answer === 'Other';
  return output;
};
export const isCCOK = (answer) => {
  const output = answer === 'Community Care of Oklahoma (CCOK)';
  return output;
};
export const isMMMFlorida = (answer) => {
  const output = answer === 'MMMFlorida';
  return output;
};
export const isHMSA = (answer) => {
  const output = answer === 'HMSA';
  return output;
};
export const isPacificSource = (answer) => {
  const output = answer === 'Pacific Source';
  return output;
};
export const isDevoted = (answer) => {
  const output = answer === 'Devoted Health dSNP';
  return output;
};
//TODO: oscar
// export const isOscar = (answer) => {
//   const output = answer === 'Oscar Health';
//   return output;
// };
// export const isOscar21BV = (answer) => {
//   const output = answer === 'Oscar Health (21BV)';
//   return output;
// };
//
export const isClearStone = (answer) => {
  const output = answer === 'Clearstone';
  return output;
};
export const isSharp = (answer) => {
  const output = answer === 'Sharp Health Plan';
  return output;
};
export const isFep = (answer) => {
  const output = answer === 'FEP';
  return output;
}

// AMN 12/8/22 - December 2022 Enhancement - #112: Client Drop Down Updates
export const isBCBS = (answer) => {
  const output = answer === 'BCBS Of MASS';
  return output;
};
// CAN 2/22/23 - Feb 2023 Enhancement - #116: Client drop down update for HealthFirst
export const isHealthFirst = (answer) => {
  const output = answer === 'Healthfirst';
  return output;
};

export const isKelseyCare = (answer) => {
  const output = answer === 'KelseyCare';
  return output;
};

// AMN 8/8/23 - August 2023 Enhancements - #127: Add red alert message when [Client]=Sharp Health
export const isSharpHealth = (answer) => {
  const output = answer === 'Sharp Health Plan';
  return output;
};

export const isAetnaSSIPDP = (answer) => answer === 'Aetna SSI PDP';