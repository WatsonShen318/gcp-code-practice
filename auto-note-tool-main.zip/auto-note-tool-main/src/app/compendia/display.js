import getInputValue from '../utils/getInputValue';
import { toggleDisplay } from '../utils/notetool.display';

export function toggleCompendiaRef(o, r, a) {
  if (a !== 'N/A') {
    toggleDisplay('solo', [`${r}${o}subcompendiaRefsQ`], 'enable');
  } else {
    toggleDisplay('solo', [`${r}${o}subcompendiaRefsQ`], 'disable');
  }
}

export function toggleDrugdex(o, r) {
  const rdo = getInputValue('radio', [`${r}${o}approveDiagoQrdo`]);
  const checked = document.querySelectorAll(
    `input[id*=${r}${o}subcompendiaRefsQ][value*="Drugdex"][type="checkbox"]:checked`
  );

  if (checked.length > 0 && rdo[`${r}${o}approveDiagoQrdo`] === 'No') {
    toggleDisplay('solo', [`${r}${o}subcompendiaRefsDdexQ`], 'enable');
  } else {
    toggleDisplay('solo', [`${r}${o}subcompendiaRefsDdexQ`], 'disable');
  }
}

export function hideallCompendia(o, r) {
  if (r === 'rph') {
    toggleDisplay(
      'solo',
      [`${r}${o}subcompendiaRefsQ`, `${r}${o}subcompendiaRefsDdexQ`],
      'disable'
    );
  }
}
