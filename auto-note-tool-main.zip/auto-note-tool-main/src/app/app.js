// import ShowNote from './utils/inputs-are-valid';
import axios from 'axios';
import checkAuthentication from './auth';
import ShowFinalNote from './buttons/buttons';
// Required for cross-site cookie (session on .cvshealth.com, frontend on .aetna.com)
axios.defaults.withCredentials = true;

// Helper to get query params
function getQueryParams() {
  return Object.fromEntries(new URLSearchParams(window.location.search));
}

const queryParams = getQueryParams();
const skipAuthentication = queryParams.skipAuthentication === 'true';

// Check for authentication after page render
document.addEventListener('DOMContentLoaded', () => {
  if(!skipAuthentication) {
    checkAuthentication(1);
  }
});

ShowFinalNote();
window.onload = () => {
  import(
    /* webpackPrefetch: true */ /* webpackChunkName: "userData" */ './user/user.data'
  ).then((module) => {
    module.ReturnToSession();
    module.RoleChange();
  });
  import(
    /* webpackPrefetch: true */ /* webpackChunkName: "modalClose" */ './modal/alert.service'
  ).then((module) => {
    module.closeModal();
  });

  import(
    /* webpackPrefetch: true */ /* webpackChunkName: "intake" */ './intake/intake'
  );
  import(
    /* webpackPrefetch: true */ /* webpackChunkName: "tech" */ './tech/tech'
  );
  import(/* webpackPrefetch: true */ /* webpackChunkName: "rph" */ './rph/rph');

  import(
    /* webpackPrefetch: true */ /* webpackChunkName: "resetNote" */ './reset/notetool.reset'
  ).then((module) => {
    module.default();
  });

  import(
    /* webpackPrefetch: true */ /* webpackChunkName: "intakeNextCase" */ './buttons/buttons'
  ).then((module) => {
    module.intakeNextCase();
  });

  import(
    /* webpackPrefetch: true */ /* webpackChunkName: "inputUtil" */ './utils/input-format'
  ).then((module) => {
    module.default();
  });
};
