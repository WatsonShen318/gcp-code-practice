import { copy } from '../../data/filterData';

const drug = require('./drugs.json');

export default function DrugFlag(str) {
  const t = drug.list
    .map(copy)
    .filter((o) => o.drug.toLowerCase().includes(str.toLowerCase()));
  if (t.length > 0) {
    const { tag } = t[0];
    return tag;
  }
}

export function isHIVDrug(drugInput) {
  const potentialHIVMedicationDrugs = ["descovy", "truvada", "apretude", "emtricitabine", "tenofovir disoproxil fumarate"];
  for (const potentialHIVMedicationDrugKeyword of potentialHIVMedicationDrugs) {
    if(drugInput?.toLowerCase()?.includes(potentialHIVMedicationDrugKeyword)) {
      return true;
    }
  }

  return false;
}
