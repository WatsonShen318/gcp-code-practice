import DrugFlag, { isHIVDrug } from './drugs';
import { toggleDisplay } from '../utils/notetool.display';

export function toggleSmartMed(o, r, a) {
  const tag = DrugFlag(a);
  //AMN 5/16/23 - May 2023 Enhancements - #125: Add red note for drug name field
  const isAetna = document.getElementById(`${r}${o}clientQsel`);
  const clientName = isAetna?.options[isAetna.selectedIndex]?.text;

  if (tag === 'Smart') {
    toggleDisplay('solo', [`${r}${o}drugHUP`], 'enable');
    toggleDisplay('solo', [`${r}${o}drugHUP_MedHOK`], 'disable');
    toggleDisplay('solo', [`${r}${o}drugSpecial`], 'disable'); //AMN 5/16/23 - May 2023 Enhancements - #125: Add red note for drug name field
  }
  else if (tag === 'MedHOK') {
    toggleDisplay('solo', [`${r}${o}drugHUP`], 'disable');
    toggleDisplay('solo', [`${r}${o}drugHUP_MedHOK`], 'enable');
    toggleDisplay('solo', [`${r}${o}drugSpecial`], 'disable'); //AMN 5/16/23 - May 2023 Enhancements - #125: Add red note for drug name field
  }
  else if (tag === 'Special' && clientName === 'Aetna MAPD') { //AMN 5/16/23 - May 2023 Enhancements - #125: Add red note for drug name field
    toggleDisplay('solo', [`${r}${o}drugSpecial`], 'enable');
    toggleDisplay('solo', [`${r}${o}drugHUP`], 'disable')
    toggleDisplay('solo', [`${r}${o}drugHUP_MedHOK`], 'disable');
  }
  else {
    toggleDisplay('solo', [`${r}${o}drugHUP`], 'disable');
    toggleDisplay('solo', [`${r}${o}drugHUP_MedHOK`], 'disable');
    toggleDisplay('solo', [`${r}${o}drugSpecial`], 'disable'); //AMN 5/16/23 - May 2023 Enhancements - #125: Add red note for drug name field
  }
}

// Change Request for Descovy, Truvada, Apretude or Emtricitabine and Tenofovir disoproxil fumarate drugs
// Change Summary: When Descovy, Truvada, Apretude or Emtricitabine and Tenofovir disoproxil fumarate are entered in the Drug Name field
// display a note indicating “Potential HIV PrEP medication – Refer to: APRETUDE, DESCOVY, & TRUVADA (emtricitabine and tenofovir disoproxil fumarate) – Med D CD&A”
export function toggleHIVMed(o, r, a) {
  if(isHIVDrug(a)) {
    toggleDisplay('solo', [`${r}${o}drugHIV`], 'enable');
  } else {
    toggleDisplay('solo', [`${r}${o}drugHIV`], 'disable');
  }
}

export function toggleDurgQs(o, r, a) {
  switch (a) {
    case 'Not found':
    case 'highlighted in blue':
      toggleDisplay(
        'solo',
        [`${r}${o}drugNameQ`, `${r}${o}qtyDSQ`, `${r}${o}diagnosisQ`],
        'disable'
      );

      break;

    default:
      toggleDisplay(
        'solo',
        [`${r}${o}drugNameQ`, `${r}${o}qtyDSQ`, `${r}${o}diagnosisQ`],
        'enable'
      );
      break;
  }
}
