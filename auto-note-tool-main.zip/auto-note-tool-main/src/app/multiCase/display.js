import getInputValue from '../utils/getInputValue';
import { toggleDisplay } from '../utils/notetool.display';

export function toggleCaseCount(o, r, a) {
  if (a === 'Yes') {
    toggleDisplay('solo', [`${r}${o}submemberCaseCountQ`], 'enable');
  } else {
    toggleDisplay('solo', [`${r}${o}submemberCaseCountQ`], 'disable');
  }
}

export function toggleMultiDrugRqst() {
  const rdo = getInputValue('radio', ['imempplsafeQrdo', 'iRqstTypeQrdo']);
  if (
    rdo.imempplsafeQrdo === 'No' ||
    rdo.iRqstTypeQrdo === 'Re-route' ||
    rdo.iRqstTypeQrdo === 'Forward Fax' ||
    rdo.iRqstTypeQrdo === 'Secondary Review'
  ) {
    toggleDisplay('solo', ['iMultirqstQ'], 'disable');
  } else if (
    rdo.imempplsafeQrdo !== 'No' ||
    rdo.iRqstTypeQrdo !== 'Re-route' ||
    rdo.iRqstTypeQrdo !== 'Forward Fax' ||
    rdo.iRqstTypeQrdo !== 'Secondary Review'
  ) {
    toggleDisplay('solo', ['iMultirqstQ'], 'enable');
  }
}

export function toggleMultiRqstDetail(MultiRqst) {
  if (MultiRqst === 'Yes') {
    toggleDisplay('solo', ['subiMultirqstQ', 'subiRqstReasonQ'], 'enable');
  } else {
    toggleDisplay('solo', ['subiMultirqstQ', 'subiRqstReasonQ'], 'disable');
  }
}
