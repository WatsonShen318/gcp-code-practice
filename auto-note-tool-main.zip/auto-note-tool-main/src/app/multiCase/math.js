import { memberCaseCount, memberRqstTotalCount } from '../qsets/fields';
import getInputValue from '../utils/getInputValue';

let txt;

function caseCount(CaseCount, Total, hiddenFieldID) {
  const balance = Total - CaseCount;
  const hiddenField = document.getElementById(hiddenFieldID);
  hiddenField.value = balance;
}

export function MultiCaseBalance(a) {
  const totalCountEl = document.getElementById('multiRqstCaseTotaltxt');
  txt = getInputValue('text', ['multiCaseCounttxt', 'multiRqstCaseTotaltxt']);
  const countCase = txt.multiCaseCounttxt;
  const totalCount = txt.multiRqstCaseTotaltxt;
  const balance = totalCount - countCase;
  if (balance < 0) {
    totalCountEl.setCustomValidity(
      'Total Count of Cases can not be less than current count'
    );
    totalCountEl.reportValidity();
  } else {
    totalCountEl.setCustomValidity('');
    caseCount(countCase, a, 'subiMultirqstQhidden');
  }
}

export function MultiCaseBalIncrement() {
  txt = getInputValue('text', ['multiRqstCaseTotaltxt']);
  const CaseCount = document.getElementById('multiCaseCounttxt');
  const totalCount = txt.multiRqstCaseTotaltxt;

  const convertCount = Number(CaseCount.value) + 1;
  CaseCount.value = convertCount;
  caseCount(convertCount, totalCount, 'subiMultirqstQhidden');
}

export function memberCaseBalance(origin, role, a) {
  const totalCountEl = memberRqstTotalCount(role, origin, 'element');
  const totalCount = memberRqstTotalCount(role, origin, 'value');
  const countCase = memberCaseCount(role, origin, 'value');
  const balance = totalCount - countCase;
  if (balance < 0) {
    totalCountEl.setCustomValidity(
      'Total Count of Cases can not be less than current count'
    );
    totalCountEl.reportValidity();
  } else {
    totalCountEl.setCustomValidity('');
    caseCount(countCase, a, `${role}${origin}submemberCaseCountQhidden`);
  }
}

export function memberCaseIncrement(origin, role) {
  const CaseCount = document.getElementById(`${role}${origin}caseCounttxt`);
  const totalCount = memberRqstTotalCount(role, origin, 'value');
  const convertCount = Number(CaseCount.value) + 1;
  CaseCount.value = convertCount;
  caseCount(
    convertCount,
    totalCount,
    `${role}${origin}submemberCaseCountQhidden`
  );
}
