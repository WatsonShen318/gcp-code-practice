import { toggleDisplay } from '../utils/notetool.display';

export function catputreAnswers(origin, role) {
  const tag = `[data-tag="multiCase"][id*="${role}${origin}"]`;
  const fields = document.querySelectorAll(
    `${tag} input[type="radio"]:checked, ${tag} input[type="checkbox"]:checked, ${tag} input[type="text"], ${tag} textarea, ${tag} select`
  );

  const cc = [].map.call(fields, ({ id, value, type }) => ({
    field: id,
    answer: value,
    inputType: type,
    isQuestionVisible: document
      .getElementById(id)
      .parentNode.closest('fieldset').disabled,
    question: document.getElementById(id).parentNode.closest('fieldset').id,
  }));
  return cc;
}

export function carryOvers(fields) {
  const cc = fields;

  cc.forEach((g) => {
    if (
      g.inputType === 'select-one' ||
      g.inputType === 'text' ||
      g.inputType === 'textarea'
    ) {
      document.getElementById(g.field).value = g.answer;
    }
    if (g.inputType === 'checkbox' || g.inputType === 'radio') {
      document.getElementById(g.field).checked = true;
    }
  });

  cc.forEach((g) => {
    if (!g.isQuestionVisible) toggleDisplay('solo', [g.question], 'enable');
  });
}
