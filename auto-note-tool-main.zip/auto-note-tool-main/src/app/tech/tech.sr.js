import { rdoBtn, ele } from '../utils/inputSelect';
import { toggleNameTxt } from '../client/display';
import { toggleDurgQs } from '../drugs/drugs.display';
import { clearLetterPreview, clearMember, clearValidatedMember } from '../reset/reset';
import { setClientNA } from '../utils/automation';
import {
  toggleChecks,
  toggleRoutes,
  toggleSRRef,
  setDecision,
} from '../decision/decision.display';
import {
  toggleDrugeRef,
  toggleRqstReasonQ,
} from '../requestReason/requestReason.display';
import { toggleLtrPreview, toggleLtrPreviewNA } from '../letterPreview/display';
import { toggleOutbound } from '../outbound/outbound.display';
import { toggleAllMemeberChecks } from '../member/member.display';
import msgMemberIDMHK from '../member/member.dialogs';
import toggleMDInfo from '../medicalDirector/mdoInfo.display';
import toggleRqstBy from '../requestBy/display';
import toggleCaseVeri from '../utils/caseVerified.display';
import toggleRobotic from '../utils/robotic.display';
import msgRqstReason from '../requestReason/requestReason.dialogs';
import common from '../shared/common';
import { caseIdInputHandler } from '../prefill/caseIdHandler';

let answer = null;
const role = 'tech';
const origin = 'SR';

common(role, origin);

//* Was the member found with at least 3 identifiers in MHK?
rdoBtn(`${role}${origin}memberQ`).forEach((elem) => {
  elem.addEventListener('click', (e) => {
    answer = e.target.value;
    toggleAllMemeberChecks(origin, role, answer);
    msgMemberIDMHK(answer);
    clearMember(origin, role);
    clearValidatedMember(origin, role);
    toggleNameTxt(origin, role, answer);
    // toggleMDInfo(origin, role, answer);
    // toggleRqstBy(origin, role, answer);
    // toggleCaseVeri(origin, role, answer);
    toggleDurgQs(origin, role, answer);
    // toggleRobotic(origin, role, answer);
    toggleRqstReasonQ(origin, role, answer);
    toggleSRRef(origin, role, answer);
    setDecision(origin, role, answer);
    toggleRoutes(origin, role, answer);
    toggleOutbound(origin, role, answer);
  });
});

//* client Name Text Box
ele(`${role}${origin}clientKeyinQ`, 'txt').addEventListener('change', (e) => {
  answer = e.target.value;
});
ele(`${role}${origin}clientKeyinQ`, 'btn').addEventListener('click', () => {
  setClientNA(origin, role);
});

//* Case Decision/Routing
ele(`${role}${origin}routingQ`, 'sel').addEventListener('change', (e) => {
  answer = e.target.value;
  clearLetterPreview(origin, role);
  toggleChecks(origin, role);
  toggleLtrPreview(origin, role);
  toggleLtrPreviewNA(origin, role, answer);
});

//* Request Reason
ele(`${role}${origin}rqstReasonQ`, 'sel').addEventListener('change', (e) => {
  answer = e.target.value;
  toggleDrugeRef(origin, role, answer);
  msgRqstReason(role, answer);
});

// caseId handler for caseId validation and conditionally display questions
caseIdInputHandler(role, origin);
