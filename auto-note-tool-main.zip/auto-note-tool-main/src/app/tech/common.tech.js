import { setTriedFailNA } from "../utils/automation";
import {
  callerProvidedClinicalInfo,
  clinicalCallerProvidedSpprtStmt,
  dltShow0TFAlts,
  drugFromPhysicianStock,
  guideline,
  guidelineBtn,
  infectionIsDrugRstnt,
  insulinPumpMedication,
  // isCallerPrescriberOrMember,
  licsAndROA,
  medicationGreaterThan7DaySupply,
  memberIsStableOnRqstDrug,
  memberTakingPlavix,
  oralChemotherapyUsedForCancer,
  oralChemotherapyUsedForSameIndication,
  patientIsStableOnRqstDrug,
  patientIsTakingNStableOnRqstDrug,
  prescriberIndicatedApprovedDosesIneffective,
  prescriberIndicatedApprovedFormularyQuantityLimitIneffective,
  prescriberIndicatedFormAltsLessEff,
  typeOfQlReview,
  prescriberIndicatedFormAltsProduceAdvAffects,
  prescriberProvidedSpprtStmt,
  rejectWithA6,
  requestDenied,
  triedExclOmprzlOrEsmprzl,
  triedFailbtn,
  triedNFailedFormAlts,
} from "../qsets/fields";
import {
  guidelines,
  toggleCDRDGrid,
  toggleGL,
} from "../guidelines/guideline.display";
import { handleCallerProvidedClinicalInfo, handleClinicalCallerProvidedSpprtStmt, handleDltShow0TFAlts, handleDrugFromPhysicianStock, handleInfectionIsDrugRstnt, handleInsulinPumpMedication, handleLicsAndROA, handleMedicationGreaterThan7DaySupply, handleMemberIsStableOnRqstDrug, handleMemberTakingPlavix, handleOralChemotherapyUsedForCancer, handleOralChemotherapyUsedForSameIndication, handlePatientIsStableOnRqstDrug, handlePatientIsTakingNStableOnRqstDrug, handlePrescriberIndicatedApprovedDosesIneffective, handlePrescriberIndicatedApprovedFormularyQuantityLimitIneffective, handlePrescriberIndicatedFormAltsLessEff, handlePrescriberIndicatedFormAltsProduceAdvAffects, handlePrescriberProvidedSpprtStmt, handleRejectWithA6, handleTriedExclOmprzlOrEsmprzl, handleTriedNFailedFormAlts, handleTypeOfQlReview } from "../dlt_guidelines/dlt_guideline.display";
import BvDListeners from "../dlt_guidelines/bvd/listeners";

let answer = null;

export default function commonTech(origin, role) {
  //* Guideline Selection
  guideline(role, origin, "event").addEventListener("change", (e) => {
    answer = e.target.value;
    toggleGL(answer);
    guidelines(origin, role, answer);
  });
  //* Guideline Button
  guidelineBtn(role, origin, "event").addEventListener("click", () => {
    toggleGL(guideline(role, origin, "value"));
    guidelines(origin, role, answer);
  });

  //* Tried and Failed Mediciations and/or Strengths */
  triedFailbtn(role, origin, "event")?.addEventListener("click", () => {
    setTriedFailNA(origin, role);
  });

  //* Is there a denied case on the memeber's profile in the past 60 days (CDRD)
  requestDenied(role, origin, "event").forEach((elem) => {
    elem.addEventListener("click", (e) => {
      answer = e.target.value;
      toggleCDRDGrid(answer);
      guidelines(origin, role, answer);
    });
  });


  /* DLT Guideline Fields */
  licsAndROA(role, origin, "event").forEach((elem) => {
    elem.addEventListener("click", (e) => {
      answer = e.target.value;
      handleLicsAndROA(role, origin, answer);
    });
  });

  rejectWithA6(role, origin, "event").forEach((elem) => {
    elem.addEventListener("click", (e) => {
      answer = e.target.value;
      handleRejectWithA6(role, origin, answer);
    });
  });

  drugFromPhysicianStock(role, origin, "event").forEach((elem) => {
    elem.addEventListener("click", (e) => {
      answer = e.target.value;
      handleDrugFromPhysicianStock(role, origin, answer);
    });
  });

  insulinPumpMedication(role, origin, "event").forEach((elem) => {
    elem.addEventListener("click", (e) => {
      answer = e.target.value;
      handleInsulinPumpMedication(role, origin, answer);
    });
  });

  if (origin === "IBC") {
    // reviewed
    // isCallerPrescriberOrMember(role, origin, "event")?.forEach((elem) => {
    //   elem.addEventListener("click", (e) => {
    //     answer = e.target.value;
    //     handleIsCallerPrescriberOrMember(role, origin, answer);
    //   });
    // });

    // reviewed
    callerProvidedClinicalInfo(role, origin, "event")?.forEach((elem) => {
      elem.addEventListener("click", (e) => {
        answer = e.target.value;
        handleCallerProvidedClinicalInfo(role, origin, answer);
      });
    });

    // reviewed
    clinicalCallerProvidedSpprtStmt(role, origin, "event").forEach((elem) => {
      elem.addEventListener("click", (e) => {
        answer = e.target.value;
        // placeholder helper for future logic
        handleClinicalCallerProvidedSpprtStmt(role, origin, answer);
      });
    });
  }

  dltShow0TFAlts(role, origin, "event").forEach((elem) => {
    elem.addEventListener("click", (e) => {
      answer = e.target.value;
      // placeholder helper for future logic
      handleDltShow0TFAlts(role, origin, answer);
    });
  });

  prescriberProvidedSpprtStmt(role, origin, "event").forEach((elem) => {
    elem.addEventListener("click", (e) => {
      answer = e.target.value;
      // placeholder helper for future logic
      handlePrescriberProvidedSpprtStmt(role, origin, answer);
    });
  });

  patientIsStableOnRqstDrug(role, origin, "event").forEach((elem) => {
    elem.addEventListener("click", (e) => {
      answer = e.target.value;
      handlePatientIsStableOnRqstDrug(role, origin, answer);
    });
  });

  memberTakingPlavix(role, origin, "event").forEach((elem) => {
    elem.addEventListener("click", (e) => {
      answer = e.target.value;
      // If yes, continue to question 11. If no, skip to question 12.
      handleMemberTakingPlavix(role, origin, answer);
    });
  });

  triedExclOmprzlOrEsmprzl(role, origin, "event").forEach((elem) => {
    elem.addEventListener("click", (e) => {
      answer = e.target.value;
      handleTriedExclOmprzlOrEsmprzl(role, origin, answer);
    });
  });

  memberIsStableOnRqstDrug(role, origin, "event").forEach((elem) => {
    elem.addEventListener("click", (e) => {
      answer = e.target.value;
      handleMemberIsStableOnRqstDrug(role, origin, answer);
    });
  });

  infectionIsDrugRstnt(role, origin, "event").forEach((elem) => {
    elem.addEventListener("click", (e) => {
      answer = e.target.value;
      handleInfectionIsDrugRstnt(role, origin, answer);
    });
  });

  medicationGreaterThan7DaySupply(role, origin, "event").forEach((elem) => {
    elem.addEventListener("click", (e) => {
      answer = e.target.value;
      handleMedicationGreaterThan7DaySupply(role, origin, answer);
    });
  });

  oralChemotherapyUsedForCancer(role, origin, "event").forEach((elem) => {
    elem.addEventListener("click", (e) => {
      answer = e.target.value;
      handleOralChemotherapyUsedForCancer(role, origin, answer);
    });
  });

  oralChemotherapyUsedForSameIndication(role, origin, "event").forEach((elem) => {
    elem.addEventListener("click", (e) => {
      answer = e.target.value;
      handleOralChemotherapyUsedForSameIndication(role, origin, answer);
    });
  });

  patientIsTakingNStableOnRqstDrug(role, origin, "event").forEach((elem) => {
    elem.addEventListener("click", (e) => {
      answer = e.target.value;
      handlePatientIsTakingNStableOnRqstDrug(role, origin, answer);
    });
  });

  prescriberIndicatedFormAltsLessEff(role, origin, "event").forEach((elem) => {
    elem.addEventListener("click", (e) => {
      answer = e.target.value;
      handlePrescriberIndicatedFormAltsLessEff(role, origin, answer);
    });
  });

  prescriberIndicatedFormAltsProduceAdvAffects(role, origin, "event").forEach(
    (elem) => {
      elem.addEventListener("click", (e) => {
        answer = e.target.value;
        handlePrescriberIndicatedFormAltsProduceAdvAffects(role, origin, answer);
      });
    }
  );

  triedNFailedFormAlts(role, origin, "event").forEach((elem) => {
    elem.addEventListener("click", (e) => {
      answer = e.target.value;
      handleTriedNFailedFormAlts(role, origin, answer);
    });
  });

  BvDListeners(origin, role);

  typeOfQlReview(role, origin, "event").forEach((elem) => {
    elem.addEventListener("click", (e) => {
      answer = e.target.value;
      handleTypeOfQlReview(role, origin, answer);
    });
  });

  prescriberIndicatedApprovedFormularyQuantityLimitIneffective(role, origin, "event").forEach((elem) => {
    elem.addEventListener("click", (e) => {
      answer = e.target.value;
      handlePrescriberIndicatedApprovedFormularyQuantityLimitIneffective(role, origin, answer);
    });
  });

  prescriberIndicatedApprovedDosesIneffective(role, origin, "event").forEach((elem) => {
    elem.addEventListener("click", (e) => {
      answer = e.target.value;
      handlePrescriberIndicatedApprovedDosesIneffective(role, origin, answer);
    });
  });
}
