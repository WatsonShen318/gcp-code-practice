import {
  clearDecision,
  clearGuidelines,
  clearLetterPreview,
  clearRqstBy,
} from '../reset/reset';
import * as aor from '../aor/aor.display';
import { filterDLTGuidelineOptions, resetDLTGuidelineFields, setGuideline, setTriedFail } from '../utils/automation';
import {
  toggleChecks,
  setDecision,
  toggleRoutes,
  setDecisionForRequestTypeRD,
} from '../decision/decision.display';
import { toggleDrugeRef } from '../requestReason/requestReason.display';
import { toggleLtrPreview, toggleLtrPreviewNA } from '../letterPreview/display';
import { toggleOutbound, toggleOBCDone } from '../outbound/outbound.display';
import msgRqstReason from '../requestReason/requestReason.dialogs';
import toggleRecommand from '../utils/rdRecommand.display';
import toggleAORCheck from '../aor/aorCheck.display';
import toggleAttachment from '../attachments/display';
import { toggleGuidelinesDrop } from '../guidelines/guideline.display';
import { handleRoutingChange } from '../verbiage/index';
import toggleTFMed from '../triedFailMed/display';
import msgRqstType from '../requestType/dialog';
import common from '../shared/common';
import msgDecision from '../decision/decision.dialog';
import claim from '../claim/claim';
import {
  approvedDiagnosis,
  client,
  decisionRouting,
  ePA,
  requestBy,
  requestReason,
  requestType,
  subAORFileLocation,
} from '../qsets/fields';
import commonTech from './common.tech';
import { handleEPA, handleTechQClient } from './clickEvents';
import { caseIdInputHandler } from '../prefill/caseIdHandler';
import { handleApproveDiagoQ } from '../dlt_guidelines/dlt_guideline.display';
import { showFormAltsSection, resetFormAlts, refreshFormAltsOnClientChange, resolveFormularyForClient } from '../form_alts/formAlts';
import { showQlSection, resetQl, refreshQlOnClientChange } from '../quantity_limit/quantityLimit';
import { initAetnaQuestions, resetAetnaQuestions } from '../aetna_questions/aetnaQuestions';

let answer = null;
const role = 'tech';
const origin = 'Queue';

common(role, origin);
commonTech(origin, role);
claim(origin, role);

//* Client Select drop down
client(role, origin, 'event').addEventListener('change', (e) => {
  handleTechQClient(e, role, origin);
  const rrAnswer = requestReason(role, origin, 'value')?.toLowerCase() || '';
  if (rrAnswer === 'non-formulary') {
    refreshFormAltsOnClientChange(role, origin);
    resetAetnaQuestions(role, origin);
    initAetnaQuestions(role, origin);
  } else if (rrAnswer.includes('quantity limit')) {
    refreshQlOnClientChange(role, origin);
  } else {
    resolveFormularyForClient(role, origin);
  }
});

//* Requested By question
requestBy(role, origin, 'event').forEach((elem) => {
  elem.addEventListener('click', (e) => {
    answer = e.target.value;
    clearRqstBy(origin, role);
    clearDecision(origin, role);
    aor.togglePOAQ(origin, role, answer);
  });
});

// * Is the required Power of Attorney (POA) on file question
subAORFileLocation(role, origin, 'event').forEach((elem) => {
  elem.addEventListener('click', (e) => {
    answer = e.target.value;
    aor.toggleAORLoc(origin, role, answer);
    setDecision(origin, role, answer, 'POA');
  });
});

//* Case Decision/Routing
decisionRouting(role, origin, 'event').addEventListener('change', (e) => {
  answer = e.target.value;
  clearLetterPreview(origin, role);
  toggleChecks(origin, role);
  toggleLtrPreview(origin, role);
  toggleRecommand(origin, role);
  toggleAORCheck(origin, role, answer);
  toggleOutbound(origin, role, answer);
  toggleAttachment(origin, role, answer);
  msgDecision(origin, role, answer);
  toggleLtrPreviewNA(origin, role, answer);
  toggleOBCDone(role, origin);
  handleRoutingChange(role, origin, answer);
});

//* Robotics/ Was the case successfully created through ePA answer, toggle visibility
ePA(role, origin, 'event').forEach((elem) => {
  elem.addEventListener('change', (e) => {
    handleEPA(e, role, origin);
  });
});

//* Request Type
requestType(role, origin, 'event').forEach((elem) => {
  elem.addEventListener('click', (e) => {
    answer = e.target.value;
    msgRqstType(origin, answer);
    toggleRoutes(origin, role, answer);
    toggleRecommand(origin, role);
    setDecisionForRequestTypeRD(role, origin, answer);
  });
});

// * Approvable diagnosis per drug lookup tool (DLT) or decision tree?
approvedDiagnosis(role, origin, 'event').forEach((elem) => {
  elem.addEventListener('click', (e) => {
    answer = e.target.value;
    setDecision(origin, role, answer, 'compendia');
    handleApproveDiagoQ(role, origin, answer);
  });
});

//* Request Reason
requestReason(role, origin, 'event').addEventListener('change', (e) => {
  answer = e.target.value;
  clearGuidelines(origin, role);
  toggleDrugeRef(origin, role, answer);
  msgRqstReason(role, answer);
  setGuideline(origin, role, answer);
  setDecision(origin, role, answer, 'RequestReason');
  toggleGuidelinesDrop(origin, role, answer);
  toggleTFMed(origin, role, answer);
  setTriedFail(origin, role, answer);
  resetDLTGuidelineFields(role, origin, answer);
  filterDLTGuidelineOptions(role, origin, answer);
  if (answer.toLowerCase() === 'non-formulary') {
    resetQl(role, origin);
    showFormAltsSection(role, origin);
    initAetnaQuestions(role, origin);
  } else if (answer.toLowerCase().includes('quantity limit')) {
    resetFormAlts(role, origin);
    resetAetnaQuestions(role, origin);
    showQlSection(role, origin);
  } else {
    resetFormAlts(role, origin);
    resetAetnaQuestions(role, origin);
    resetQl(role, origin);
  }
});


// caseId handler for caseId validation and conditionally display questions
caseIdInputHandler(role, origin);
