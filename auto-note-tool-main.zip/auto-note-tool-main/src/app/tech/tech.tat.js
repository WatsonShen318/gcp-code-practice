import {
  toggleRestrict,
  toggleClientName,
  toggleClientHeadsup,
} from "../client/display";
import { setDecisionForRequestTypeRD, toggleChecks, toggleRoutes } from "../decision/decision.display";
import {
  clearLetterPreview,
  // clearMDReview,
  // clearNewMDInfo,
} from "../reset/reset";
import { filterDLTGuidelineOptions, resetDLTGuidelineFields } from "../utils/automation";
import { toggleApprovedTier, toggleCurrentTier } from "../tiering/display";
import msgRqstType from "../requestType/dialog";
import msgDecision from "../decision/decision.dialog";
// import toggleMDTemplate from "../medicalDirector/mdTemplate.display";
import { toggleOBCDone, toggleOutbound } from "../outbound/outbound.display";
import common from "../shared/common";
import commonTech from "./common.tech";
import {
  toggledeniedRD,
  toggledeniedRDrphDecision,
} from "../utils/deniedRD.display";
import { toggleLtrPreview, toggleLtrPreviewNA } from "../letterPreview/display";
import toggleDeniedOutreach from "../utils/deniedOutreach.display";
// import toggleExceptionRdo from "../utils/exceptionRdo.display";
import { toggleDLTRef, toggleDrugeRef } from "../requestReason/requestReason.display";
import msgAttachment from "../attachments/dialog";
import { handleRoutingChange } from '../verbiage/index';
import {
  approvedDiagnosis,
  client,
  decisionRouting,
  failedFaxQ,
  newAttachments,
  requestReason,
  requestType,
  rfiFaxTemplateQ,
  threeOutreachAttemptsQ,
} from "../qsets/fields";
import { caseIdInputHandler } from "../prefill/caseIdHandler";
import { toggleCompendiaRef, toggleDrugdex } from "../compendia/display";
import {msgFailedFax, msgRFIFaxTemplate, msgThreeOutreachAttempts, } from "../fax/fax.dialog";
import { handleAnyFailedFaxesQ, handleRFIFaxTemplateQ, handleThreeOutReactAttemptsQ } from "./clickEvents";
import { handleApproveDiagoQ } from "../dlt_guidelines/dlt_guideline.display";
import { showFormAltsSection, resetFormAlts, refreshFormAltsOnClientChange, resolveFormularyForClient } from "../form_alts/formAlts";
import { showQlSection, resetQl, refreshQlOnClientChange } from "../quantity_limit/quantityLimit";
import { initAetnaQuestions, resetAetnaQuestions } from "../aetna_questions/aetnaQuestions";

let answer = null;
const role = "tech";
const origin = "TAT";

common(role, origin);
commonTech(origin, role);

//* Client Select drop down
client(role, origin, "event").addEventListener("change", (e) => {
  answer = e.target.value;
  // AMN 12/8/22 - December 2022 Enhancement - #112: Client Drop Down Updates
  // toggleRestrict(origin, role, answer);
  // toggleClientName(origin, role, answer);
  toggleClientHeadsup(origin, role, answer);
  toggleRestrict(origin, role, answer);
  toggleClientName(origin, role, answer);
  const rrAnswer = requestReason(role, origin, 'value')?.toLowerCase() || '';
  if (rrAnswer === 'non-formulary') {
    refreshFormAltsOnClientChange(role, origin);
    resetAetnaQuestions(role, origin);
    initAetnaQuestions(role, origin);
  } else if (rrAnswer.includes('quantity limit')) {
    refreshQlOnClientChange(role, origin);
  } else {
    resolveFormularyForClient(role, origin);
  }
});

//* Approvable Diagnosis?
approvedDiagnosis(role, origin, "event").forEach((elem) => {
  elem.addEventListener("click", (e) => {
    answer = e.target.value;
    // setMDdxNo(origin, role);
    toggleCompendiaRef(origin, role, answer);
    toggleDrugdex(origin, role);
    // setSupprtStatement(origin, role, answer, "comdenpia");
    handleApproveDiagoQ(role, origin, answer);
  });
});

//* Request Reason
requestReason(role, origin, "event").addEventListener("change", (e) => {
  answer = e.target.value;
  // setSupprtStatement(origin, role, answer, 'RequestReason');
  toggleCurrentTier(origin, role, answer);
  toggleApprovedTier(origin, role);
  toggleDrugeRef(origin, role, answer);
  toggleDLTRef(origin, role, answer);
  resetDLTGuidelineFields(role, origin, answer);
  filterDLTGuidelineOptions(role, origin, answer);
  if (answer.toLowerCase() === 'non-formulary') {
    resetQl(role, origin);
    showFormAltsSection(role, origin);
    initAetnaQuestions(role, origin);
  } else if (answer.toLowerCase().includes('quantity limit')) {
    resetFormAlts(role, origin);
    resetAetnaQuestions(role, origin);
    showQlSection(role, origin);
  } else {
    resetFormAlts(role, origin);
    resetAetnaQuestions(role, origin);
    resetQl(role, origin);
  }
});

//* Request Type
requestType(role, origin, "event").forEach((elem) => {
  elem.addEventListener("click", (e) => {
    answer = e.target.value;
    // clearNewMDInfo(origin, role);
    msgRqstType(origin, answer);
    toggleChecks(origin, role);
    toggleRoutes(origin, role, answer);
    toggledeniedRD(origin, role);
    // setMDnewInfo(origin, role);
    setDecisionForRequestTypeRD(role, origin, answer);
  });
});

//* Case Decision/Routing
decisionRouting(role, origin, "event").addEventListener("change", (e) => {
  answer = e.target.value;
  clearLetterPreview(origin, role);
  // clearMDReview(origin, role);
  msgDecision(origin, role, answer);
  // toggleMDTemplate(origin, role); // $ lazy load here
  toggleChecks(origin, role);
  toggleApprovedTier(origin, role);
  toggleOutbound(origin, role, answer);
  toggleLtrPreview(origin, role);
  toggledeniedRD(origin, role);
  toggleDeniedOutreach(origin, role, answer);
  // toggleExceptionRdo(origin, role, answer);
  // toggleLtrPreviewNA(origin, role, answer);
  toggledeniedRDrphDecision(origin, role);
  toggleOBCDone(role, origin);
  handleRoutingChange(role, origin, answer);
});

//* New Attachments Received?
newAttachments(role, origin, "event").forEach((elem) => {
  elem.addEventListener("click", (e) => {
    answer = e.target.value;
    msgAttachment(answer);
  });
});

/* RFI fax template completed Field */
rfiFaxTemplateQ(role, origin, "event").forEach((elem) => {
  elem.addEventListener("click", (e) => {
    answer = e.target.value;
    msgRFIFaxTemplate(origin, role, answer);
    handleRFIFaxTemplateQ(role, origin, answer);
  });
});

/* 3 outreach attempts (1 successful fax, 2 calls) Field */
threeOutreachAttemptsQ(role, origin, "event").forEach((elem) => {
  elem.addEventListener("click", (e) => {
    answer = e.target.value;
    msgThreeOutreachAttempts(origin, role, answer);
    handleThreeOutReactAttemptsQ(role, origin, answer);
  });
});

/* Any failed faxes Field */
failedFaxQ(role, origin, "event").forEach((elem) => {
  elem.addEventListener("click", (e) => {
    answer = e.target.value;
    msgFailedFax(origin, role, answer);
    handleAnyFailedFaxesQ(role, origin, answer);
  });
});

// caseId handler for caseId validation and conditionally display questions
caseIdInputHandler(role, origin);
