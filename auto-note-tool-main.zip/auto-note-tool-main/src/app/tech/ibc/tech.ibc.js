import {
  toggleRqstByCallerInfo,
  toggleRqstByCallerAOR,
  showRqstByCaller,
  toggleCallerProvidedClinicalInfo,
} from '../../caller/display';
import { togglePOAQ, toggleAORLoc } from '../../aor/aor.display';
import {
  toggleRestrict,
  toggleNoforRDHeadsup,
  toggleClientName,
  toggleClientHeadsup,
  toggleNoDecision,
} from '../../client/display';
import { clearRqstBy, clearLetterPreview } from '../../reset/reset';
import { filterDLTGuidelineOptions, resetDLTGuidelineFields, setGuideline } from '../../utils/automation';
import { setDecisionForRequestTypeRD, toggleChecks, toggleRoutes } from '../../decision/decision.display';

import toggleTFMed from '../../triedFailMed/display';
import {
  toggleDrugeRef,
  toggleIsCaseInRFI,
  toggleRqstReason,
} from '../../requestReason/requestReason.display';
import {
  toggleLtrPreview,
  toggleLtrPreviewNA,
} from '../../letterPreview/display';
import toggleRecommand from '../../utils/rdRecommand.display';
import toggleTechSuper from '../../utils/techSuper.display';
import { handleRoutingChange } from '../../verbiage/index';
import toggleAORCheck from '../../aor/aorCheck.display';
import { toggleOBCDone, toggleOutbound } from '../../outbound/outbound.display';
import msgRqstReason from '../../requestReason/requestReason.dialogs';
import msgRqstType from '../../requestType/dialog';
import common from '../../shared/common';
import commonIBC from '../../shared/common.ibc';
import commonTech from '../common.tech';
import msgDecision from '../../decision/decision.dialog';
import claim from '../../claim/claim';
import {
  approvedDiagnosis,
  careAgent,
  client,
  decisionRouting,
  inProgressCase,
  isCaseInRFI,
  requestBy,
  requestReason,
  requestType,
  subAORFileLocation,
  subAORMember,
  subRequestByCaller,
} from '../../qsets/fields';
import eagAAFNR from '../../eag/eag.aafnr';
//import {
  // toggleMemberDeniedbyClient, // AMN 1/3/23 - January 2023 Enhancement - #114: Remove Question 'Is there a denied case on the member's profile in 2022?'
 // toggleOD,
//} from '../../requestType/display';
import * as evt from './clickEvents';
//AMN 5/9/23 - May 2023 Enhancements - #124: Add pop-up for Inbound Call [Requested By] = AOR
import msgAOR from '../../requestBy/dialogs';
import { caseIdInputHandler } from '../../prefill/caseIdHandler';
import { handleApproveDiagoQ } from '../../dlt_guidelines/dlt_guideline.display';
import { showFormAltsSection, resetFormAlts, refreshFormAltsOnClientChange, resolveFormularyForClient } from '../../form_alts/formAlts';
import { showQlSection, resetQl, refreshQlOnClientChange } from '../../quantity_limit/quantityLimit';
import { initAetnaQuestions, resetAetnaQuestions } from '../../aetna_questions/aetnaQuestions';

let answer = null;
const role = 'tech';
const origin = 'IBC';

common(role, origin);
commonIBC(origin, role);
commonTech(origin, role);
claim(origin, role);
eagAAFNR(origin, role);

//* Is the call being transferred to you from a CARE agent?
careAgent(role, origin, 'event').forEach((elem) => {
  elem.addEventListener('change', (e) => {
    evt.handleCareAgent(e, role, origin);
  });
});

/* Handle inProgress CASE field*/
inProgressCase(role, origin, 'event').forEach((elem) => {
  elem.addEventListener('change', (e) => {
    evt.handleInProgressCASE(e, role, origin)
  });
});

//* Is request a RM Task?
// document.getElementsByName(`${role}${origin}rmTaskQrdo`).forEach((elem) => {
//   elem.addEventListener('change', (e) => {
//     evt.handleRMtask(e, role, origin);
//   });
// });

//* Client Select drop down
client(role, origin, 'event').addEventListener('change', (e) => {
  answer = e.target.value;
  toggleRestrict(origin, role, answer);
  toggleClientName(origin, role, answer);
  toggleNoforRDHeadsup(origin, role, answer);
  toggleClientHeadsup(origin, role, answer);
  toggleChecks(origin, role);
  toggleNoDecision(origin, role);
  toggleRqstReason(origin, role, answer);
  toggleRoutes(origin, role);
  //toggleOD(origin, role);
  // toggleMemberDeniedbyClient(origin, role, answer);  //AMN 1/3/23 - January 2023 Enhancement - #114: Remove Question 'Is there a denied case on the member's profile in 2022?'
  //* Toggle multiple fields by selecting Oscar Health (21BV)
  //toggleMultiFieldsOscar21BV(origin, role, answer);
  // AMN 1/3/23 - January 2023 Enhancement - #114: Remove Question 'Is there a denied case on the member's profile in 2022?'
  // toggleMemberDeniedbyClient(origin, role, answer);
  const rrAnswer = requestReason(role, origin, 'value')?.toLowerCase() || '';
  if (rrAnswer === 'non-formulary') {
    refreshFormAltsOnClientChange(role, origin);
    resetAetnaQuestions(role, origin);
    initAetnaQuestions(role, origin);
  } else if (rrAnswer.includes('quantity limit')) {
    refreshQlOnClientChange(role, origin);
  } else {
    resolveFormularyForClient(role, origin);
  }
});

//* Requested By question
requestBy(role, origin, 'event').forEach((elem) => {
  elem.addEventListener('click', (e) => {
    answer = e.target.value;
    //AMN 5/9/23 - May 2023 Enhancements - #124: Add pop-up for Inbound Call [Requested By] = AOR
    msgAOR(answer);
    toggleRqstByCallerAOR(origin, role, answer);
    clearRqstBy(origin, role);
    toggleOBCDone(role, origin);
    toggleCallerProvidedClinicalInfo(role, origin, answer);
  });
});

subRequestByCaller(role, origin, 'event').forEach((elem) => {
  elem.addEventListener('click', (e) => {
    answer = e.target.value;
    toggleRqstByCallerInfo(origin, role, answer);
  });
});

//* Did you speak with the member who authorized you to speak with another person?
subAORMember(role, origin, 'event').forEach((elem) => {
  elem.addEventListener('click', (e) => {
    answer = e.target.value;
    toggleRqstByCallerInfo(origin, role, answer);
    showRqstByCaller(origin, role, answer);
    togglePOAQ(origin, role, answer);
  });
});

// * Is the required Power of Attorney (POA) on file question
subAORFileLocation(role, origin, 'event').forEach((elem) => {
  elem.addEventListener('click', (e) => {
    answer = e.target.value;
    toggleAORLoc(origin, role, answer);
  });
});

//* Request Reason
requestReason(role, origin, 'event').addEventListener('change', (e) => {
  const isDLTGuidelineFormAutomated = sessionStorage.getItem("isDLTGuidelineFormAutomated") === 'true';
  const lastDLTAutomatedAnswer = sessionStorage.getItem("lastDLTAutomatedAnswer");
  answer = e.target.value;
  toggleDrugeRef(origin, role, answer);
  toggleTFMed(origin, role, answer);
  msgRqstReason(role, answer);
  setGuideline(origin, role, answer);
  toggleIsCaseInRFI(origin, role, answer);
  if(!(isDLTGuidelineFormAutomated && answer === lastDLTAutomatedAnswer)){
    resetDLTGuidelineFields(role, origin, answer);
  }
  filterDLTGuidelineOptions(role, origin, answer);
  if (answer.toLowerCase() === 'non-formulary') {
    resetQl(role, origin);
    showFormAltsSection(role, origin);
    initAetnaQuestions(role, origin);
  } else if (answer.toLowerCase().includes('quantity limit')) {
    resetFormAlts(role, origin);
    resetAetnaQuestions(role, origin);
    showQlSection(role, origin);
  } else {
    resetFormAlts(role, origin);
    resetAetnaQuestions(role, origin);
    resetQl(role, origin);
  }
});

//* Request Type
requestType(role, origin, 'event').forEach((elem) => {
  elem.addEventListener('click', (e) => {
    answer = e.target.value;
    msgRqstType(origin, answer);
    toggleRoutes(origin, role, answer);
    toggleRecommand(origin, role);
    setDecisionForRequestTypeRD(role, origin, answer);
  });
});

//* Case Decision/Routing
decisionRouting(role, origin, 'event').addEventListener('change', (e) => {
  answer = e.target.value;
  clearLetterPreview(origin, role);
  toggleChecks(origin, role);
  toggleLtrPreview(origin, role);
  toggleRecommand(origin, role);
  toggleTechSuper(origin, role, answer);
  toggleAORCheck(origin, role, answer);
  toggleOutbound(origin, role, answer);
  msgDecision(origin, role, answer);
  toggleLtrPreviewNA(origin, role, answer);
  toggleOBCDone(role, origin);
  handleRoutingChange(role, origin, answer);
});

isCaseInRFI(role, origin, 'event').forEach((elem) => {
  elem.addEventListener('change', (e) => {
    evt.handleIsCaseInRFI(e, role, origin)
  });
});

// * Approvable diagnosis per drug lookup tool (DLT) or decision tree?
approvedDiagnosis(role, origin, 'event').forEach((elem) => {
  elem.addEventListener('click', (e) => {
    answer = e.target.value;
    handleApproveDiagoQ(role, origin, answer);
  });
});

// caseId handler for caseId validation and conditionally display questions
caseIdInputHandler(role, origin);
