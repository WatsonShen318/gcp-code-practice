/* eslint-disable import/prefer-default-export */
// import { toggleRqsterInfo } from '../../caller/display';
import msgCareAgentAuthen from '../../care/dialogs';
import CAREagentDetail from '../../care/display';
import toggleDrugNameWSearchQ from '../../dlt_guidelines/display';
import { manualFormTemplate } from '../../prefill/manualTemplate';
import { removeTechIBCFieldsForNewCase } from '../../prefill/removeFields';
import { toggleDisplay } from '../../utils/notetool.display';
// import { toggleEAGAAFNRQs } from '../../eag/eagAafnr.display';
// import { toggleInquiry } from '../../inquiry/inquiry.display';
// import { toggleRMPriorityReminder } from '../../priority/displays';
// import {
//   clearRMTaskRest,
//   clearRMTaskSubQuestions,
// } from '../../rmTask/clear.answers';
// import {
  // hideRMTaskQuestions,
  // toggleRMtask,
//   toggleRMtaskID,
//   toggleRMtaskNotes,
// } from '../../rmTask/display';
// import {
//   toggleRMTaskReminder,
//   disableMHKoption,
// } from '../../timestamp/display';

let answer = null;

export const handleCareAgent = (e, role, origin) => {
  answer = e.target.value;
  CAREagentDetail(origin, role, answer);
  msgCareAgentAuthen(answer);
  // toggleRMtask(origin, role, answer);
  // hideRMTaskQuestions(origin, role, answer);
  // clearRMTaskRest(origin, role);
};

export const handleInProgressCASE = (e, role, origin) => {
  answer = e.target.value;
  if(answer === 'Yes') {
    toggleDisplay("solo", [`${role}${origin}inqcallerQ`], "disable");
    toggleDisplay('solo', [`${role}${origin}caseIdQbtn`, `${role}${origin}caseIdQ`], 'enable');

    const hideQs = document.querySelectorAll(".initiallyHidden");
    hideQs.forEach((s) => {
      s.style.display = "none";
      // s.disabled = true;

      if (s.id === "techIBCcaseIdQ") {
        s.style.display = "block";
        // s.disabled = false;
      }
    });

    toggleDisplay(
      "solo",
      [
        "generateNotebtn",
        "buttonSection",
        `${role}${origin}drugNameWSearchQ`
      ],
      "disable"
    )
  } else {
    toggleDisplay("solo", [`${role}${origin}inqcallerQ`], "enable");
    manualFormTemplate(role, origin);
    // remove "Do not need" fields from manual fields as well
    removeTechIBCFieldsForNewCase(role, origin);

    // Enable Drug Name with Search field in case of manual or new case flow in Tech IBC
    toggleDrugNameWSearchQ(role, origin);
  }
}

/* Handler to show Review External Template Free Text Field when Case is in RFI */
export const handleIsCaseInRFI = (e, role, origin) => {
  answer = e.target.value;
  if(answer === 'Yes') {
    toggleDisplay("solo", [`${role}${origin}reviewExternalTemplateQ`], "enable");
    
  } else {
    toggleDisplay("solo", [`${role}${origin}reviewExternalTemplateQ`], "disable");
  }
}

/**
 * * Event handler function when Is request a RM Task is answered
 * @param {origin} origin
 * @param {role} role
 * @param {answer} answer
 */
// export const handleRMtask = (e, role, origin) => {
//   answer = e.target.value;
//   clearRMTaskSubQuestions(origin, role);
//   toggleRMTaskReminder(origin, role, answer);
//   toggleRMPriorityReminder(origin, role, answer);
//   toggleRMtaskID(origin, role, answer);
//   toggleRMtaskNotes(origin, role, answer);
//   toggleRqsterInfo(origin, role, answer);
//   toggleInquiry(origin, role, answer);
//   toggleEAGAAFNRQs(origin, role, answer);
//   disableMHKoption(origin, role, answer);
// };
