import { rdoBtn } from '../utils/inputSelect';
import toggleOriginRefs from '../origin/originRefs.display';
import { initHideMember, toggleMemberChecks } from '../member/member.display';
import { showButtons } from '../buttons/display';
import { originChange } from '../utils/showTool';
import { initRequestTypeState } from '../requestType/display';
import { handleOriginClickEvent } from '../prefill/caseIdHandler';
import resetSessionStorage from '../utils/resetSessionStorage';
import resetFillIntake from '../utils/resetIntakeFields';
//import { toggleClients } from '../client/display';

const role = 'tech';

rdoBtn('techoriginQ').forEach((elem) => {
  elem.addEventListener('click', (e) => {
    resetSessionStorage();
    resetFillIntake("tech", "Queue");
    const origin = e.target.value;
    if (origin === 'Queue') {
      import(
        /* webpackPrefetch: true */ /* webpackChunkName: "techqfunctions" */ './tech.q'
      );
      initRequestTypeState(origin, role);
      handleOriginClickEvent(role, origin);
    }
    if (origin === 'SR') {
      import(
        /* webpackPrefetch: true */ /* webpackChunkName: "techSRfunctions" */ './tech.sr'
      );
      handleOriginClickEvent(role, origin);
    }
    if (origin === 'IBC') {
      import(
        /* webpackPrefetch: true */ /* webpackChunkName: "techIBCfuncstions" */ './ibc/tech.ibc'
      );
      handleOriginClickEvent(role, origin);
    }
    if (origin === 'TAT') {
      import(
        /* webpackPrefetch: true */ /* webpackChunkName: "techIBCfuncstions" */ './tech.tat'
      );
      handleOriginClickEvent(role, origin);
    }

    initHideMember(origin, role);
    originChange(role, origin);
    toggleMemberChecks(origin, role);
    toggleOriginRefs(role, origin);
    //toggleClients(origin, role);
    showButtons(origin); //! Display Generate Note button.
  });
});
