import { toggleAllClaimQs } from "../claim/claim.display";
import {
  toggleClientHeadsup,
  toggleClientName,
  toggleNoforRDHeadsup,
  toggleRestrict,
} from "../client/display";
import { toggleChecks } from "../decision/decision.display";
import {
  //toggleMemberDeniedbyClient, //AMN 1/3/23 - January 2023 Enhancement - #114: Remove Question 'Is there a denied case on the member's profile in 2022?'
  //toggleMemberDeniedbyEPA, //AMN 1/3/23 - January 2023 Enhancement - #114: Remove Question 'Is there a denied case on the member's profile in 2022?'
  toggleRequestType,
  toggleRqstDeniedCase,
  toggleRqstTypeByMemberDenied,
} from "../requestType/display";
import { clearRejects } from "../reset/reset";
import { toggleDisable } from "../utils/notetool.display";

let answer = null;

export const handleEPA = (e, role, origin) => {
  answer = e.target.value;
  toggleAllClaimQs(origin, role, answer);
  clearRejects(origin, role);
  //toggleMemberDeniedbyEPA(origin, role, answer); //AMN 1/3/23 - January 2023 Enhancement - #114: Remove Question 'Is there a denied case on the member's profile in 2022?'
  toggleRqstDeniedCase(origin, role, answer);
  toggleRequestType(origin, role, answer);
};
export const handleMemberDenied = (e, role, origin) => {
  answer = e.target.value;
  toggleRqstTypeByMemberDenied(origin, role, answer);
};

export const handleTechQClient = (e, role, origin) => {
  answer = e.target.value;
  toggleRestrict(origin, role, answer);
  toggleClientName(origin, role, answer);
  //toggleMemberDeniedbyClient(origin, role, answer); //AMN 1/3/23 - January 2023 Enhancement - #114: Remove Question 'Is there a denied case on the member's profile in 2022?'
  toggleNoforRDHeadsup(origin, role, answer);
  toggleClientHeadsup(origin, role, answer);
  toggleChecks(origin, role);
};

/* Tech TAT Click Events */
export const handleRFIFaxTemplateQ = (role, origin, answer) => {
  const listOfDependentFields = [
    `${role}${origin}threeOutreachAttemptsQ`,
    `${role}${origin}failedFaxQ`,
    // `${role}${origin}outboundQ`,
    `${role}${origin}newAttachQ`,
    "generateNotebtn",
  ];
  if (answer == "No") {
    toggleDisable(listOfDependentFields, "disable");
  } else {
    toggleDisable(listOfDependentFields, "enable");
  }
};

export const handleThreeOutReactAttemptsQ = (role, origin, answer) => {
  const listOfDependentFields = [
    `${role}${origin}failedFaxQ`,
    // `${role}${origin}outboundQ`,
    `${role}${origin}newAttachQ`,
    "generateNotebtn",
  ];
  if (answer == "No") {
    toggleDisable(listOfDependentFields, "disable");
  } else {
    toggleDisable(listOfDependentFields, "enable");
  }
};

export const handleAnyFailedFaxesQ = (role, origin, answer) => {
  const listOfDependentFields = [
    // `${role}${origin}outboundQ`,
    `${role}${origin}newAttachQ`,
    "generateNotebtn",
  ];
  if (answer == "Yes") {
    toggleDisable(listOfDependentFields, "disable");
  } else {
    toggleDisable(listOfDependentFields, "enable");
  }
};
