import { memberMultiDrug, memberCaseCountBalance } from '../qsets/fields';
import getInputValue from '../utils/getInputValue';
import { toggleDisplay } from '../utils/notetool.display';
import togglePartialValidation from '../utils/validation';

function techRPhNextCaseBtn(role, origin) {
  const multi = memberMultiDrug(role, origin, 'value');
  const balance = memberCaseCountBalance(role, origin, 'value');

  const status = multi === 'Yes' && balance > 0 ? 'enable' : 'disable';
  // toggleDisplay('button', [`${role}${origin}moreBtn`], status);
}

function intakeNextCaseBtn() {
  const rdo = getInputValue('radio', ['iMultirqstQrdo']);
  const txt = getInputValue('text', ['subiMultirqstQhidden']);
  const status =
    rdo.iMultirqstQrdo === 'Yes' && txt.subiMultirqstQhidden > 0
      ? 'enable'
      : 'disable';
  toggleDisplay('button', ['intakeNextCasebtn'], status);
}

export function toggleNextCaseBtn(role, origin) {
  const isQIBC = origin === 'Queue' || origin === 'IBC';
  if (role === 'intake') {
    intakeNextCaseBtn();
  }
  if (role !== 'intake' && isQIBC) {
    techRPhNextCaseBtn(role, origin);
  }
}

export function showButtons(origin) {
  const userInfo = JSON.parse(sessionStorage.getItem("userInfo") || "{}");
  const hideGenerateNoteButtons = !userInfo?.isHoldoutUser && ['Queue', 'SR', 'TAT', 'IBC'].includes(origin)
  toggleDisplay('solo', ['generateNotebtn', 'buttonSection'], hideGenerateNoteButtons ? 'disable' : 'enable');
}

export function goBackButton() {
  toggleDisplay('button', ['goBack'], 'enable');
}

export function goBackShowTool(o, r) {
  const resetbtn = document.getElementById('Resetbtn');

  togglePartialValidation(o, r, 'back');
  document.getElementById('pills-tabContent').style.display = 'block';
  document.getElementById('finalNoteDiv').style.display = 'none';
  document.getElementById('finalSideNoteDiv').style.display = 'none';
  document.getElementById('finalNoteReminder').style.display = 'none';
  document.getElementById('goBack').style.display = 'none';
  document.getElementById('generateNotebtn').style.display = 'block';
  resetbtn.style.display = 'block';

  // & go back to the top of the page
  // window.scrollTo(0, document.body.scrollHeight);
  // AlertService('reset');
}
