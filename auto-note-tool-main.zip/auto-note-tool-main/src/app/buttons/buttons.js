import sendDataToBigTable from '../bigTable/bigTable';
import { updateSSDLTGuidelineAutomatedFields } from '../dlt_guidelines/selection';
import FinalNotes, { FinalSideNotes } from '../finalnote/final.note';
import saveDataToMedhok from '../medhok/handler';
import { memberCaseIncrement, MultiCaseBalIncrement } from '../multiCase/math';
import { decisionRouting, requestType, subSpprtStatement, supportingStatement } from '../qsets/fields';
import { resetNoteCreateNextbtn } from '../reset/intake.reset';
import { currentProfile } from '../user/user.data';
import togglePartialValidation from '../utils/validation';

export default function ShowFinalNote() {
  const form = document.getElementById('notetool');

  function handleForm(event) {
    const profile = currentProfile();
    if (!form.checkValidity()) {
      event.preventDefault();
      event.stopPropagation();
      const invalidTooltips = form.querySelectorAll(':invalid')[2];
      console.log("form.querySelectorAll(':invalid') - invalid fields log", form.querySelectorAll(':invalid'))
      invalidTooltips.scrollIntoView({behavior: 'smooth', block: 'center'});
      invalidTooltips.focus();
    } else {
      event.preventDefault();
      const originalMedhokResponse = JSON.parse(sessionStorage.getItem("originalMedhokResponse"));
      const rxPAId = originalMedhokResponse?.medhokId;
      const rxId = originalMedhokResponse?.rxId;
      updateSSDLTGuidelineAutomatedFields(profile.role, profile.origin);
      FinalNotes(profile.role, profile.origin);
      if(["tech", "rph"].includes(profile.role)){
        const saveData = async () => {
          const finalNote = document.getElementById("finalNote")?.value || "";
          const routingValue = decisionRouting(profile.role, profile.origin, "value") || "";
          const requestTypeValue = requestType(profile.role, profile.origin, "value") || "";
          const supportingStatementValue = supportingStatement(profile.role, profile.origin, "value") || "";
          const subSpprtStatementValue = subSpprtStatement(profile.role, profile.origin, "value") || "";
          sessionStorage.setItem("FINAL_CASE_DCSN_ROUTING", routingValue);
          await saveDataToMedhok(profile.role, profile.origin, rxPAId, rxId, finalNote, routingValue, requestTypeValue, supportingStatementValue, subSpprtStatementValue);
          sendDataToBigTable(finalNote, profile.role, profile.origin);
        }
        saveData();
      }
    }
    form.classList.add('was-validated');
  }
  form.addEventListener('submit', handleForm);
}

/** alt is used for differentiating between normal obc or alt obc used for RFI TAT case reviewed for RPH - Queue & IBC*/
export function ShowOBCNote(o, r, alt=false) {
  const altsfx = alt ? 'alt' : '';
  const outbound = document.getElementById(`${r}${o}outboundQ${altsfx}`);

  outbound?.addEventListener('click', () => {
    const obcBtn = document.getElementById(`${r}${o}obcSubmit${altsfx}btn`);
    const form = document.getElementById('notetool');

    function handleForm(event) {
      const type = `outboundcall${altsfx}`;
      togglePartialValidation(o, r, type);
      if (!form.checkValidity()) {
        event.preventDefault();
        event.stopPropagation();
        // const t = form.querySelectorAll(':invalid');
        // console.log(t);
      } else {
        event.preventDefault();
        FinalSideNotes(o, r, type);
      }
      form.classList.add('was-validated');
    }
    obcBtn?.addEventListener('click', handleForm);
  });
}

export function ShowSideNote(o, r, type) {
  function anchor(t) {
    const button = {
      inquiry: document.getElementById(`${r}${o}inquiryQ`),
      EAG: document.getElementById(`${r}${o}eagQ`),
      AAFNR: document.getElementById(`${r}${o}eagQ`),
    };
    return button[t];
  }
  function btn(t) {
    const button = {
      inquiry: document.getElementById(`${r}${o}iqnrySubmitbtn`),
      EAG: document.getElementById(`${r}${o}eagbtnbtn`),
      AAFNR: document.getElementById(`${r}${o}aafnrbtnbtn`),
    };
    return button[t];
  }

  const noteBtn = btn(type);
  const form = document.getElementById('notetool');

  function handleForm(event) {
    // type = 'inquiry';
    if (!form.checkValidity()) {
      event.preventDefault();
      event.stopPropagation();
      // const t = form.querySelectorAll(':invalid');
      // console.log(t);
    } else {
      event.preventDefault();
      FinalSideNotes(o, r, type);
    }
    form.classList.add('was-validated');
  }
  noteBtn.addEventListener('click', handleForm);

  // // const inquiry = document.getElementById(`${r}${o}inquiryQ`);
  // const question = anchor(type);
  // question.addEventListener('click', () => {

  // });
}

export function intakeNextCase() {
  document.getElementById('intakeNextCasebtn').addEventListener('click', () => {
    MultiCaseBalIncrement();
    resetNoteCreateNextbtn();
  });
}
