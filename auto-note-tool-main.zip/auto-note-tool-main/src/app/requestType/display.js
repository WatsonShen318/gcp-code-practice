import { isAetna } from '../client/modules';
import { client } from '../qsets/fields';
import { clearInput } from '../utils/clearInput';
import { toggleDisplay, toggleDisable } from '../utils/notetool.display';
import { clickCD } from './automation';
import { msgCD } from './dialog';

/**
 * * Toggle member Denied Case question when epa question Yes is selected
 * @param {origin} origin
 * @param {role} role
 * @param {answer} answer
 */
//AMN 1/3/23 - January 2023 Enhancement - #114: Remove Question 'Is there a denied case on the member's profile in 2022?'
/* 
export function toggleMemberDeniedbyEPA(o, r, a) {
  const isAetnaMAPD = isAetna(client(r, o, 'value'));
  const status = a === 'Yes' ? 'disable' : 'enable';
  if (isAetnaMAPD) toggleDisplay('solo', [`${r}${o}memberDeniedCaseQ`], status);
}
*/

/**
 * * Toggle member Denied Case question when Client Aetna MAPD is selected. When Client changes, the radio selection is cleared
 * @param {origin} origin
 * @param {role} role
 * @param {answer} answer
 */
//AMN 1/3/23 - January 2023 Enhancement - #114: Remove Question 'Is there a denied case on the member's profile in 2022?'
/* 
export function toggleMemberDeniedbyClient(o, r, a) {
  ///AMN 1/3/23 - January 2023 Enhancement - #114: Remove Question 'Is there a denied case on the member's profile in 2022?'
  ///const status = isAetna(a) ? 'enable' : 'disable';
  const status = isAetna(a) ? 'disable' : 'enable';
  clearInput('radio', [`${r}${o}memberDeniedCaseQrdo`]);
  toggleDisplay('solo', [`${r}${o}memberDeniedCaseQ`], status);
}
*/

/**
 * *Based on Robotic(epa) or denied case on the member profile question answer, it will toggle denied case in the past 60days
 * @param {origin} o
 * @param {role} r
 * @param {answer} a
 * @param {trigger} trigger function that triggers this function
 */
export function toggleRqstDeniedCase(o, r, a) {
  const status = a === 'Yes' ? 'disable' : 'enable';
  toggleDisplay('solo', [`${r}${o}rqstTypeDeniedQ`], status);
}

function clearRequestType(o, r) {
  clearInput('radio', [`${r}${o}rqstTypeQrdo`]);
}

/**
 * * Based on Robotic(epa) or denied case on the member profile question answer, it will disable the question when they are answered Yes
 * @param {o}  origin
 * @param {r}  role
 * @param {a}  answer answer from Request Type
 */
export function toggleRequestType(o, r, a) {
  const status = a === 'Yes' ? 'enable' : 'disable';
  clearRequestType(o, r);
  toggleDisable([`${r}${o}rqstTypeQ`], status);
}

export function toggleRqstTypeByMemberDenied(o, r, a) {
  const isAetnaMAPD = isAetna(client(r, o, 'value'));
  //AMN 1/3/23 - January 2023 Enhancement - #114: Remove Question 'Is there a denied case on the member's profile in 2022?'
  /* 
  const rqstTypestatus = a === 'No' && isAetnaMAPD ? 'enable' : 'disable';
  const deniedStatus = a === 'No' && isAetnaMAPD ? 'disable' : 'enable';
  clearRequestType(o, r);
  toggleDisable([`${r}${o}rqstTypeQ`], rqstTypestatus);
  toggleDisplay('solo', [`${r}${o}rqstTypeDeniedQ`], deniedStatus);
  */
  if (isAetnaMAPD && a === 'No') {
    msgCD();
    clickCD(o, r);
  }
}

/**
 * *Disable Request Type question when title is changed to Tech. This function is triggered by tech.js
 * @param {origin} o
 * @param {role} r
 * @param {answer} a
 */
export function initRequestTypeState(o, r) {
  toggleDisable([`${r}${o}rqstTypeQ`], 'disable');
}

/**
 * *Add Organization Determination request type when specific client is selected and disable others
 * @param {origin} o
 * @param {role} r
 * @param {answer} a
 */

// export function toggleOD(o, r) {
//   const oscar21bv = isOscar21BV(client(r, o, 'value'));
//   const status = o === 'IBC' && oscar21bv ? 'enable' : 'disable';
//   const cdrdStatus = o === 'IBC' && oscar21bv ? 'disable' : 'enable';
//   toggleDisplay('solo', [`${r}${o}rqstTypeQODrdo`], status);
//   toggleDisable([`${r}${o}rqstTypeQOD`], status);
//   toggleDisable([`${r}${o}rqstTypeQCD`, `${r}${o}rqstTypeQRD`], cdrdStatus);
// }
