import { GeneralModal } from '../modal/alert.service';
import { bold } from '../utils/font.formatter';

export default function msgRqstType(o, a) {
  const glModal = document.querySelector('#guidelineModal.show');

  const RDRadiobtn = document.getElementById(`tech${o}rqstTypeQRD`);

  // Skip showing alerts when CDRD grid is automated
  if(RDRadiobtn && RDRadiobtn.getAttribute('data-automated') === 'true') {
    RDRadiobtn.removeAttribute('data-automated'); // Reset attribute
    return;
  }

  if (!glModal && a === 'RD' && o !== 'TAT') {
    GeneralModal({
      message: bold(
        'If the original Coverage Determination that was denied was an expedited request then the Redetermination should also be marked as an expedited request.'
      ),
      icon: 'notification_important',
    });
  }
  if (!glModal && a === 'RD' && o === 'TAT') {
    GeneralModal({
      message: bold(
        'If no expedited indicators present on RD case, please review CD case to confirm priority - if CD was expedited, RD should also be expedited.'
      ),
      icon: 'notification_important',
    });
  }
}
export function msgCD() {
  GeneralModal({
    message: bold('Case is a Coverage Determination'),
    icon: 'notification_important',
  });
}
