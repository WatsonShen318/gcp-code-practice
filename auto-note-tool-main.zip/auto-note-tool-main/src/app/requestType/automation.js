export function clickCD(origin, role) {
  const cd = document.getElementById(`${role}${origin}rqstTypeQCD`);
  cd.click();

  // Capturing CDRD end time for auditing
  const timestamp = new Date().toISOString();
  sessionStorage.setItem("cdrdEndTime", timestamp);
}

export function clickRD(origin, role) {
  const rd = document.getElementById(`${role}${origin}rqstTypeQRD`);
  rd.click();

  // Capturing CDRD end time for auditing
  const timestamp = new Date().toISOString();
  sessionStorage.setItem("cdrdEndTime", timestamp);
}
