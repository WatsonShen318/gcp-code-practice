import { claimToday, subClaimTodayRefill } from '../qsets/fields';
import { toggleDisplay, toggleDisable } from '../utils/notetool.display';

/**
 * $ Based on Robotics/ Was the case successfully created through ePA answer, toggle visibility
 * @param {origin} o
 * @param {role} r
 * @param {answer} a
 */
export function toggleAllClaimQs(o, r, a) {
  const claims = document.querySelectorAll(
    `[data-tag="claim"][id*="${r}${o}"]`
  );

  if (a === 'Yes' || a === 'disable') {
    toggleDisplay('tag', claims, 'disable');
  } else {
    toggleDisplay(
      'solo',
      [
        `${r}${o}claimQ`,
        `${r}${o}subclaimTodayDQ`,
        `${r}${o}claim90dQ`,
        `${r}${o}subclaim90dQ`,
      ],
      'enable'
    );
  }
}

export function toggleTodayRefill(o, r, a) {
  if (a === 'Yes') {
    toggleDisplay('solo', [`${r}${o}subclaimTodayRefillQ`], 'enable');
  } else {
    toggleDisplay('solo', [`${r}${o}subclaimTodayRefillQ`], 'disable');
  }
}

export function toggeTodayRjCode(o, r, a) {
  if (a === 'No') {
    toggleDisplay('solo', [`${r}${o}subclaimTodayCodeQ`], 'enable');
  } else {
    toggleDisplay('solo', [`${r}${o}subclaimTodayCodeQ`], 'disable');
  }
}

export function toggleRj90dAddClaim(o, r) {
  // $ toggles both rejects 90days and additional claim
  const claim = claimToday(r, o, 'value');
  const todayRefill = subClaimTodayRefill(r, o, 'value');

  if (claim === 'Yes' && todayRefill !== 'Yes') {
    toggleDisplay(
      'solo',
      [
        `${r}${o}claim90dQ`,
        `${r}${o}subclaim90dQ`,
        `${r}${o}addClaimbtn`,
        `${r}${o}subreject90dQ`,
      ],
      'disable'
    );
  } else {
    toggleDisplay(
      'solo',
      [`${r}${o}claim90dQ`, `${r}${o}subclaim90dQ`, `${r}${o}addClaimbtn`],
      'enable'
    );
  }
}

export function toggleRj90DdateCode(o, r, a) {
  if (a === 'No') {
    toggleDisplay('solo', [`${r}${o}subclaim90dQ`], 'enable');
    toggleDisplay('solo', [`${r}${o}subreject90dQ`], 'disable');
  } else if (a === 'Yes') {
    toggleDisplay('solo', [`${r}${o}subreject90dQ`], 'enable');
  }
}

export function toggleAddClaim(o, r, a) {
  const btn = document.getElementById(a);
  const expanded = btn.getAttribute('aria-expanded');
  if (expanded === 'true') {
    toggleDisable([`${r}${o}addClaimbtnColl`], 'enable');
  } else {
    toggleDisable([`${r}${o}addClaimbtnColl`], 'disable');
  }
}

export function toggleaddRjCode(o, r, a) {
  if (a === 'Yes') {
    toggleDisplay('solo', [`${r}${o}subaddTCRjCQ`], 'enable');
  } else {
    toggleDisplay('solo', [`${r}${o}subaddTCRjCQ`], 'disable');
  }
}
