import { GeneralModal } from '../modal/alert.service';
import { bold } from '../utils/font.formatter';
import getInputValue from '../utils/getInputValue';

export default function msgGuideline(o, r) {
  const rdo = getInputValue('radio', [
    `${r}${o}claimQrdo`,
    `${r}${o}subclaimTodayRefillQrdo`,
    `${r}${o}claim90dQrdo`,
  ]);

  if (
    rdo[`${r}${o}claim90dQrdo`] === 'No' &&
    rdo[`${r}${o}claimQrdo`] === 'No'
  ) {
    GeneralModal({
      message: bold(
        'Please refer to the Test Claim Guideline located on Sharepoint for help in further processing the case. Document findings in the rationale section below.'
      ),
      icon: 'notification_important',
    });
  } else if (
    rdo[`${r}${o}claim90dQrdo`] === 'No' &&
    rdo[`${r}${o}claimQrdo`] === 'Yes' &&
    rdo[`${r}${o}subclaimTodayRefillQrdo`] === 'Yes'
  ) {
    GeneralModal({
      message: bold(
        'Please refer to the Test Claim Guideline located on Sharepoint for help in further processing the case. Document findings in the rationale section below.'
      ),
      icon: 'notification_important',
    });
  }
}
