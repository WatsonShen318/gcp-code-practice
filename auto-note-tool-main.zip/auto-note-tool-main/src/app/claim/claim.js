import { rdoBtn, ele } from '../utils/inputSelect';
import msgGuideline from './claim.dialog';
import {
  toggeTodayRjCode,
  toggleAddClaim,
  toggleaddRjCode,
  toggleRj90dAddClaim,
  toggleRj90DdateCode,
  toggleTodayRefill,
} from './claim.display';
import { clearRjcode90Ds, clearTodayRefill } from '../reset/reset';
import { claimToday, subClaimTodayRefill } from '../qsets/fields';

let answer;

export default function claim(origin, role) {
  //* Claim Questions (rejects today...)
  claimToday(role, origin, 'event').forEach((elem) => {
    elem.addEventListener('click', (e) => {
      answer = e.target.value;
      clearTodayRefill(origin, role);
      toggleTodayRefill(origin, role, answer);
      toggleRj90dAddClaim(origin, role);
      msgGuideline(origin, role);
    });
  });

  //* Claim Rejects for refill too soon?
  subClaimTodayRefill(role, origin, 'event').forEach((elem) => {
    elem.addEventListener('click', (e) => {
      answer = e.target.value;
      clearRjcode90Ds(origin, role);
      toggeTodayRjCode(origin, role, answer);
      toggleRj90dAddClaim(origin, role);
    });
  });

  //* Claim Rejects 90 days out?
  rdoBtn(`${role}${origin}claim90dQ`).forEach((elem) => {
    elem.addEventListener('click', (e) => {
      answer = e.target.value;
      msgGuideline(origin, role);
      toggleRj90DdateCode(origin, role, answer);
    });
  });

  //* Claim additional test claim rejects?
  rdoBtn(`${role}${origin}addTestClaimQ`).forEach((elem) => {
    elem.addEventListener('click', (e) => {
      answer = e.target.value;
      toggleaddRjCode(origin, role, answer);
    });
  });

  //* Add additional test claim accordion
  ele(`${role}${origin}addClaimbtn`, '-btn').addEventListener('click', (e) => {
    answer = e.target.id;
    toggleAddClaim(origin, role, answer);
  });
}
