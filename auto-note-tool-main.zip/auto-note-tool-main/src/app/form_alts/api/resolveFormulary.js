import axios from 'axios';
// eslint-disable-next-line import/no-extraneous-dependencies
import axiosRetry from 'axios-retry';
import { getEnvironmentVariables } from '../../../../environment/config';
// Mock scenarios - swap the import to test a different path:
//   formularyFound    → formularyId auto-resolved (formularyIdSource = 'auto')
//   formularyNotFound → not found, user enters via dropdown or manual input
// import mockResolveFormularyResponse from '../../../mockData/formalts/mockResolveFormularyResponse';
// import { formularyFound as mockResolveFormularyResponse } from '../../../mockData/formalts/mockResolveFormularyResponse';
// import { formularyNotFound as mockResolveFormularyResponse } from '../../../mockData/formalts/mockResolveFormularyResponse';

axiosRetry(axios, {
  retries: 2,
  retryCondition: (error) => error.response?.status >= 500,
  retryDelay: (retryCount) => retryCount * 1000,
});

async function resolveFormulary(companyLob, companyAccounts, companyAccountGroup) {
  const { AUTO_NOTE_BACKEND } = getEnvironmentVariables();

  if (window.location.href.includes('localhost')) {
    // return mockResolveFormularyResponse;
  }

  const response = await axios.post(
    `${AUTO_NOTE_BACKEND}/formulary-alternatives/resolve-formulary`,
    { companyLob, companyAccounts, companyAccountGroup },
    { timeout: 60000 }
  );

  let resolveFormularyResponseData = response.data.data;

  return resolveFormularyResponseData;
}

export default resolveFormulary;
