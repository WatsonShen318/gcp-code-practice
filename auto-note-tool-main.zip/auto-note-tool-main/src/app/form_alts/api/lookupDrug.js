import axios from 'axios';
// eslint-disable-next-line import/no-extraneous-dependencies
import axiosRetry from 'axios-retry';
import { getEnvironmentVariables } from '../../../../environment/config';
// Mock scenarios - swap the import to test a different path:
//   drugNotSupported        → drug is not supported, shows "not supported" message
//   supportedSingleNoAuto   → single drug option, no auto-matched indication
//   supportedSingleWithAuto → single drug option, indication auto-matched from ICD-10 (happy path)
//   supportedMultipleOptions → multiple drug options, drug picker shown
// import mockLookupDrugResponse from '../../../mockData/formalts/mockLookupDrugResponse';
// import { drugNotSupported        as mockLookupDrugResponse } from '../../../mockData/formalts/mockLookupDrugResponse';
// import { supportedSingleNoAuto   as mockLookupDrugResponse } from '../../../mockData/formalts/mockLookupDrugResponse';
// import { supportedSingleWithAuto as mockLookupDrugResponse } from '../../../mockData/formalts/mockLookupDrugResponse';
// import { supportedMultipleOptions as mockLookupDrugResponse } from '../../../mockData/formalts/mockLookupDrugResponse';

axiosRetry(axios, {
  retries: 2,
  retryCondition: (error) => error.response?.status >= 500,
  retryDelay: (retryCount) => retryCount * 1000,
});

async function lookupDrug(gpi, mhkDrugName, primaryDxIcd10) {
  const { AUTO_NOTE_BACKEND } = getEnvironmentVariables();

  if (window.location.href.includes('localhost')) {
    // TODO: Remove when done testing
    // return mockLookupDrugResponse;
  }
  const response = await axios.post(
    `${AUTO_NOTE_BACKEND}/formulary-alternatives/lookup`,
    { gpi, mhkDrugName, primaryDxIcd10 },
    { timeout: 60000 }
  );

  let lookupDrugResponseData = response.data.data;

  return lookupDrugResponseData;
}

export default lookupDrug;
