import axios from 'axios';
// eslint-disable-next-line import/no-extraneous-dependencies
import axiosRetry from 'axios-retry';
import { getEnvironmentVariables } from '../../../../environment/config';
// Mock scenarios - swap the import to test a different path:
//   withSubClients → subclient picker shown before formulary dropdown
//   noSubClients   → formulary dropdown shown directly (no subclient step)
// import mockGetFormularyOptionsResponse from '../../../mockData/formalts/mockGetFormularyOptionsResponse';
// import { withSubClients as mockGetFormularyOptionsResponse } from '../../../mockData/formalts/mockGetFormularyOptionsResponse';
// import { noSubClients as mockGetFormularyOptionsResponse } from '../../../mockData/formalts/mockGetFormularyOptionsResponse';

axiosRetry(axios, {
  retries: 2,
  retryCondition: (error) => error.response?.status >= 500,
  retryDelay: (retryCount) => retryCount * 1000,
});

async function getFormularyOptions(client) {
  const { AUTO_NOTE_BACKEND } = getEnvironmentVariables();

  if (window.location.href.includes('localhost')) {
    // return mockGetFormularyOptionsResponse;
  }

  const response = await axios.post(
    `${AUTO_NOTE_BACKEND}/formulary-alternatives/formulary-options`,
    { client },
    { timeout: 30000 }
  );

  return response.data.data;
}

export default getFormularyOptions;
