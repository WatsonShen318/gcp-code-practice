import axios from 'axios';
// eslint-disable-next-line import/no-extraneous-dependencies
import axiosRetry from 'axios-retry';
import { getEnvironmentVariables } from '../../../../environment/config';
// Mock scenarios - swap the import to test a different path:
//   rfiAndDenial → both RFI and denial alternatives found (happy path)
//   rfiOnly      → only RFI alternatives (denial list empty)
//   denialOnly   → only denial alternatives (RFI list empty - edge case)
//   noAlts       → no alternatives found at all
// import mockFetchFormAltsResponse from '../../../mockData/formalts/mockFetchFormAltsResponse';
// import { rfiAndDenial as mockFetchFormAltsResponse } from '../../../mockData/formalts/mockFetchFormAltsResponse';
// import { rfiOnly      as mockFetchFormAltsResponse } from '../../../mockData/formalts/mockFetchFormAltsResponse';
// import { denialOnly   as mockFetchFormAltsResponse } from '../../../mockData/formalts/mockFetchFormAltsResponse';
// import { noAlts       as mockFetchFormAltsResponse } from '../../../mockData/formalts/mockFetchFormAltsResponse';

axiosRetry(axios, {
  retries: 2,
  retryCondition: (error) => error.response?.status >= 500,
  retryDelay: (retryCount) => retryCount * 1000,
});

async function fetchFormAlts(formularyId, drugName, indication, memberId, receivedDate = null) {
  const { AUTO_NOTE_BACKEND } = getEnvironmentVariables();

  if (window.location.href.includes('localhost')) {
    // TODO: Remove when done testing
    // return mockFetchFormAltsResponse;
  }

  const response = await axios.post(
    `${AUTO_NOTE_BACKEND}/formulary-alternatives/fetch`,
    { formularyId, drugName, indication, memberId, receivedDate },
    { timeout: 60000 }
  );

  let fetchFormAltsResponseData = response.data.data;

  return fetchFormAltsResponseData;
}

export default fetchFormAlts;
