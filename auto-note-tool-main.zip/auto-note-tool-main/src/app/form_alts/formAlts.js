import resolveFormulary from './api/resolveFormulary';
import lookupDrug from './api/lookupDrug';
import fetchFormAlts from './api/fetchFormAlts';
import { toggleDisplay, toggleDisable } from '../utils/notetool.display';
import { automateDLTGuidelineFieldsBasedOnFormAlts, automateDLTShow0TFAltsQ, resetFormAltsDLTFields } from '../dlt_guidelines/automation';
import { SS_FORMULARY, SS_FORMULARY_SOURCE, resolveFormularyUI, resetSubegwpDropdown } from '../shared/resolveFormularyUI';
import { isManualFlow } from '../shared/manualFlow';
import { refreshVerbiageIfActive } from '../verbiage/index';

const SS_RESOLVE    = 'formAltsResolveResult';
const SS_LOOKUP     = 'formAltsLookupResult';
const SS_DRUG       = 'formAltsDrugName';
const SS_AUTOMATED_INDICATION = 'formAltsAutomatedIndication';
const SS_FINAL_INDICATION = 'formAltsFinalIndication';
const SS_FETCH      = 'formAltsFetchResult';
const SS_FETCH_SUB  = 'formAltsFetchSubmitted';
const SS_FORM_ALTS_AUDIT = 'formAltsAudit';
const SS_NF_ACTIVE       = 'formAltsNfActive';

function _readFormAltsAudit() {
  return JSON.parse(sessionStorage.getItem(SS_FORM_ALTS_AUDIT) || 'null') || {};
}
function _writeFormAltsAudit(updates) {
  sessionStorage.setItem(SS_FORM_ALTS_AUDIT, JSON.stringify({ ..._readFormAltsAudit(), ...updates }));
}
function _appendFormAltsError(msg) {
  const current = _readFormAltsAudit();
  const errors = Array.isArray(current.automationErrors) ? current.automationErrors : [];
  sessionStorage.setItem(SS_FORM_ALTS_AUDIT, JSON.stringify({ ...current, automationErrors: [...errors, msg] }));
}

// Per role+origin init promise -prevents duplicate API calls if multiple events fire
const initPromises = {};

// Tracks the SS key used for manual drug selection (no medhok flow)
const SS_MANUAL_DRUG = 'manualFlowDrug';

// Callbacks registered by other features (e.g. QL) to run after formularyId is confirmed.
// Keyed by `${role}${origin}` so each qset instance has its own callback.
const _afterFormularyResolvedCallbacks = {};

export function registerAfterFormularyResolved(role, origin, cb) {
  _afterFormularyResolvedCallbacks[`${role}${origin}`] = cb;
}

function _fireAfterFormularyResolved(role, origin) {
  const cb = _afterFormularyResolvedCallbacks[`${role}${origin}`];
  if (cb) cb();
}

// Callbacks registered by other features (e.g. QL) to be notified when the user picks a
// drug from Q250 (formAltsDrugPickerQ). Only fires on explicit user selection (multiple-drug
// picker); single-drug auto-selection does not trigger this since the drug name is unchanged.
const _onDrugChangedCallbacks = {};

export function registerOnDrugChanged(role, origin, cb) {
  _onDrugChangedCallbacks[`${role}${origin}`] = cb;
}

function _fireDrugChanged(role, origin, drugName) {
  const cb = _onDrugChangedCallbacks[`${role}${origin}`];
  if (cb) cb(drugName);
}

export function clearFormAltsCache() {
  Object.keys(initPromises).forEach((k) => delete initPromises[k]);
}

function _clearInitCache(role, origin) {
  delete initPromises[`${role}${origin}`];
}

// Show Q250/Q251 if both drug lookup and formulary are already available.
// Called when either drug is selected or formulary resolves - whichever comes second.
function _showDrugPickersIfReady(role, origin) {
  const lookupResult = JSON.parse(sessionStorage.getItem(SS_LOOKUP) || 'null');
  if (!lookupResult || !sessionStorage.getItem(SS_FORMULARY)) return;
  _resetDownstream(role, origin);
  _proceedWithLookup(role, origin, lookupResult);
}

export function initFormAlts(role, origin) {
  const key = `${role}${origin}`;
  if (initPromises[key]) return initPromises[key];
  initPromises[key] = _doInit().then(() => {
    // Delete the cache only when _doInit returned early (medhok/companyLob not yet available).
    // SS_RESOLVE is set by _doInit as long as companyLob was present, so its absence means
    // we didn't even reach the API calls — safe to retry on the next initFormAlts call.
    // When SS_RESOLVE IS set (even found:false), the result is authoritative; keep the cache.
    if (!sessionStorage.getItem(SS_RESOLVE)) {
      delete initPromises[key];
    }
  }).catch((err) => {
    console.error('[FormAlts] Init failed:', err);
    delete initPromises[key];
  });
  return initPromises[key];
}

function _resolveDiagnosis(medhok) {
  const NA = 'Not Available';
  const d1 = medhok?.diagnosis1;
  const d2 = medhok?.diagnosis2;
  const d3 = medhok?.diagnosis3;
  if (d1 && d1 !== NA) return d1;
  if (d2 && d2 !== NA) return d2;
  if (d3 && d3 !== NA) return d3;
  return null;
}

async function _doInit() {
  const medhok = JSON.parse(sessionStorage.getItem('originalMedhokResponse') || 'null');
  if (!medhok) return;

  const companyLob          = medhok?.memberEligibility?.companyLob;
  const companyAccounts     = medhok?.memberEligibility?.companyAccounts;
  const companyAccountGroup = medhok?.memberEligibility?.companyAccountGroup;
  const gpi                 = medhok?.gpiCode;
  const mhkDrugName         = medhok?.drugName;
  const primaryDxIcd10      = _resolveDiagnosis(medhok);

  // resolveFormulary only needs CAG fields - run it whenever companyLob is present,
  // even if GPI / drug name are missing (manual-drug or incomplete medhok cases).
  if (!companyLob) return;

  const [resolveRes, lookupRes] = await Promise.allSettled([
    resolveFormulary(companyLob, companyAccounts, companyAccountGroup),
    (gpi && mhkDrugName) ? lookupDrug(gpi, mhkDrugName, primaryDxIcd10) : Promise.resolve(null),
  ]);

  if (resolveRes.status === 'fulfilled' && resolveRes.value) {
    sessionStorage.setItem(SS_RESOLVE, JSON.stringify(resolveRes.value));
  }
  if (lookupRes.status === 'fulfilled' && lookupRes.value) {
    sessionStorage.setItem(SS_LOOKUP, JSON.stringify(lookupRes.value));
  }
}

export async function showFormAltsSection(role, origin) {
  // Mark NF as active so _tryFetch knows to fetch (guards auto-selected indication
  // from firing the fetch before request reason is confirmed)
  sessionStorage.setItem(SS_NF_ACTIVE, 'true');

  // Re-show DLT fields hidden by resetFormAlts — they belong to the NF section and
  // must be visible before the user can fill them in or before automation populates them.
  toggleDisplay('solo', [
    `${role}${origin}dltShow0TFAltsQ`,
    `${role}${origin}triedNFailedFormAltsQ`,
    `${role}${origin}triedNFailedMedicationsQ`,
  ], 'enable');

  // Await CAG formulary auto-resolve before calling resolveFormularyUI so SS_RESOLVE
  // is guaranteed to be populated when we check it (avoids the async race where
  // resolveFormularyUI would fall through to getFormularyOptions unnecessarily).
  await initFormAlts(role, origin);

  // Automated flow: show drug note in alert as soon as lookup is available, before
  // formulary resolves (or if it resolves to N/A). Manual flow has its own early
  // show in onManualDrugSelected.
  if (!isManualFlow()) {
    const _autoLookup = JSON.parse(sessionStorage.getItem(SS_LOOKUP) || 'null');
    if (_autoLookup?.supported && (_autoLookup.drugOptions || []).length === 1) {
      _showDrugNoteInAlert(_autoLookup.drugOptions[0].drugName, _autoLookup.drugOptions[0].notes || null);
    }
  }

  // Pre-populate formulary if CAG auto-resolved it
  const earlyResolve = JSON.parse(sessionStorage.getItem(SS_RESOLVE) || 'null');
  if (earlyResolve?.found && earlyResolve?.formularyId) {
    sessionStorage.setItem(SS_FORMULARY, earlyResolve.formularyId);
    sessionStorage.setItem(SS_FORMULARY_SOURCE, 'auto');
  }

  toggleDisplay('solo', [`${role}${origin}subFormularyIDQ`], 'disable');

  resolveFormularyUI(role, origin, 'formulary', {
    onResolved: () => {
      _writeFormAltsAudit({ formularyId: sessionStorage.getItem(SS_FORMULARY) || 'N/A', formularyIdSource: sessionStorage.getItem(SS_FORMULARY_SOURCE) });
      const _nfFormularySrc = sessionStorage.getItem(SS_FORMULARY_SOURCE);
      if (_nfFormularySrc && _nfFormularySrc !== 'auto') {
        _appendFormAltsError(`Formulary ID not auto-resolved (CAG unavailable); entered via: ${_nfFormularySrc}`);
      }

      // Case 1: indication already selected → fetch results.
      // null  = never set / reset (removeItem) → fall through to re-render picker.
      // ''    = RPH "None of above" → valid, fetch with empty indication.
      // '__none__' = tech "None of above" → no fetch, fall through to re-render picker.
      const _finalIndication = sessionStorage.getItem(SS_FINAL_INDICATION);
      if (_finalIndication !== null && _finalIndication !== '__none__') {
        _tryFetch(role, origin);
        return;
      }

      // Case 2: drug picked from Q250 but indication not yet selected → wait
      if (sessionStorage.getItem(SS_DRUG)) return;

      // Case 3: lookup done but Q250 not yet rendered → show drug picker now
      const lookupResult = JSON.parse(sessionStorage.getItem(SS_LOOKUP) || 'null');

      if (lookupResult) {
        _resetDownstream(role, origin);
        _proceedWithLookup(role, origin, lookupResult);
        return;
      }

      // Case 4: no lookup yet → show prompt or error
      if (isManualFlow()) {
        const _manualDrug = JSON.parse(sessionStorage.getItem(SS_MANUAL_DRUG) || 'null');
        if (_manualDrug && !_manualDrug.gpi) return; // "Other" selected — full manual, no formAlts
        _setContainerHtml(role, origin, '<div class="alert alert-info mb-0">Select a drug from the Drug Name field above to load formulary alternatives.</div>');
        toggleDisplay('solo', [`${role}${origin}formAltsListQ`], 'enable');
      } else {
        _appendFormAltsError('Drug/GPI not available from medhok - automated formulary alternatives lookup cannot proceed');
        _setContainerHtml(role, origin, '<div class="alert alert-warning mb-0">Drug information not available from MedHok — formulary alternatives lookup cannot proceed. Verify the drug/GPI on the case.</div>');
        toggleDisplay('solo', [`${role}${origin}formAltsListQ`], 'enable');
      }
    },
    onNotAvailable: () => {
      _writeFormAltsAudit({ formularyId: 'N/A', formularyIdSource: 'na' });
      sessionStorage.removeItem(SS_FORMULARY);
      _resetDownstream(role, origin);
      _setContainerHtml(role, origin, '<div class="alert alert-secondary mb-0">Formulary ID not available - formulary alternatives lookup skipped.</div>');
      toggleDisplay('solo', [`${role}${origin}formAltsListQ`], 'enable');
    },
    onReset: () => _resetDownstream(role, origin),
  });
}

// Called when user selects a drug in manual flow (no medhok).
// Stores the selection, runs lookupDrug, then resumes the alts flow
// if the formulary is already resolved; otherwise formulary's onResolved will pick it up.
export async function onManualDrugSelected(role, origin, gpi, drugName) {
  toggleDisplay('solo', [`${role}${origin}drugNameWSearchNoteQ`, `${role}${origin}drugPickerNoteQ`], 'disable');
  sessionStorage.setItem(SS_MANUAL_DRUG, JSON.stringify({ gpi, drugName }));
  sessionStorage.removeItem(SS_LOOKUP);

  // "Other" drug selected — no GPI means no formulary lookup is possible.
  // Always clear downstream so stale data from any prior valid drug doesn't carry forward.
  if (!gpi) {
    _resetDownstream(role, origin);
    sessionStorage.removeItem(SS_FORM_ALTS_AUDIT);
    return;
  }

  const medhok = JSON.parse(sessionStorage.getItem('originalMedhokResponse') || 'null');
  const primaryDxIcd10 = _resolveDiagnosis(medhok);

  let lookupResult;
  try {
    lookupResult = await lookupDrug(gpi, drugName, primaryDxIcd10);
    sessionStorage.setItem(SS_LOOKUP, JSON.stringify(lookupResult));
  } catch (err) {
    console.error('[FormAlts] Manual drug lookup failed:', err);
    _setContainerHtml(role, origin, '<div class="alert alert-danger mb-0">Failed to load drug data. Please try again.</div>');
    return;
  }

  // Show note immediately for single-drug results — lookup doesn't need formulary,
  // so the note is available now. When formulary later resolves and _proceedWithLookup
  // fires, _showDrugNoteInline is called again with the same value (idempotent).
  if (lookupResult.supported && (lookupResult.drugOptions || []).length === 1) {
    _showDrugNoteInline(role, origin, 'drugNameWSearchNoteQ', lookupResult.drugOptions[0].notes || null);
  }

  // Show Q250/Q251 if formulary is ready; if not, resolveFormularyForClient's onResolved
  // will call _showDrugPickersIfReady when formulary eventually resolves.
  _showDrugPickersIfReady(role, origin);
}

function _proceedWithLookup(role, origin, lookupResult) {
  if (!lookupResult.supported) {
    _writeFormAltsAudit({ drugLookupStatus: 'Drug not supported' });
    _appendFormAltsError('Drug not supported for formulary alternatives lookup');
    _setContainerHtml(role, origin, [
      '<div class="alert alert-warning mb-0">',
      '<strong>Formulary alternatives not available for this drug.</strong>',
      // ' This drug may already be on-formulary - if a quantity limit applies,',
      // ' check the <em>Drug Strength / Quantity Limit</em> section above.',
      '</div>',
    ].join(''));
    toggleDisplay('solo', [`${role}${origin}formAltsListQ`], 'enable');
    return;
  }

  const drugOptions = lookupResult.drugOptions || [];
  const optCount = drugOptions.length;
  _writeFormAltsAudit({ drugLookupStatus: `Supported - ${optCount} option${optCount === 1 ? '' : 's'}` });

  if (optCount === 0) {
    _appendFormAltsError('Drug lookup returned no formulary alternative options');
    _setContainerHtml(role, origin, '<div class="alert alert-info mb-0">Drug found but no formulary alternative options are available for this drug/formulary combination.</div>');
    toggleDisplay('solo', [`${role}${origin}formAltsListQ`], 'enable');
    _fireAfterFormularyResolved(role, origin);
    return;
  }

  const medhok = JSON.parse(sessionStorage.getItem('originalMedhokResponse') || 'null');
  const noDiagnosis = !_resolveDiagnosis(medhok);

  _handleDrugPicker(role, origin, drugOptions, noDiagnosis);
  _fireAfterFormularyResolved(role, origin);
}

export function resetFormAlts(role, origin) {
  // NOTE: resetSubegwpDropdown intentionally NOT called here. The sub-client dropdown on Q33
  // belongs to the client selection context (cleared on client change), not the request reason.
  // SS_FORMULARY is kept by this reset, so resetting Q33 would leave it as blank free-text
  // with no way to re-inject the dropdown (resolveFormularyUI short-circuits when SS_FORMULARY set).
  // Clear NF-active flag and fetch state only - drug/indication state persists so Q250/Q251
  // remain visible when request reason changes away from NF and back again.
  sessionStorage.removeItem(SS_NF_ACTIVE);
  sessionStorage.removeItem(SS_FETCH);
  sessionStorage.removeItem(SS_FETCH_SUB);
  sessionStorage.removeItem(SS_FORM_ALTS_AUDIT);
  // SS_FORMULARY, SS_FORMULARY_SOURCE: kept (client-level)
  // SS_MANUAL_DRUG, SS_DRUG, SS_LOOKUP: kept (drug state persists across NF changes)
  // SS_AUTOMATED_INDICATION, SS_FINAL_INDICATION: kept (indication persists)
  // Q254/Q255/Q249: intentionally NOT hidden (client-level)
  // Q250 (formAltsDrugPickerQ), Q251 (formAltsIndicationQ): intentionally NOT hidden
  toggleDisplay('solo', [`${role}${origin}formAltsListQ`], 'disable');
  _setContainerHtml(role, origin, '');
}

// Shows Q251 (indication picker) for the QL flow using the drug resolved from SS_LOOKUP.
// Unlike the NF path, _tryFetch is guarded by SS_NF_ACTIVE so no form alts fetch fires;
// only SS_FINAL_INDICATION is written — available for the QL verbiage template to consume.
export function showFormAltsIndicationPickerForQl(role, origin) {
  const lookupResult = JSON.parse(sessionStorage.getItem(SS_LOOKUP) || 'null');
  if (!lookupResult?.supported) return;

  const drugOptions = lookupResult.drugOptions || [];
  if (drugOptions.length === 0) return;

  const drugName = sessionStorage.getItem(SS_DRUG);
  const drug = (drugName && drugOptions.find(d => d.drugName === drugName)) || drugOptions[0];
  if (!drug) return;

  const medhok = JSON.parse(sessionStorage.getItem('originalMedhokResponse') || 'null');
  const noDiagnosis = !_resolveDiagnosis(medhok);
  _handleIndicationPicker(role, origin, drug, noDiagnosis);
}

// Shows Q250 (formAlts drug picker) for the QL flow when multiple drug formulations exist.
// Returns true  → picker shown, QL should wait for drug selection (registerOnDrugChanged fires _runLookup).
// Returns false → single match auto-selected, or drug already picked, or no lookup data; proceed immediately.
export function showFormAltsDrugPickerForQl(role, origin) {
  if (sessionStorage.getItem(SS_DRUG)) return false; // already selected from Q250

  const lookupResult = JSON.parse(sessionStorage.getItem(SS_LOOKUP) || 'null');
  if (!lookupResult?.supported) return false;
  const drugOptions = lookupResult.drugOptions || [];
  if (drugOptions.length === 0) return false;

  if (drugOptions.length === 1) {
    sessionStorage.setItem(SS_DRUG, drugOptions[0].drugName);
    toggleDisplay('solo', [`${role}${origin}formAltsDrugPickerQ`], 'disable');
    if (sessionStorage.getItem(SS_MANUAL_DRUG)) {
      _showDrugNoteInline(role, origin, 'drugNameWSearchNoteQ', drugOptions[0].notes || null);
    } else {
      _showDrugNoteInAlert(drugOptions[0].drugName, drugOptions[0].notes || null);
    }
    return false;
  }

  const sel = document.getElementById(`${role}${origin}formAltsDrugPickerQsel`);
  if (!sel) return false;

  sel.innerHTML = '<option value="">Select...</option>';
  drugOptions.forEach((drug, i) => {
    const opt = document.createElement('option');
    opt.value = i;
    opt.textContent = drug.drugName;
    sel.appendChild(opt);
  });
  sel.onchange = () => {
    const idx = parseInt(sel.value, 10);
    if (isNaN(idx)) return;
    sessionStorage.setItem(SS_DRUG, drugOptions[idx].drugName);
    sessionStorage.removeItem(SS_AUTOMATED_INDICATION);
    sessionStorage.removeItem(SS_FINAL_INDICATION);
    _fireDrugChanged(role, origin, drugOptions[idx].drugName);
    const _notes = drugOptions[idx].notes || null;
    if (sessionStorage.getItem(SS_MANUAL_DRUG)) {
      _showDrugNoteInline(role, origin, 'drugPickerNoteQ', _notes);
    } else {
      _showDrugNoteInAlert(drugOptions[idx].drugName, _notes);
    }
  };
  toggleDisplay('solo', [`${role}${origin}formAltsDrugPickerQ`], 'enable');
  return true;
}

function _resetDownstream(role, origin) {
  sessionStorage.removeItem(SS_DRUG);
  sessionStorage.removeItem(SS_AUTOMATED_INDICATION);
  sessionStorage.removeItem(SS_FINAL_INDICATION);
  sessionStorage.removeItem(SS_FETCH);
  sessionStorage.removeItem(SS_FETCH_SUB);
  resetFormAltsDLTFields(role, origin);
  _setContainerHtml(role, origin, '');
  toggleDisplay('solo', [`${role}${origin}drugNameWSearchNoteQ`, `${role}${origin}drugPickerNoteQ`], 'disable');
  toggleDisplay('solo', [`${role}${origin}formAltsDrugPickerQ`], 'disable');
  toggleDisplay('solo', [`${role}${origin}formAltsIndicationQ`], 'disable');
  toggleDisplay('solo', [`${role}${origin}formAltsListQ`],       'disable');
}


function _showDrugNoteInline(role, origin, internal, notes) {
  _writeFormAltsAudit({ drugNoteAvailable: notes ? 'Yes' : 'No' });
  const bannerId = `${role}${origin}${internal}`;
  if (!notes) {
    toggleDisplay('solo', [bannerId], 'disable');
    return;
  }
  const banner = document.getElementById(bannerId);
  if (!banner) { console.warn('[FormAlts] Drug note banner not found in DOM:', bannerId); return; }
  const textDiv = banner.querySelector('.d-flex > div:last-child');
  if (textDiv) textDiv.innerHTML = notes;
  toggleDisplay('solo', [bannerId], 'enable');
}

function _showDrugNoteInAlert(drugName, notes) {
  _writeFormAltsAudit({ drugNoteAvailable: notes ? 'Yes' : 'No' });
  const body = document.getElementById('alertPopupBody');
  if (!body || !notes || !drugName) return;
  body.querySelector('.ant-drug-note-alert')?.remove();
  const div = document.createElement('div');
  div.className = 'ant-drug-note-alert';
  div.innerHTML = `<h5><strong>Drug:</strong> ${drugName}</h5><p>${notes}</p>`;
  body.appendChild(div);
}

function _handleDrugPicker(role, origin, drugOptions, noDiagnosis = false) {
  if (drugOptions.length === 0) return;

  if (drugOptions.length === 1) {
    sessionStorage.setItem(SS_DRUG, drugOptions[0].drugName);
    toggleDisplay('solo', [`${role}${origin}formAltsDrugPickerQ`], 'disable');
    _handleIndicationPicker(role, origin, drugOptions[0], noDiagnosis);
    if (sessionStorage.getItem(SS_MANUAL_DRUG)) {
      _showDrugNoteInline(role, origin, 'drugNameWSearchNoteQ', drugOptions[0].notes || null);
    } else {
      _showDrugNoteInAlert(drugOptions[0].drugName, drugOptions[0].notes || null);
    }
  } else {
    const sel = document.getElementById(`${role}${origin}formAltsDrugPickerQsel`);
    if (sel) {
      sel.innerHTML = '<option value="">Select...</option>';
      drugOptions.forEach((drug, i) => {
        const opt = document.createElement('option');
        opt.value = i;
        opt.textContent = drug.drugName;
        sel.appendChild(opt);
      });
      sel.onchange = () => {
        const idx = parseInt(sel.value, 10);
        if (!isNaN(idx)) {
          // Drug changed -indication and fetch results are invalid; reset cascade.
          sessionStorage.setItem(SS_DRUG, drugOptions[idx].drugName);
          _fireDrugChanged(role, origin, drugOptions[idx].drugName);
          sessionStorage.removeItem(SS_AUTOMATED_INDICATION);
          sessionStorage.removeItem(SS_FINAL_INDICATION);
          sessionStorage.removeItem(SS_FETCH);
          sessionStorage.removeItem(SS_FETCH_SUB);
          resetFormAltsDLTFields(role, origin);
          _setContainerHtml(role, origin, '');
          toggleDisplay('solo', [`${role}${origin}formAltsIndicationQ`], 'disable');
          toggleDisplay('solo', [`${role}${origin}formAltsListQ`],       'disable');
          const _notes = drugOptions[idx].notes || null;
          if (sessionStorage.getItem(SS_MANUAL_DRUG)) {
            _showDrugNoteInline(role, origin, 'drugPickerNoteQ', _notes);
          } else {
            _showDrugNoteInAlert(drugOptions[idx].drugName, _notes);
          }
          _handleIndicationPicker(role, origin, drugOptions[idx], noDiagnosis);
        }
      };
    }
    toggleDisplay('solo', [`${role}${origin}formAltsDrugPickerQ`], 'enable');
  }
}

function _handleIndicationPicker(role, origin, drug, noDiagnosis = false) {
  sessionStorage.removeItem(SS_AUTOMATED_INDICATION);
  sessionStorage.removeItem(SS_FINAL_INDICATION);

  const fieldset = document.getElementById(`${role}${origin}formAltsIndicationQ`);
  const formGroup = fieldset?.querySelector('.form-group');
  if (!formGroup) return;

  const rdoName = `${role}${origin}formAltsIndicationRdo`;
  const indications = drug.indications || [];
  const autoSelected = drug.autoSelectedIndication;

  let html = '';
  if (!autoSelected && noDiagnosis) {
    html += '<div class="alert alert-info mb-2">Diagnosis information not available - auto-match could not be performed. Select the most appropriate indication below.</div>';
    _appendFormAltsError('Indication auto-match skipped - diagnosis not available from medhok');
  }
  html += `<table class="table table-sm table-bordered mb-1">
    <thead class="table-light">
      <tr>
        <th>Diagnosis</th>
        <th>ICD-10</th>
        <th class="text-center" style="width:130px">Diagnosis Match${autoSelected ? ' <span class="text-primary fw-bold">*</span>' : ''}</th>
      </tr>
    </thead>
    <tbody>`;

  const sortedIndications = [...indications].sort((a, b) => a.indication.localeCompare(b.indication));
  sortedIndications.forEach(({ indication, icd10List }, i) => {
    const id = `${rdoName}${i}`;
    const isAuto = indication === autoSelected;
    html += `
      <tr data-ind-row style="cursor:pointer"${isAuto ? ' class="table-success"' : ''}>
        <td>${indication}</td>
        <td>${icd10List || '-'}</td>
        <td class="text-center">
          <input class="form-check-input form-alts-ind-rdo" type="radio"
                 name="${rdoName}" id="${id}" value="${indication}"${isAuto ? ' checked' : ''}>
        </td>
      </tr>`;
  });

  const noneId = `${rdoName}none`;
  const naId   = `${rdoName}na`;
  html += `
      <tr data-ind-row style="cursor:pointer">
        <td colspan="2" class="fst-italic text-muted">None of the above</td>
        <td class="text-center">
          <input class="form-check-input form-alts-ind-rdo" type="radio"
                 name="${rdoName}" id="${noneId}" value="__none__">
        </td>
      </tr>
      <tr data-ind-row style="cursor:pointer">
        <td colspan="2" class="fst-italic text-muted">N/A - no diagnosis provided</td>
        <td class="text-center">
          <input class="form-check-input form-alts-ind-rdo" type="radio"
                 name="${rdoName}" id="${naId}" value="__na__">
        </td>
      </tr>
    </tbody>
  </table>`;

  if (autoSelected) {
    html += `<div class="text-muted small mb-2"><span class="text-primary fw-bold">*</span> Auto-matched based on patient's primary ICD-10</div>`;
    sessionStorage.setItem(SS_AUTOMATED_INDICATION, autoSelected);
    sessionStorage.setItem(SS_FINAL_INDICATION, autoSelected);
    _writeFormAltsAudit({ automatedIndication: autoSelected, indicationSelected: autoSelected });
  }

  formGroup.innerHTML = html;

  toggleDisplay('solo', [`${role}${origin}formAltsIndicationQ`], 'enable');

  formGroup.onchange = (e) => {
    if (!e.target.classList.contains('form-alts-ind-rdo')) return;

    formGroup.querySelectorAll('tr[data-ind-row]').forEach((tr) => tr.classList.remove('table-success'));
    e.target.closest('tr')?.classList.add('table-success');

    // Indication changed -clear previous fetch result before loading new one.
    sessionStorage.removeItem(SS_FETCH);
    sessionStorage.removeItem(SS_FETCH_SUB);
    resetFormAltsDLTFields(role, origin);
    _setContainerHtml(role, origin, '');
    toggleDisplay('solo', [`${role}${origin}formAltsListQ`], 'disable');

    // Re-enable approveDiagoQ whenever an indication is selected (any row).
    if (origin !== 'SR') {
      toggleDisable([`${role}${origin}approveDiagoQ`], 'enable');
    }

    const val = e.target.value;
    const _automated = sessionStorage.getItem(SS_AUTOMATED_INDICATION);
    if (val === '__none__') {
      if (role === 'tech') {
        _setContainerHtml(
          role, origin,
          '<div class="alert alert-warning mb-0 text-primary"><strong>Clinical Review Required:</strong> The patient\'s diagnosis does not match any available indication. Escalate to Clinical Review.</div>'
        );
        toggleDisplay('solo', [`${role}${origin}formAltsListQ`], 'enable');
        sessionStorage.setItem(SS_FINAL_INDICATION, '__none__');
        _writeFormAltsAudit({ indicationSelected: 'N/A' });
        _setIndicationApprovableDiagnosis(role, origin, 'No');
        refreshVerbiageIfActive(role, origin);
        return;
      }
      _setIndicationApprovableDiagnosis(role, origin, 'No');
      sessionStorage.setItem(SS_FINAL_INDICATION, '');
      _writeFormAltsAudit({ indicationSelected: 'N/A' });
    } else if (val === '__na__') {
      // No diagnosis provided — fetch all formulary alternatives without indication filter.
      sessionStorage.setItem(SS_FINAL_INDICATION, '');
      _writeFormAltsAudit({ indicationSelected: 'N/A - no diagnosis' });
      _setIndicationApprovableDiagnosis(role, origin, 'N/A');
      refreshVerbiageIfActive(role, origin);
      _tryFetch(role, origin);
      return;
    } else {
      sessionStorage.setItem(SS_FINAL_INDICATION, val);
      _writeFormAltsAudit({ indicationSelected: val });
      _setIndicationApprovableDiagnosis(role, origin, 'Yes');
    }
    refreshVerbiageIfActive(role, origin);
    _tryFetch(role, origin);
  };

  formGroup.onclick = (e) => {
    const row = e.target.closest('tr[data-ind-row]');
    if (!row) return;
    const radio = row.querySelector('.form-alts-ind-rdo');
    if (radio && !radio.checked) radio.click();
  };

  if (autoSelected) {
    _tryFetch(role, origin);
  }
}

// Sets approveDiagoQ radio and stores the indication-based answer in sessionStorage.
// Runs immediately on indication selection for both tech and rph roles so the
// answer is available even if automateDLTGuidelines re-runs after the fetch completes.
function _setIndicationApprovableDiagnosis(role, origin, answer) {
  const suffix = answer === 'Yes' ? 'approveDiagoQYes'
               : answer === 'No'  ? 'approveDiagoQNo'
               : 'approveDiagoQNA';
  const btn = document.getElementById(`${role}${origin}${suffix}`);
  if (btn) { btn.checked = true; btn.click(); }
  sessionStorage.setItem('indicationBasedApprovableDiagnosis', answer);
  sessionStorage.setItem('dltAutomatedApprovableDiagnosisFieldAns', answer);
  sessionStorage.setItem('dltFinalApprovableDiagnosisFieldAns', answer);
}

async function _tryFetch(role, origin) {
  // Don't fetch unless NF request reason is currently active
  if (!sessionStorage.getItem(SS_NF_ACTIVE)) return;
  const formularyId = sessionStorage.getItem(SS_FORMULARY);
  const drugName    = sessionStorage.getItem(SS_DRUG);
  const indication  = sessionStorage.getItem(SS_FINAL_INDICATION);

  // null = never set / reset → no indication chosen, skip fetch.
  // '__none__' = tech "None of above" → no fetch.
  // '' = RPH "None of above" → fetch with empty indication (API accepts this).
  if (!formularyId || !drugName || indication === null || indication === '__none__') return;

  _setContainerHtml(role, origin, '<div class="text-muted p-2">Loading formulary alternatives…</div>');
  toggleDisplay('solo', [`${role}${origin}formAltsListQ`], 'enable');

  try {
    const _medhok = JSON.parse(sessionStorage.getItem('originalMedhokResponse') || '{}');
    const memberId = _medhok.memberId?.trim() || null;
    const receivedDate = _medhok.receivedDate ? _medhok.receivedDate.split('T')[0] : null;
    const result = await fetchFormAlts(formularyId, drugName, indication, memberId, receivedDate);
    sessionStorage.setItem(SS_FETCH, JSON.stringify(result));
    _renderList(role, origin, result);
  } catch (err) {
    console.error('[FormAlts] fetchFormAlts failed:', err);
    _writeFormAltsAudit({ altsStatus: 'Fetch failed', formularyAltsDisplayed: 'N/A', rfiFormAlts: 'N/A', denialFormAlts: 'N/A' });
    _appendFormAltsError(`FormAlts fetch failed: ${err?.message || 'API error'}`);
    _setContainerHtml(role, origin, '<div class="alert alert-danger mb-0">Failed to load formulary alternatives.</div>');
  }
}

function _doSave(role, origin, container, submitBtn) {
  const _rawTfReq = submitBtn.dataset.tfRequired;
  const tfRequired = (_rawTfReq === '' || _rawTfReq === undefined) ? null : parseInt(_rawTfReq, 10);
  const rfiUnchecked = [...container.querySelectorAll('.form-alts-rfi-chk:not(:checked)')].map((cb) => ({ formularyAlternative: cb.dataset.label, gpi10: cb.dataset.gpi10, groupId: cb.dataset.groupId }));
  const rfiChecked   = [...container.querySelectorAll('.form-alts-rfi-chk:checked')].map((cb) => ({ formularyAlternative: cb.dataset.label, gpi10: cb.dataset.gpi10, groupId: cb.dataset.groupId }));
  sessionStorage.setItem(SS_FETCH_SUB, JSON.stringify({ rfiChecked, rfiUnchecked, tfRequired }));
  automateDLTGuidelineFieldsBasedOnFormAlts(role, origin);
  const saved = getFormAltsValues(role, origin);
  _writeFormAltsAudit({
    rfiFormAlts:        saved?.finalRfiFormAlts    || 'N/A',
    rfiFormAltsChecked: saved?.rfiChecked?.length > 0
      ? saved.rfiChecked.map(alt => alt.formularyAlternative).join(', ')
      : 'N/A',
    denialFormAlts:     saved?.finalDenialFormAlts || 'N/A',
  });
  refreshVerbiageIfActive(role, origin);
  submitBtn.textContent = 'Confirmed ✓';
  submitBtn.className = 'btn btn-success';
}

function _renderList(role, origin, result) {
  const rfiAlts    = result?.rfi?.alternatives   || [];
  const denialAlts = result?.denial?.alternatives || [];
  const tfRequired = result?.rfi?.tfRequired ?? null;

  // Automate dltShow0TFAltsQ on fetch — tfRequired is known immediately from the API response,
  // independent of which T/F checkboxes the tech selects before saving.
  // Clear triedNFailed stored answer first so the 100ms toggle callback triggered by clicking
  // dltShow0TFAltsQ doesn't re-apply a stale answer from a previous save.
  sessionStorage.removeItem("dltAutomatedTriedNFailedFormAltsQAnswer");
  sessionStorage.removeItem("dltFinalTriedNFailedFormAltsQAnswer");
  if (Number.isFinite(tfRequired)) {
    automateDLTShow0TFAltsQ(tfRequired, role, origin);
  } else {
    sessionStorage.removeItem("dltAutomatedShow0TFAltsQAnswer");
    sessionStorage.removeItem("dltFinalShow0TFAltsQAnswer");
  }

  const _hasAlts = rfiAlts.length > 0 || denialAlts.length > 0;
  _writeFormAltsAudit({
    altsStatus:             _hasAlts ? `Found - RFI: ${rfiAlts.length}, Denial: ${denialAlts.length}` : 'No alternatives found',
    formularyAltsDisplayed: _hasAlts ? `RFI: ${rfiAlts.length}, Denial: ${denialAlts.length}` : 'None found',
    rfiFormAlts:            rfiAlts.length > 0 ? null : 'N/A',   // updated with actual list on Save
    denialFormAlts:         denialAlts.length > 0 ? null : 'N/A', // updated with actual list on Save
  });

  if (rfiAlts.length === 0 && denialAlts.length === 0) {
    _setContainerHtml(role, origin, '<div class="alert alert-info mb-0">No formulary alternatives found.</div>');
    return;
  }

  const submitBtnId  = `${role}${origin}formAltsSubmitBtn`;
  const copyAltsBtnId = `${role}${origin}formAltsCopyBtn`;
  let html = '';

  if (rfiAlts.length > 0) {
    html += `<table class="table table-sm table-bordered mb-3">
      <thead class="table-light">
        <tr>
          <th>Formulary Alternative</th>
          <th class="text-center" style="width:130px">Previously T/F</th>
        </tr>
      </thead>
      <tbody>`;
    rfiAlts.forEach((alt, i) => {
      const id = `${role}${origin}formAltsRFIChk${i}`;
      html += `
        <tr>
          <td>${alt.formularyAlternative}</td>
          <td class="text-center">
            <input class="form-check-input form-alts-rfi-chk" type="checkbox"
                   id="${id}" data-label="${alt.formularyAlternative}"
                   data-gpi10="${alt.gpi10}" data-group-id="${alt.formularyAlternativeGroupId}"${alt.autoCheck ? ' checked' : ''}>
          </td>
        </tr>`;
    });
    html += '</tbody></table>';
  }

  // Denial Formulary Alternatives are not required to display in the UI
  // if (denialAlts.length > 0) {
  //   html += `<p class="fw-semibold mb-1">Formulary Alternatives (Denial Letter) THIS IS ONLY FOR DEMO AND WILL BE REMOVED:</p>
  //   <table class="table table-sm table-bordered mb-3">
  //     <thead class="table-light">
  //       <tr>
  //         <th>Formulary Alternative</th>
  //         <th class="text-center" style="width:130px">Previously T/F</th>
  //       </tr>
  //     </thead>
  //     <tbody>`;
  //   denialAlts.forEach((alt, i) => {
  //     const id = `${role}${origin}formAltsDALChk${i}`;
  //     html += `
  //       <tr>
  //         <td>${alt.formularyAlternative}</td>
  //         <td class="text-center">
  //           <input class="form-check-input form-alts-dal-chk" type="checkbox"
  //                  id="${id}" data-label="${alt.formularyAlternative}"
  //                  data-gpi10="${alt.gpi10}" data-group-id="${alt.formularyAlternativeGroupId}">
  //         </td>
  //       </tr>`;
  //   });
  //   html += '</tbody></table>';
  // }

  html += `<div class="d-flex align-items-center gap-3 mt-1">
    <div>
      <span class="fw-semibold">Number of T/F Required:</span>
      <span class="badge bg-primary ms-1">${tfRequired}</span>
    </div>
    <button type="button" class="btn btn-success" id="${submitBtnId}" data-tf-required="${tfRequired ?? ''}">Confirm Alts</button>
    <button type="button" class="btn btn-copy" id="${copyAltsBtnId}">📋 Copy Alts</button>
  </div>`;

  _setContainerHtml(role, origin, html);

  const autoCheckedAlts = rfiAlts.filter(a => a.autoCheck).map(a => a.formularyAlternative);
  const _claimsMemberId = JSON.parse(sessionStorage.getItem('originalMedhokResponse') || '{}').memberId?.trim() || null;
  _writeFormAltsAudit({
    claimsCheckStatus:    !_claimsMemberId ? 'skipped' : (autoCheckedAlts.length > 0 ? 'auto-checked' : 'no_claims'),
    claimsAutoCheckedAlts: autoCheckedAlts.length > 0 ? autoCheckedAlts.join(', ') : 'None',
  });

  const container = document.getElementById(`${role}${origin}formAltsListQcontainer`);
  const submitBtn = document.getElementById(submitBtnId);

  // Re-signal pending state if user toggles a T/F checkbox after saving
  container.querySelectorAll('.form-alts-rfi-chk').forEach((chk) => {
    chk.addEventListener('change', () => {
      submitBtn.textContent = 'Confirm Alts';
      submitBtn.className = 'btn btn-success';
    });
  });

  submitBtn.addEventListener('click', () => {
    _doSave(role, origin, container, submitBtn);
  });

  const copyAltsBtn = document.getElementById(copyAltsBtnId);
  copyAltsBtn.addEventListener('click', () => {
    const unchecked = [...container.querySelectorAll('.form-alts-rfi-chk:not(:checked)')]
      .map(cb => cb.dataset.label)
      .filter(Boolean)
      .join(', ');
    if (!unchecked) {
      copyAltsBtn.textContent = '— Nothing to copy';
      setTimeout(() => { copyAltsBtn.textContent = '📋 Copy Alts'; }, 1500);
      return;
    }
    navigator.clipboard.writeText(unchecked).then(() => {
      copyAltsBtn.textContent = '✓ Copied!';
      copyAltsBtn.classList.replace('btn-copy', 'btn-copy-success');
      setTimeout(() => {
        copyAltsBtn.textContent = '📋 Copy Alts';
        copyAltsBtn.classList.replace('btn-copy-success', 'btn-copy');
      }, 1500);
    });
  });
}

function _setContainerHtml(role, origin, html) {
  const container = document.getElementById(`${role}${origin}formAltsListQcontainer`);
  if (container) container.innerHTML = html;
}

// Called from each qset's client change handler.
// Resets formulary/drug/indication state and re-runs formulary resolution for the new client.
// Always re-resolves formulary for the new client regardless of whether a drug lookup exists —
// the drug lookup check is deferred to onResolved so we don't bail when no drug is selected yet.
export function refreshFormAltsOnClientChange(role, origin) {
  // Clear the CAG auto-resolve result from the previous client. Without this, resolveFormularyUI
  // would short-circuit on the stale SS_AUTO_RESOLVE and silently keep the old formulary ID.
  sessionStorage.removeItem(SS_RESOLVE);

  // Client changed - previous formulary/drug/indication are all invalid; reset cascade.
  resetSubegwpDropdown(role, origin);
  sessionStorage.removeItem(SS_FORMULARY);
  toggleDisplay('solo', [`${role}${origin}subFormularyIDQ`],    'disable');
  toggleDisplay('solo', [`${role}${origin}formularySubclientQ`], 'disable');
  toggleDisplay('solo', [`${role}${origin}formularyDropdownQ`],  'disable');
  toggleDisplay('solo', [`${role}${origin}formularyIdQ`],        'disable');
  const _fDropdownSel = document.getElementById(`${role}${origin}formularyDropdownQsel`);
  if (_fDropdownSel) _fDropdownSel.innerHTML = '<option value="">Select formulary…</option>';
  _resetDownstream(role, origin);
  resolveFormularyUI(role, origin, 'formulary', {
    onResolved: () => {
      _writeFormAltsAudit({ formularyId: sessionStorage.getItem(SS_FORMULARY) || 'N/A', formularyIdSource: sessionStorage.getItem(SS_FORMULARY_SOURCE) });
      // Drug lookup may not exist yet (client changed before drug was searched) — only
      // re-render the drug picker if a supported lookup result is available.
      const lookupResult = JSON.parse(sessionStorage.getItem(SS_LOOKUP) || 'null');
      if (!lookupResult || !lookupResult.supported) return;
      _resetDownstream(role, origin);
      _handleDrugPicker(role, origin, lookupResult.drugOptions || []);
      _fireAfterFormularyResolved(role, origin);
    },
    onNotAvailable: () => {
      _writeFormAltsAudit({ formularyId: 'N/A', formularyIdSource: 'na' });
      sessionStorage.removeItem(SS_FORMULARY);
      _resetDownstream(role, origin);
      _setContainerHtml(role, origin, '<div class="alert alert-secondary mb-0">Formulary ID not available - formulary alternatives lookup skipped.</div>');
      toggleDisplay('solo', [`${role}${origin}formAltsListQ`], 'enable');
    },
    onReset: () => _resetDownstream(role, origin),
  });
}

// Called from each template's client change handler when request reason is NOT NF/QL.
// Clears the previous formulary and shows the resolution UI for the new client so the
// formulary is ready by the time the user selects NF/QL.
export async function resolveFormularyForClient(role, origin) {
  sessionStorage.removeItem(SS_FORMULARY);
  sessionStorage.removeItem(SS_FORMULARY_SOURCE);
  // Clear NF-active flag synchronously before the await. A stale value left over from a
  // previous case load (sessionStorage survives soft reloads within the same tab) would
  // cause the guard below to fire on the very first case, hiding the formulary UI forever.
  // showFormAltsSection re-sets this flag when the RR change fires — that always happens
  // after this synchronous block — so the guard still works for the prefill race.
  sessionStorage.removeItem(SS_NF_ACTIVE);
  // Clear the stale CAG auto-resolve from the previous client — without this, initFormAlts
  // returns the cached promise from the previous client, SS_RESOLVE still holds the old
  // formularyId, and resolveFormularyUI fast-paths without ever showing the dropdown.
  sessionStorage.removeItem(SS_RESOLVE);
  _clearInitCache(role, origin);
  // Reset all formulary resolution UI - a previous NF/QL flow may have left the dropdown visible
  resetSubegwpDropdown(role, origin);
  toggleDisplay('solo', [`${role}${origin}subFormularyIDQ`],     'disable');
  toggleDisplay('solo', [`${role}${origin}formularySubclientQ`], 'disable');
  toggleDisplay('solo', [`${role}${origin}formularyDropdownQ`],  'disable');
  toggleDisplay('solo', [`${role}${origin}formularyIdQ`],        'disable');
  const _formularyDropdownSel = document.getElementById(`${role}${origin}formularyDropdownQsel`);
  if (_formularyDropdownSel) _formularyDropdownSel.innerHTML = '<option value="">Select formulary…</option>';
  // Await CAG formulary resolve so SS_AUTO_RESOLVE is set before resolveFormularyUI checks it
  await initFormAlts(role, origin);

  // If showFormAltsSection fired while we were awaiting init (NF selected during prefill),
  // it already set SS_NF_ACTIVE and will own the resolveFormularyUI call.
  // Returning here prevents a second concurrent call that would race and overwrite its handler.
  if (sessionStorage.getItem(SS_NF_ACTIVE)) return;
  // Same guard for QL: showQlSection sets 'qlActive' before its initFormAlts await,
  // so if QL was selected while this prefetch was running, it now owns resolution.
  if (sessionStorage.getItem('qlActive')) return;

  // Pre-populate formulary if CAG resolved it
  const earlyResolve = JSON.parse(sessionStorage.getItem(SS_RESOLVE) || 'null');
  if (earlyResolve?.found && earlyResolve?.formularyId) {
    sessionStorage.setItem(SS_FORMULARY, earlyResolve.formularyId);
    sessionStorage.setItem(SS_FORMULARY_SOURCE, 'auto');
  }
  resolveFormularyUI(role, origin, 'formulary', {
    onResolved: () => {
      _showDrugPickersIfReady(role, origin);
    },
    onNotAvailable: () => {},
    onReset: () => _resetDownstream(role, origin),
  });
}

export function getFormAltsValues(role, origin) {
  const fetchResult = JSON.parse(sessionStorage.getItem(SS_FETCH) || 'null');
  if (!fetchResult) return null;

  const base = {
    formularyId        : sessionStorage.getItem(SS_FORMULARY),
    drugName           : sessionStorage.getItem(SS_DRUG),
    automatedIndication: sessionStorage.getItem(SS_AUTOMATED_INDICATION),
    finalIndication         : sessionStorage.getItem(SS_FINAL_INDICATION),
    tfRequired         : fetchResult.rfi?.tfRequired ?? null,
    denialAlternatives : fetchResult.denial?.alternatives || [],
  };

  const submitted = JSON.parse(sessionStorage.getItem(SS_FETCH_SUB) || 'null');
  if (submitted) {
    const rfiChecked = submitted.rfiChecked || [];
    const rfiUnchecked = submitted.rfiUnchecked || [];
    
    // Format final RFI FormAlts (unchecked) as comma-separated
    const finalRfiFormAlts = rfiUnchecked
      .map((alt) => alt.formularyAlternative)
      .join(", ");

    // Get tried/failed groupIds from rfiChecked (convert to numbers for consistent comparison)
    const triedFailedGroupIds = new Set(rfiChecked.map((alt) => Number(alt.groupId)));
    
    // Filter denial alternatives to exclude tried/failed groupIds, format as line-by-line
    const finalDenialFormAlts = base.denialAlternatives
      .filter((alt) => !triedFailedGroupIds.has(alt.formularyAlternativeGroupId))
      .map((alt) => alt.formularyAlternative)
      .join("\n");

    return {
      ...base,
      rfiChecked,
      rfiUnchecked,
      finalRfiFormAlts,
      finalDenialFormAlts,
    };
  }

  const container = document.getElementById(`${role}${origin}formAltsListQcontainer`);
  const rfiUnchecked = container
    ? [...container.querySelectorAll('.form-alts-rfi-chk:not(:checked)')].map((cb) => ({ formularyAlternative: cb.dataset.label, gpi10: cb.dataset.gpi10, groupId: cb.dataset.groupId }))
    : [];
  const rfiChecked = container
    ? [...container.querySelectorAll('.form-alts-rfi-chk:checked')].map((cb) => ({ formularyAlternative: cb.dataset.label, gpi10: cb.dataset.gpi10, groupId: cb.dataset.groupId }))
    : [];

  // Format final RFI FormAlts (unchecked) as comma-separated
  const finalRfiFormAlts = rfiUnchecked
    .map((alt) => alt.formularyAlternative)
    .join(", ");

  // Get tried/failed groupIds from rfiChecked (convert to numbers for consistent comparison)
  const triedFailedGroupIds = new Set(rfiChecked.map((alt) => Number(alt.groupId)));
  
  // Filter denial alternatives to exclude tried/failed groupIds, format as line-by-line
  const finalDenialFormAlts = base.denialAlternatives
    .filter((alt) => !triedFailedGroupIds.has(alt.formularyAlternativeGroupId))
    .map((alt) => alt.formularyAlternative)
    .join("\n");

  return { ...base, rfiChecked, rfiUnchecked, finalRfiFormAlts, finalDenialFormAlts };
}
