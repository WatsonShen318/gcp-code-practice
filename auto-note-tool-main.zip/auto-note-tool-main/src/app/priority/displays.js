import { isFlowAutomated } from '../prefill/helpers';
import { toggleDisplay } from '../utils/notetool.display';

export function toggleIndication(o, r, a) {
  if (r === 'tech' && !isFlowAutomated()) {
    if (a === 'Expedited') {
      toggleDisplay('solo', [`${r}${o}subExpReasonQ`], 'enable');
    } else {
      toggleDisplay('solo', [`${r}${o}subExpReasonQ`], 'disable');
    }
  }
}

/**
 * Toggle Priority Sub Question Indication for expedited request when Priority = Expedited is selected
 * @param {string} Priority
 */
export function priorityExpDetails(Priority) {
  const status = Priority === 'Expedited' ? 'enable' : 'disable';
  toggleDisplay('solo', ['subiExpQ'], status);
}

/**
 * Toggle reminder when Is request a RM Task? = Yes is selected
 * @param {string} origin
 * @param {string} role
 * @param {string} answer
 */

export function toggleRMPriorityReminder(origin, role, answer) {
  const status = answer === 'Yes' ? 'enable' : 'disable';
  toggleDisplay('solo', [`${role}${origin}rmTaskPriorityHUP`], status);
}
