import { GeneralModal } from '../modal/alert.service';
import { bold } from '../utils/font.formatter';

export default function msgPriority(o, r, a) {
  if (a === 'Expedited') {
    GeneralModal({
      message: bold(
        'Please verify the expedited radio button has been populated in MHK.'
      ),
      icon: 'notification_important',
    });
  }
  //AMN 7/14/22 - #101 - New [Priority] = 'Standard' Pop-Up Alert
  var radios = document.getElementsByName('techIBCrmTaskQrdo');
  var value;
  for (var i = 0; i < radios.length; i++) {
      if (radios[i].type === 'radio' && radios[i].checked) {
          value = radios[i].value;       
      }
  }
  if (value === "Yes" && a === 'Standard') {
    GeneralModal({
      message: bold(
        'Review for any indicators of priority before continuing including the Type box and Notes History sections of the RM Task.<br/><br/>Note: Incorrect case priority can result in an out of compliance or auto-forward case.'
      ),
      icon: 'notification_important',
    });
  }

  if (a === 'Standard' && r === 'tech' && o === 'Queue') {
    GeneralModal({
      message: bold(
        'If the fax contains a letter of medical necessity from the MDO, did you check the letter completely for priority indicators?<br/><br/> If not, review for priority indicators prior to continuing.'
      ),
      icon: 'notification_important',
    });
  }
}
