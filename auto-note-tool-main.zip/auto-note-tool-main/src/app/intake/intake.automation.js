export default function SubDrugQAnswers(a) {
  if (a.toLowerCase().includes('compound')) {
    document.getElementById('subiDrugNameCompQYes').checked = true;
  } else {
    document.getElementById('subiDrugNameCompQNo').checked = true;
  }
  // //CAN 2/22/23 - Feb 2023 Enhancement - #116: Client drop down update for HealthFirst
  if (a.toLowerCase().includes('tadalafil')) {
    document.getElementById('intakedrugHUP_Intake').style.display = 'block';
  }
  else
  {
    document.getElementById('intakedrugHUP_Intake').style.display = 'none';
  }
} 
