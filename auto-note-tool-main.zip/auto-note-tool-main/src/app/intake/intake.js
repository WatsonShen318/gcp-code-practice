//AMN 12/8/22 - December 2022 Enhancement - #113: Intake Update for BCBS of MASS
// import { iPriorityPopup, MAonlyPopUp } from './intake.dialogs';
import { iPriorityPopup, MAonlyPopUp, BCBSonlyPopUp } from './intake.dialogs';
import FinalNotes from '../finalnote/final.note';
import { MultiCaseBalance, MultiCaseBalIncrement } from '../multiCase/math';
import {
  RqstTypeChanged,
  FinalVerify,
  CheckMemberPplSafe,
  TierRqst,
  IdFoundMHK,
  DrugNameCompReminder,
} from './intake.display';
// import { member } from '../qsets/fields';
// import { handleMember } from '../shared/clickEvents';
import {
  ClearByRqstType,
  ClearPriorityDetails,
  ClearTierRqst,
  ClearRqstType,
  ClearMemPplSafe,
} from '../reset/intake.reset';
import { toggleDisplay } from '../utils/notetool.display';
import { clearInput } from '../utils/clearInput';
import SubDrugQAnswers from './intake.automation';
import { ele, rdoBtn } from '../utils/inputSelect';
import { togglepplSafeBadge } from '../aor/aor.display';
import { priorityExpDetails } from '../priority/displays';
import {
  toggleMultiDrugRqst,
  toggleMultiRqstDetail,
} from '../multiCase/display';
import { member } from '../qsets/fields';
import { handleMember } from '../shared/clickEvents';
import resetSessionStorage from '../utils/resetSessionStorage';

let answer = null;

rdoBtn('iRqstTypeQ').forEach((elem) => {
  elem.addEventListener('change', (e) => {
    const RqstType = e.target.value;
    ClearByRqstType(RqstType);
    RqstTypeChanged(RqstType);
    FinalVerify();
    // & Multiple Drug or Request Question Reset
    toggleMultiDrugRqst();
    toggleMultiRqstDetail('reset');
    // & Tiering Request question Reset
    TierRqst();
    // & Priority Reset
    priorityExpDetails('reset');
    ClearPriorityDetails();
  });
});

// $  Trashed Fax - Stop the tool and generate note

rdoBtn('itrashFaxQ').forEach((elem) => {
  elem.addEventListener('change', (e) => {
    resetSessionStorage();
    answer = e.target.value;
    // const l = document.getElementById('userLocation').value;
    const NotTrashed = document.getElementById('itrashFaxNOgrp');

    document.getElementById('buttonSection').style.display = 'block';
    if (answer === 'Yes') {
      FinalNotes('intake', 'all', 'trash');
    } else if (answer === 'No') {
      NotTrashed.style.display = 'block';
      document.getElementById('subiDrugNameCompQNo').checked = true;
      document.getElementById('generateNotebtn').style.display = 'block';
      document.getElementById('memberidsQ').style.display = 'none';
      document.getElementById('validatedMemberQ').style.display = 'none';
    }
  });
});

// $ member Compass Clicked
rdoBtn('imempplsafeQ').forEach((elem) => {
  elem.addEventListener('change', (e) => {
    answer = e.target.value;
    CheckMemberPplSafe(answer);
    toggleMultiDrugRqst();
    TierRqst();
  });
});

// $ Member Ids Clicked
member('','', 'event').forEach((elem) => {
  elem.addEventListener('click', (e) => {
    handleMember(e, '', '');
  });
});

// $ hospiceFax clicked
rdoBtn('ihopsiceFaxQ').forEach((elem) => {
  elem.addEventListener('change', (e) => {
    const a = e.target.value;
    const hospAdmin = document.getElementById('subihospiceadminQ');

    hospAdmin.style.display = a === 'Yes' ? 'block' : 'none';
    hospAdmin.disabled = a !== 'Yes';

    clearInput('radio', ['subihospiceadminQrdo']);
  });
});

// $ hospice Admission click
rdoBtn('subihospiceadminQ').forEach((elem) => {
  elem.addEventListener('change', (e) => {
    answer = e.target.value;
    if (answer === 'Yes') {
      FinalNotes('intake', 'all', 'IntakeHospice');
    }
  });
});

rdoBtn('memberQ').forEach((elem) => {
  elem.addEventListener('change', (e) => {
    const MemberFound = e.target.value;
    const RequestTypeRequired = document.getElementById('iRqstTypeQNewCase');

    RqstTypeChanged('member');
    CheckMemberPplSafe('reset');
    ClearRqstType();
    MAonlyPopUp(MemberFound);
    //AMN 12/8/22 - December 2022 Enhancement - #113: Intake Update for BCBS of MASS
    BCBSonlyPopUp(MemberFound);
    ClearMemPplSafe();
    IdFoundMHK(MemberFound);
    toggleMultiDrugRqst();

    if (MemberFound !== 'Not found') {
      toggleDisplay('solo', ['memberidsQ'], 'disable');
      toggleDisplay('solo', ['validatedMemberQ'], 'enable');
    } else {
      toggleDisplay('solo', ['memberidsQ'], 'disable');
      toggleDisplay('solo', ['validatedMemberQ'], 'disable');
    }
    // ! allowed to have blank on the rquest type for Member Found Not Found
    RequestTypeRequired.required = MemberFound !== 'Not found';
    // ! allowed to have blank on the rquest type for Member Found Not Found
  });
});

//* Compass Badge
ele(`imempplsafeQbadge`).addEventListener('click', () => {
  togglepplSafeBadge();
});

// $Priority change

rdoBtn('iPriorityQ').forEach((elem) => {
  elem.addEventListener('change', (e) => {
    answer = e.target.value;
    priorityExpDetails(answer);
    ClearPriorityDetails();
    iPriorityPopup(answer);
  });
});

// //$ multi member selected

rdoBtn('iMultiMemberQ').forEach((elem) => {
  elem.addEventListener('change', (e) => {
    answer = e.target.value;
    const MemberQs = 'subiMultiMemberQ';
    if (answer === 'Yes') {
      toggleDisplay('solo', [MemberQs], 'enable');
    } else {
      clearInput('radio', ['subiMultiMemberQrdo']);
      toggleDisplay('solo', [MemberQs], 'disable');
    }
  });
});

// $ fax indicated drug compound? clicked
rdoBtn('subiDrugNameCompQ').forEach((elem) => {
  elem.addEventListener('change', (e) => {
    answer = e.target.value;
    DrugNameCompReminder(answer);
  });
});

// $ drug name text field change
document.getElementById('iDrugNameQtxt').addEventListener('change', (e) => {
  answer = e.target.value;
  SubDrugQAnswers(answer);
});

// $multi drug request change
rdoBtn('iMultirqstQ').forEach((elem) => {
  elem.addEventListener('change', (e) => {
    answer = e.target.value;
    toggleMultiRqstDetail(answer);
    TierRqst();
    ClearTierRqst();
  });
});

// $multi drug request case remain number changes
document
  .getElementById('multiRqstCaseTotaltxt')
  .addEventListener('change', (e) => {
    answer = e.target.value;
    MultiCaseBalance(answer);
  });
