import getInputValue from '../utils/getInputValue';
import { toggleDisplay } from '../utils/notetool.display';

let rdo;

export function FinalVerify() {
  rdo = getInputValue('radio', ['memberQrdo', 'iRqstTypeQrdo']);
  const FinalVerification = document.getElementById('iFverifyQ');

  if (
    rdo.memberQrdo === 'Not found' ||
    rdo.iRqstTypeQrdo === 'Re-route' ||
    rdo.iRqstTypeQrdo === 'Forward Fax'
  ) {
    FinalVerification.style.display = 'none';
    FinalVerification.disabled = true;
  } else if (
    rdo.memberQrdo !== 'Not found' ||
    rdo.iRqstTypeQrdo !== 'Re-route' ||
    rdo.iRqstTypeQrdo !== 'Forward Fax'
  ) {
    FinalVerification.style.display = 'block';
    FinalVerification.disabled = false;
  }
}

export function RqstTypeChanged(requestType) {
  switch (requestType) {
    case 'New Case':
      toggleDisplay(
        'solo',
        ['iPriorityQ', 'iMultiMemberQ', 'iDrugNameQ'],
        'enable'
      );
      toggleDisplay(
        'solo',
        ['iReRouteRatQ', 'iRTsecondRationQ', 'iRtFFaxQ'],
        'disable'
      );
      break;
    case 'Secondary Review':
      toggleDisplay(
        'solo',
        [
          'iPriorityQ',
          'iMultiMemberQ',
          'iDrugNameQ',
          'subiDrugNameCompQ',
          'iRTsecondRationQ', // & enable Secondary REview Rational Secondary Review
        ],
        'enable'
      );
      toggleDisplay('solo', ['iReRouteRatQ', 'iRtFFaxQ'], 'disable'); // & disable Re Route Rational Forward Fax Rational
      break;
    case 'Re-route':
      // & enable Re Route Rational
      toggleDisplay('solo', ['iReRouteRatQ'], 'enable');

      // & disable valid request
      // & disable Secondary REview Rational // & disable Forward Fax Rational // & disable Secondary Review
      toggleDisplay(
        'solo',
        [
          'iRTsecondRationQ',
          'iRtFFaxQ',
          'iPriorityQ',
          'iMultiMemberQ',
          'iDrugNameQ',
          'subiDrugNameCompQ',
          'iRDReimburseReqQ',
        ],
        'disable'
      );
      break;
    case 'Forward Fax':
      // & enable Forward Fax Rational
      toggleDisplay('solo', ['iRtFFaxQ'], 'enable');
      // & disable valid request
      // & disable Re Route Rational Secondary REview Rational Secondary Review
      toggleDisplay(
        'solo',
        [
          'iReRouteRatQ',
          'iRTsecondRationQ',
          'iPriorityQ',
          'iMultiMemberQ',
          'iDrugNameQ',
          'subiDrugNameCompQ',
        ],
        'disable'
      );
      break;
    default:
      //! this will enable default fields to show up
      toggleDisplay(
        'solo',
        ['iPriorityQ', 'iMultiMemberQ', 'iDrugNameQ', 'subiDrugNameCompQ'],
        'enable'
      );
      // & disable Re Route Rational Secondary REview Rational Forward Fax Rational Secondary Review
      toggleDisplay(
        'solo',
        ['iReRouteRatQ', 'iRTsecondRationQ', 'iRtFFaxQ'],
        'disable'
      );
      break;
  }
}

export function IdFoundMHK(found) {
  if (found === 'Not found' || found === 'highlighted in blue') {
    toggleDisplay('solo', ['iRqstTypeQ'], 'enable');
  } else {
    toggleDisplay('solo', ['iRqstTypeQ'], 'disable');
  }
  if (found === 'Not found') {
    toggleDisplay('solo', ['iFverifyQ'], 'disable');
    toggleDisplay('solo', ['imempplsafeQ'], 'enable');
  } else {
    toggleDisplay('solo', ['iFverifyQ'], 'enable');
    toggleDisplay('solo', ['imempplsafeQ'], 'disable');
  }
}

export function CheckMemberPplSafe(radio) {
  rdo = getInputValue('radio', ['iRqstTypeQrdo']); // Get Request Type Radio Values
  const rqst = rdo.iRqstTypeQrdo;
  if (radio === 'Yes') {
    //AMN 11/2/22 - #110: Reminder doesn't show up for Was the member found in Compass with 3 identifiers question
    // toggleDisplay('solo', ['iRqstTypeQ', 'intakeallmempplsafeHUP'], 'enable');
    toggleDisplay('solo', ['iRqstTypeQ', 'intakemempplsafeHUP'], 'enable');
    toggleDisplay('solo', ['iTierRqstQ'], 'disable');
    RqstTypeChanged(rqst);
  } else if (radio === 'No') {
    //AMN 11/2/22 - #110: Reminder doesn't show up for Was the member found in Compass with 3 identifiers question
    // toggleDisplay('solo', ['iRqstTypeQ', 'intakeallmempplsafeHUP'], 'disable');
    toggleDisplay('solo', ['iRqstTypeQ', 'intakemempplsafeHUP'], 'disable');
    toggleDisplay('solo', ['iTierRqstQ'], 'enable');
    toggleDisplay(
      'solo',
      ['iReRouteRatQ', 'iRTsecondRationQ', 'iRtFFaxQ'],
      'disable'
    );
  }
}

export function TierRqst() {
  rdo = getInputValue('radio', ['imempplsafeQrdo', 'iMultirqstQrdo']);
  if (rdo.imempplsafeQrdo === 'No' || rdo.iMultirqstQrdo !== 'No') {
    toggleDisplay('solo', ['iTierRqstQ'], 'disable');
  } else if (rdo.imempplsafeQrdo !== 'No' || rdo.iMultirqstQrdo === 'No') {
    toggleDisplay('solo', ['iTierRqstQ'], 'enable');
  }
}

export function DrugNameCompReminder(a) {
  if (a === 'Yes') {
    toggleDisplay('solo', ['intakeallDNameCompHUP'], 'enable');
  } else {
    toggleDisplay('solo', ['intakeallDNameCompHUP'], 'disable');
  }
}
