import { GeneralModal } from '../modal/alert.service';
import { bold } from '../utils/font.formatter';

export function iPriorityPopup(answer) {
  if (answer === 'Expedited') {
    GeneralModal({
      message: bold(
        'Please verify the expedited radio button has been populated in MHK.'
      ),
      icon: 'notification_important',
    });
  }
}

export function MAonlyPopUp(a) {
  if (a === 'MA') {
    GeneralModal({
      message: bold(
        "Update 'Request Type' to 'Organization Determination' and select the 'Request Reason' of 'Prior Authorization'."
      ),
      icon: 'notification_important',
    });
  }
}

 //AMN 12/8/22 - December 2022 Enhancement - #113: Intake Update for BCBS of MASS
 export function BCBSonlyPopUp(a) {
  if (a === 'BCBS of MASS') {
    GeneralModal({
      message: bold(
        "Request Type is Redetermination. Refer to BCBS of MASS client specific job aid."
      ),
      icon: 'notification_important',
    });
  }
}