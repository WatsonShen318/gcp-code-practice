import { toggleDisplay } from "../utils/notetool.display";
import DrugFlag from "../drugs/drugs";
import { drugName } from "../qsets/fields";
import { isFlowAutomated } from "../prefill/helpers";

export function toggleDrugeRef(o, r, a) {
  if (a === "Hospice") {
    toggleDisplay("solo", [`${r}${o}hospiceRefHUP`], "enable");
  } else {
    toggleDisplay("solo", [`${r}${o}hospiceRefHUP`], "disable");
  }
  if (o === "IBC") {
    const q = drugName(r, o, "value");
    const tag = DrugFlag(q);
    if (a === "Non-formulary" && tag === "Hep C") {
      toggleDisplay("solo", [`${r}${o}hepcHUP`], "enable");
    } else {
      toggleDisplay("solo", [`${r}${o}hepcHUP`], "disable");
    }
    if (a === "Non-formulary" && tag === "PCSK9") {
      toggleDisplay("solo", [`${r}${o}pcsk9HUP`], "enable");
    } else {
      toggleDisplay("solo", [`${r}${o}pcsk9HUP`], "disable");
    }
  }
  if (o === "TAT") {
    if (a === "Non-formulary") {
      toggleDisplay("solo", [`${r}${o}bVdHUP`], "enable");
    } else {
      toggleDisplay("solo", [`${r}${o}bVdHUP`], "disable");
    }
  }
}

export function toggleDLTRef(o, r, a) {
  if (r === "tech" && o === "TAT") {
    if (a === "Non-formulary") {
      toggleDisplay(
        "solo",
        [`${r}${o}guidelineQ`, `${r}${o}subguidelineQ`],
        "enable"
      );
    } else {
      /* [Automated flow only] Skipping disabling DLT guidelines for Phase-3.0 and later changes */
      const workFlow = sessionStorage.getItem("workFlow");
      if(workFlow !== 'Automated'){
        toggleDisplay(
          "solo",
          [`${r}${o}guidelineQ`, `${r}${o}subguidelineQ`],
          "disable"
        );
      }
    }
  }
}

export function toggleRqstReasonQ(o, r, a) {
  const status =
    a === "Not found" || a === "highlighted in blue" ? "disable" : "enable";
  toggleDisplay("solo", [`${r}${o}rqstReasonQ`], status);
}

export function toggleRqstReason(o, r, answer) {
  const allButPA = document.querySelectorAll(
    `#${r}${o}rqstReasonQsel option:not(#${r}${o}rqstReasonPA)`
  );
  const status =
    o === "IBC" && answer === "Oscar Health (21BV)" ? "disable" : "enable";
  toggleDisplay("tag", allButPA, status);
}

export function toggleIsCaseInRFI(o, r, answer) {
  const isAutomated = isFlowAutomated();
  if (r === "tech" && o === "IBC" && isAutomated) {
    if (["Hospice", "Tier Change", "Step Therapy"].includes(answer)) {
      toggleDisplay("solo", [`${r}${o}isCaseInRFIQ`], "enable");
    } else {
      toggleDisplay(
        "solo",
        [`${r}${o}isCaseInRFIQ`, `${r}${o}reviewExternalTemplateQ`],
        "disable"
      );
    }
  }
}
