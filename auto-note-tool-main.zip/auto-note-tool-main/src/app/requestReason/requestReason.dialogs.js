import { GeneralModal } from '../modal/alert.service';
import { bold } from '../utils/font.formatter';

export default function msgRqstReason(r, a) {
  if (a === 'Step Therapy' && r === 'tech') {
    GeneralModal({
      message: bold(
        'Step Therapy medications must be reviewed by a pharmacist. Forward to clinical for review.'
      ),
      icon: 'notification_important',
    });
  }
  if (a === 'Tier Change' && r === 'tech') {
    GeneralModal({
      message: bold(
        'Tier change exceptions must be reviewed by a pharmacist. Forward to clinical for review.'
      ),
      icon: 'notification_important',
    });
  }
}
