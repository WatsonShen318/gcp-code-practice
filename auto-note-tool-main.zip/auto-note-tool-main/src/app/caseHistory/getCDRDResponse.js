import axios from "axios";
// eslint-disable-next-line import/no-extraneous-dependencies
import axiosRetry from "axios-retry";
import { getEnvironmentVariables } from "../../../environment/config";

// Configure axios to retry requests
axiosRetry(axios, {
  retries: 2,
  retryCondition: (error) => error.response.status >= 500,
  retryDelay: (retryCount) => {
    console.log(`CDRD - Retry attempt: ${retryCount}`);
    return retryCount * 1000; // Exponential backoff
  },
});

const extractCDRDPayload = (medhokReponse) => {
  const cdrdPayload = {
    caseId: medhokReponse?.rxId?.trim(),
    memberAccountId: medhokReponse?.memberId?.trim(),
    companyLob: medhokReponse?.memberEligibility?.companyLob?.trim(),
    companyAccounts: medhokReponse?.memberEligibility?.companyAccounts?.trim(),
    companyAccountGroup:
      medhokReponse?.memberEligibility?.companyAccountGroup?.trim(),
    memberEligibilityTermDate:
      medhokReponse?.memberEligibility?.termdate?.trim(),
    requestReason: medhokReponse?.requestReason?.trim(),
    client: medhokReponse?.memberEligibility?.company?.trim(),
    gpiCode: medhokReponse?.gpiCode?.trim(),
    ndc: medhokReponse?.ndc?.trim(),
    // Current request's received date — anchors the Q8 65-day approved-RD window
    receivedDate: medhokReponse?.receivedDate?.trim(),
  };

  return cdrdPayload;
};

async function getCDRDResponse(medhokReponse) {
  try {
    console.log("Attempting to get the cdrd response.");
    const { AUTO_NOTE_BACKEND } = getEnvironmentVariables();
    const payload = extractCDRDPayload(medhokReponse);
    const cdrdResponse = await axios.post(
      // `${AUTO_NOTE_BACKEND}/cdrd/bigquery`,
      `${AUTO_NOTE_BACKEND}/cdrd/bigtable`,
      // `${AUTO_NOTE_BACKEND}/cdrd/teradata`,
      payload,
      { timeout: 60000 }
    );

    const cdrdStatusList = JSON.parse(sessionStorage.getItem("cdrdStatus")) || [];
    cdrdStatusList.push("200");
    sessionStorage.setItem("cdrdStatus", JSON.stringify(cdrdStatusList));

    const cdrdBackendResponseList =
      JSON.parse(sessionStorage.getItem("cdrdBackendResponse")) || [];
    cdrdBackendResponseList.push(cdrdResponse?.data);
    sessionStorage.setItem(
      "cdrdBackendResponse",
      JSON.stringify(cdrdBackendResponseList)
    );

    return cdrdResponse.data;
  } catch (error) {
    console.error("Error fetching cdrd data: ", error);

    const cdrdStatusList = JSON.parse(sessionStorage.getItem("cdrdStatus")) || [];
    cdrdStatusList.push(`${error.response?.status || "Unknown"}`);
    sessionStorage.setItem("cdrdStatus", JSON.stringify(cdrdStatusList));

    const cdrdBackendResponseList =
      JSON.parse(sessionStorage.getItem("cdrdBackendResponse")) || [];
    if (error.response?.data) {
      cdrdBackendResponseList.push(error.response.data);
    }
    sessionStorage.setItem(
      "cdrdBackendResponse",
      JSON.stringify(cdrdBackendResponseList)
    );
    return null;
  }
}

export default getCDRDResponse;
