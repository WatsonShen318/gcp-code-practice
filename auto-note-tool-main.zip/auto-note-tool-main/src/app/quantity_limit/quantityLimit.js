import lookupQl from './api/lookupQl';
import { toggleDisplay } from '../utils/notetool.display';
import { SS_FORMULARY, SS_FORMULARY_SOURCE, SS_AUTO_RESOLVE, resolveFormularyUI, resetSubegwpDropdown } from '../shared/resolveFormularyUI';
import { initFormAlts, registerOnDrugChanged, showFormAltsDrugPickerForQl, showFormAltsIndicationPickerForQl } from '../form_alts/formAlts';
import { syncPlanQlRefIfVisible, clearPlanQlRef, handlePrescriberIndicatedApprovedFormularyQuantityLimitIneffective } from '../dlt_guidelines/dlt_guideline.display';
import { automatePrescriberIndicatedQlIneffectiveField, resetQlDLTFields } from '../dlt_guidelines/automation';
import { refreshVerbiageIfActive } from '../verbiage/index';
import { PLACEHOLDER_LABELS } from '../verbiage/templates';

const SS_QL_RESULT                        = 'qlLookupResult';
const SS_MANUAL_DRUG                      = 'manualFlowDrug';
const SS_QL_ACTIVE                        = 'qlActive';
const SS_QL_AUTOMATED_DRUG_AND_REQ_QL     = 'qlAutomatedDrugAndRequestedQl';
const SS_QL_AUTOMATED_DRUG_AND_PLAN_QL    = 'qlAutomatedDrugAndPlanQl';
const SS_QL_AUTOMATED_PLAN_QL             = 'qlAutomatedPlanQl';
const SS_QL_FINAL_DRUG_AND_REQ_QL         = 'qlFinalDrugAndRequestedQl';
const SS_QL_FINAL_DRUG_AND_PLAN_QL        = 'qlFinalDrugAndPlanQl';
const SS_QL_FINAL_PLAN_QL                 = 'qlFinalPlanQl';
const SS_QL_AUDIT                         = 'qlAudit';
const SS_QL_CLAIM                         = 'qlQualifyingClaim';
const SS_QL_HAS_QUALIFYING_CLAIMS         = 'qlHasQualifyingClaims';

function _formatClaimDate(fillDt) {
  if (!fillDt) return '';
  const [y, m, d] = String(fillDt).split('-');
  return `${parseInt(m, 10)}/${parseInt(d, 10)}/${y}`;
}

function _updateClaimBanner(role, origin, show) {
  document.getElementById(`${role}${origin}qlClaimInfoBanner`)?.remove();
  if (!show) return;
  const claimText = sessionStorage.getItem(SS_QL_CLAIM);
  if (!claimText) return;
  const anchor = document.getElementById(`${role}${origin}prescriberIndicatedApprovedFormularyQuantityLimitIneffectiveQ`);
  if (!anchor) return;
  const banner = document.createElement('div');
  banner.id = `${role}${origin}qlClaimInfoBanner`;
  banner.className = 'alert alert-success mt-2 mb-2 ant-ql-claim-info';
  banner.innerHTML = `<strong>Auto Note Tool found a qualifying paid claim:</strong> ${claimText}`;
  anchor.insertAdjacentElement('beforebegin', banner);
}

function _storeAndShowClaim(role, origin, qualifyingClaim) {
  if (!qualifyingClaim) {
    sessionStorage.removeItem(SS_QL_CLAIM);
    sessionStorage.removeItem(SS_QL_HAS_QUALIFYING_CLAIMS);
    _updateClaimBanner(role, origin, false);
    return;
  }
  const { dispQty, daysSply, fillDt, units } = qualifyingClaim;
  const qty  = dispQty  != null ? dispQty  : '?';
  const days = daysSply != null ? daysSply : '?';
  const claimText = `${qty} ${units} / ${days} days (fill date: ${_formatClaimDate(fillDt)})`;
  sessionStorage.setItem(SS_QL_CLAIM, claimText);
  sessionStorage.setItem(SS_QL_HAS_QUALIFYING_CLAIMS, 'true');
}

function _wireTypeOfQlReviewQChange(role, origin) {
  document.querySelectorAll(`[name="${role}${origin}typeOfQlReviewQrdo"]`).forEach(rdo => {
    rdo.onchange = () => {
      const hasQualifyingClaims = sessionStorage.getItem(SS_QL_HAS_QUALIFYING_CLAIMS) === 'true';
      const answer = automatePrescriberIndicatedQlIneffectiveField(hasQualifyingClaims, role, origin);
      if (!answer) {
        // QvT selected or no qualifying claims — clear the auto-answered field and undo its
        // side effects (Decision Routing set to Approved + follow-up questions hidden).
        resetQlDLTFields(role, origin);
        handlePrescriberIndicatedApprovedFormularyQuantityLimitIneffective(role, origin, 'No');
        sessionStorage.removeItem('dltFinalPrescriberIndicatedQlIneffectiveFieldAns');
      }
      _updateClaimBanner(role, origin, answer === 'Yes');
      _writeQlAudit({ claimsAutoAnsweredDlt: answer === 'Yes' });
    };
  });
}

function _readQlAudit() {
  return JSON.parse(sessionStorage.getItem(SS_QL_AUDIT) || 'null') || {};
}
function _writeQlAudit(updates) {
  sessionStorage.setItem(SS_QL_AUDIT, JSON.stringify({ ..._readQlAudit(), ...updates }));
}
function _appendQlError(msg) {
  const current = _readQlAudit();
  const errors = Array.isArray(current.automationErrors) ? current.automationErrors : [];
  sessionStorage.setItem(SS_QL_AUDIT, JSON.stringify({ ...current, automationErrors: [...errors, msg] }));
}

export async function showQlSection(role, origin) {
  // Re-use cached result only if qty/days match the current form values.
  // If the user filled Q45 after the pre-fetch, the cached result has stale 0/0
  // values - fall through so _runLookup re-fetches with the correct numbers.
  const existingResult = JSON.parse(sessionStorage.getItem(SS_QL_RESULT) || 'null');
  if (existingResult) {
    const { qty: formQty, days: formDays } = _getQtyDays(role, origin);
    if (existingResult._qty === formQty && existingResult._days === formDays) {
      // resolveFormularyUI is bypassed on cache hit - write formularyId here so qlAudit is complete
      _writeQlAudit({
        formularyId:       sessionStorage.getItem(SS_FORMULARY)        || 'N/A',
        formularyIdSource: sessionStorage.getItem(SS_FORMULARY_SOURCE) || '',
      });
      _showVerbiageFields(role, origin);
      _renderResult(role, origin, existingResult);
      if (existingResult.requiresPicker && existingResult.verbiage) {
        // resetQl cleared SS_QL_AUDIT and SS_QL_FINAL_xxx — restore all three state layers
        // so the final note and RFI/Denial templates read the correct values.
        _writeQlAudit({
          finalDrugAndRequestedQl: existingResult.verbiage.drugAndRequestedQl,
          finalDrugAndPlanQl:      existingResult.verbiage.drugAndPlanQl,
          finalPlanQl:             existingResult.verbiage.planQlOnly,
        });
        _writeFinalVerbiage(existingResult.verbiage);
        _renderVerbiage(role, origin, existingResult.verbiage);
        refreshVerbiageIfActive(role, origin);
        // Picker onchange never fires on cache restore — re-apply DLT auto-answer if needed
        if (existingResult.selectedOption) {
          _storeAndShowClaim(role, origin, existingResult.selectedOption.qualifyingClaim ?? null);
          _wireTypeOfQlReviewQChange(role, origin);
          _updateClaimBanner(role, origin, sessionStorage.getItem('dltAutomatedPrescriberIndicatedQlIneffectiveFieldAns') === 'Yes');
          _writeQlAudit({ qlHasQualifyingClaims: !!existingResult.selectedOption.hasQualifyingClaims });
        }
      }
      return;
    }

    // Qty/days changed but user had already picked a strength — recalculate verbiage
    // locally using the new values. Drug options don't change with qty/days, so no
    // API re-fetch is needed. This preserves the selection across request reason changes
    // where Q45 was filled after the initial lookup.
    if (existingResult.requiresPicker && existingResult.selectedOption) {
      const newVerbiage = _buildVerbiage(existingResult.selectedOption, formQty, formDays);
      const updated = { ...existingResult, verbiage: newVerbiage, _qty: formQty, _days: formDays };
      sessionStorage.setItem(SS_QL_RESULT, JSON.stringify(updated));
      _writeQlAudit({
        formularyId:             sessionStorage.getItem(SS_FORMULARY)        || 'N/A',
        formularyIdSource:       sessionStorage.getItem(SS_FORMULARY_SOURCE) || '',
        finalDrugAndRequestedQl: newVerbiage.drugAndRequestedQl,
        finalDrugAndPlanQl:      newVerbiage.drugAndPlanQl,
        finalPlanQl:             newVerbiage.planQlOnly,
      });
      _showVerbiageFields(role, origin);
      _writeFinalVerbiage(newVerbiage);
      _renderResult(role, origin, updated);
      _renderVerbiage(role, origin, newVerbiage);
      refreshVerbiageIfActive(role, origin);
      // Picker onchange never fires on cache restore — re-apply DLT auto-answer if needed
      if (existingResult.selectedOption) {
        _storeAndShowClaim(role, origin, existingResult.selectedOption.qualifyingClaim ?? null);
        _wireTypeOfQlReviewQChange(role, origin);
        _writeQlAudit({ qlHasQualifyingClaims: !!existingResult.selectedOption.hasQualifyingClaims });
      }
      return;
    }

    // qty or days differ, no prior selection - clear stale result and re-fetch below
    sessionStorage.removeItem(SS_QL_RESULT);
  }

  // Always show verbiage fields immediately - user can enter manually at any time
  _showVerbiageFields(role, origin);
  _wireVerbiageEditable(role, origin);

  const medhok   = JSON.parse(sessionStorage.getItem('originalMedhokResponse') || 'null');
  const gpi      = medhok?.gpiCode  || null;
  const drugName = medhok?.drugName || null;

  // Hide the Aetna MAPD legacy field while the resolve flow owns formulary entry
  // (for both automated and manual flows - client dropdown drives formulary resolution)
  toggleDisplay('solo', [`${role}${origin}subFormularyIDQ`], 'disable');

  // Signal that QL owns formulary resolution so resolveFormularyForClient backs off if still running.
  sessionStorage.setItem(SS_QL_ACTIVE, 'true');

  // When Q250 (formAlts drug picker) is showing with multiple options, re-run QL lookup
  // if the user changes their selection. Only fires while QL is active (SS_QL_ACTIVE set).
  registerOnDrugChanged(role, origin, (newDrugName) => {
    if (!sessionStorage.getItem(SS_QL_ACTIVE)) return;
    const formularyId = sessionStorage.getItem(SS_FORMULARY);
    if (!formularyId) return;
    const _medhok = JSON.parse(sessionStorage.getItem('originalMedhokResponse') || 'null');
    const _gpi = _medhok?.gpiCode || JSON.parse(sessionStorage.getItem(SS_MANUAL_DRUG) || 'null')?.gpi || null;
    if (!_gpi) return;
    const { qty, days } = _getQtyDays(role, origin);
    _resetQlResults(role, origin);
    showFormAltsIndicationPickerForQl(role, origin);
    _runLookup(role, origin, formularyId, _gpi, newDrugName, qty, days);
  });

  // Await CAG formulary auto-resolve before calling resolveFormularyUI so SS_AUTO_RESOLVE
  // is guaranteed to be populated when resolveFormularyUI checks it.
  await initFormAlts(role, origin);

  // Pre-populate SS_FORMULARY from CAG result so resolveFormularyUI uses the fast path
  const autoResolve = JSON.parse(sessionStorage.getItem(SS_AUTO_RESOLVE) || 'null');
  if (autoResolve?.found && autoResolve?.formularyId && !sessionStorage.getItem(SS_FORMULARY)) {
    sessionStorage.setItem(SS_FORMULARY, autoResolve.formularyId);
    sessionStorage.setItem(SS_FORMULARY_SOURCE, 'auto');
  }

  resolveFormularyUI(role, origin, 'formulary', {
    onResolved: (formularyId) => {
      _writeQlAudit({ formularyId: formularyId || 'N/A', formularyIdSource: sessionStorage.getItem(SS_FORMULARY_SOURCE) });
      const _qlFormularySrc = sessionStorage.getItem(SS_FORMULARY_SOURCE);
      if (_qlFormularySrc && _qlFormularySrc !== 'auto') {
        _appendQlError(`Formulary ID not auto-resolved (CAG unavailable); entered via: ${_qlFormularySrc}`);
      }
      _resetQlResults(role, origin);

      // Show Q250 (formAlts drug picker) when multiple drug formulations are available and
      // no selection has been made yet. registerOnDrugChanged fires _runLookup on selection.
      if (showFormAltsDrugPickerForQl(role, origin)) return;

      // Show Q251 (indication picker) — used by QL verbiage template.
      // _tryFetch is guarded by SS_NF_ACTIVE so no form alts fetch occurs; only SS_FINAL_INDICATION is written.
      showFormAltsIndicationPickerForQl(role, origin);

      // Automated flow: medhok has gpi + drugName.
      // Prefer the Q250 drug picker selection (SS_DRUG) over raw medhok drugName when the
      // user picked a specific formulation from the form alts multi-drug picker.
      if (gpi && drugName) {
        const q250Drug = sessionStorage.getItem('formAltsDrugName');
        const { qty, days } = _getQtyDays(role, origin);
        _runLookup(role, origin, formularyId, gpi, q250Drug || drugName, qty, days);
        return;
      }

      // Manual flow: check if drug was already selected via drug search
      const manualDrug = JSON.parse(sessionStorage.getItem(SS_MANUAL_DRUG) || 'null');
      if (manualDrug && !manualDrug.gpi) return; // "Other" selected — full manual, no QL lookup
      if (manualDrug?.gpi && manualDrug?.drugName) {
        const q250Drug = sessionStorage.getItem('formAltsDrugName');
        const { qty, days } = _getQtyDays(role, origin);
        _runLookup(role, origin, formularyId, manualDrug.gpi, q250Drug || manualDrug.drugName, qty, days);
        return;
      }

      // No drug yet - show prompt (drug search field is visible for user to select)
      _appendQlError('Drug/GPI not available - manual drug selection required for QL lookup');
      _setPickerHtml(role, origin, '<div class="alert alert-info mb-0">Select a drug from the Drug Name field above to load quantity limit data.</div>');
      toggleDisplay('solo', [`${role}${origin}qlPickerQ`], 'enable');
    },
    onNotAvailable: () => {
      _writeQlAudit({ formularyId: 'N/A', formularyIdSource: 'na' });
      _resetQlResults(role, origin);
      _setPickerHtml(role, origin, '<div class="alert alert-secondary mb-0">Formulary ID not available - quantity limit lookup skipped.</div>');
      toggleDisplay('solo', [`${role}${origin}qlPickerQ`], 'enable');
    },
    onReset: () => _resetQlResults(role, origin),
  });
}

// Called when user selects a drug in manual flow (no medhok).
// If formulary is already resolved, runs the lookup immediately;
// otherwise formulary's onResolved will pick it up from SS_MANUAL_DRUG.
export function onManualDrugSelectedQl(role, origin, gpi, drugName) {
  sessionStorage.setItem(SS_MANUAL_DRUG, JSON.stringify({ gpi, drugName }));

  // "Other" drug selected — no GPI means no QL lookup is possible.
  // Always clear downstream so stale data from any prior valid drug doesn't carry forward.
  if (!gpi) {
    _resetQlResults(role, origin);
    sessionStorage.removeItem(SS_QL_AUDIT);
    toggleDisplay('solo', [
      `${role}${origin}qlDrugAndRequestedQlQ`,
      `${role}${origin}qlDrugAndPlanQlQ`,
      `${role}${origin}qlPlanQlQ`,
    ], 'disable');
    refreshVerbiageIfActive(role, origin);
    return;
  }

  const formularyId = sessionStorage.getItem(SS_FORMULARY);
  if (!formularyId) return; // Formulary not yet resolved - onResolved will fire later

  const { qty, days } = _getQtyDays(role, origin);
  _resetQlResults(role, origin);
  _runLookup(role, origin, formularyId, gpi, drugName, qty, days);
}

export function resetQl(role, origin) {
  // NOTE: resetSubegwpDropdown intentionally NOT called here — same reason as resetFormAlts.
  // Sub-client belongs to the client context; SS_FORMULARY is kept by this reset.
  resetQlDLTFields(role, origin);
  _updateClaimBanner(role, origin, false);
  sessionStorage.removeItem(SS_QL_ACTIVE);
  sessionStorage.removeItem(SS_QL_CLAIM);
  sessionStorage.removeItem(SS_QL_HAS_QUALIFYING_CLAIMS);
  sessionStorage.removeItem(SS_QL_AUTOMATED_DRUG_AND_REQ_QL);
  sessionStorage.removeItem(SS_QL_AUTOMATED_DRUG_AND_PLAN_QL);
  sessionStorage.removeItem(SS_QL_AUTOMATED_PLAN_QL);
  sessionStorage.removeItem(SS_QL_FINAL_DRUG_AND_REQ_QL);
  sessionStorage.removeItem(SS_QL_FINAL_DRUG_AND_PLAN_QL);
  sessionStorage.removeItem(SS_QL_FINAL_PLAN_QL);
  sessionStorage.removeItem(SS_QL_AUDIT);
  // SS_FORMULARY, SS_FORMULARY_SOURCE: kept (client-level, persists across request reason changes)
  // SS_MANUAL_DRUG: kept (drug state persists across QL changes)
  // SS_QL_RESULT: kept (re-rendered when QL re-selected without re-fetching)
  // Q254/Q255/Q249: intentionally NOT hidden (client-level)
  toggleDisplay('solo', [`${role}${origin}qlPickerQ`],             'disable');
  toggleDisplay('solo', [`${role}${origin}qlDrugAndRequestedQlQ`], 'disable');
  toggleDisplay('solo', [`${role}${origin}qlDrugAndPlanQlQ`],      'disable');
  toggleDisplay('solo', [`${role}${origin}qlPlanQlQ`],             'disable');
  // QL-only DLT fields: shouldSkipField hides these when rqstReasonQsel != 'quantity limit',
  // but that check only runs when DLT fields change — not on request reason change.
  // Explicitly hide here so they don't persist after switching away from QL.
  toggleDisplay('solo', [
    `${role}${origin}typeOfQlReviewQ`,
    `${role}${origin}prescriberIndicatedApprovedFormularyQuantityLimitIneffectiveQ`,
    `${role}${origin}prescriberIndicatedApprovedDosesIneffectiveQ`,
  ], 'disable');
  _clearVerbiageFields(role, origin);
  clearPlanQlRef(role, origin);
}

// Called from each qset's client change handler when request reason is QL.
// Always re-runs resolution because QL has no auto-resolve path (all manual picks).
export function refreshQlOnClientChange(role, origin) {
  resetSubegwpDropdown(role, origin);
  sessionStorage.removeItem(SS_FORMULARY);
  // Clear CAG auto-resolve from a previous client/NF flow — resolveFormularyUI checks
  // SS_AUTO_RESOLVE (same key) and would silently reuse the stale formulary ID.
  sessionStorage.removeItem(SS_AUTO_RESOLVE);
  toggleDisplay('solo', [`${role}${origin}subFormularyIDQ`],    'disable');
  toggleDisplay('solo', [`${role}${origin}formularySubclientQ`], 'disable');
  toggleDisplay('solo', [`${role}${origin}formularyDropdownQ`],  'disable');
  toggleDisplay('solo', [`${role}${origin}formularyIdQ`],        'disable');
  // Reset dropdown options so resolveFormularyUI's fast-path (options.length > 1) does not
  // reuse stale options from the previous client's formulary list.
  const _fDropdownSel = document.getElementById(`${role}${origin}formularyDropdownQsel`);
  if (_fDropdownSel) _fDropdownSel.innerHTML = '<option value="">Select formulary…</option>';
  _resetQlResults(role, origin);
  showQlSection(role, origin);
}

function _getQtyDays(role, origin) {
  const medhok = JSON.parse(sessionStorage.getItem('originalMedhokResponse') || 'null');
  // Form fields (qtyDSQ) are the primary source - they reflect what the user has entered.
  // Medhok values are the fallback when the fields haven't been filled yet.
  const qty  = Number(document.getElementById(`${role}${origin}qtytxt`)?.value) || Number(medhok?.quantity)   || 0;
  const days = Number(document.getElementById(`${role}${origin}dstxt`)?.value)  || Number(medhok?.daysSupply) || 0;
  return { qty, days };
}

async function _runLookup(role, origin, formularyId, gpi, drugName, qty, days) {
  // Write formularyId now - covers the onManualDrugSelectedQl pre-fetch path where the
  // caller (not onResolved) kicks off the lookup without going through resolveFormularyUI.
  _writeQlAudit({
    formularyId:       formularyId                                  || 'N/A',
    formularyIdSource: sessionStorage.getItem(SS_FORMULARY_SOURCE) || '',
  });
  if (qty === 0 || days === 0) {
    _appendQlError(`Quantity (${qty}) or days supply (${days}) is 0 - medhok data unavailable; manual entry may be required`);
  }
  _setPickerHtml(role, origin, '<div class="text-muted p-2">Loading quantity limit data…</div>');
  toggleDisplay('solo', [`${role}${origin}qlPickerQ`], 'enable');

  try {
    const _medhok = JSON.parse(sessionStorage.getItem('originalMedhokResponse') || '{}');
    const memberId = _medhok.memberId?.trim() || null;
    const receivedDate = _medhok.receivedDate ? _medhok.receivedDate.split('T')[0] : null;
    const result = await lookupQl(formularyId, gpi, drugName, qty, days, memberId, receivedDate);
    // _gpi/_drugName/_qty/_days stored so the qty/days Update button can re-run the lookup
    sessionStorage.setItem(SS_QL_RESULT, JSON.stringify({ ...result, _qty: qty, _days: days, _gpi: gpi, _drugName: drugName }));
    _renderResult(role, origin, result);
  } catch (err) {
    console.error('[QL] lookupQl failed:', err);
    _writeQlAudit({ lookupStatus: 'Lookup failed' });
    _appendQlError(`QL lookup failed: ${err?.message || 'API error'}`);
    _setPickerHtml(role, origin, '<div class="alert alert-danger mb-0">Failed to load quantity limit data.</div>');
  }
}

function _renderResult(role, origin, result) {
  if (!result.supported) {
    _writeQlAudit({ lookupStatus: result.reason || 'not_supported' });
    _appendQlError(`Drug not supported for QL lookup: ${result.reason || 'not_supported'}`);
    _setPickerHtml(role, origin, '<div class="alert alert-warning mb-0"><strong>Quantity limit data is not available for this drug.</strong></div>');
    return;
  }

  if (result.requiresPicker) {
    _writeQlAudit({ lookupStatus: 'Multiple matches - strength selection required' });
    // System has no single answer -automated keys stay null; final written after picker selection
    _renderPicker(role, origin, result.options, result.selectedOption || null);
    return;
  }

  _writeQlAudit({
    lookupStatus:          'Single match - verbiage auto-generated',
    automatedDrugAndRequestedQl: result.verbiage.drugAndRequestedQl,
    automatedDrugAndPlanQl:      result.verbiage.drugAndPlanQl,
    automatedPlanQl:             result.verbiage.planQlOnly,
    finalDrugAndRequestedQl:     result.verbiage.drugAndRequestedQl,
    finalDrugAndPlanQl:          result.verbiage.drugAndPlanQl,
    finalPlanQl:                 result.verbiage.planQlOnly,
  });
  // Single result -system computed verbiage automatically; freeze it, also set as final
  _writeAutomatedVerbiage(result.verbiage);
  _writeFinalVerbiage(result.verbiage);

  toggleDisplay('solo', [`${role}${origin}qlPickerQ`], 'disable');
  _renderVerbiage(role, origin, result.verbiage);
  refreshVerbiageIfActive(role, origin);
  syncPlanQlRefIfVisible(role, origin);
  _wireQtyDaysUpdateBtn(role, origin);
  _storeAndShowClaim(role, origin, result.result?.qualifyingClaim ?? null);
  _wireTypeOfQlReviewQChange(role, origin);
  _writeQlAudit({ qlHasQualifyingClaims: !!result.result?.hasQualifyingClaims });
}

function _renderPicker(role, origin, options, selectedOption = null) {
  let html = `<table class="table table-sm table-bordered mb-3">
      <thead class="table-light">
        <tr>
          <th>Drug / Form / Strength</th>
          <th class="text-center" style="width:80px">QL</th>
          <th class="text-center" style="width:80px">Days</th>
          <th class="text-center" style="width:80px">Unit</th>
          <th class="text-center" style="width:60px">Select</th>
        </tr>
      </thead>
      <tbody>`;

  options.forEach((opt, i) => {
    const rdoId  = `${role}${origin}qlPickerRdo${i}`;
    const checked = selectedOption && opt.drugNameFormStrength === selectedOption.drugNameFormStrength ? ' checked' : '';
    const unitLabel = Number(opt.ql) === 1 ? opt.unit : opt.units;
    html += `
      <tr>
        <td>${opt.drugNameFormStrength}</td>
        <td class="text-center">${opt.ql}</td>
        <td class="text-center">${opt.qd}</td>
        <td class="text-center">${unitLabel || ''}</td>
        <td class="text-center">
          <input class="form-check-input ql-picker-rdo" type="radio"
                 name="${role}${origin}qlPickerRdo" id="${rdoId}" value="${i}"${checked}>
        </td>
      </tr>`;
  });

  html += '</tbody></table>';
  _setPickerHtml(role, origin, html);
  toggleDisplay('solo', [`${role}${origin}qlPickerQ`], 'enable');

  const container = document.getElementById(`${role}${origin}qlPickerQcontainer`);
  if (!container) return;

  container.onchange = (e) => {
    if (!e.target.classList.contains('ql-picker-rdo')) return;
    const idx = parseInt(e.target.value, 10);
    const selected = options[idx];
    if (!selected) return;

    const { qty, days } = _getQtyDays(role, origin);

    const verbiage = _buildVerbiage(selected, qty, days);
    const existing = JSON.parse(sessionStorage.getItem(SS_QL_RESULT) || '{}');
    sessionStorage.setItem(SS_QL_RESULT, JSON.stringify({ ...existing, selectedOption: selected, verbiage }));

    // Automated keys stay null (requiresPicker was true -system had no single answer)
    // Final keys reflect the user's picker selection
    _writeFinalVerbiage(verbiage);
    _writeQlAudit({
      finalDrugAndRequestedQl: verbiage.drugAndRequestedQl,
      finalDrugAndPlanQl:      verbiage.drugAndPlanQl,
      finalPlanQl:             verbiage.planQlOnly,
    });

    // Picker stays visible as reference after selection; just fill the verbiage fields
    _renderVerbiage(role, origin, verbiage);
    syncPlanQlRefIfVisible(role, origin);
    refreshVerbiageIfActive(role, origin);
    _wireQtyDaysUpdateBtn(role, origin);
    _storeAndShowClaim(role, origin, selected.qualifyingClaim ?? null);
    _wireTypeOfQlReviewQChange(role, origin);
    _writeQlAudit({ qlHasQualifyingClaims: !!selected.hasQualifyingClaims });
  };
}

function _showVerbiageFields(role, origin) {
  ['qlDrugAndRequestedQlQ', 'qlDrugAndPlanQlQ', 'qlPlanQlQ'].forEach((internal) => {
    toggleDisplay('solo', [`${role}${origin}${internal}`], 'enable');
  });
}

function _renderVerbiage(role, origin, verbiage) {
  const fields = [
    { internal: 'qlDrugAndRequestedQlQ', value: verbiage.drugAndRequestedQl },
    { internal: 'qlDrugAndPlanQlQ',      value: verbiage.drugAndPlanQl },
    { internal: 'qlPlanQlQ',             value: verbiage.planQlOnly },
  ];

  fields.forEach(({ internal, value }) => {
    const txtEl = document.getElementById(`${role}${origin}${internal}txt`);
    if (txtEl) {
      txtEl.value = value;
      txtEl.readOnly = document.getElementById(`${role}${origin}routingQsel`)?.value === 'Approved';
    }

    const btnEl = document.getElementById(`${role}${origin}${internal}btn`);
    if (btnEl) {
      btnEl.onclick = () => {
        const current = document.getElementById(`${role}${origin}${internal}txt`)?.value || value;
        navigator.clipboard.writeText(current).then(() => {
          const orig = btnEl.textContent;
          btnEl.textContent = 'Copied!';
          setTimeout(() => { btnEl.textContent = orig; }, 1500);
        });
      };
    }
  });

  _wireVerbiageEditable(role, origin);
}

function _wireVerbiageEditable(role, origin) {
  const fields = [
    { internal: 'qlDrugAndRequestedQlQ', auditKey: 'finalDrugAndRequestedQl', ssKey: SS_QL_FINAL_DRUG_AND_REQ_QL, placeholder: PLACEHOLDER_LABELS.DRUG_AND_REQUESTED_QL },
    { internal: 'qlDrugAndPlanQlQ',      auditKey: 'finalDrugAndPlanQl',      ssKey: SS_QL_FINAL_DRUG_AND_PLAN_QL, placeholder: PLACEHOLDER_LABELS.DRUG_AND_PLAN_QL },
    { internal: 'qlPlanQlQ',             auditKey: 'finalPlanQl',             ssKey: SS_QL_FINAL_PLAN_QL, placeholder: PLACEHOLDER_LABELS.PLAN_QL },
  ];
  fields.forEach(({ internal, auditKey, ssKey, placeholder }) => {
    const txtEl = document.getElementById(`${role}${origin}${internal}txt`);
    if (!txtEl) return;
    txtEl.oninput = () => {
      const val = txtEl.value;
      sessionStorage.setItem(ssKey, val);
      _writeQlAudit({ [auditKey]: val });
      refreshVerbiageIfActive(role, origin);
    };
    txtEl.onblur = () => {
      const trimmed = txtEl.value.trim();
      if (trimmed.length < 3) {
        sessionStorage.setItem(ssKey, placeholder);
        _writeQlAudit({ [auditKey]: placeholder });
      } else {
        txtEl.value = trimmed;
        sessionStorage.setItem(ssKey, trimmed);
        _writeQlAudit({ [auditKey]: trimmed });
      }
      refreshVerbiageIfActive(role, origin);
    };
  });
}

function _buildVerbiage(r, qtyReq, daysReq) {
  const planUnitLabel = r.ql    === 1 ? r.unit : r.units;
  const planDayLabel  = r.qd    === 1 ? 'DAY'  : 'DAYS';
  const reqUnitLabel  = qtyReq  === 1 ? r.unit : r.units;
  const reqDayLabel   = daysReq === 1 ? 'DAY'  : 'DAYS';
  return {
    drugAndRequestedQl: `${r.drugNameFormStrength}, ${qtyReq} ${reqUnitLabel} PER ${daysReq} ${reqDayLabel}`,
    drugAndPlanQl:      `${r.drugNameFormStrength}, ${r.ql} ${planUnitLabel} PER ${r.qd} ${planDayLabel}`,
    planQlOnly:         `${r.ql} ${planUnitLabel} PER ${r.qd} ${planDayLabel}`,
  };
}

// Injects an "Update / Updated" button next to the qty/days inputs after a successful QL lookup.
// Only shown when qtyDSQPA is visible — when qty/days are automated and hidden no button appears.
// If the user edits qty or days after the lookup the button switches to "Update" so they know
// the displayed verbiage is stale.  Clicking re-runs the full QL lookup with the new values.
function _wireQtyDaysUpdateBtn(role, origin) {
  const qtyPA = document.getElementById(`${role}${origin}qtyDSQPA`);
  if (!qtyPA || getComputedStyle(qtyPA).display === 'none') return;

  const btnId = `${role}${origin}qtyDaysUpdateBtn`;

  const qtyEl = document.getElementById(`${role}${origin}qtytxt`);
  if (!qtyEl) return;
  const inputGroup = qtyEl.closest('.input-group');
  if (!inputGroup) return;

  // Get or create the button — re-use the existing element so onclick stays wired.
  let btn = document.getElementById(btnId);
  if (!btn) {
    btn = document.createElement('button');
    btn.type = 'button';
    btn.id = btnId;
    btn.textContent = 'Updated!';
    btn.className = 'btn btn-primary ms-1';
    inputGroup.appendChild(btn);

    btn.onclick = async () => {
      const formularyId = sessionStorage.getItem(SS_FORMULARY);
      if (!formularyId) return;
      const stored = JSON.parse(sessionStorage.getItem(SS_QL_RESULT) || 'null');
      if (!stored?._gpi || !stored?._drugName) return;
      const { qty, days } = _getQtyDays(role, origin);
      _resetQlResults(role, origin);
      await _runLookup(role, origin, formularyId, stored._gpi, stored._drugName, qty, days);
    };
  }

  const _refreshLabel = () => {
    const stored = JSON.parse(sessionStorage.getItem(SS_QL_RESULT) || 'null');
    if (!stored) return;
    const { qty, days } = _getQtyDays(role, origin);
    const changed = qty !== stored._qty || days !== stored._days;
    btn.textContent = changed ? 'Update' : 'Updated!';
    btn.className = changed ? 'btn btn-save-pending ms-1' : 'btn btn-primary ms-1';
  };

  // oninput assignment overwrites any prior listener — no duplicate handlers
  const qtyInput = document.getElementById(`${role}${origin}qtytxt`);
  const dsInput  = document.getElementById(`${role}${origin}dstxt`);
  if (qtyInput) qtyInput.oninput = _refreshLabel;
  if (dsInput)  dsInput.oninput  = _refreshLabel;

  // Apply correct label/colour immediately instead of waiting for the first oninput
  _refreshLabel();
}

// Clears API results and picker but keeps verbiage fieldsets visible for continued manual entry
function _resetQlResults(role, origin) {
  resetQlDLTFields(role, origin);
  _updateClaimBanner(role, origin, false);
  sessionStorage.removeItem(SS_QL_RESULT);
  sessionStorage.removeItem(SS_QL_CLAIM);
  sessionStorage.removeItem(SS_QL_HAS_QUALIFYING_CLAIMS);
  sessionStorage.removeItem(SS_QL_AUTOMATED_DRUG_AND_REQ_QL);
  sessionStorage.removeItem(SS_QL_AUTOMATED_DRUG_AND_PLAN_QL);
  sessionStorage.removeItem(SS_QL_AUTOMATED_PLAN_QL);
  sessionStorage.removeItem(SS_QL_FINAL_DRUG_AND_REQ_QL);
  sessionStorage.removeItem(SS_QL_FINAL_DRUG_AND_PLAN_QL);
  sessionStorage.removeItem(SS_QL_FINAL_PLAN_QL);
  document.getElementById(`${role}${origin}qtyDaysUpdateBtn`)?.remove();
  _clearVerbiageFields(role, origin);
  _setPickerHtml(role, origin, '');
  toggleDisplay('solo', [`${role}${origin}qlPickerQ`], 'disable');
  clearPlanQlRef(role, origin);
}

function _clearVerbiageFields(role, origin) {
  ['qlDrugAndRequestedQlQ', 'qlDrugAndPlanQlQ', 'qlPlanQlQ'].forEach((internal) => {
    const txtEl = document.getElementById(`${role}${origin}${internal}txt`);
    if (txtEl) {
      txtEl.value = '';
      txtEl.readOnly = false;
    }
  });
}

function _setPickerHtml(role, origin, html) {
  const container = document.getElementById(`${role}${origin}qlPickerQcontainer`);
  if (container) container.innerHTML = html;
}

function _writeAutomatedVerbiage(verbiage) {
  sessionStorage.setItem(SS_QL_AUTOMATED_DRUG_AND_REQ_QL,  verbiage.drugAndRequestedQl);
  sessionStorage.setItem(SS_QL_AUTOMATED_DRUG_AND_PLAN_QL, verbiage.drugAndPlanQl);
  sessionStorage.setItem(SS_QL_AUTOMATED_PLAN_QL,          verbiage.planQlOnly);
}

function _writeFinalVerbiage(verbiage) {
  sessionStorage.setItem(SS_QL_FINAL_DRUG_AND_REQ_QL,  verbiage.drugAndRequestedQl);
  sessionStorage.setItem(SS_QL_FINAL_DRUG_AND_PLAN_QL, verbiage.drugAndPlanQl);
  sessionStorage.setItem(SS_QL_FINAL_PLAN_QL,          verbiage.planQlOnly);
}

export function getQlValues() {
  const raw = JSON.parse(sessionStorage.getItem(SS_QL_RESULT) || 'null');

  return {
    formularyId:    sessionStorage.getItem(SS_FORMULARY) || null,
    requiresPicker: raw?.requiresPicker ?? null,
    selectedOption: raw?.selectedOption ?? null,
    automated: {
      drugAndRequestedQl: sessionStorage.getItem(SS_QL_AUTOMATED_DRUG_AND_REQ_QL)  || null,
      drugAndPlanQl:      sessionStorage.getItem(SS_QL_AUTOMATED_DRUG_AND_PLAN_QL) || null,
      planQlOnly:         sessionStorage.getItem(SS_QL_AUTOMATED_PLAN_QL)          || null,
    },
    final: {
      drugAndRequestedQl: sessionStorage.getItem(SS_QL_FINAL_DRUG_AND_REQ_QL)  || null,
      drugAndPlanQl:      sessionStorage.getItem(SS_QL_FINAL_DRUG_AND_PLAN_QL) || null,
      planQlOnly:         sessionStorage.getItem(SS_QL_FINAL_PLAN_QL)          || null,
    },
  };
}
