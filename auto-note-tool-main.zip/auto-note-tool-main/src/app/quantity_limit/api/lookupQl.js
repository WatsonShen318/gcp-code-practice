import axios from 'axios';
// eslint-disable-next-line import/no-extraneous-dependencies
import axiosRetry from 'axios-retry';
import { getEnvironmentVariables } from '../../../../environment/config';
// Mock scenarios - swap the import to test a different path:
//   singleMatch    → supported, single result, verbiage auto-generated
//   requiresPicker → supported, multiple strengths, picker shown (default)
//   noMatch        → not supported - drug/formulary combination not found
//   nfDrug         → not supported - non-formulary drug, no QL data
//   incompleteData → not supported - incomplete data, QL unavailable
// import mockLookupQlResponse from '../../../mockData/ql/mockLookupQlResponse';
// import { singleMatch    as mockLookupQlResponse } from '../../../mockData/ql/mockLookupQlResponse';
// import { requiresPicker as mockLookupQlResponse } from '../../../mockData/ql/mockLookupQlResponse';
// import { noMatch        as mockLookupQlResponse } from '../../../mockData/ql/mockLookupQlResponse';
// import { nfDrug         as mockLookupQlResponse } from '../../../mockData/ql/mockLookupQlResponse';
// import { incompleteData as mockLookupQlResponse } from '../../../mockData/ql/mockLookupQlResponse';

axiosRetry(axios, {
  retries: 2,
  retryCondition: (error) => error.response?.status >= 500,
  retryDelay: (retryCount) => retryCount * 1000,
});

async function lookupQl(formularyId, gpi, drugName, quantityRequested, daysSupplyRequested, memberId, receivedDate = null) {
  const { AUTO_NOTE_BACKEND } = getEnvironmentVariables();

  if (window.location.href.includes('localhost')) {
    // TODO: Remove when done testing
    // return mockLookupQlResponse;
  }

  const response = await axios.post(
    `${AUTO_NOTE_BACKEND}/quantity-limit/lookup`,
    { formularyId, gpi, drugName, quantityRequested, daysSupplyRequested, memberId, receivedDate },
    { timeout: 60000 }
  );

  return response.data.data;
}

export default lookupQl;
