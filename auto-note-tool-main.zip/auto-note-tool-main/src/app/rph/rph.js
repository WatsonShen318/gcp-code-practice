import { rdoBtn } from "../utils/inputSelect";
import handleRPH from "./clickEvents";
import resetSessionStorage from "../utils/resetSessionStorage";
import resetFillIntake from "../utils/resetIntakeFields";

rdoBtn("rphoriginQ").forEach((elem) => {
  elem.addEventListener("click", (e) => {
    resetSessionStorage();
    resetFillIntake("rph", "Queue");
    handleRPH(e);
  });
});
