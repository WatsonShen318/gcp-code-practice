import toggleOriginRefs from '../origin/originRefs.display';
import { toggleMemberChecks } from '../member/member.display';
import { showButtons } from '../buttons/display';
import { originChange } from '../utils/showTool';
import { setCAREAgent } from '../utils/automation';
import { handleOriginClickEvent } from '../prefill/caseIdHandler';
import resetSessionStorage from '../utils/resetSessionStorage';
//import { toggleClients } from '../client/display';

const role = 'rph';

export default function handleRPH(e) {
  const origin = e.target.value;
  resetSessionStorage();
  if (origin === 'Queue') {
    import(
      /* webpackPrefetch: true */ /* webpackChunkName: "rphqfunctions" */ './rph.q'
    );
    handleOriginClickEvent(role, origin);
  }
  if (origin === 'TAT') {
    import(
      /* webpackPrefetch: true */ /* webpackChunkName: "rphTATfunctions" */ './rph.tat'
    );
    handleOriginClickEvent(role, origin);
  }
  if (origin === 'IBC') {
    import(
      /* webpackPrefetch: true */ /* webpackChunkName: "rphIBCfuncstions" */ './ibc/rph.ibc'
    );
    setCAREAgent(origin, role);
    handleOriginClickEvent(role, origin);
  }

  originChange(role, origin);
  toggleMemberChecks(origin, role);
  toggleOriginRefs(role, origin);
  //toggleClients(origin, role);
  showButtons(origin); //! Display Generate Note button.
}
