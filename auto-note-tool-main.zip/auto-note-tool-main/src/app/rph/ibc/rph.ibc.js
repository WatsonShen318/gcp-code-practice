import {
  toggleRqstByCallerInfo,
  toggleRqstByCallerAOR,
  showRqstByCaller,
  toggleRqsterNameCallBack,
} from '../../caller/display';
import { togglePOAQ, toggleAORLoc } from '../../aor/aor.display';
import {
  toggleRestrict,
  toggleNoforRDHeadsup,
  toggleClientName,
  toggleClientHeadsup,
} from '../../client/display';
import {
  clearRqstBy,
  clearLetterPreview,
  clearMDReview,
  clearNewMDInfo,
} from '../../reset/reset';
import { setMDnewInfo, setSupprtStatement } from '../../utils/automation';
import { handleRoutingChange } from '../../verbiage/index';
import { toggleChecks, toggleRoutes } from '../../decision/decision.display';
import {
  toggleDrugeRef,
  toggleRqstReason,
} from '../../requestReason/requestReason.display';
import { showFormAltsSection, resetFormAlts, refreshFormAltsOnClientChange, resolveFormularyForClient } from '../../form_alts/formAlts';
import { showQlSection, resetQl, refreshQlOnClientChange } from '../../quantity_limit/quantityLimit';
import { initAetnaQuestions, resetAetnaQuestions } from '../../aetna_questions/aetnaQuestions';
import {
  toggleLtrPreview,
  toggleLtrPreviewNA,
} from '../../letterPreview/display';
import toggleAORCheck from '../../aor/aorCheck.display';
import { toggleOBCDone, toggleOutbound } from '../../outbound/outbound.display';
import msgRqstType from '../../requestType/dialog';
import common from '../../shared/common';
import commonIBC from '../../shared/common.ibc';
import commonRPH from '../shared/common.rph';
import msgDecision from '../../decision/decision.dialog';
import claim from '../../claim/claim';
import {
  careAgent,
  client,
  decisionRouting,
  requestBy,
  requestReason,
  requestType,
  subAORFileLocation,
  subAORMember,
} from '../../qsets/fields';
import {
  toggledeniedRD,
  toggledeniedRDrphDecision,
} from '../../utils/deniedRD.display';
import toggleMDTemplate from '../../medicalDirector/mdTemplate.display';
import toggleRecommand from '../../utils/rdRecommand.display';
import { toggleApprovedTier, toggleCurrentTier } from '../../tiering/display';
//import { toggleOD } from '../../requestType/display';
import { handleCareAgent } from './clickEvents';
//AMN 5/9/23 - May 2023 Enhancements - #124: Add pop-up for Inbound Call [Requested By] = AOR
import msgAOR from '../../requestBy/dialogs';
import { caseIdInputHandler } from '../../prefill/caseIdHandler';

let answer = null;
const role = 'rph';
const origin = 'IBC';

common(role, origin);
commonIBC(origin, role);
commonRPH(origin, role);
claim(origin, role);

//* Is the call being transferred to you from a CARE agent?
careAgent(role, origin, 'event').forEach((elem) => {
  elem.addEventListener('change', (e) => {
    handleCareAgent(e, role, origin);
  });
});

//* Client Select drop down
client(role, origin, 'event').addEventListener('change', (e) => {
  answer = e.target.value;
  toggleRestrict(origin, role, answer);
  toggleClientName(origin, role, answer);
  toggleNoforRDHeadsup(origin, role, answer);
  toggleClientHeadsup(origin, role, answer);
  toggleChecks(origin, role);
  toggleRoutes(origin, role, answer);
  toggleRqstReason(origin, role, answer);
  //toggleOD(origin, role);
  //* Toggle multiple fields by selecting Oscar Health (21BV)
  //toggleMultiFieldsOscar21BV(origin, role, answer);
  const rrAnswer = requestReason(role, origin, 'value')?.toLowerCase() || '';
  if (rrAnswer === 'non-formulary') {
    refreshFormAltsOnClientChange(role, origin);
    resetAetnaQuestions(role, origin);
    initAetnaQuestions(role, origin);
  } else if (rrAnswer.includes('quantity limit')) {
    refreshQlOnClientChange(role, origin);
  } else {
    resolveFormularyForClient(role, origin);
  }
});

//* Requested By question
requestBy(role, origin, 'event').forEach((elem) => {
  elem.addEventListener('click', (e) => {
    answer = e.target.value;
    //AMN 5/9/23 - May 2023 Enhancements - #124: Add pop-up for Inbound Call [Requested By] = AOR
    msgAOR(answer);
    clearRqstBy(origin, role);
    toggleRqstByCallerAOR(origin, role, answer);
    toggleRqsterNameCallBack(origin, role, answer);
  });
});

//* Did you speak with the member who authorized you to speak with another person?
subAORMember(role, origin, 'event').forEach((elem) => {
  elem.addEventListener('click', (e) => {
    answer = e.target.value;
    toggleRqstByCallerInfo(origin, role, answer);
    showRqstByCaller(origin, role, answer);
    togglePOAQ(origin, role, answer);
  });
});

// * Is the required Power of Attorney (POA) on file question
subAORFileLocation(role, origin, 'event').forEach((elem) => {
  elem.addEventListener('click', (e) => {
    answer = e.target.value;
    toggleAORLoc(origin, role, answer);
  });
});

//* Request Reason
requestReason(role, origin, 'event').addEventListener('change', (e) => {
  answer = e.target.value;
  setSupprtStatement(origin, role, answer, 'RequestReason');
  toggleCurrentTier(origin, role, answer);
  toggleChecks(origin, role);
  toggleApprovedTier(origin, role);
  toggleDrugeRef(origin, role, answer);
  if (answer.toLowerCase() === 'non-formulary') {
    resetQl(role, origin);
    showFormAltsSection(role, origin);
    initAetnaQuestions(role, origin);
  } else if (answer.toLowerCase().includes('quantity limit')) {
    resetFormAlts(role, origin);
    resetAetnaQuestions(role, origin);
    showQlSection(role, origin);
  } else {
    resetFormAlts(role, origin);
    resetAetnaQuestions(role, origin);
    resetQl(role, origin);
  }
});

//* Request Type
requestType(role, origin, 'event').forEach((elem) => {
  elem.addEventListener('click', (e) => {
    answer = e.target.value;
    clearNewMDInfo(origin, role);
    msgRqstType(origin, answer);
    toggleChecks(origin, role);
    toggleRoutes(origin, role, answer);
    toggleRecommand(origin, role);
    toggledeniedRD(origin, role);
    setMDnewInfo(origin, role);
  });
});

//* Case Decision/Routing
decisionRouting(role, origin, 'event').addEventListener('change', (e) => {
  answer = e.target.value;
  clearLetterPreview(origin, role);
  clearMDReview(origin, role);
  msgDecision(origin, role, answer);
  toggleMDTemplate(origin, role); // $ lazy load here
  toggleChecks(origin, role);
  toggleApprovedTier(origin, role);
  toggleLtrPreview(origin, role);
  toggleRecommand(origin, role);
  toggleAORCheck(origin, role, answer);
  toggleOutbound(origin, role, answer);
  toggledeniedRD(origin, role);
  toggleLtrPreviewNA(origin, role, answer);
  toggledeniedRDrphDecision(origin, role);
  toggleOBCDone(role, origin);
  handleRoutingChange(role, origin, answer);
});

// caseId handler for caseId validation and conditionally display questions
caseIdInputHandler(role, origin);
