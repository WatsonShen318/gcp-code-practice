/* eslint-disable import/prefer-default-export */
import msgCareAgentAuthen from '../../care/dialogs';
import CAREagentDetail from '../../care/display';

let answer = null;

export const handleCareAgent = (e, role, origin) => {
  answer = e.target.value;
  CAREagentDetail(origin, role, answer);
  msgCareAgentAuthen(answer);
};
