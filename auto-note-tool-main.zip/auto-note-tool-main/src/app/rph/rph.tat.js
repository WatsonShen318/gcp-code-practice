import {
  toggleRestrict,
  toggleClientName,
  toggleClientHeadsup,
} from '../client/display';
import { toggleChecks, toggleRoutes } from '../decision/decision.display';
import {
  clearLetterPreview,
  clearMDReview,
  clearNewMDInfo,
} from '../reset/reset';
import {
  setMDdxNo,
  setMDnewInfo,
  setSupprtStatement,
} from '../utils/automation';
import { toggleApprovedTier, toggleCurrentTier } from '../tiering/display';
import msgRqstType from '../requestType/dialog';
import msgDecision from '../decision/decision.dialog';
import toggleMDTemplate from '../medicalDirector/mdTemplate.display';
import { handleRoutingChange } from '../verbiage/index';
import { toggleOBCDone, toggleOutbound } from '../outbound/outbound.display';
import common from '../shared/common';
import commonRPH from './shared/common.rph';
import {
  toggledeniedRD,
  toggledeniedRDrphDecision,
} from '../utils/deniedRD.display';
import { toggleLtrPreview, toggleLtrPreviewNA } from '../letterPreview/display';
import toggleDeniedOutreach from '../utils/deniedOutreach.display';
import toggleExceptionRdo from '../utils/exceptionRdo.display';
import { toggleDrugeRef } from '../requestReason/requestReason.display';
import { showFormAltsSection, resetFormAlts, refreshFormAltsOnClientChange, resolveFormularyForClient } from '../form_alts/formAlts';
import { showQlSection, resetQl, refreshQlOnClientChange } from '../quantity_limit/quantityLimit';
import { initAetnaQuestions, resetAetnaQuestions } from '../aetna_questions/aetnaQuestions';
import msgAttachment from '../attachments/dialog';
import {
  approvedDiagnosis,
  client,
  decisionRouting,
  newAttachments,
  requestReason,
  requestType,
} from '../qsets/fields';
import { caseIdInputHandler } from '../prefill/caseIdHandler';

let answer = null;
const role = 'rph';
const origin = 'TAT';

common(role, origin);
commonRPH(origin, role);

//* Client Select drop down
client(role, origin, 'event').addEventListener('change', (e) => {
  answer = e.target.value;
  // AMN 12/8/22 - December 2022 Enhancement - #112: Client Drop Down Updates
  // toggleRestrict(origin, role, answer);
  // toggleClientName(origin, role, answer);
  toggleClientHeadsup(origin, role, answer);
  toggleRestrict(origin, role, answer);
  toggleClientName(origin, role, answer);
  const rrAnswer = requestReason(role, origin, 'value')?.toLowerCase() || '';
  if (rrAnswer === 'non-formulary') {
    refreshFormAltsOnClientChange(role, origin);
    resetAetnaQuestions(role, origin);
    initAetnaQuestions(role, origin);
  } else if (rrAnswer.includes('quantity limit')) {
    refreshQlOnClientChange(role, origin);
  } else {
    resolveFormularyForClient(role, origin);
  }
});

//* Approvable Diagnosis?
approvedDiagnosis(role, origin, 'event').forEach((elem) => {
  elem.addEventListener('click', (e) => {
    answer = e.target.value;
    setMDdxNo(origin, role);
  });
});

//* Request Reason
requestReason(role, origin, 'event').addEventListener('change', (e) => {
  answer = e.target.value;
  setSupprtStatement(origin, role, answer, 'RequestReason');
  toggleCurrentTier(origin, role, answer);
  toggleApprovedTier(origin, role);
  toggleDrugeRef(origin, role, answer);
  if (answer.toLowerCase() === 'non-formulary') {
    resetQl(role, origin);
    showFormAltsSection(role, origin);
    initAetnaQuestions(role, origin);
  } else if (answer.toLowerCase().includes('quantity limit')) {
    resetFormAlts(role, origin);
    resetAetnaQuestions(role, origin);
    showQlSection(role, origin);
  } else {
    resetFormAlts(role, origin);
    resetAetnaQuestions(role, origin);
    resetQl(role, origin);
  }
});

//* Request Type
requestType(role, origin, 'event').forEach((elem) => {
  elem.addEventListener('click', (e) => {
    answer = e.target.value;
    clearNewMDInfo(origin, role);
    msgRqstType(origin, answer);
    toggleChecks(origin, role);
    toggleRoutes(origin, role, answer);
    toggledeniedRD(origin, role);
    setMDnewInfo(origin, role);
  });
});

//* Case Decision/Routing
decisionRouting(role, origin, 'event').addEventListener('change', (e) => {
  answer = e.target.value;
  clearLetterPreview(origin, role);
  clearMDReview(origin, role);
  msgDecision(origin, role, answer);
  toggleMDTemplate(origin, role); // $ lazy load here
  toggleChecks(origin, role);
  toggleApprovedTier(origin, role);
  toggleOutbound(origin, role, answer);
  toggleLtrPreview(origin, role);
  toggledeniedRD(origin, role);
  toggleDeniedOutreach(origin, role, answer);
  // toggleExceptionRdo(origin, role, answer);
  toggleLtrPreviewNA(origin, role, answer);
  toggledeniedRDrphDecision(origin, role);
  toggleOBCDone(role, origin);
  handleRoutingChange(role, origin, answer);
});

//* New Attachments Received?
newAttachments(role, origin, 'event').forEach((elem) => {
  elem.addEventListener('click', (e) => {
    answer = e.target.value;
    msgAttachment(answer);
  });
});

// caseId handler for caseId validation and conditionally display questions
caseIdInputHandler(role, origin);