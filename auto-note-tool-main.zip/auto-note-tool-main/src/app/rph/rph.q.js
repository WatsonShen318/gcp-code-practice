import {
  toggleRestrict,
  toggleNoforRDHeadsup,
  toggleClientName,
  toggleClientHeadsup,
} from '../client/display';
import {
  toggleChecks,
  setDecision,
  toggleRoutes,
} from '../decision/decision.display';
import {
  clearDecision,
  clearLetterPreview,
  clearMDReview,
  clearNewMDInfo,
  clearRejects,
  clearRqstBy,
} from '../reset/reset';
import { toggleAORLoc, togglePOAQ } from '../aor/aor.display';
import { setMDnewInfo, setSupprtStatement } from '../utils/automation';
import toggleRecommand from '../utils/rdRecommand.display';
import { toggleAllClaimQs } from '../claim/claim.display';
import { toggleApprovedTier, toggleCurrentTier } from '../tiering/display';
import msgRqstType from '../requestType/dialog';
import msgDecision from '../decision/decision.dialog';
import toggleMDTemplate from '../medicalDirector/mdTemplate.display';
import { handleRoutingChange } from '../verbiage/index';
import { toggleLtrPreview, toggleLtrPreviewNA } from '../letterPreview/display';
import toggleAORCheck from '../aor/aorCheck.display';
import { toggleOBCDone, toggleOutbound } from '../outbound/outbound.display';
import common from '../shared/common';
import commonRPH from './shared/common.rph';
import claim from '../claim/claim';
import {
  toggledeniedRD,
  toggledeniedRDrphDecision,
} from '../utils/deniedRD.display';
import { toggleDrugeRef } from '../requestReason/requestReason.display';
import { showFormAltsSection, resetFormAlts, refreshFormAltsOnClientChange, resolveFormularyForClient } from '../form_alts/formAlts';
import { showQlSection, resetQl, refreshQlOnClientChange } from '../quantity_limit/quantityLimit';
import { initAetnaQuestions, resetAetnaQuestions } from '../aetna_questions/aetnaQuestions';
import {
  client,
  decisionRouting,
  ePA,
  requestBy,
  requestReason,
  requestType,
  subAORFileLocation,
} from '../qsets/fields';
import { caseIdInputHandler } from '../prefill/caseIdHandler';

let answer = null;
const role = 'rph';
const origin = 'Queue';

common(role, origin);
commonRPH(origin, role);
claim(origin, role);

//* Client Select drop down
client(role, origin, 'event').addEventListener('change', (e) => {
  answer = e.target.value;
  toggleRestrict(origin, role, answer);
  toggleClientName(origin, role, answer);
  toggleNoforRDHeadsup(origin, role, answer);
  toggleClientHeadsup(origin, role, answer);
  toggleChecks(origin, role);
  const rrAnswer = requestReason(role, origin, 'value')?.toLowerCase() || '';
  if (rrAnswer === 'non-formulary') {
    refreshFormAltsOnClientChange(role, origin);
    resetAetnaQuestions(role, origin);
    initAetnaQuestions(role, origin);
  } else if (rrAnswer.includes('quantity limit')) {
    refreshQlOnClientChange(role, origin);
  } else {
    resolveFormularyForClient(role, origin);
  }
});

//* Requested By question
requestBy(role, origin, 'event').forEach((elem) => {
  elem.addEventListener('click', (e) => {
    answer = e.target.value;
    clearRqstBy(origin, role);
    clearDecision(origin, role);
    togglePOAQ(origin, role, answer);
  });
});

// * Is the required Power of Attorney (POA) on file question
subAORFileLocation(role, origin, 'event').forEach((elem) => {
  elem.addEventListener('click', (e) => {
    answer = e.target.value;
    toggleAORLoc(origin, role, answer);
    setDecision(origin, role, answer, 'POA');
  });
});

//* Robotics/ Was the case successfully created through ePA answer, toggle visibility
ePA(role, origin, 'event').forEach((elem) => {
  elem.addEventListener('change', (e) => {
    answer = e.target.value;
    toggleAllClaimQs(origin, role, answer);
    clearRejects(origin, role);
  });
});

//* Request Reason
requestReason(role, origin, 'event').addEventListener('change', (e) => {
  answer = e.target.value;
  setSupprtStatement(origin, role, answer, 'RequestReason');
  toggleCurrentTier(origin, role, answer);
  toggleChecks(origin, role);
  toggleApprovedTier(origin, role);
  toggleDrugeRef(origin, role, answer);
  if (answer.toLowerCase() === 'non-formulary') {
    resetQl(role, origin);
    showFormAltsSection(role, origin);
    initAetnaQuestions(role, origin);
  } else if (answer.toLowerCase().includes('quantity limit')) {
    resetFormAlts(role, origin);
    resetAetnaQuestions(role, origin);
    showQlSection(role, origin);
  } else {
    resetFormAlts(role, origin);
    resetAetnaQuestions(role, origin);
    resetQl(role, origin);
  }
});

//* Request Type
requestType(role, origin, 'event').forEach((elem) => {
  elem.addEventListener('click', (e) => {
    answer = e.target.value;
    clearNewMDInfo(origin, role);
    msgRqstType(origin, answer);
    toggleChecks(origin, role);
    toggleRoutes(origin, role, answer);
    toggleRecommand(origin, role);
    toggledeniedRD(origin, role);
    setMDnewInfo(origin, role);
  });
});

//* Case Decision/Routing
decisionRouting(role, origin, 'event').addEventListener('change', (e) => {
  answer = e.target.value;
  clearLetterPreview(origin, role);
  clearMDReview(origin, role);
  msgDecision(origin, role, answer);
  toggleMDTemplate(origin, role); // $ lazy load here
  toggleChecks(origin, role);
  toggleApprovedTier(origin, role);
  toggleLtrPreview(origin, role);
  toggleRecommand(origin, role);
  toggleAORCheck(origin, role, answer);
  toggleOutbound(origin, role, answer);
  toggledeniedRD(origin, role);
  toggleLtrPreviewNA(origin, role, answer);
  toggledeniedRDrphDecision(origin, role);
  toggleOBCDone(role, origin);
  handleRoutingChange(role, origin, answer);
});

// caseId handler for caseId validation and conditionally display questions
caseIdInputHandler(role, origin);