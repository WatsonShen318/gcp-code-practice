import { setSupprtStatement } from "../../utils/automation";
import { toggleCompendiaRef, toggleDrugdex } from "../../compendia/display";
import msgDeniedRD from "../../utils/deniedRD.dialog";
import { toggledeniedRDrphDecision } from "../../utils/deniedRD.display";
import {
  additionalOutboundCallNeeded,
  approvedDiagnosis,
  mdReview,
  RFITATCaseReviewed,
  subCompendiaRefs,
  supportingStatement,
} from "../../qsets/fields";
import toggleMDTemplate from "../../medicalDirector/mdTemplate.display";
import { clearToll } from "../../reset/reset";
import {
  toggleToll,
  toggleSupportStatementLocation,
} from "../../supportingStatement/display";
import toggleSubQuestionsForRFITATCaseReviewed from "../../reviewedByRFI/displays";
import { toggleOBCFromAdditionalOBCNeeded, toggleOBdetails } from "../../outbound/outbound.display";

let answer;
export default function commonRPH(origin, role) {
  // * Approvable diagnosis?
  approvedDiagnosis(role, origin, "event").forEach((elem) => {
    elem.addEventListener("click", (e) => {
      answer = e.target.value;
      toggleCompendiaRef(origin, role, answer);
      toggleDrugdex(origin, role);
      setSupprtStatement(origin, role, answer, "comdenpia");
    });
  });

  // * Compendia Referenced
  subCompendiaRefs(role, origin, "event").forEach((elem) => {
    elem.addEventListener("click", () => {
      toggleDrugdex(origin, role);
    });
  });

  //* Is the denial for a status reason that does NOT require MD review for RD denial?
  mdReview(role, origin, "event").forEach((elem) => {
    elem.addEventListener("click", (e) => {
      answer = e.target.value;
      toggledeniedRDrphDecision(origin, role);
      msgDeniedRD(answer);
      toggleMDTemplate(origin, role); // $ lazy load here
    });
  });

  //* Does the case have a supporting statement OR is not required?
  supportingStatement(role, origin, "event").forEach((elem) => {
    elem.addEventListener("click", (e) => {
      answer = e.target.value;
      toggleToll(origin, role, answer);
      toggleSupportStatementLocation(origin, role, answer);
      clearToll(origin, role);
    });
  });

  /* RFI TAT Case Reviewed by technician */
  RFITATCaseReviewed(role, origin, "event").forEach((elem) => {
    elem.addEventListener("click", (e) => {
      answer = e.target.value;
      toggleSubQuestionsForRFITATCaseReviewed(origin, role, answer);
      toggleOBdetails(origin, role, '', `${role}${origin}subobPurposeQaltPA`, true);
    });
  });

  /* Additional Outbound call needed */
  additionalOutboundCallNeeded(role, origin, "event").forEach((elem) => {
    elem.addEventListener("click", (e) => {
      answer = e.target.value;
      toggleOBCFromAdditionalOBCNeeded(origin, role, answer);
    });
  });
}
