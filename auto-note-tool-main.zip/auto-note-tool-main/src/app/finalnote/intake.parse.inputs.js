import ComponentNote from './components/intake.component';
import sendDataToBigTable from '../bigTable/bigTable';

export const UserCaseComponent = (toolType) => {
  const notes = new ComponentNote();
  const requestType = notes.iRequestType;
  let output;

  if (toolType === 'trash') {
    output = 'Intake';
  } else if (toolType === 'IntakeHospice') {
    output = 'Intake';
  } else if (requestType === 'Forward Fax' || requestType === 'Re-route') {
    output = 'Intake';
  } else {
    output = `Intake ${notes.priority}${notes.expediteNote}${notes.iTier}${notes.ihospice}${notes.barcode}case for ${notes.idrugcompound}${notes.drugname}. ${notes.iSplitFax}`;
  }
  
  return output;
};

export const OutcomeReminderComponent = (toolType) => {
  const notes = new ComponentNote();
  const MultipleRqst = notes.multipleRqst;
  const MultiCaseCountBalance = notes.multipleRqstBalance;
  let output;

  if (toolType === 'trash') {
    output = 'Please trash your fax';
  } else if (toolType === 'IntakeHospice') {
    output =
      'Forward fax to 1-844-242-0904 (MedForce) and follow the forward fax work instructions.';
  } else if (MultipleRqst === 'Yes' && MultiCaseCountBalance > 0) {
    output = `You need to create ${MultiCaseCountBalance} more case(s) for this member.`;
  }
  return output;
};

export const OutcomeComponent = (toolType) => {
  const notes = new ComponentNote();
  const requestType = notes.iRequestType;
  const MemberSearch = notes.iMemberSearch;
  const MultipleRqst = notes.multipleRqst;
  const MultipleRqstReason = notes.multipleRqstReason;
  const { memberID } = notes;
  let output;

  if (toolType === 'trash') {
    output = ' TRASH FAX';
  } else if (toolType === 'IntakeHospice') {
    output =
      ' The fax only indicates hospice admission/discharge dates. Sending to MedForce for processing.';
  } else if (MemberSearch === 'No') {
    output = `Member termed or not found in MHK/Compass and/or unable to verify 3 identifiers. Forwarding to secondary for review.`;
  } else if (requestType === 'Secondary Review') {
    output = `Member not found in MHK, but found in Compass. ${notes.iSecRational}. Forwarding to secondary for review.`;
  } else if (requestType === 'Re-route') {
    output = ` Re-routing to ${notes.reRouteRational} for review.`;
  } else if (requestType === 'Forward Fax') {
    output = ` ${notes.forwardFaxRational}. Forwarding to ${notes.forwardFaxTo} for review. `;
  } else if (MultipleRqst === 'Yes' && MultipleRqstReason === 'PA/NF/ST') {
    output = `Forwarding request ${notes.multipleRqstCases} of ${notes.multipleRqstCaseTotal} for this member to tech for review.`;
  } else if (MultipleRqst === 'Yes' && MultipleRqstReason !== 'PA/NF/ST') {
    output = `Forwarding request ${notes.multipleRqstCases} of ${notes.multipleRqstCaseTotal} for this member to tech for review. (${notes.multipleRqstReason}).`;
  } else if (memberID === 'MA') {
    output = ' Forwarding to Organization Determination for review.';
  } else if (memberID === 'BCBS of MASS') { //AMN 12/8/22 - December 2022 Enhancement - #113: Intake Update for BCBS of MASS
    output = ' Forwarding to clinical for review.';
  } else {
    output = 'Forwarding to tech for review.';
  }

  output += ` ${notes.memberValidated}`
  // if (notes.member.length > 8) {
  //   output += ` ${notes.member}`
  // }

  sendDataToBigTable(output, "intake", "form");
  return output;
};
