import MDComponent from './components/md.component';
import RPHqComponent from './components/rph.q.components';
import RPHtatComponent from './components/rph.tat.component';
import RPHibcComponent from './components/rph.ibc.component';

const br = '\r\n';
let output = null;

export const rphT = (origin, role) => {
  const rtnotes = new RPHtatComponent(origin, role);
  const mdnotes = new MDComponent(origin, role);

  output = [
    mdnotes.pdpmapd,
    mdnotes.mddiagnosis,
    mdnotes.fda,
    mdnotes.csoOffLabel,
    mdnotes.mdCompendia,
    mdnotes.mdoSafety,
    mdnotes.infoReview,
    mdnotes.newInfoRD,
    mdnotes.conflictInfo,
    mdnotes.mdClaims,
    mdnotes.mdResolution,
    mdnotes.mdRationale,
    mdnotes.mdOutreach,
    mdnotes.letterStatus,
    mdnotes.MDdateTime,
    // mdnotes.nameTitle,
    mdnotes.break,
    rtnotes.title,
    rtnotes.prospective,
    // rtnotes.member,
    rtnotes.memberValidated,
    rtnotes.priority,
    rtnotes.client,
    rtnotes.timeStamp,
    rtnotes.requestedBy,
    rtnotes.diagnosis,
    rtnotes.compendia,
    rtnotes.drug,
    rtnotes.requestReason,
    rtnotes.tiering + rtnotes.tierCaseCreate + rtnotes.currentTier,
    rtnotes.matchingCase,
    rtnotes.requestType,
    rtnotes.aetnaSpecificAnswers,
    rtnotes.supportStatement,
    rtnotes.supportStatementLocation,
    rtnotes.outbound,
    rtnotes.decisionRational,
    rtnotes.checkedPriorHistory,
    rtnotes.decision,
    rtnotes.newAttachment,
    rtnotes.MDReviewRD,
  ]
    .filter(Boolean)
    .join(br);

  return output;
};

export const rphQ = (origin, role) => {
  const rqnotes = new RPHqComponent(origin, role);
  const mdnotes = new MDComponent(origin, role);

  output = [
    mdnotes.pdpmapd,
    mdnotes.mddiagnosis,
    mdnotes.fda,
    mdnotes.csoOffLabel,
    mdnotes.mdCompendia,
    mdnotes.mdoSafety,
    mdnotes.infoReview,
    mdnotes.newInfoRD,
    mdnotes.conflictInfo,
    mdnotes.mdClaims,
    mdnotes.mdResolution,
    mdnotes.mdRationale,
    mdnotes.mdOutreach,
    mdnotes.letterStatus,
    mdnotes.MDdateTime,
    // mdnotes.nameTitle,
    mdnotes.break,
    rqnotes.title,
    rqnotes.prospective,
    // rqnotes.member,
    rqnotes.memberValidated,
    rqnotes.priority,
    rqnotes.client,
    rqnotes.formularID,
    rqnotes.subClient,
    rqnotes.formularyDropdown,
    rqnotes.timeStamp,
    rqnotes.SourceMDOInfo,
    rqnotes.requestedBy,
    rqnotes.diagnosis,
    rqnotes.compendia,
    rqnotes.drug,
    rqnotes.rejectCode,
    rqnotes.requestReason,
    rqnotes.tiering +
      rqnotes.tierCaseCreate +
      rqnotes.currentTier +
      rqnotes.approvedTier,
    rqnotes.matchingCase,
    rqnotes.ePA,
    rqnotes.requestType,
    rqnotes.aetnaSpecificAnswers,
    rqnotes.supportStatement,
    rqnotes.supportStatementLocation,
    rqnotes.qlDrugAndRequestedQl,
    rqnotes.qlDrugAndPlanQl,
    rqnotes.qlPlanQl,
    rqnotes.rfiTATCaseReviewed,
    rqnotes.outbound,
    rqnotes.decisionRational,
    rqnotes.decision,
    rqnotes.rfiReason,
    rqnotes.denialReason,
    rqnotes.multipleCase,
    rqnotes.newAttachment,
    rqnotes.rdRecommand,
    rqnotes.MDReviewRD,
  ]
    .filter(Boolean)
    .join(br);

  return output;
};

export const rphIBC = (origin, role) => {
  const ibcnotes = new RPHibcComponent(origin, role);
  const mdnotes = new MDComponent(origin, role);

  output = [
    mdnotes.pdpmapd,
    mdnotes.mddiagnosis,
    mdnotes.fda,
    mdnotes.csoOffLabel,
    mdnotes.mdCompendia,
    mdnotes.mdoSafety,
    mdnotes.infoReview,
    mdnotes.newInfoRD,
    mdnotes.conflictInfo,
    mdnotes.mdClaims,
    mdnotes.mdResolution,
    mdnotes.mdRationale,
    mdnotes.mdOutreach,
    mdnotes.letterStatus,
    mdnotes.MDdateTime,
    // mdnotes.nameTitle,
    mdnotes.break,
    ibcnotes.title,
    ibcnotes.prospective,
    ibcnotes.careAgent,
    ibcnotes.careContact,
    ibcnotes.memberChecks,
    ibcnotes.priority,
    ibcnotes.client,
    ibcnotes.formularID,
    ibcnotes.subClient,
    ibcnotes.formularyDropdown,
    ibcnotes.timeStamp,
    ibcnotes.SourceMDOInfo,
    ibcnotes.requestedBy,
    ibcnotes.diagnosis,
    ibcnotes.compendia,
    ibcnotes.drug,
    ibcnotes.rejectCode,
    ibcnotes.requestReason,
    ibcnotes.tiering +
      ibcnotes.tierCaseCreate +
      ibcnotes.currentTier +
      ibcnotes.approvedTier,
    ibcnotes.matchingCase,
    ibcnotes.requestType,
    ibcnotes.aetnaSpecificAnswers,
    ibcnotes.supportStatement,
    ibcnotes.supportStatementLocation,
    ibcnotes.qlDrugAndRequestedQl,
    ibcnotes.qlDrugAndPlanQl,
    ibcnotes.qlPlanQl,
    ibcnotes.rfiTATCaseReviewed,
    ibcnotes.outbound,
    ibcnotes.decisionRational,
    ibcnotes.decision,
    ibcnotes.rfiReason,
    ibcnotes.denialReason,
    ibcnotes.multipleCase,
    ibcnotes.newAttachment,
    ibcnotes.rdRecommand,
    ibcnotes.MDReviewRD,
  ]
    .filter(Boolean)
    .join(br);

  return output;
};
