import EAGAAFNRcomponent from './components/eagAafnr.component';

import sendDataToBigTable from '../bigTable/bigTable';

const br = '\r\n';

const eagNote = (origin, role) => {
  const eagnotes = new EAGAAFNRcomponent(origin, role);

  const output = [
    eagnotes.title,
    // eagnotes.member,
    eagnotes.memberValidated,
    eagnotes.careAgent,
    eagnotes.careContact,
    eagnotes.requestedBy,
    eagnotes.drug,
    eagnotes.qtyDS,
    eagnotes.testClaimGLanswers,
    eagnotes.reasonNoCase,
  ]
    .filter(Boolean)
    .join(br);

  sendDataToBigTable(output, role, origin);

  return output;
};

export default eagNote;
