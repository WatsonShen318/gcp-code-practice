import { subClientManual } from '../qsets/fields';

export function getClientVerb(role, origin, selection) {
  const clientText = subClientManual(role, origin, 'value').trim();
  const otherclient = {
    EGWP: `Client: EGWP - ${clientText}`,
    Other: `Client: ${clientText}`,
  };
  return otherclient[selection] || `Client: ${clientSelect}`;
}

export function getRDRecVerb(answer) {
  const RDrecommandation = {
    Yes: 'Redetermination Recommendation Approved',
    No: 'Redetermination Recommendation needs additional Pharmacist review',
  };
  return RDrecommandation[answer] || '';
}

export function getRqstedBy(rqstBy, AORonFile, AORLoc) {
  let verb;
  if (rqstBy === 'AOR' && AORonFile === 'Yes') {
    verb = `Requested by: ${rqstBy} - found in ${AORLoc}`;
  } else if (rqstBy === 'AOR' && AORonFile === 'No') {
    verb = `Requested by: ${rqstBy} - AOR/POA not found on file.`;
  } else {
    verb = rqstBy ? `Requested by: ${rqstBy}` : '';
  }
  return verb;
}
