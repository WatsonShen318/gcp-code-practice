import {
  UserCaseComponent as IntakeUserInfo,
  OutcomeComponent as IntakeOutcome,
  OutcomeReminderComponent as IntakeReminder,
} from './intake.parse.inputs';
import { techSR, techQ, techIBC, techTAT } from './tech.parse.inputs';
import inquiryNote from './inquiry.parse.inputs';
import { AlertService } from '../modal/alert.service';
import { toggleNextCaseBtn, goBackButton } from '../buttons/display';
import { getRepeatSectionVals } from '../utils/getInputValue';
import eagNote from './eagAafnr.parse.inputs';
import { rphQ, rphT, rphIBC } from './rph.parse.inputs';
import copyToClipBoard from '../utils/clipboard.api';
import { toggleDisplay } from '../utils/notetool.display';

export default function FinalNotes(role, origin, type = null) {
  const finalNote = document.getElementById('finalNote');
  const s = document.getElementById('FNReminderText');
  s.textContent = 'Confirm all changes were made in MHK';

  const reminder = document.getElementById('finalNoteReminder');

  if (role === 'intake') {
    finalNote.value = IntakeUserInfo(type) + IntakeOutcome(type);
    s.textContent = IntakeReminder(type);
  }
  if (role === 'tech') {
    if (origin === 'IBC') {
      finalNote.value = techIBC(origin, role);
    }
    if (origin === 'Queue') {
      finalNote.value = techQ(origin, role); // $ Queue Note
    }
    if (origin === 'TAT') {
      finalNote.value = techTAT(origin, role); // $ Turn Arount Time Note
    }
    if (origin === 'SR') {
      finalNote.value = techSR(origin, role); //! ! Secondary Review Note
    }
  }
  if (role === 'rph') {
    if (origin === 'IBC') {
      finalNote.value = rphIBC(origin, role);
    }
    if (origin === 'Queue') {
      finalNote.value = rphQ(origin, role); // $ Queue Note
    }
    if (origin === 'TAT') {
      finalNote.value = rphT(origin, role);
    }
  }
  document.getElementById('finalNoteDiv').style.display = 'block';

  if (s.textContent) {
    reminder.style.display = 'block';
  }

  document.getElementById('pills-tabContent').style.display = 'none';
  document.getElementById('generateNotebtn').style.display = 'none';
  toggleNextCaseBtn(role, origin);

  finalNote.select();
  copyToClipBoard(finalNote.value);
  AlertService('finalnote');
  toggleDisplay('solo', ['alertPopupBtn', 'alertPopup', `${role}${origin}manualTemplateBtn`,`${role}${origin}manualTemplateAboveTxt`], 'disable');
}

export function FinalSideNotes(origin, role, type) {
  const note = document.getElementById('finalSideNote');
  const section = document.getElementById('finalSideNoteDiv');
  const resetbtn = document.getElementById('Resetbtn');
  const header = document.getElementById('sideNoteH4');

  if (type === 'outboundcall') {
    header.innerText = 'Copy and Paste the note below into the Contacts tab';
    note.value = getRepeatSectionVals(role, origin);
    goBackButton();
    resetbtn.style.display = 'none';
  }
  if (type === 'outboundcallalt') {
    header.innerText = 'Copy and Paste the note below into the Contacts tab';
    note.value = getRepeatSectionVals(role, origin, true);
    goBackButton();
    resetbtn.style.display = 'none';
  }
  if (type === 'inquiry') {
    header.innerText = 'Copy and Paste the note below into the Member 360';
    note.value = inquiryNote(origin, role);
  }
  if (type === 'EAG' || type === 'AAFNR') {
    header.innerText = 'Copy and Paste the note below into the Member 360';
    note.value = eagNote(origin, role);
  }
  section.style.display = 'block';
  document.getElementById('pills-tabContent').style.display = 'none';
  document.getElementById('generateNotebtn').style.display = 'none';
  note.select();
  copyToClipBoard(note.value);
  AlertService(type);
}
