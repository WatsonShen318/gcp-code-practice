import { toTitleCase } from '../../utils/input-format';
import {
  decisionRouting,
  drugDS,
  drugName,
  drugNameWSearch,
  drugQty,
  rationale,
  requestBy,
  requestReason,
  timeStamp,
} from '../../qsets/fields';
import { getDiagnosisValue, getMemberValidated, getOBCValue, getPriority } from './get.values';
import getProsReviewVal from '../../prospectiveReview/get.values';

/**
 * * This component is a Base Component for all origins and roles, except Intake.
 */

export default class BaseComponent {
  constructor(origin, role) {

    const decsionRoute = decisionRouting(role, origin, 'value');
    function decision(route) {
      const d = {
      };
      return d[route] || '';
    }

    function finalTitle() {
      if (origin === 'IBC') {
        return `Title: ${origin} ${toTitleCase(role)}`;
      }
      return `Title: ${toTitleCase(role)}`;
    }

    // $ Title
    this.title = finalTitle();

    // $ Prospective Review
    this.prospective = getProsReviewVal(role, origin);

    // $ Diagnosis
    this.diagnosis = getDiagnosisValue(role, origin);

    // $ Member
    // this.member = getMembers(role, origin);
    this.memberValidated = getMemberValidated(role, origin)

    // $ Requested By
    this.requestedBy = requestBy(role, origin, 'value');

    // $ Priority
    this.priority = getPriority(role, origin);

    // $ TimeStamp
    const timestampValue = timeStamp(role, origin, 'value')
    this.timeStamp = timestampValue ? `Does case have a manual time stamp?: ${timestampValue}` : '';

    // $ Decision rational
    this.decisionRational = `Decision/Routing Rationale: ${rationale(
      role,
      origin,
      'value'
    )}`;

    // $ Decision routing
    this.decisionDropdown = decsionRoute; // $ this is to pass on a value
    this.decision = `Case Decision/Routing: ${decsionRoute}${decision(
      decsionRoute
    )}`;

    const drugNameValue = drugName(role, origin, 'value');
    const drugNameWSearchValue = drugNameWSearch(role, origin, 'value');

    // $ Drug
    this.drug = `Drug: ${drugNameValue || drugNameWSearchValue || ''}    Qty/DS: ${drugQty(
      role,
      origin,
      'value'
    )}/${drugDS(role, origin, 'value')}`;

    // $ Requset Reason
    this.requestReason = `Request Reason: ${requestReason(
      role,
      origin,
      'value'
    )}`;
    // $ OutboundCall
    this.outbound = getOBCValue(role, origin, decsionRoute);
  }
}
