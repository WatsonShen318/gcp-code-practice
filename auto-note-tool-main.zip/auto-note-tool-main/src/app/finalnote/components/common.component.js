import BaseComponent from "./base.component";
import { getAetnaSpecificAnswers } from "../../aetna_questions/fields";
import {
  client,
  subAORFileLocation,
  subAORonFileDoc,
  sourceMDOInfo,
  tierRequest,
  requestType,
  rdRecomand,
  ePA,
  subFormularyID as subFormularyIDField,
} from "../../qsets/fields";
import {
  getAttachmentValue,
  getMatchingCaseValue,
  getrejectCodeValue,
  getTieringValue,
  getClientVerb,
  getRDRecVerb,
  getRqstedBy,
  getMultipleCase,
  getTierCaseCreate,
  getRequestTypeDeniedValue,
  getRFITATCaseReviewedValue,
  getFormularyDropdown,
  getSubClient,
  getQlDrugAndRequestedQl,
  getQlDrugAndPlanQl,
  getQlPlanQl,
  getTypeOfQlReview,
  getPrescriberApprovedFormularyQlIneffective,
  getPrescriberApprovedDosesIneffective,
  getQlQualifyingClaim,
  getRfiReason,
  getDenialReason,
} from "./get.values";

/**
 * * This component is extension to the Base Component and it is used by Case Queue and Inbound Call notes for both Tech and RPh.
 */
export default class CommonComponent extends BaseComponent {
  constructor(origin, role) {
    super(origin, role);
    this.origin = origin;
    this.role = role;

    const AORonFile = subAORFileLocation(role, origin, "value").trim();
    const AORLoc = subAORonFileDoc(role, origin, "value").trim();
    const clientSelect = client(role, origin, "value");
    const tieringVal = tierRequest(role, origin, "value");
    const rqstBy = this.requestedBy;

    this.AORFile = AORonFile;
    this.AORLocation = AORLoc;

    this.memberChecks = this.memberValidated;

    // $ Claims
    this.rejectCode = getrejectCodeValue(role, origin);
    this.requester = rqstBy;

    // $ Requested By
    this.requestedBy = getRqstedBy(rqstBy, AORonFile, AORLoc);

    // $ Client
    this.client = getClientVerb(role, origin, clientSelect);

    const sourceMdoInfo = sourceMDOInfo(role, origin, "value");

    // $ MDO Info
    this.SourceMDOInfo = sourceMdoInfo
      ? `Source MDO Info: ${sourceMdoInfo}`
      : "";

    // $ Tiering
    this.tiering = getTieringValue(role, origin, tieringVal);
    // $ Tier Case created
    this.tierCaseCreate = getTierCaseCreate(role, origin, tieringVal);

    // $ New Attachments
    this.newAttachment = getAttachmentValue(role, origin, this.decision);

    // $ Matching In-Progress Cases
    this.matchingCase = getMatchingCaseValue(role, origin);

    // $ Denied Case in Last 65 days
    this.deniedCaseInLast65 = getRequestTypeDeniedValue(role, origin, "value");

    // $ RFI TAT Case reviewed by technician
    this.rfiTATCaseReviewed = getRFITATCaseReviewedValue(role, origin, "value");

    // $ Request Type and CDRD Grid Answers
    this.requestType = requestType(role, origin, "value");

    // $ RD Recommandation
    this.rdRecommand = getRDRecVerb(rdRecomand(role, origin, "value"));

    const ePAValue = ePA(role, origin, "value");
    // $ ePA (Robitc)
    this.ePA = ePAValue ? `Was the case created through ePA? ${ePAValue}` : "";

    // $ Multiple Drugs or Requests
    this.multipleCase = getMultipleCase(role, origin);

    const subFormularyID = subFormularyIDField(role, origin, "value");
    this.formularID = subFormularyID ? `Formulary ID: ${subFormularyID}` : "";

    // $ Formulary resolution — sub-client and dropdown (NF/QL flows)
    this.subClient = getSubClient(role, origin);
    this.formularyDropdown = getFormularyDropdown(role, origin);

    // $ QL verbiage fields
    this.qlDrugAndRequestedQl = getQlDrugAndRequestedQl(role, origin);
    this.qlDrugAndPlanQl = getQlDrugAndPlanQl(role, origin);
    this.qlPlanQl = getQlPlanQl(role, origin);

    // $ QL prescriber indicated questions
    this.typeOfQlReview = getTypeOfQlReview(role, origin);
    this.prescriberApprovedFormularyQlIneffective = getPrescriberApprovedFormularyQlIneffective(role, origin);
    this.prescriberApprovedDosesIneffective = getPrescriberApprovedDosesIneffective(role, origin);
    this.qlQualifyingClaim = getQlQualifyingClaim();

    // $ RFI / Denial reason
    this.rfiReason = getRfiReason(role, origin);
    this.denialReason = getDenialReason(role, origin);

    // $ Aetna-specific drug questions (NF + Aetna/SilverScript clients only)
    this.aetnaSpecificAnswers = getAetnaSpecificAnswers(role, origin);
  }
}
