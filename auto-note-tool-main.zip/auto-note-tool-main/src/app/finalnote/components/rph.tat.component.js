import BaseComponent from './base.component';
import {
  approvedDiagnosis,
  client,
  currentTier,
  matchCase,
  mdReview,
  newAttachments,
  outbound,
  requestType,
  subClientManual,
  subSpprtStatement,
  subTierRequest,
  supportingStatement,
  tierRequest,
} from '../../qsets/fields';
import {
  getCompendiaChecks,
  getDurgdexChecks,
} from '../../utils/getInputValue';
import { getMemberValidated, getSupportStatementLocationValue } from './get.values';
import { getAetnaSpecificAnswers } from '../../aetna_questions/fields';

export default class RPHtatComponent extends BaseComponent {
  constructor(origin, role) {
    super(origin, role);
    this.origin = origin;
    this.role = role;

    const decsionRoute = this.decisionDropdown;
    const clientSelect = client(role, origin, 'value');
    const clientText = subClientManual(role, origin, 'value').trim();
    const compendiardo = approvedDiagnosis(role, origin, 'value');
    const compendiachks = getCompendiaChecks(role, origin);
    const drugdexchks = getDurgdexChecks(role, origin);
    const tiering = tierRequest(role, origin, 'value');
    const tierCaseCreate = subTierRequest(role, origin, 'value');
    const tolled = subSpprtStatement(role, origin, 'value');
    const currentTr = currentTier(role, origin, 'value');
    const deci = this.decision;
    const rqstType = requestType(role, origin, 'value');
    const rqstBy = this.requestedBy;
    function decision(route) {
      const d = {
        Denied: `. Reviewed case approaching end of adjudication time frame. ${route}.`,
        Approved: `${route}. Override entered.`,
        Dismissed: `${route}.`,
      };
      return d[route] || `${decsionRoute}`;
    }

    // $ Decision routing
    this.decision = `Case Decision/Routing: ${decision(decsionRoute)}`;

    // $ Client
    function clientVerb(selection) {
      const otherclient = {
        EGWP: `Client: EGWP - ${clientText}`,
        Other: `Client: ${clientText}`,
      };
      return otherclient[selection] || `Client: ${clientSelect}`;
    }

    function compen(compendiaAnswer) {
      const verb = {
        Yes: `Compendia supported?: Yes${compendiachks}`,
        No: `Compendia supported?: No${compendiachks}${drugdexchks}`,
        'N/A': `Compendia supported?: N/A`,
      };
      return verb[compendiaAnswer] || '';
    }
    this.compendia = compen(compendiardo);

    this.client = clientVerb(clientSelect);
    // $ Tiering
    this.tiering = `Tiering: ${tiering}`;
    // $ Tier Case created
    this.tierCaseCreate =
      tiering === 'Yes' && tierCaseCreate !== ''
        ? ` Tier case created: ${tierCaseCreate}`
        : '';
    // $ Current Tier
    this.currentTier = currentTr !== '' ? ` Current Tier: ${currentTr}` : '';
    // $ Matching In-Progress Cases
    this.matchingCase = `Matching In-Progress Cases: ${matchCase(
      role,
      origin,
      'value'
    )}`;
    // $ Request Type
    this.requestType = `Request Type: ${rqstType}`;
    // $ Member
    // this.member = 'Member: Confirmed with at least 3 identifiers';
    this.memberValidated = getMemberValidated(role, origin)

    // $ Supporting sattement
    const ssVal = supportingStatement(role, origin, 'value');
    this.supportStatement = ssVal ? `Supporting Statement: ${ssVal} ${tolled}`.trim() : '';

    // $ Supporting Statement Location
    this.supportStatementLocation = getSupportStatementLocationValue(role, origin);


    // $ New Attachments
    if (deci === 'Pending Appointment of Representative') {
      this.newAttachment = 'New Attachments Received: N/A';
    } else {
      this.newAttachment = `New Attachments Received: ${newAttachments(
        role,
        origin,
        'value'
      )}`;
    }
    // $ Denial for a status reason that does not require MD review
    this.MDReviewRD =
      deci.includes('Denied') && rqstType === 'RD'
        ? `Is the denial for a status reason that does NOT require MD review for RD denial?: ${mdReview(
            role,
            origin,
            'value'
          )}`
        : '';

    this.checkedPriorHistory = 'Checked prior history: Yes';

    // $ Requested By

    this.requestedBy = rqstBy ? `Requested by: ${rqstBy}` : '';

    // $ OutboundCall
    this.outbound = `OBC Made and Documented on Outbound Contact Tab: ${outbound(
      role,
      origin,
      'value'
    )}`;
    this.aetnaSpecificAnswers = getAetnaSpecificAnswers(role, origin);
  }
}
