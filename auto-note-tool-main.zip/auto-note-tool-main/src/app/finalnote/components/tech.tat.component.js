import CommonComponent from "./common.component";
import { approvedDiagnosis, failedFaxQ } from "../../qsets/fields";
import {
  getDeniedMember,
  getFailedFaxes,
  getInfectionIsDrugRstnt,
  getMedicationGreaterThan7DaySupply,
  getMemberIsStableOnRqstDrug,
  getMemberTakingPlavix,
  getOralChemotherapyUsedForCancer,
  getOralChemotherapyUsedForSameIndication,
  getPatientIsStableOnRqstDrug,
  getPatientIsTakingNStableOnRqstDrug,
  getRFIFAXTemplateCompleted,
  getThreeOutreachAttempts,
  getTriedExclOmprzlOrEsmprzl,
  guidelineAnswerValue,
  guidelineValue,
  rqstTypeCDRD,
  triedFailMedValue,
  getDrugFromPhysicianStock,
  getPrescriberIndicatedFormAltsLessEff,
  getPrescriberIndicatedFormAltsProduceAdvAffects,
  getTriedNFailedFormAlts,
  getLicsMember,
  getRejectWithA4orA6,
  getPatientRiskHepatitisB,
  getTransplantIndicatorPresent,
  getDrugPrescribedBySpecialist,
  getDrugForESRD,
  getDrugAdminViaInfusionPump,
  getDrugAdminViaInfusionPumpHome,
  getPatientInSkilledNursingFacility,
  getMedicarePartAPayingFacilityBed,
  getNarcoticAnalgesicNonCancerDx,
  getInjectableAgentRequest,
  getDrugFromPhysicianStockBvD,
  getParenteralNutritionRequest,
  getPermanentDysfunctionDigestiveTract,
  getPatientResidenceCode,
  getPatientUsingMedWithNebulizer,
  getRequestForBetaAgonistSteroidInhalantAnticholinergicOrPDEInhibitor,
  getRequestForAsthmaOrObstructivePulmonaryDisease,
  getRequestForDornaseAlphaPulmozyme,
  getPatientHasCysticFibrosis,
  getRequestForTobramycinInhalationSolution,
  getPatientHasCysticFibrosisOrBronchiectasis,
  getRequestForAcetylcysteine,
  getPersistentThickPulmonarySecretions,
  getRequestForNebupent,
  getPatientHasHIVPneumocystosisOrComplicationsOfOrganTransplants,
  getRequestForTyvasoOrVentavis,
  getPatientHasPulmonaryArteryHypertension,
  getBvdDiagnosisProvided,
  getMedicationReceivedInHome,
  getPatientReceivingMedicationForPrimaryImmuneDeficiencyDisease,
  getRequestForHizentraOrHyQvia,
  getMedicationGivenSubcutaneously,
  getPatientReceivingMedicationForCIDP,
  getPatientReceivingMedicationInMedicalOfficeOrInfusionCenter,
  getRequestedDrugSuppliedFromPhysicianOfficeStockIVIG,
  getPatientResidesInSNFOrSkilledCareFacility,
  getMedicarePartAPayingForLTCFacilityBed,
  getBvdDiagnosisProvidedIVIG,
  getRequestForVarubiEmendOrAkynzeo,
  getOralAntiemeticUsedInChemotherapy,
  getOralAntiemeticUsedInChemotherapyReplacement,
  getPatientRequiresOneOfFollowing,
  getRequestForAkynzeo,
  getRequestedDrugUsedInCancerChemotherapy,
  getOralAntiemeticFullTherapeuticReplacement,
  getOralCorticosteroidAnd5HT3ReceptorAntagonist,
  getPatientReceivingChemotherapeuticAgents,
  getAkynzeoUsedInCancerChemotherapyRegimen,
  getOralAntiemeticFullTherapeuticReplacementAkynzeo,
  getOralCorticosteroidRegimen,
  getPatientReceivingChemotherapeuticAgentsAkynzeo,
} from "./get.values";
import {
  getCompendiaChecks,
  getDurgdexChecks,
} from "../../utils/getInputValue";

export default class TechTATComponent extends CommonComponent {
  constructor(origin, role) {
    super(origin, role);
    this.origin = origin;
    this.role = role;

    const compendiardo = approvedDiagnosis(role, origin, "value");
    const diagno = this.diagnosis;
    const rqstBy = this.requestedBy;
    const compendiachks = getCompendiaChecks(role, origin);
    const drugdexchks = getDurgdexChecks(role, origin);

    // $ Tried and Fail medication
    this.triedfailMed = triedFailMedValue(role, origin);

    // $ Requested By
    this.requester = rqstBy;

    // $ Diagnosis

    function diag(compendiaAnswer) {
      const verb = {
        Yes: `${diagno} - approvable diagnosis`,
        No: `${diagno} - not an approvable diagnosis per DLT and/or decision tree`,
      };
      return verb[compendiaAnswer] || `${diagno}`;
    }
    this.diagnosis = diag(compendiardo);

    function compen(compendiaAnswer) {
      const verb = {
        Yes: `Compendia supported?: Yes${compendiachks}`,
        No: `Compendia supported?: No${compendiachks}${drugdexchks}`,
        "N/A": `Compendia supported?: N/A`,
      };
      return verb[compendiaAnswer] || "";
    }
    this.compendia = compen(compendiardo);

    // $ Is there a denied case on the member's profile
    this.deniedCaseMember = getDeniedMember(role, origin);

    // $ Request Type and CDRD Grid Answers
    this.requestType = rqstTypeCDRD(role, origin, this.requestType, this.ePA);

    // $ Guideline
    this.guideline = guidelineValue(role, origin);
    this.guidelineAnswers = guidelineAnswerValue(role, origin);

    // $ New Tech TAT fields
    this.rfiFAXTemplateCompleted = getRFIFAXTemplateCompleted(role, origin);
    this.threeOutreachAttempts = getThreeOutreachAttempts(role, origin);
    this.failedFaxes = getFailedFaxes(role, origin);

    // $ Guidline fields in Main Template
    this.drugFromPhysicianStock = getDrugFromPhysicianStock(role, origin);
    this.patientIsStableOnRqstDrug = getPatientIsStableOnRqstDrug(role, origin);
    this.memberTakingPlavix = getMemberTakingPlavix(role, origin);
    this.triedExclOmprzlOrEsmprzl = getTriedExclOmprzlOrEsmprzl(role, origin);
    this.memberIsStableOnRqstDrug = getMemberIsStableOnRqstDrug(role, origin);
    this.infectionIsDrugRstnt = getInfectionIsDrugRstnt(role, origin);
    this.medicationGreaterThan7DaySupply = getMedicationGreaterThan7DaySupply(
      role,
      origin
    );
    this.oralChemotherapyUsedForCancer = getOralChemotherapyUsedForCancer(
      role,
      origin
    );
    this.oralChemotherapyUsedForSameIndication =
      getOralChemotherapyUsedForSameIndication(role, origin);
    this.patientIsTakingNStableOnRqstDrugQ =
      getPatientIsTakingNStableOnRqstDrug(role, origin);
    this.prescriberIndicatedFormAltsLessEff =
      getPrescriberIndicatedFormAltsLessEff(role, origin);
    this.prescriberIndicatedFormAltsProduceAdvAffects =
      getPrescriberIndicatedFormAltsProduceAdvAffects(role, origin);
    this.triedNFailedFormAlts = getTriedNFailedFormAlts(role, origin);

    // $ BvD Common Responses
    this.licsMember = getLicsMember(role, origin);
    this.rejectWithA4orA6 = getRejectWithA4orA6(role, origin);

    // $ BvD - Hepatitis B
    this.patientRiskHepatitisB = getPatientRiskHepatitisB(role, origin);

    // $ BvD - Immunosuppressant
    this.transplantIndicatorPresent = getTransplantIndicatorPresent(role, origin);

    // $ BvD - ESRD & Infusion
    this.drugPrescribedBySpecialist = getDrugPrescribedBySpecialist(role, origin);
    this.drugForESRD = getDrugForESRD(role, origin);
    this.drugAdminViaInfusionPump = getDrugAdminViaInfusionPump(role, origin);
    this.drugAdminViaInfusionPumpHome = getDrugAdminViaInfusionPumpHome(role, origin);
    this.patientInSkilledNursingFacility = getPatientInSkilledNursingFacility(role, origin);
    this.medicarePartAPayingFacilityBed = getMedicarePartAPayingFacilityBed(role, origin);
    this.narcoticAnalgesicNonCancerDx = getNarcoticAnalgesicNonCancerDx(role, origin);
    this.injectableAgentRequest = getInjectableAgentRequest(role, origin);
    this.drugFromPhysicianStockBvD = getDrugFromPhysicianStockBvD(role, origin);

    // $ BvD - Parental Nutrition
    this.parenteralNutritionRequest = getParenteralNutritionRequest(role, origin);
    this.permanentDysfunctionDigestiveTract = getPermanentDysfunctionDigestiveTract(role, origin);

    // $ BvD - Inhalation
    this.patientResidenceCode = getPatientResidenceCode(role, origin);
    this.patientUsingMedWithNebulizer = getPatientUsingMedWithNebulizer(role, origin);
    this.requestForBetaAgonistSteroidInhalantAnticholinergicOrPDEInhibitor = getRequestForBetaAgonistSteroidInhalantAnticholinergicOrPDEInhibitor(role, origin);
    this.requestForAsthmaOrObstructivePulmonaryDisease = getRequestForAsthmaOrObstructivePulmonaryDisease(role, origin);
    this.requestForDornaseAlphaPulmozyme = getRequestForDornaseAlphaPulmozyme(role, origin);
    this.patientHasCysticFibrosis = getPatientHasCysticFibrosis(role, origin);
    this.requestForTobramycinInhalationSolution = getRequestForTobramycinInhalationSolution(role, origin);
    this.patientHasCysticFibrosisOrBronchiectasis = getPatientHasCysticFibrosisOrBronchiectasis(role, origin);
    this.requestForAcetylcysteine = getRequestForAcetylcysteine(role, origin);
    this.persistentThickPulmonarySecretions = getPersistentThickPulmonarySecretions(role, origin);
    this.requestForNebupent = getRequestForNebupent(role, origin);
    this.patientHasHIVPneumocystosisOrComplicationsOfOrganTransplants = getPatientHasHIVPneumocystosisOrComplicationsOfOrganTransplants(role, origin);
    this.requestForTyvasoOrVentavis = getRequestForTyvasoOrVentavis(role, origin);
    this.patientHasPulmonaryArteryHypertension = getPatientHasPulmonaryArteryHypertension(role, origin);
    this.bvdDiagnosisProvided = getBvdDiagnosisProvided(role, origin);

    // $ BvD - IVIG
    this.medicationReceivedInHome = getMedicationReceivedInHome(role, origin);
    this.patientReceivingMedicationForPrimaryImmuneDeficiencyDisease = getPatientReceivingMedicationForPrimaryImmuneDeficiencyDisease(role, origin);
    this.requestForHizentraOrHyQvia = getRequestForHizentraOrHyQvia(role, origin);
    this.medicationGivenSubcutaneously = getMedicationGivenSubcutaneously(role, origin);
    this.patientReceivingMedicationForCIDP = getPatientReceivingMedicationForCIDP(role, origin);
    this.patientReceivingMedicationInMedicalOfficeOrInfusionCenter = getPatientReceivingMedicationInMedicalOfficeOrInfusionCenter(role, origin);
    this.requestedDrugSuppliedFromPhysicianOfficeStockIVIG = getRequestedDrugSuppliedFromPhysicianOfficeStockIVIG(role, origin);
    this.patientResidesInSNFOrSkilledCareFacility = getPatientResidesInSNFOrSkilledCareFacility(role, origin);
    this.medicarePartAPayingForLTCFacilityBed = getMedicarePartAPayingForLTCFacilityBed(role, origin);
    this.bvdDiagnosisProvidedIVIG = getBvdDiagnosisProvidedIVIG(role, origin);

    // $ BvD - Oral Antiemetics
    this.requestForVarubiEmendOrAkynzeo = getRequestForVarubiEmendOrAkynzeo(role, origin);
    this.oralAntiemeticUsedInChemotherapy = getOralAntiemeticUsedInChemotherapy(role, origin);
    this.oralAntiemeticUsedInChemotherapyReplacement = getOralAntiemeticUsedInChemotherapyReplacement(role, origin);
    this.patientRequiresOneOfFollowing = getPatientRequiresOneOfFollowing(role, origin);
    this.requestForAkynzeo = getRequestForAkynzeo(role, origin);
    this.requestedDrugUsedInCancerChemotherapy = getRequestedDrugUsedInCancerChemotherapy(role, origin);
    this.oralAntiemeticFullTherapeuticReplacement = getOralAntiemeticFullTherapeuticReplacement(role, origin);
    this.oralCorticosteroidAnd5HT3ReceptorAntagonist = getOralCorticosteroidAnd5HT3ReceptorAntagonist(role, origin);
    this.patientReceivingChemotherapeuticAgents = getPatientReceivingChemotherapeuticAgents(role, origin);
    this.akynzeoUsedInCancerChemotherapyRegimen = getAkynzeoUsedInCancerChemotherapyRegimen(role, origin);
    this.oralAntiemeticFullTherapeuticReplacementAkynzeo = getOralAntiemeticFullTherapeuticReplacementAkynzeo(role, origin);
    this.oralCorticosteroidRegimen = getOralCorticosteroidRegimen(role, origin);
    this.patientReceivingChemotherapeuticAgentsAkynzeo = getPatientReceivingChemotherapeuticAgentsAkynzeo(role, origin);
  }
}
