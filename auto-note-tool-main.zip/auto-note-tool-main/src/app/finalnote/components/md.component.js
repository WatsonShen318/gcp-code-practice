import BaseComponent from './base.component';
import {
  approvedDiagnosis,
  mdClaim,
  mdConflictInfo,
  mdDateTime,
  mdDiagnosis,
  mdFDA,
  mdInfoReview,
  mdLetterStatus,
  // mdNameTitle,
  mdNewInfo,
  mdOffLabel,
  mdPDPMAPD,
  mdRationale,
  mdResolution,
  mdSafety,
  mdsubNewInfo,
  mdsubSafety,
  mdTally,
} from '../../qsets/fields';
import {
  getCompendiaChecks,
  getDurgdexChecks,
} from '../../utils/getInputValue';

export default class MDComponent extends BaseComponent {
  constructor(origin, role) {
    super(origin, role);
    this.origin = origin;
    this.role = role;

    const pdpMAPD = mdPDPMAPD(role, origin, 'value');
    const safety = mdSafety(role, origin, 'value');
    const newInfo = mdNewInfo(role, origin, 'value');

    if (pdpMAPD !== '') {
      const safetyVerb =
        safety === 'No'
          ? `All Safety Issues Resolved: ${safety} - ${mdsubSafety(
              role,
              origin,
              'value'
            )}`
          : `All Safety Issues Resolved: ${safety}`;

      const newInfoVerb =
        newInfo === 'Yes'
          ? `New Clinical Information Received For RD: ${newInfo} - ${mdsubNewInfo(
              role,
              origin,
              'value'
            )}`
          : `New Clinical Information Received For RD: ${newInfo}`;
      const compendiardo = approvedDiagnosis(role, origin, 'value');
      const compendiachks = getCompendiaChecks(role, origin);
      const drugdexchks = getDurgdexChecks(role, origin);

      const compen = (compendiaAnswer) => {
        const verb = {
          Yes: `Compendia supported?: Yes ${compendiachks}`,
          No: `Compendia supported?: No ${compendiachks} ${drugdexchks}`,
          'N/A': `Compendia supported?: N/A`,
        };
        return verb[compendiaAnswer] || '';
      };
      this.mdCompendia = compen(compendiardo);

      this.pdpmapd = pdpMAPD;
      this.fda = `FDA-Labeled Indication(s): ${mdFDA(role, origin, 'value')}`;
      this.csoOffLabel = `Off-Label Indication/Compendium-Supported(s): ${mdOffLabel(
        role,
        origin,
        'value'
      )}`;

      // $ Diagonsis/Diagnoses
      this.mddiagnosis = `Diagnosis/Diagnoses: ${mdDiagnosis(
        role,
        origin,
        'value'
      )}`;
      this.mdoSafety = safetyVerb;
      this.infoReview = `All Clinical Information Reviewed: ${mdInfoReview(
        role,
        origin,
        'value'
      )}`;
      this.newInfoRD = newInfoVerb;
      this.conflictInfo = `Conflicting Clinical Information and Resolution: ${mdConflictInfo(
        role,
        origin,
        'value'
      )}`;
      this.mdClaims = `Claims Check and Results: ${mdClaim(
        role,
        origin,
        'value'
      )}`;
      this.mdResolution = `Resolution: ${mdResolution(role, origin, 'value')}`;
      this.mdRationale = `Rationale: ${mdRationale(role, origin, 'value')}`;
      this.mdOutreach = `Outreach/Communications Tally and Results: ${mdTally(
        role,
        origin,
        'value'
      )}`;
      this.letterStatus = `Letter Template Status: ${mdLetterStatus(
        role,
        origin,
        'value'
      )}`;
      this.MDdateTime = `Date/Time: ${mdDateTime(role, origin, 'value')}`;
      // this.nameTitle = `Name/Title: ${mdNameTitle(role, origin, 'value')}`;
      this.break = '\r\n';
    }
  }
}
