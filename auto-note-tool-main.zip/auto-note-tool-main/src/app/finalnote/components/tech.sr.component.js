import BaseComponent from './base.component';
import getInputValue from '../../utils/getInputValue';
import { getMemberValidated } from './get.values';

export default class TechSRComponent extends BaseComponent {
  constructor(origin, role) {
    super(origin, role);
    this.origin = origin;
    this.role = role;

    const rdo = getInputValue('radio', [`${role}${origin}memberQrdo`]);
    const txt = getInputValue('text', [`${role}${origin}clientKeyinQtxt`]);
    const srMembers =
      rdo[`${role}${origin}memberQrdo`] === 'highlighted in blue' ||
      rdo[`${role}${origin}memberQrdo`] === 'Not found'
        ? `Member termed or not found in MHK and/or unable to verify 3 identifiers`
        : this.memberValidated;
    const rqstBy = this.requestedBy;

    this.title = `Title: Tech`;
    this.memberFound = rdo[`${role}${origin}memberQrdo`];
    this.requestedBy = rqstBy ? `Requested by: ${rqstBy}` : '';
    // this.member = srMembers;
    this.memberValidated = srMembers
    this.client = `Client: ${txt[`${role}${origin}clientKeyinQtxt`]}`;
    this.tiering = `Tiering: N/A`;
  }
}
