import { eag, subAAFNRTestClaim, subEAGTestClaim } from '../../qsets/fields';
import SideNoteComponent from './sidenote.component';

export default class EAGAAFNRcomponent extends SideNoteComponent {
  constructor(origin, role) {
    super(origin, role);
    this.origin = origin;
    this.role = role;

    const eagRdo = eag(role, origin, 'value');

    // $ Test Claim Guideline answers
    this.testClaimGLanswers =
      eagRdo === 'EAG'
        ? `Test Claim Guideline Answers: ${subEAGTestClaim(
            role,
            origin,
            'value'
          )}`
        : `Test Claim Guideline Answers: ${subAAFNRTestClaim(
            role,
            origin,
            'value'
          )}`;

    // $ Reason for call and why case not create
    this.reasonNoCase =
      eagRdo === 'EAG'
        ? 'Reason for call and why case not created: Exception Already Granted'
        : 'Reason for call and why case not created: Approved Approved Formulary No Restriction. Case not required';
  }
}
