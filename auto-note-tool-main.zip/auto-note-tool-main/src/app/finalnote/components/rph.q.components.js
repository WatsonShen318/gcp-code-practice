import CommonComponent from './common.component';
import {
  approvedDiagnosis,
  approvedTier,
  currentTier,
  mdReview,
} from '../../qsets/fields';
import {
  getCompendiaChecks,
  getDurgdexChecks,
} from '../../utils/getInputValue';
import { getSupportStatementLocationValue, getSupportStatementValue } from './get.values';

export default class RPHqComponent extends CommonComponent {
  constructor(origin, role) {
    super(origin, role);
    this.origin = origin;
    this.role = role;

    const deci = this.decisionDropdown;
    const rqstType = this.requestType;
    const compendiardo = approvedDiagnosis(role, origin, 'value');
    const currentTr = currentTier(role, origin, 'value');
    const compendiachks = getCompendiaChecks(role, origin);
    const drugdexchks = getDurgdexChecks(role, origin);

    // $ Denial for a status reason that does not require MD review
    this.MDReviewRD =
      deci === 'Denied' && rqstType === 'RD'
        ? `Is the denial for a status reason that does NOT require MD review for RD denial?: ${mdReview(
            role,
            origin,
            'value'
          )}`
        : '';

    // $ Supporting statement
    this.supportStatement = getSupportStatementValue(role, origin);

    // $ Supporting Statement Location
    this.supportStatementLocation = getSupportStatementLocationValue(role, origin);

    // $ Compendia

    function compen(compendiaAnswer) {
      const verb = {
        Yes: `Compendia supported?: Yes ${compendiachks}`,
        No: `Compendia supported?: No ${compendiachks} ${drugdexchks}`,
        'N/A': `Compendia supported?: N/A`,
      };
      return verb[compendiaAnswer] || '';
    }
    this.compendia = compen(compendiardo);

    // $ Request Type
    this.requestType = `Request Type: ${rqstType}`;

    // $ approved Tier
    this.approvedTier =
      deci === 'Approved' && this.requestReason.includes('Tier Change')
        ? ` Approved Tier: ${approvedTier(role, origin, 'value')}`
        : '';

    // $ Current Tier
    this.currentTier = currentTr !== '' ? ` Current Tier: ${currentTr}` : '';
  }
}
