import getInputValue from '../../utils/getInputValue';
import { getMembers } from '../../utils/getInputValue';
import { getMemberValidated } from './get.values';

export default class ComponentNote {
  constructor() {
    const rdo = getInputValue('radio', [
      'iPriorityQrdo',
      'iRqstTypeQrdo',
      'ibarcodeFaxQrdo',
      'ihopsiceFaxQrdo',
      'subiDrugNameCompQrdo',
      'subiMultiMemberQrdo',
      'iTierRqstQrdo',
      'imempplsafeQrdo',
      'iMultirqstQrdo',
      'subiRqstReasonQrdo',
      'memberQrdo',
    ]);
    const txt = getInputValue('text', [
      'subiExpQIndtxt',
      'subiExpQPgtxt',
      'multiCaseCounttxt',
      'multiRqstCaseTotaltxt',
      'subiMultirqstQhidden',
      'iRtFFaxQwhytxt',
      'iRtFFaxQwheretxt',
      'iRTsecondRationQlt',
      'iReRouteRatQsel',
      'iDrugNameQtxt',
    ]);
    this.memberID = rdo.memberQrdo;
    // this.member = getMembers('', '');
    this.memberValidated = getMemberValidated('', '')
    // this.location = txt.userLocation;
    this.priority = `${rdo.iPriorityQrdo} `;
    this.expediteNote =
      rdo.iPriorityQrdo === 'Expedited'
        ? ` (${txt.subiExpQIndtxt} page ${txt.subiExpQPgtxt}) `
        : '';
    this.iRequestType = rdo.iRqstTypeQrdo;
    this.barcode = rdo.ibarcodeFaxQrdo === 'Yes' ? ' barcode ' : '';
    this.ihospice = rdo.ihopsiceFaxQrdo === 'Yes' ? ' hospice ' : '';
    this.idrugcompound =
      rdo.subiDrugNameCompQrdo === 'Yes' ? ' compound drug ' : '';
    if (rdo.subiMultiMemberQrdo === '') {
      this.iSplitFax = '';
    } else if (rdo.subiMultiMemberQrdo === 'Unable') {
      this.iSplitFax =
        'Unable to split multiple members on the same page due to system limitation. All members have been addressed separately. Do not send back to intake. ';
    } else {
      this.iSplitFax = 'Split fax for multiple members. ';
    }
    this.iTier = rdo.iTierRqstQrdo === 'Yes' ? ' tier change ' : '';
    this.iMemberSearch = rdo.imempplsafeQrdo;
    this.multipleRqst = rdo.iMultirqstQrdo;
    this.multipleRqstReason = rdo.subiRqstReasonQrdo;
    this.multipleRqstCases = txt.multiCaseCounttxt;
    this.multipleRqstCaseTotal = txt.multiRqstCaseTotaltxt;
    this.multipleRqstBalance = txt.subiMultirqstQhidden;
    this.forwardFaxRational = txt.iRtFFaxQwhytxt;
    this.forwardFaxTo = txt.iRtFFaxQwheretxt;
    this.iSecRational = txt.iRTsecondRationQlt;
    this.reRouteRational = txt.iReRouteRatQsel;
    this.drugname = txt.iDrugNameQtxt;
  }
}
