import {
  careAgent,
  careAgentInfo,
  inquiryCaller,
  subAORMember,
  subMemberWAOR,
  subRequestByCaller,
  subRequestInfo,
} from '../../qsets/fields';
import { toTitleCase } from '../../utils/input-format';
import CommonComponent from './common.component';

export default class IBCComponent extends CommonComponent {
  constructor(origin, role) {
    super(origin, role);
    this.origin = origin;
    this.role = role;

    const rqstBy = this.requester;
    const behlafof = subMemberWAOR(role, origin, 'value').trim();
    const caller = subRequestInfo(role, origin, 'value');
    const aorLOC = this.AORLocation;
    const subrqstAORmem = subAORMember(role, origin, 'value');
    const subrqstCaller = subRequestByCaller(role, origin, 'value');

    const aorCaller = () => {
      if (rqstBy === 'Member' && subrqstCaller === 'Yes') {
        return `Requested by: ${rqstBy} - The member authorized ${behlafof} to speak on their behalf for this request.`;
      }
      if (rqstBy === 'AOR' && subrqstAORmem === 'No' && this.AORFile === 'No') {
        return `Requested by: ${rqstBy} - Spoke with ${caller}. The member was not on the phone for the request and no AOR/POA was found on file.`;
      }
      if (
        rqstBy === 'AOR' &&
        subrqstAORmem === 'No' &&
        this.AORFile === 'Yes'
      ) {
        return `Requested by: ${rqstBy} - AOR located on file for ${caller} in ${aorLOC}.`;
      }
      return rqstBy ? `Requested by: ${rqstBy} - Spoke with ${caller}.` : '';
    };

    const careAgentrdo = careAgent(role, origin, 'value');
    const careAgentContact =
      careAgentrdo === 'Yes'
        ? `CARE agent information: ${careAgentInfo(role, origin, 'value')}`
        : '';

    this.requestedBy = aorCaller();
    this.title = `Title: IBC ${toTitleCase(role)}`;
    // $ CARE Agent
    this.careAgent = `Call being transferred to you from CARE agent: ${careAgentrdo}`;

    // $ CARE Agent Contact
    this.careContact = careAgentContact;

    // $ Inquiry Caller
    const inquiryCallerInfo = inquiryCaller(role, origin, 'value');
    this.caller = inquiryCallerInfo && `Caller: ${inquiryCallerInfo}` || '';
  }
}
