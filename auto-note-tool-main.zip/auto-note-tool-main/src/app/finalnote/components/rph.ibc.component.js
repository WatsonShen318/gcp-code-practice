import RPHqComponent from './rph.q.components';
import IBCComponent from './ibc.commponent';

export default class RPHibcComponent extends RPHqComponent {
  constructor(origin, role) {
    super(origin, role);
    this.origin = origin;
    this.role = role;

    const ibc = new IBCComponent(origin, role);
    this.requestedBy = ibc.requestedBy;
    // $ CARE Agent
    this.careAgent = ibc.careAgent;
    // $ CARE Agent Contact
    this.careContact = ibc.careContact;
    // $ TimeStamp
    this.timeStamp = ibc.timeStamp;
  }
}
