import {
  inquiry,
  inquiryCaller,
  subInquiryCaller,
  subInquiryCMM,
  subInquiryCMMDoB,
  subInquiryCMMKey,
  subInquiryCMMLastName,
  subInquiryReason,
  subInquiryRejectCode,
  subInquiryTR,
} from '../../qsets/fields';
import SideNoteComponent from './sidenote.component';

export default class InquiryComponent extends SideNoteComponent {
  constructor(origin, role) {
    super(origin, role);
    this.origin = origin;
    this.role = role;

    const cmmSubmit = subInquiryCMM(role, origin, 'value');
    const cmmRejectCode =
      cmmSubmit === 'No'
        ? `Reject Code: ${subInquiryRejectCode(role, origin, 'value')}`
        : '';
    const cmmRequestReason =
      cmmSubmit === 'No'
        ? `Request Reason: ${subInquiryTR(role, origin, 'value')}`
        : '';
    const cmmKey =
      cmmSubmit === 'Yes'
        ? `Key: ${subInquiryCMMKey(role, origin, 'value')}`
        : '';
    const cmmLastName =
      cmmSubmit === 'Yes'
        ? `Last Name: ${subInquiryCMMLastName(role, origin, 'value')}`
        : '';
    const cmmDob =
      cmmSubmit === 'Yes'
        ? `Date of Birth: ${subInquiryCMMDoB(role, origin, 'value')}`
        : '';

    // $ Inquiry
    this.inqury = `Is this Inquiry?: ${inquiry(role, origin, 'value')}`;

    // $ Inquiry Caller
    const subInquiryCallerInfo = subInquiryCaller(role, origin, 'value');
    const inquiryCallerInfo = inquiryCaller(role, origin, 'value');
    if(subInquiryCallerInfo) {
      this.caller = `Caller: ${subInquiryCallerInfo}` || '';
    }

    if(inquiryCallerInfo) {
      this.caller = `Caller: ${inquiryCallerInfo}` || '';
    }

    // $ CMM
    this.cmm = `Request successfully submitted through CMM: ${cmmSubmit}`;

    // $ Reject Code
    this.rejectCode = cmmRejectCode;

    // $ Request Reason
    this.requestReason = cmmRequestReason;

    // $ Reason
    this.reason = `Reason for call and why case not created: ${subInquiryReason(
      role,
      origin,
      'value'
    )}`;

    // $ CMM Key
    this.key = cmmKey;

    // $ CMM Last Name
    this.LastName = cmmLastName;

    // $ CMM Date of Birth
    this.DOB = cmmDob;
  }
}
