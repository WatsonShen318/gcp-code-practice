import {
  getCurrentYear,
  getFoward90daysDate,
  getLastQtr,
} from "../../utils/calculateDates";
import {
  additionalClaim,
  cdrdGridAnswers,
  claim90,
  claimToday,
  client,
  clientKeyIn,
  diagnosis,
  ePA,
  guideline,
  guidelineRationale,
  matchCase,
  newAttachments,
  outbound,
  subAdditionalDate,
  subAdditionalRejectCode,
  subClaim90Date,
  subClaim90RejectCode,
  subClaimTodayCode,
  subClaimTodayDate,
  subClaimTodayRefill,
  subSpprtStatement,
  supportingStatement,
  triedFail,
  subClientManual,
  memberMultiDrug,
  memberCaseCount,
  memberRqstTotalCount,
  subTierRequest,
  priority,
  subExpediteReason,
  validatedMemberQ,
  requestDenied,
  subspprStatementLocationInfo,
  RFITATCaseReviewed,
  outboundalt,
  failedFaxQ,
  threeOutreachAttemptsQ,
  rfiFaxTemplateQ,
  drugFromPhysicianStock,
  prescriberIndicatedFormAltsLessEff,
  prescriberIndicatedFormAltsProduceAdvAffects,
  triedNFailedFormAlts,
  patientIsStableOnRqstDrug,
  memberTakingPlavix,
  triedExclOmprzlOrEsmprzl,
  memberIsStableOnRqstDrug,
  infectionIsDrugRstnt,
  medicationGreaterThan7DaySupply,
  oralChemotherapyUsedForCancer,
  oralChemotherapyUsedForSameIndication,
  patientIsTakingNStableOnRqstDrug,
  licsMember,
  rejectWithA4orA6,
  patientRiskHepatitisB,
  transplantIndicatorPresent,
  drugPrescribedBySpecialist,
  drugForESRD,
  drugAdminViaInfusionPump,
  drugAdminViaInfusionPumpHome,
  patientInSkilledNursingFacility,
  medicarePartAPayingFacilityBed,
  narcoticAnalgesicNonCancerDx,
  injectableAgentRequest,
  drugFromPhysicianStockBvD,
  parenteralNutritionRequest,
  permanentDysfunctionDigestiveTract,
  patientResidenceCode,
  patientUsingMedWithNebulizer,
  requestForBetaAgonistSteroidInhalantAnticholinergicOrPDEInhibitor,
  requestForAsthmaOrObstructivePulmonaryDisease,
  requestForDornaseAlphaPulmozyme,
  patientHasCysticFibrosis,
  requestForTobramycinInhalationSolution,
  patientHasCysticFibrosisOrBronchiectasis,
  requestForAcetylcysteine,
  persistentThickPulmonarySecretions,
  requestForNebupent,
  patientHasHIVPneumocystosisOrComplicationsOfOrganTransplants,
  requestForTyvasoOrVentavis,
  patientHasPulmonaryArteryHypertension,
  bvdDiagnosisProvided,
  medicationReceivedInHome,
  patientReceivingMedicationForPrimaryImmuneDeficiencyDisease,
  requestForHizentraOrHyQvia,
  medicationGivenSubcutaneously,
  patientReceivingMedicationForCIDP,
  patientReceivingMedicationInMedicalOfficeOrInfusionCenter,
  requestedDrugSuppliedFromPhysicianOfficeStockIVIG,
  patientResidesInSNFOrSkilledCareFacility,
  medicarePartAPayingForLTCFacilityBed,
  bvdDiagnosisProvidedIVIG,
  requestForVarubiEmendOrAkynzeo,
  oralAntiemeticUsedInChemotherapy,
  oralAntiemeticUsedInChemotherapyReplacement,
  patientRequiresOneOfFollowing,
  requestForAkynzeo,
  requestedDrugUsedInCancerChemotherapy,
  oralAntiemeticFullTherapeuticReplacement,
  oralCorticosteroidAnd5HT3ReceptorAntagonist,
  patientReceivingChemotherapeuticAgents,
  akynzeoUsedInCancerChemotherapyRegimen,
  oralAntiemeticFullTherapeuticReplacementAkynzeo,
  oralCorticosteroidRegimen,
  patientReceivingChemotherapeuticAgentsAkynzeo,
  typeOfQlReview,
  prescriberIndicatedApprovedFormularyQuantityLimitIneffective,
  prescriberIndicatedApprovedDosesIneffective,
  formularySubclientQ,
  qlDrugAndRequestedQlQ,
  qlDrugAndPlanQlQ,
  qlPlanQlQ,
  rfiReasonQ,
  denialReasonQ,
} from "../../qsets/fields";
import { getRepeatSectionVals } from "../../utils/getInputValue";
import { isFlowAutomated } from "../../prefill/helpers";

export function getClientValue(role, origin) {
  const val =
    origin === "SR"
      ? clientKeyIn(role, origin, "value")
      : client(role, origin, "value");

  return val;
}

export function getClientVerb(role, origin, selection) {
  const clientText = subClientManual(role, origin, "value").trim();
  const clientSelect = client(role, origin, "value");
  const otherclient = {
    EGWP: `Client: EGWP - ${clientText}`,
    Other: `Client: ${clientText}`,
  };
  return otherclient[selection] || `Client: ${clientSelect}`;
}

export function getOBCValue(role, origin, decision) {
  const ob = outbound(role, origin, "value");
  const obalt = outboundalt(role, origin, "value");

  let output = "";
  if (decision === "Pending Appointment of Representative") {
    output = "Outbound Call Made and Documented on Outbound Contact Tab: N/A";
  } else if (ob === "No") {
    output = "Outbound Call Made and Documented on Outbound Contact Tab: No";
  } else if (ob === "Yes") {
    const obcSpacing = isFlowAutomated() ? "\r\n" : "";
    // Phase 4.0 Part 1 - Skip including OBC sub section values in the final notes - "Only include "Outbound Call Made and Documented on the Contacts Tab" in the final notes"
    // output = `Outbound Call Made and Documented on Outbound Contact Tab: Yes${obcSpacing}${getRepeatSectionVals(
    //   role,
    //   origin
    // )}`;
    output = "Outbound Call Made and Documented on Outbound Contact Tab: Yes";
  } else if (obalt === "No") {
    output = "Outbound Call Made and Documented on Outbound Contact Tab: No";
  } else if (obalt === "Yes") {
    // Phase 4.0 Part 1 - Skip including OBC sub section values in the final notes - "Only include "Outbound Call Made and Documented on the Contacts Tab" in the final notes"
    // const obcSpacing = isFlowAutomated() ? "\r\n" : "";
    // output = `Outbound Call Made and Documented on Outbound Contact Tab: Yes${obcSpacing}${getRepeatSectionVals(
    //   role,
    //   origin,
    //   true
    // )}`;
    output = "Outbound Call Made and Documented on Outbound Contact Tab: Yes";
  }
  return output;
}

export function getAttachmentValue(role, origin, decision) {
  let output = "";
  if (decision.includes("Pending Appointment of Representative")) {
    output = "New Attachments Received: N/A";
  } else {
    output = `New Attachments Received: ${newAttachments(
      role,
      origin,
      "value"
    )}`;
  }
  return output;
}

export function getTieringValue(role, origin, tiering) {
  // const clientVal = getClientValue(role, origin);
  const output = `Tiering: ${tiering}`;
  return output;
}

export function getMatchingCaseValue(role, origin) {
  // const clientVal = getClientValue(role, origin);
  const output = `Matching In-Progress Cases: ${matchCase(role, origin, "value")}`;
  return output;
}

export function getRequestTypeDeniedValue(role, origin) {
  const output = `Denied case on the member's current line of eligibility in the past 65 days: ${requestDenied(role, origin, "value")}`;
  return output;
}

export function getSupportStatementValue(role, origin) {
  const val = supportingStatement(role, origin, "value");
  const sub = subSpprtStatement(role, origin, "value");
  if (!val) return '';
  return `Supporting Statement: ${val} ${sub}`.trim();
}

export function getSupportStatementLocationValue(role, origin) {
  const supportingStatementValue = supportingStatement(role, origin, "value");
  let output;
  if (supportingStatementValue === "Yes") {
    output = `Location of Supporting Statement: ${subspprStatementLocationInfo(role, origin, "value")}`;
  }

  return output;
}

export function getrejectCodeValue(role, origin) {
  const RejectsrefilltooSoon = subClaimTodayRefill(role, origin, "value");
  const cliamTodayD = subClaimTodayDate(role, origin, "value");
  const rejTodayCode =
    RejectsrefilltooSoon === "Yes"
      ? "Refill too soon"
      : subClaimTodayCode(role, origin, "value");
  const claims90 = claim90(role, origin, "value");
  const claims90D = subClaim90Date(role, origin, "value");
  const claim90daysFwd = getFoward90daysDate();
  const rej90Code = subClaim90RejectCode(role, origin, "value").trim();
  const addClaim = additionalClaim(role, origin, "value");
  const addClaimD = subAdditionalDate(role, origin, "value");
  const addClaimCode = subAdditionalRejectCode(role, origin, "value");

  function getClaims() {
    const claimTodayR = claimToday(role, origin, "value");

    const LastQtr = getLastQtr();
    if (claimTodayR === "No" && claims90 === "No") {
      return `Reject Code: N/A. Test claim pays on ${cliamTodayD} and ${claims90D}.`;
    }
    if (claimTodayR === "No" && claims90 === "Yes") {
      return `Reject Code: ${rej90Code} on ${claims90D}. Paid on ${cliamTodayD}.`;
    }
    if (claimTodayR === "Yes" && claims90 === "Yes") {
      return `Reject Code: ${rejTodayCode} on ${cliamTodayD} and ${rej90Code} on ${claims90D}.`;
    }
    if (
      claimTodayR === "Yes" &&
      claims90 === "No" &&
      !LastQtr.includes("noshow")
    ) {
      return `Reject Code: ${rejTodayCode} on ${cliamTodayD}. Pays on ${claims90D}.`;
    }
    if (
      claimTodayR === "Yes" &&
      claims90 === "No" &&
      LastQtr.includes("noshow")
    ) {
      return `Reject Code: ${rejTodayCode} on ${cliamTodayD}. Pays on ${claim90daysFwd}.`;
    }
    if (
      claimTodayR === "Yes" &&
      RejectsrefilltooSoon === "No" &&
      claims90 === ""
    ) {
      return `Reject Code: ${rejTodayCode} on ${cliamTodayD}.`;
    }

    return "";
  }

  function addclaims(answer) {
    const ac = {
      Yes: ` Rejects ${addClaimCode} on ${addClaimD}`,
      No: ` Pays on ${addClaimD}`,
    };
    return ac[answer] || "";
  }

  const output = getClaims() + addclaims(addClaim);
  return output;
}

export function getDiagnosisValue(role, origin) {
  const output = `Diagnosis: ${diagnosis(role, origin, "value")}`;
  return output;
}

export function triedFailMedValue(role, origin) {
  const glSelect = guideline(role, origin, "value");
  const triedFailValue = triedFail(role, origin, "value");
  const output =
    glSelect === "Opioid Quantity Limit - 925"
      ? ""
      : (triedFailValue && `Tried and Failed Medications: ${triedFailValue}` || "");

  return output;
}

export function guidelineValue(role, origin) {
  const guidelineVal = guideline(role, origin, "value");
  const output = (guidelineVal && `Exception Guideline: ${guidelineVal}`) || "";
  return output;
}

export function guidelineAnswerValue(role, origin) {
  const glRationale = guidelineRationale(role, origin, "value");
  let output =
    (glRationale && `Exception Question Answers: ${glRationale}`) || "";

  if (glRationale.includes("Exception Review Guidelines Answers")) {
    output = glRationale;
  }

  return output;
}

export function rqstTypeCDRD(role, origin, requestType) {
  const ePAval = ePA(role, origin, "value");
  const cdrdGridAs = cdrdGridAnswers(role, origin, "value");
  let output = "";

  // AMN 1/5/23 - January 2023 Enhancement - #114: Remove Question 'Is there a denied case on the member's profile in 2022?'
  // if (requestType === 'RD' && cdrdGridAs.includes('Q8=Yes')) {
  if (requestType === "RD" && cdrdGridAs.includes("Q9=Yes")) {
    output = `Request Type: ${requestType} (Possible 3rd Case) ${cdrdGridAs}`;
  } else if (requestType === "RD" || requestType === "CD") {
    output = `Request Type: ${requestType} ${cdrdGridAs}`;
  } else if (ePAval === "Yes") {
    output = `Request Type: ${requestType}`;
  } else {
    output = `Request Type: ${requestType}`;
  }
  return output;
}

export function getRDRecVerb(answer) {
  const RDrecommandation = {
    Yes: "Redetermination Recommendation Approved",
    No: "Redetermination Recommendation needs additional Pharmacist review",
  };
  return RDrecommandation[answer] || "";
}

export function getRqstedBy(rqstBy, AORonFile, AORLoc) {
  let verb;
  if (rqstBy === "AOR" && AORonFile === "Yes") {
    verb = `Requested by: ${rqstBy} - found in ${AORLoc}`;
  } else if (rqstBy === "AOR" && AORonFile === "No") {
    verb = `Requested by: ${rqstBy} - AOR/POA not found on file.`;
  } else {
    verb = rqstBy ? `Requested by: ${rqstBy}` : "";
  }
  return verb;
}

export function getMultipleCase(role, origin) {
  const multi = memberMultiDrug(role, origin, "value");
  const current = memberCaseCount(role, origin, "value");
  const total = memberRqstTotalCount(role, origin, "value");
  let verb = "";

  if (multi === "Yes") {
    verb = `This is Case ${current} of ${total} for this member`;
  }
  return verb;
}

export function getTierCaseCreate(role, origin, tiering) {
  const tierCaseCreate = subTierRequest(role, origin, "value");
  const verb =
    tiering === "Yes" && tierCaseCreate !== ""
      ? ` Tier case created: ${tierCaseCreate}`
      : "";
  return verb;
}

export function getPriority(role, origin) {
  const prioritya = priority(role, origin, "value");
  const epediteReason =
    role === "tech" && !isFlowAutomated()
      ? ` - ${subExpediteReason(role, origin, "value")}`
      : "";
  function priorityVerb(t) {
    const select = {
      Expedited: `${prioritya}${epediteReason}`,
      Standard: `${prioritya}`,
    };
    return `Priority: ${select[t]}` || `Priority: ${prioritya}`;
  }
  return priorityVerb(prioritya);
}

export function getDeniedMember(role, origin) {
  const isAetnaMAPD = getClientValue(role, origin) === "Aetna MAPD";
  const output = isAetnaMAPD
    ? `Denied case on the member's profile in ${getCurrentYear()}`
    : "";
  return output;
}

export function getMemberValidated(role, origin) {
  const memberValidated = validatedMemberQ(role, origin, "value");
  return memberValidated
    ? `Validated Member using 3 identifiers: ${memberValidated}`
    : "";
}

export function getRFITATCaseReviewedValue(role, origin, type) {
  const output = `RFI TAT case reviewed by a technician: ${RFITATCaseReviewed(role, origin, type)}`;
  return output;
}

export function getRFIFAXTemplateCompleted(role, origin) {
  const rfiFAXTemplateCompleted = rfiFaxTemplateQ(role, origin, "value");
  return rfiFAXTemplateCompleted
    ? `Is the RFI fax template completed?: ${rfiFAXTemplateCompleted}`
    : "";
}

export function getThreeOutreachAttempts(role, origin) {
  const threeOutreachAttempts = threeOutreachAttemptsQ(role, origin, "value");
  return threeOutreachAttempts
    ? `Are there 3 outreach attempts? (1 successful fax, 2 calls): ${threeOutreachAttempts}`
    : "";
}

export function getFailedFaxes(role, origin) {
  const failedFaxes = failedFaxQ(role, origin, "value");
  return failedFaxes ? `Are there any failed faxes?: ${failedFaxes}` : "";
}

export function getDrugFromPhysicianStock(role, origin) {
  const drugFromPhysicianStockValue = drugFromPhysicianStock(role, origin, "value");
  return drugFromPhysicianStockValue
    ? `Requested Drug from Physician: ${drugFromPhysicianStockValue}`
    : "";
}

export function getPrescriberIndicatedFormAltsLessEff(role, origin) {
  const prescriberIndicatedFormAltsLessEffValue = prescriberIndicatedFormAltsLessEff(role, origin, "value");
  return prescriberIndicatedFormAltsLessEffValue
    ? `Prescriber Indicated Form Alternatives are Less Effective: ${prescriberIndicatedFormAltsLessEffValue}`
    : "";
}

export function getPrescriberIndicatedFormAltsProduceAdvAffects(role, origin) {
  const prescriberIndicatedFormAltsProduceAdvAffectsValue = prescriberIndicatedFormAltsProduceAdvAffects(role, origin, "value");
  return prescriberIndicatedFormAltsProduceAdvAffectsValue
    ? `Prescriber Indicated Form Alternatives Likely Produce ANY Adverse Effects: ${prescriberIndicatedFormAltsProduceAdvAffectsValue}`
    : "";
}

export function getTriedNFailedFormAlts(role, origin) {
  const triedNFailedFormAltsValue = triedNFailedFormAlts(role, origin, "value");
  return triedNFailedFormAltsValue
    ? `Member Tried and Failed a sufficient number of Form Alternatives: ${triedNFailedFormAltsValue}`
    : "";
}

export function getPatientIsStableOnRqstDrug(role, origin) {
  const patientIsStableOnRqstDrugValue = patientIsStableOnRqstDrug(role, origin, "value");
  return patientIsStableOnRqstDrugValue
    ? `Prescriber indicated that the patient is stable on the requested drug: ${patientIsStableOnRqstDrugValue}`
    : "";
}

export function getMemberTakingPlavix(role, origin) {
  const memberTakingPlavixValue = memberTakingPlavix(role, origin, "value");
  return memberTakingPlavixValue
    ? `Member's claims history show that the member is currently taking Plavix (clopidogrel): ${memberTakingPlavixValue}`
    : "";
}

export function getTriedExclOmprzlOrEsmprzl(role, origin) {
  const triedExclOmprzlOrEsmprzlValue = triedExclOmprzlOrEsmprzl(role, origin, "value");
  return triedExclOmprzlOrEsmprzlValue
    ? `Is Plavix member failed formulary alternatives or prescriber indicated adverse effects?: ${triedExclOmprzlOrEsmprzlValue}`
    : "";
}

/* Has the prescriber indicated that the member is stable on the requested drug? */
export function getMemberIsStableOnRqstDrug(role, origin) {
  const memberIsStableOnRqstDrugValue = memberIsStableOnRqstDrug(role, origin, "value");
  return memberIsStableOnRqstDrugValue
    ? `Prescriber indicated that the member is stable on the requested drug?: ${memberIsStableOnRqstDrugValue}`
    : "";
}

/* Has the prescriber indicated that the infection is drug resistant OR the infection is not sensitive to other drugs, as verified by culture study? */
export function getInfectionIsDrugRstnt(role, origin) {
  const infectionIsDrugRstntValue = infectionIsDrugRstnt(role, origin, "value");
  return infectionIsDrugRstntValue
    ? `Prescriber indicated that the infection is drug resistant OR the infection is not sensitive to other drugs, as verified by culture study?: ${infectionIsDrugRstntValue}`
    : "";
}

/* Is greater than a 7 day supply of this medication medically necessary for this patient? */
export function getMedicationGreaterThan7DaySupply(role, origin) {
  const medicationGreaterThan7DaySupplyValue = medicationGreaterThan7DaySupply(role, origin, "value");
  return medicationGreaterThan7DaySupplyValue
    ? `Greater than a 7 day supply of this medication medically necessary for this patient?: ${medicationGreaterThan7DaySupplyValue}`
    : "";
}

/* Is the oral chemotherapy medication being used as a treatment for cancer? */
export function getOralChemotherapyUsedForCancer(role, origin) {
  const oralChemotherapyUsedForCancerValue = oralChemotherapyUsedForCancer(role, origin, "value");
  return oralChemotherapyUsedForCancerValue
    ? `Oral chemotherapy medication being used as a treatment for cancer?: ${oralChemotherapyUsedForCancerValue}`
    : "";
}

/* Is the oral chemotherapy formulation being used for the same indication as the injectable chemotherapy formulation? */
export function getOralChemotherapyUsedForSameIndication(role, origin) {
  const oralChemotherapyUsedForSameIndicationValue = oralChemotherapyUsedForSameIndication(role, origin, "value");
  return oralChemotherapyUsedForSameIndicationValue
    ? `Oral chemotherapy formulation being used for the same indication as the injectable chemotherapy formulation?: ${oralChemotherapyUsedForSameIndicationValue}`
    : "";
}

/* Has the prescriber indicated that the patient is currently taking and is stable on the requested drug? */
export function getPatientIsTakingNStableOnRqstDrug(role, origin) {
  const patientIsTakingNStableOnRqstDrugValue = patientIsTakingNStableOnRqstDrug(role, origin, "value");
  return patientIsTakingNStableOnRqstDrugValue
    ? `Prescriber indicated that the patient is currently taking and is stable on the requested drug?: ${patientIsTakingNStableOnRqstDrugValue}`
    : "";
}

/* BvD Common Responses for Final Note generation */
// Is this request for a LICS Member?
export function getLicsMember(role, origin) {
  const licsMemberValue = licsMember(role, origin, "value");
  return licsMemberValue
    ? `Is this request for a LICS Member?: ${licsMemberValue}`
    : "";
}

// Is the requested drug rejecting with an 'A4' or 'A6' reject code OR is there messaging indicating the medication may be covered under Part D or B, indicating a BvD review is needed?
export function getRejectWithA4orA6(role, origin) {
  const rejectWithA4orA6Value = rejectWithA4orA6(role, origin, "value");
  return rejectWithA4orA6Value
    ? `Is the requested drug rejecting with an A4 or A6 reject code OR is there messaging indicating the medication may be covered under Part D or B, indicating a BvD review is needed?: ${rejectWithA4orA6Value}`
    : "";
}

/* BvD Specific Responses for Final Note generation */
/* BvD - Heptatitis B */
// Is the patient at high or intermediate risk of contracting hepatitis B?
export function getPatientRiskHepatitisB(role, origin) {
  const patientRiskHepatitisBValue = patientRiskHepatitisB(role, origin, "value");
  return patientRiskHepatitisBValue
    ? `Is the patient at high or intermediate risk of contracting hepatitis B?: ${patientRiskHepatitisBValue}`
    : "";
}

/* BvD - IMMUNOSUPPRESSANT */
// Review the transplant indicator field in RxClaim. Is the Transplant indicator present?
export function getTransplantIndicatorPresent(role, origin) {
  const transplantIndicatorPresentValue = transplantIndicatorPresent(role, origin, "value");
  return transplantIndicatorPresentValue
    ? `Is the transplant indicator present in RxClaim?: ${transplantIndicatorPresentValue}`
    : "";
}

/* BvD - ESRD & Infusion */
// Is the drug being prescribed by a dentist, chiropractor, gynecologist, ophthalmologist, podiatrist, or hospital emergency room prescriber?
export function getDrugPrescribedBySpecialist(role, origin) {
  const drugPrescribedBySpecialistValue = drugPrescribedBySpecialist(role, origin, "value");
  return drugPrescribedBySpecialistValue
    ? `Is the drug being prescribed by a dentist, chiropractor, gynecologist, ophthalmologist, podiatrist, or hospital emergency room prescriber?: ${drugPrescribedBySpecialistValue}`
    : "";
}

// Is the requested drug being prescribed or dispensed for End-Stage Renal Disease (ESRD) and/or dialysis related services provided by an ESRD facility?
export function getDrugForESRD(role, origin) {
  const drugForESRDValue = drugForESRD(role, origin, "value");
  return drugForESRDValue
    ? `Is the requested drug being prescribed or dispensed for End-Stage Renal Disease (ESRD) or dialysis related services provided by an ESRD facility?: ${drugForESRDValue}`
    : "";
}

// Is the requested drug being administered via an infusion pump (excluding disposable pump)
export function getDrugAdminViaInfusionPump(role, origin) {
  const drugAdminViaInfusionPumpValue = drugAdminViaInfusionPump(role, origin, "value");
  return drugAdminViaInfusionPumpValue
    ? `Is the requested drug being administered via an infusion pump (excluding disposable pump)?: ${drugAdminViaInfusionPumpValue}`
    : "";
}

// Is the requested drug being administered via an infusion pump in the home?
export function getDrugAdminViaInfusionPumpHome(role, origin) {
  const drugAdminViaInfusionPumpHomeValue = drugAdminViaInfusionPumpHome(role, origin, "value");
  return drugAdminViaInfusionPumpHomeValue
    ? `Is the requested drug being administered via an infusion pump in the home?: ${drugAdminViaInfusionPumpHomeValue}`
    : "";
}

// Does the patient reside in one of the following skilled nursing/skilled care facilities?
export function getPatientInSkilledNursingFacility(role, origin) {
  const patientInSkilledNursingFacilityValue = patientInSkilledNursingFacility(role, origin, "value");
  return patientInSkilledNursingFacilityValue
    ? `Does the patient reside in skilled nursing/skilled care facilities?: ${patientInSkilledNursingFacilityValue}`
    : "";
}

// Is Medicare Part A paying for the facility bed during the days this treatment is being requested?
export function getMedicarePartAPayingFacilityBed(role, origin) {
  const medicarePartAPayingFacilityBedValue = medicarePartAPayingFacilityBed(role, origin, "value");
  return medicarePartAPayingFacilityBedValue
    ? `Is Medicare Part A paying for the facility bed during the days this treatment is being requested?: ${medicarePartAPayingFacilityBedValue}`
    : "";
}

// Is the drug being prescribed a narcotic analgesic for a non-cancer diagnosis?
export function getNarcoticAnalgesicNonCancerDx(role, origin) {
  const narcoticAnalgesicNonCancerDxValue = narcoticAnalgesicNonCancerDx(role, origin, "value");
  return narcoticAnalgesicNonCancerDxValue
    ? `Is the drug being prescribed a narcotic analgesic for a non-cancer diagnosis?: ${narcoticAnalgesicNonCancerDxValue}`
    : "";
}

// Is the request for an injectable agent?
export function getInjectableAgentRequest(role, origin) {
  const injectableAgentRequestValue = injectableAgentRequest(role, origin, "value");
  return injectableAgentRequestValue
    ? `Is the request for an injectable agent?: ${injectableAgentRequestValue}`
    : "";
}

// Is the requested drug being supplied from the physician and/or office stock supply and billed as part of a physician service?
export function getDrugFromPhysicianStockBvD(role, origin) {
  const drugFromPhysicianStockBvDValue = drugFromPhysicianStockBvD(role, origin, "value");
  return drugFromPhysicianStockBvDValue
    ? `Is the requested drug being supplied from the physician or office stock supply and billed as part of a physician service?: ${drugFromPhysicianStockBvDValue}`
    : "";
}

/* BvD - Parental Nutrition */
// Is the parenteral nutrition request for intradialytic parenteral nutrition (IDPN) or total parenteral nutrition (TPN)?
export function getParenteralNutritionRequest(role, origin) {
  const parenteralNutritionRequestValue = parenteralNutritionRequest(role, origin, "value");
  return parenteralNutritionRequestValue
    ? `Is the parenteral nutrition request for intradialytic parenteral nutrition (IDPN) or total parenteral nutrition (TPN)?: ${parenteralNutritionRequestValue}`
    : "";
}

// Does the patient have or is the patient expected to have permanent dysfunction of the digestive tract (duration greater than 90 days)?
export function getPermanentDysfunctionDigestiveTract(role, origin) {
  const permanentDysfunctionDigestiveTractValue = permanentDysfunctionDigestiveTract(role, origin, "value");
  return permanentDysfunctionDigestiveTractValue
    ? `Does the patient have or is the patient expected to have permanent dysfunction of the digestive tract (duration greater than 90 days)?: ${permanentDysfunctionDigestiveTractValue}`
    : "";
}

/* BvD - Inhalation */
// Is the Patient Residence Code 03 or 09 in RxClaim?
export function getPatientResidenceCode(role, origin) {
  const patientResidenceCodeValue = patientResidenceCode(role, origin, "value");
  return patientResidenceCodeValue
    ? `Is the Patient Residence Code 03 or 09 in RxClaim?: ${patientResidenceCodeValue}`
    : "";
}

// Is the patient using the medication with a nebulizer?
export function getPatientUsingMedWithNebulizer(role, origin) {
  const patientUsingMedWithNebulizerValue = patientUsingMedWithNebulizer(role, origin, "value");
  return patientUsingMedWithNebulizerValue
    ? `Is the patient using the medication with a nebulizer?: ${patientUsingMedWithNebulizerValue}`
    : "";
}

// Is the request for a beta-agonist, steroid inhalant, anticholinergic or phosphodiesterase inhibitor?
export function getRequestForBetaAgonistSteroidInhalantAnticholinergicOrPDEInhibitor(role, origin) {
  const requestForBetaAgonistValue = requestForBetaAgonistSteroidInhalantAnticholinergicOrPDEInhibitor(role, origin, "value");
  return requestForBetaAgonistValue
    ? `Is the request for a beta-agonist, steroid inhalant, anticholinergic or phosphodiesterase inhibitor?: ${requestForBetaAgonistValue}`
    : "";
}

// Is the requested drug being prescribed for the management of asthma or obstructive pulmonary disease?
export function getRequestForAsthmaOrObstructivePulmonaryDisease(role, origin) {
  const requestForAsthmaValue = requestForAsthmaOrObstructivePulmonaryDisease(role, origin, "value");
  return requestForAsthmaValue
    ? `Is the requested drug being prescribed for the management of asthma or obstructive pulmonary disease?: ${requestForAsthmaValue}`
    : "";
}

// Is the request for dornase alpha (Pulmozyme)?
export function getRequestForDornaseAlphaPulmozyme(role, origin) {
  const requestForDornaseAlphaValue = requestForDornaseAlphaPulmozyme(role, origin, "value");
  return requestForDornaseAlphaValue
    ? `Is the request for dornase alpha (Pulmozyme)?: ${requestForDornaseAlphaValue}`
    : "";
}

// Does the patient have a diagnosis of cystic fibrosis?
export function getPatientHasCysticFibrosis(role, origin) {
  const patientHasCysticFibrosisValue = patientHasCysticFibrosis(role, origin, "value");
  return patientHasCysticFibrosisValue
    ? `Does the patient have a diagnosis of cystic fibrosis?: ${patientHasCysticFibrosisValue}`
    : "";
}

// Is the request for Tobramycin inhalation solution, TOBI nebulizer solution, Bethkis or Kitabis Pak?
export function getRequestForTobramycinInhalationSolution(role, origin) {
  const requestForTobramycinValue = requestForTobramycinInhalationSolution(role, origin, "value");
  return requestForTobramycinValue
    ? `Is the request for Tobramycin inhalation solution, TOBI nebulizer solution, Bethkis or Kitabis Pak?: ${requestForTobramycinValue}`
    : "";
}

// Does the patient have a diagnosis of cystic fibrosis or bronchiectasis?
export function getPatientHasCysticFibrosisOrBronchiectasis(role, origin) {
  const patientHasCysticFibrosisOrBronchiectasisValue = patientHasCysticFibrosisOrBronchiectasis(role, origin, "value");
  return patientHasCysticFibrosisOrBronchiectasisValue
    ? `Does the patient have a diagnosis of cystic fibrosis or bronchiectasis?: ${patientHasCysticFibrosisOrBronchiectasisValue}`
    : "";
}

// Is the request for acetylcysteine?
export function getRequestForAcetylcysteine(role, origin) {
  const requestForAcetylcysteineValue = requestForAcetylcysteine(role, origin, "value");
  return requestForAcetylcysteineValue
    ? `Is the request for acetylcysteine?: ${requestForAcetylcysteineValue}`
    : "";
}

// Does the patient have a diagnosis of persistent thick or tenacious pulmonary secretions associated with following ICD-10 diagnosis codes?
export function getPersistentThickPulmonarySecretions(role, origin) {
  const persistentThickPulmonarySecretionsValue = persistentThickPulmonarySecretions(role, origin, "value");
  return persistentThickPulmonarySecretionsValue
    ? `Does the patient have a diagnosis of persistent thick or tenacious pulmonary secretions associated?: ${persistentThickPulmonarySecretionsValue}`
    : "";
}

// Is the request for Nebupent (pentamide)?
export function getRequestForNebupent(role, origin) {
  const requestForNebupentValue = requestForNebupent(role, origin, "value");
  return requestForNebupentValue
    ? `Is the request for Nebupent (pentamide)?: ${requestForNebupentValue}`
    : "";
}

// Does the patient have a diagnosis of human immunodeficiency virus (HIV) or pneumocystosis or complications of organ transplants?
export function getPatientHasHIVPneumocystosisOrComplicationsOfOrganTransplants(role, origin) {
  const patientHasHIVValue = patientHasHIVPneumocystosisOrComplicationsOfOrganTransplants(role, origin, "value");
  return patientHasHIVValue
    ? `Does the patient have a diagnosis of human immunodeficiency virus (HIV) or pneumocystosis or complications of organ transplants?: ${patientHasHIVValue}`
    : "";
}

// Is the request for Tyvaso or Ventavis?
export function getRequestForTyvasoOrVentavis(role, origin) {
  const requestForTyvasoOrVentavisValue = requestForTyvasoOrVentavis(role, origin, "value");
  return requestForTyvasoOrVentavisValue
    ? `Is the request for Tyvaso or Ventavis?: ${requestForTyvasoOrVentavisValue}`
    : "";
}

// Does the patient have a diagnosis of pulmonary artery hypertension?
export function getPatientHasPulmonaryArteryHypertension(role, origin) {
  const patientHasPulmonaryArteryHypertensionValue = patientHasPulmonaryArteryHypertension(role, origin, "value");
  return patientHasPulmonaryArteryHypertensionValue
    ? `Does the patient have a diagnosis of pulmonary artery hypertension?: ${patientHasPulmonaryArteryHypertensionValue}`
    : "";
}

// Was a diagnosis provided as part of the above BvD review?
export function getBvdDiagnosisProvided(role, origin) {
  const bvdDiagnosisProvidedValue = bvdDiagnosisProvided(role, origin, "value");
  return bvdDiagnosisProvidedValue
    ? `Was a diagnosis provided as part of the above BvD review?: ${bvdDiagnosisProvidedValue}`
    : "";
}

/* BvD - IVIG */
// Will the patient be receiving the medication in the home?
export function getMedicationReceivedInHome(role, origin) {
  const medicationReceivedInHomeValue = medicationReceivedInHome(role, origin, "value");
  return medicationReceivedInHomeValue
    ? `Will the patient be receiving the medication in the home?: ${medicationReceivedInHomeValue}`
    : "";
}

// Is the patient receiving the requested medication for the diagnosis of primary immune deficiency disease for one of the following ICD-10 codes?:
export function getPatientReceivingMedicationForPrimaryImmuneDeficiencyDisease(role, origin) {
  const patientReceivingMedicationValue = patientReceivingMedicationForPrimaryImmuneDeficiencyDisease(role, origin, "value");
  return patientReceivingMedicationValue
    ? `Is the patient receiving the requested medication for the diagnosis of primary immune deficiency disease?: ${patientReceivingMedicationValue}`
    : "";
}

// Is this a request for Hizentra or HyQvia?
export function getRequestForHizentraOrHyQvia(role, origin) {
  const requestForHizentraOrHyQviaValue = requestForHizentraOrHyQvia(role, origin, "value");
  return requestForHizentraOrHyQviaValue
    ? `Is this a request for Hizentra or HyQvia?: ${requestForHizentraOrHyQviaValue}`
    : "";
}

// Will the requested medication be given subcutaneously?
export function getMedicationGivenSubcutaneously(role, origin) {
  const medicationGivenSubcutaneouslyValue = medicationGivenSubcutaneously(role, origin, "value");
  return medicationGivenSubcutaneouslyValue
    ? `Will the requested medication be given subcutaneously?: ${medicationGivenSubcutaneouslyValue}`
    : "";
}

// Is the patient receiving the requested medication for the diagnosis of chronic inflammatory demyelinating polyneuropathy (CIDP) (ICD-10 code G61.81)?
export function getPatientReceivingMedicationForCIDP(role, origin) {
  const patientReceivingMedicationForCIDPValue = patientReceivingMedicationForCIDP(role, origin, "value");
  return patientReceivingMedicationForCIDPValue
    ? `Is the patient receiving the requested medication for the diagnosis of chronic inflammatory demyelinating polyneuropathy (CIDP) (ICD-10 code G61.81)?: ${patientReceivingMedicationForCIDPValue}`
    : "";
}

// Will the patient be receiving the medication in a medical office or infusion center?
export function getPatientReceivingMedicationInMedicalOfficeOrInfusionCenter(role, origin) {
  const patientReceivingMedicationInMedicalOfficeValue = patientReceivingMedicationInMedicalOfficeOrInfusionCenter(role, origin, "value");
  return patientReceivingMedicationInMedicalOfficeValue
    ? `Will the patient be receiving the medication in a medical office or infusion center?: ${patientReceivingMedicationInMedicalOfficeValue}`
    : "";
}

// Is the requested drug being supplied from the physician and/or office stock supply and billed as part of a physician service?
export function getRequestedDrugSuppliedFromPhysicianOfficeStockIVIG(role, origin) {
  const requestedDrugSuppliedValue = requestedDrugSuppliedFromPhysicianOfficeStockIVIG(role, origin, "value");
  return requestedDrugSuppliedValue
    ? `Is the requested drug being supplied from the physician and/or office stock supply and billed as part of a physician service?: ${requestedDrugSuppliedValue}`
    : "";
}

// Does the patient reside in one of the following skilled nursing facilities (SNF)/skilled care facilities?:
export function getPatientResidesInSNFOrSkilledCareFacility(role, origin) {
  const patientResidesInSNFValue = patientResidesInSNFOrSkilledCareFacility(role, origin, "value");
  return patientResidesInSNFValue
    ? `Does the patient reside in skilled nursing facilities (SNF)/skilled care facilities?: ${patientResidesInSNFValue}`
    : "";
}

// Is Medicare Part A paying for the long-term care (LTC) facility bed during the days this treatment is being requested?
export function getMedicarePartAPayingForLTCFacilityBed(role, origin) {
  const medicarePartAPayingForLTCFacilityBedValue = medicarePartAPayingForLTCFacilityBed(role, origin, "value");
  return medicarePartAPayingForLTCFacilityBedValue
    ? `Is Medicare Part A paying for the long-term care (LTC) facility bed during the days this treatment is being requested?: ${medicarePartAPayingForLTCFacilityBedValue}`
    : "";
}

// Was a diagnosis provided as part of the above BvD review?
export function getBvdDiagnosisProvidedIVIG(role, origin) {
  const bvdDiagnosisProvidedIVIGValue = bvdDiagnosisProvidedIVIG(role, origin, "value");
  return bvdDiagnosisProvidedIVIGValue
    ? `Was a diagnosis provided as part of the above BvD review?: ${bvdDiagnosisProvidedIVIGValue}`
    : "";
}

/* BvD - Oral Antiemetics */
// Is the request for Varubi or Emend (aprepitant) or Akynzeo?
export function getRequestForVarubiEmendOrAkynzeo(role, origin) {
  const requestForVarubiEmendOrAkynzeoValue = requestForVarubiEmendOrAkynzeo(role, origin, "value");
  return requestForVarubiEmendOrAkynzeoValue
    ? `Is the request for Varubi or Emend (aprepitant) or Akynzeo?: ${requestForVarubiEmendOrAkynzeoValue}`
    : "";
}

// Is the oral antiemetic agent being used as part of a cancer chemotherapy regimen?
export function getOralAntiemeticUsedInChemotherapy(role, origin) {
  const oralAntiemeticUsedInChemotherapyValue = oralAntiemeticUsedInChemotherapy(role, origin, "value");
  return oralAntiemeticUsedInChemotherapyValue
    ? `Is the oral antiemetic agent being used as part of a cancer chemotherapy regimen?: ${oralAntiemeticUsedInChemotherapyValue}`
    : "";
}

// Will the oral antiemetic formulation be used as a full therapeutic replacement for intravenous administration within 48 hours of chemotherapy or within 24 hours of chemotherapy if dolasetron or granisetron?
export function getOralAntiemeticUsedInChemotherapyReplacement(role, origin) {
  const oralAntiemeticUsedInChemotherapyReplacementValue = oralAntiemeticUsedInChemotherapyReplacement(role, origin, "value");
  return oralAntiemeticUsedInChemotherapyReplacementValue
    ? `Will the oral antiemetic formulation be used as a full therapeutic replacement for intravenous administration within 48 hours of chemotherapy or within 24 hours of chemotherapy if dolasetron or granisetron?: ${oralAntiemeticUsedInChemotherapyReplacementValue}`
    : "";
}

// Will the patient require one of the following?:
export function getPatientRequiresOneOfFollowing(role, origin) {
  const patientRequiresOneOfFollowingValue = patientRequiresOneOfFollowing(role, origin, "value");
  return patientRequiresOneOfFollowingValue
    ? `Will the patient require one of the following?: ${patientRequiresOneOfFollowingValue}`
    : "";
}

// Is the request for Akynzeo?
export function getRequestForAkynzeo(role, origin) {
  const requestForAkynzeoValue = requestForAkynzeo(role, origin, "value");
  return requestForAkynzeoValue
    ? `Is the request for Akynzeo?: ${requestForAkynzeoValue}`
    : "";
}

// Is the requested drug being used as part of a cancer chemotherapy regimen?
export function getRequestedDrugUsedInCancerChemotherapy(role, origin) {
  const requestedDrugUsedInCancerChemotherapyValue = requestedDrugUsedInCancerChemotherapy(role, origin, "value");
  return requestedDrugUsedInCancerChemotherapyValue
    ? `Is the requested drug being used as part of a cancer chemotherapy regimen?: ${requestedDrugUsedInCancerChemotherapyValue}`
    : "";
}

// Will the oral antiemetic formulation be used as a full therapeutic replacement for intravenous administration of an antiemetic within 48 hours of chemotherapy?
export function getOralAntiemeticFullTherapeuticReplacement(role, origin) {
  const oralAntiemeticFullTherapeuticReplacementValue = oralAntiemeticFullTherapeuticReplacement(role, origin, "value");
  return oralAntiemeticFullTherapeuticReplacementValue
    ? `Will the oral antiemetic formulation be used as a full therapeutic replacement for intravenous administration of an antiemetic within 48 hours of chemotherapy?: ${oralAntiemeticFullTherapeuticReplacementValue}`
    : "";
}

// Will this drug be part of a regimen that includes an oral corticosteroid (e.g., dexamethasone) and an oral 5-HT3-receptor antagonist (e.g., ondansetron, granisetron, Anzemet)?
export function getOralCorticosteroidAnd5HT3ReceptorAntagonist(role, origin) {
  const oralCorticosteroidAnd5HT3ReceptorAntagonistValue = oralCorticosteroidAnd5HT3ReceptorAntagonist(role, origin, "value");
  return oralCorticosteroidAnd5HT3ReceptorAntagonistValue
    ? `Will this drug be part of a regimen that includes an oral corticosteroid (e.g., dexamethasone) and an oral 5-HT3-receptor antagonist (e.g., ondansetron, granisetron, Anzemet)?: ${oralCorticosteroidAnd5HT3ReceptorAntagonistValue}`
    : "";
}

// Is the patient receiving one or more of the following chemotherapeutic agents?
export function getPatientReceivingChemotherapeuticAgents(role, origin) {
  const patientReceivingChemotherapeuticAgentsValue = patientReceivingChemotherapeuticAgents(role, origin, "value");
  return patientReceivingChemotherapeuticAgentsValue
    ? `Is the patient receiving one or more of the chemotherapeutic agents?: ${patientReceivingChemotherapeuticAgentsValue}`
    : "";
}

// Is Akynzeo being used as part of a cancer chemotherapy regimen?
export function getAkynzeoUsedInCancerChemotherapyRegimen(role, origin) {
  const akynzeoUsedInCancerChemotherapyRegimenValue = akynzeoUsedInCancerChemotherapyRegimen(role, origin, "value");
  return akynzeoUsedInCancerChemotherapyRegimenValue
    ? `Is Akynzeo being used as part of a cancer chemotherapy regimen?: ${akynzeoUsedInCancerChemotherapyRegimenValue}`
    : "";
}

// Will the oral antiemetic formulation be used as a full therapeutic replacement for intravenous administration of an antiemetic within 48 hours of chemotherapy?
export function getOralAntiemeticFullTherapeuticReplacementAkynzeo(role, origin) {
  const oralAntiemeticFullTherapeuticReplacementAkynzeoValue = oralAntiemeticFullTherapeuticReplacementAkynzeo(role, origin, "value");
  return oralAntiemeticFullTherapeuticReplacementAkynzeoValue
    ? `Will the oral antiemetic formulation be used as a full therapeutic replacement for intravenous administration of an antiemetic within 48 hours of chemotherapy?: ${oralAntiemeticFullTherapeuticReplacementAkynzeoValue}`
    : "";
}

// Will this drug be part of a regimen that includes an oral corticosteroid?
export function getOralCorticosteroidRegimen(role, origin) {
  const oralCorticosteroidRegimenValue = oralCorticosteroidRegimen(role, origin, "value");
  return oralCorticosteroidRegimenValue
    ? `Will this drug be part of a regimen that includes an oral corticosteroid?: ${oralCorticosteroidRegimenValue}`
    : "";
}

// Is the patient receiving one or more of the following chemotherapeutic agents?
export function getPatientReceivingChemotherapeuticAgentsAkynzeo(role, origin) {
  const patientReceivingChemotherapeuticAgentsAkynzeoValue = patientReceivingChemotherapeuticAgentsAkynzeo(role, origin, "value");
  return patientReceivingChemotherapeuticAgentsAkynzeoValue
    ? `Is the patient receiving one or more of the chemotherapeutic agents?: ${patientReceivingChemotherapeuticAgentsAkynzeoValue}`
    : "";
}

/* Formulary Resolution */
export function getFormularyDropdown(role, origin) {
  const sel = document.getElementById(`${role}${origin}formularyDropdownQsel`);
  const val = sel?.value;
  const text = sel?.selectedOptions?.[0]?.text?.trim();
  const skip = !val || val === '__other__' || val === '__na__' || text === 'Select formulary…';
  return skip ? '' : `Formulary: ${text}`;
}

export function getSubClient(role, origin) {
  const val = formularySubclientQ(role, origin, 'value');
  return val ? `Sub-Client: ${val}` : '';
}

/* QL Verbiage Fields */
export function getQlDrugAndRequestedQl(role, origin) {
  const val = qlDrugAndRequestedQlQ(role, origin, 'value');
  return val ? `Drug and Requested QL: ${val}` : '';
}

export function getQlDrugAndPlanQl(role, origin) {
  const val = qlDrugAndPlanQlQ(role, origin, 'value');
  return val ? `Drug and Plan QL: ${val}` : '';
}

export function getQlPlanQl(role, origin) {
  const val = qlPlanQlQ(role, origin, 'value');
  return val ? `Plan QL: ${val}` : '';
}

/* QL Prescriber Indicated Questions — only for Quantity Limit Exception, not Opioid QL */
export function getTypeOfQlReview(role, origin) {
  const val = typeOfQlReview(role, origin, 'value');
  return val ? `Type of Quantity Limit review: ${val}` : '';
}

export function getPrescriberApprovedFormularyQlIneffective(role, origin) {
  const gl = guideline(role, origin, 'value');
  if (!gl || gl === 'Opioid Quantity Limit - 925') return '';
  const val = prescriberIndicatedApprovedFormularyQuantityLimitIneffective(role, origin, 'value');
  return val ? `Has prescriber indicated approved formulary QL ineffective: ${val}` : '';
}

export function getPrescriberApprovedDosesIneffective(role, origin) {
  const gl = guideline(role, origin, 'value');
  if (!gl || gl === 'Opioid Quantity Limit - 925') return '';
  const val = prescriberIndicatedApprovedDosesIneffective(role, origin, 'value');
  return val ? `Has prescriber indicated approved doses ineffective: ${val}` : '';
}

export function getQlQualifyingClaim() {
  const val = sessionStorage.getItem('qlQualifyingClaim');
  return val ? `Qualifying paid claim: ${val}` : '';
}

/* RFI / Denial Reason */
export function getRfiReason(role, origin) {
  const val = rfiReasonQ(role, origin, 'value');
  return val ? `RFI Reason: ${val}` : '';
}

export function getDenialReason(role, origin) {
  const val = denialReasonQ(role, origin, 'value');
  return val ? `Denial Reason: ${val}` : '';
}
