import getInputValue from '../../utils/getInputValue';
import { toTitleCase } from '../../utils/input-format';
import CommonComponent from './common.component';

export default class SideNoteComponent extends CommonComponent {
  constructor(origin, role) {
    super(origin, role);
    this.origin = origin;
    this.role = role;

    //* * Get IBC only fields */
    const rdo = getInputValue('radio', [
      `${role}${origin}careAgentQrdo`,
      `${role}${origin}subrqstByAORmemberQrdo`,
      `${role}${origin}subrqstByCallerQrdo`,
    ]);
    const txt = getInputValue('text', [
      // `${role}${origin}subrqstInfoQtxt`,
      `${role}${origin}subMemberWaorQtxt`,
      `${role}${origin}subrqstInfoQtxt`,
      `${role}${origin}subcareAgentQcareAgenttxt`,
    ]);
    const rqstBy = this.requester;
    const behlafof = txt[`${role}${origin}subMemberWaorQtxt`].trim();
    const caller = txt[`${role}${origin}subrqstInfoQtxt`].trim();
    const aorLOC = this.AORLocation;

    const aorCaller = () => {
      if (
        rqstBy === 'Member' &&
        rdo[`${role}${origin}subrqstByCallerQrdo`] === 'Yes'
      ) {
        return `Requested by: ${rqstBy} - The member authorized ${behlafof} to speak on their behalf for this request.`;
      }
      if (
        rqstBy === 'AOR' &&
        rdo[`${role}${origin}subrqstByAORmemberQrdo`] === 'No' &&
        this.AORFile === 'No'
      ) {
        return `Requested by: ${rqstBy} - Spoke with ${caller}. The member was not on the phone for the request and no AOR/POA was found on file.`;
      }
      if (
        rqstBy === 'AOR' &&
        rdo[`${role}${origin}subrqstByAORmemberQrdo`] === 'No' &&
        this.AORFile === 'Yes'
      ) {
        return `Requested by: ${rqstBy} - AOR located on file for ${caller} in ${aorLOC}.`;
      }
      return rqstBy ? `Requested by: ${rqstBy} - Spoke with ${caller}.` : '';
    };

    const careAgentrdo = rdo[`${role}${origin}careAgentQrdo`];
    const careAgentContact =
      careAgentrdo === 'Yes'
        ? `CARE agent information: ${
            txt[`${role}${origin}subcareAgentQcareAgenttxt`]
          }`
        : '';

    this.requestedBy = aorCaller();
    this.title = `Title: IBC ${toTitleCase(role)}`;
    // $ CARE Agent
    this.careAgent = `Call being transferred to you from CARE agent: ${careAgentrdo}`;

    // $ CARE Agent Contact
    this.careContact = careAgentContact;

    // $ TimeStamp
    this.timeStamp = 'TimeStamp: MHK';
  }
}
