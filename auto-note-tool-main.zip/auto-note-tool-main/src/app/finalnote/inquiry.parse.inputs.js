import InquiryComponent from './components/inquiry.component';
import sendDataToBigTable from '../bigTable/bigTable';

const br = '\r\n';

const inquiryNote = (origin, role) => {
  const notes = new InquiryComponent(origin, role);

  const output = [
    notes.title,
    // notes.member,
    notes.memberValidated,
    notes.careAgent,
    notes.careContact,
    notes.inqury,
    notes.caller,
    notes.drug,
    notes.rejectCode,
    notes.requestReason,
    notes.cmm,
    notes.key,
    notes.LastName,
    notes.DOB,
    notes.reason,
  ]
    .filter(Boolean)
    .join(br);

  sendDataToBigTable(output, role, origin);
  return output;
};

export default inquiryNote;
