import { toggleDisplay } from '../utils/notetool.display';

export function togglePOAQ(o, r, a) {
  if ((o === 'IBC' && a === 'No') || (o === 'Queue' && a === 'AOR')) {
    toggleDisplay('solo', [`${r}${o}subAorOnFileQ`], 'enable');
  } else {
    toggleDisplay(
      'solo',
      [`${r}${o}subAorOnFileQ`, `${r}${o}subAorOnFileDocQ`],
      'disable'
    );
  }
}

export function toggleAORLoc(o, r, a) {
  if (a === 'Yes') {
    toggleDisplay('solo', [`${r}${o}subAorOnFileDocQ`], 'enable');
  } else {
    toggleDisplay('solo', [`${r}${o}subAorOnFileDocQ`], 'disable');
  }
}

export function togglepplSafeBadge() {
  const url = 'https://service360.my.salesforce.com/';
  const features =
    'menubar=yes,height=800,width=1100,resizable=Yes,scrollbars=yes,status=no;';

  window.open(url, '_blank', features);
}
