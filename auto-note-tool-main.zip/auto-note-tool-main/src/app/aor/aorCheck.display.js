import { toggleDisplay } from '../utils/notetool.display';

export default function toggleAORCheck(o, r, a) {
  if (a === 'Pending Appointment of Representative') {
    toggleDisplay('solo', [`${r}${o}aorCheckQ`], 'enable');
  } else {
    toggleDisplay('solo', [`${r}${o}aorCheckQ`], 'disable');
  }
}
