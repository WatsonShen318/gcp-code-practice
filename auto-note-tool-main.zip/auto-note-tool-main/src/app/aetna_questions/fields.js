export function getAetnaSpecificAnswers(role, origin) {
  const fieldset = document.getElementById(`${role}${origin}aetnaQuestionsQ`);
  if (!fieldset || fieldset.disabled) return '';

  const container = document.getElementById(`${role}${origin}aetnaQuestionsQcontainer`);
  if (!container) return '';

  const br = '\r\n';
  const lines = [];
  container.querySelectorAll('fieldset').forEach(fs => {
    const question = fs.querySelector('legend div')?.textContent?.trim() || '';
    const checked  = fs.querySelector('input[type="radio"]:checked');
    const answer   = checked?.value || '';
    if (question && answer) lines.push(`${question}: ${answer}`);
  });

  return lines.join(br);
}
