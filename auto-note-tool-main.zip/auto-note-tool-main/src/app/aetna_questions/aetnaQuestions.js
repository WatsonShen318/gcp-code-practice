import fetchAetnaQuestions from './api/fetchAetnaQuestions';
import { toggleDisplay } from '../utils/notetool.display';

const AETNA_CLIENTS = new Set(['Aetna MAPD', 'Aetna SSI PDP', 'SSI']);

// Tracks the latest fetch ID per role+origin to discard stale responses on rapid re-calls.
const _fetchSeq = {};

function _getClientValue(role, origin) {
  const el = document.getElementById(`${role}${origin}clientQsel`);
  return el ? el.value : '';
}

function _getRequestReason(role, origin) {
  const el = document.getElementById(`${role}${origin}rqstReasonQsel`);
  return el ? el.value : '';
}

function _renderSubQuestions(role, origin, questions) {
  const container = document.getElementById(`${role}${origin}aetnaQuestionsQcontainer`);
  if (!container) return;
  container.innerHTML = '';

  questions.forEach(q => {
    const fieldName = `${role}${origin}aetnaQ${q.index}rdo`;
    const fieldset = document.createElement('fieldset');
    fieldset.className = 'my-3';

    // Match standard legend format used across the tool
    const legend = document.createElement('legend');
    legend.className = 'fs-5 fw-bolder text-break align-items-start d-flex';
    const icon = document.createElement('i');
    icon.className = 'material-icons-q flex-shrink-0';
    icon.textContent = 'drag_handle';
    const textDiv = document.createElement('div');
    textDiv.textContent = q.question;
    legend.appendChild(icon);
    legend.appendChild(textDiv);
    fieldset.appendChild(legend);

    const choices = ['Yes', 'No'];
    choices.forEach((value, i) => {
      const isLast = i === choices.length - 1;
      const wrapper = document.createElement('div');
      wrapper.className = `custom-control form-check mx-4${isLast ? ' position-relative' : ''}`;
      wrapper.id = `${fieldName}${value}rdo`;

      const input = document.createElement('input');
      input.className = 'form-check-input';
      input.setAttribute('data-tag', 'int-input');
      input.type = 'radio';
      input.name = fieldName;
      input.id = `${fieldName}${value}`;
      input.value = value;
      input.required = true; // required on all so last input's :invalid triggers the tooltip

      const label = document.createElement('label');
      label.className = 'form-check-label';
      label.setAttribute('for', input.id);
      label.textContent = value;

      wrapper.appendChild(input);
      wrapper.appendChild(label);
      if (isLast) {
        const tooltip = document.createElement('div');
        tooltip.className = 'invalid-tooltip';
        tooltip.textContent = 'Please select an answer';
        wrapper.appendChild(tooltip);
      }
      fieldset.appendChild(wrapper);
    });

    container.appendChild(fieldset);
  });
}

export async function initAetnaQuestions(role, origin) {
  // Always reset first — clears any questions from a previous drug search.
  resetAetnaQuestions(role, origin);

  const requestReason = _getRequestReason(role, origin);
  if (requestReason.toLowerCase() !== 'non-formulary') return;

  const clientValue = _getClientValue(role, origin);
  if (!AETNA_CLIENTS.has(clientValue)) return;

  const medhok = JSON.parse(sessionStorage.getItem('originalMedhokResponse') || 'null');
  // In automated flow GPI/NDC come from the medhok response.
  // In manual flow (no medhok) GPI comes from the searchable drug-name dropdown.
  const manualGpi = sessionStorage.getItem('gpiSelectedWDrugNameSearch') || '';
  const gpi = medhok?.gpiCode?.trim() || (manualGpi !== 'Other' ? manualGpi.trim() : '') || '';
  const ndc = medhok?.ndc?.trim() || '';
  if (!gpi && !ndc) return;

  // Guard against stale responses when the user changes the drug quickly.
  const key = `${role}${origin}`;
  const seq = (_fetchSeq[key] = (_fetchSeq[key] || 0) + 1);

  try {
    const questions = await fetchAetnaQuestions(gpi, ndc);
    if (_fetchSeq[key] !== seq) return; // a newer call already took over
    if (!questions || !questions.length) return;

    _renderSubQuestions(role, origin, questions);
    toggleDisplay('solo', [`${role}${origin}aetnaQuestionsQ`], 'enable');
  } catch (err) {
    console.error('[AetnaQuestions] initAetnaQuestions failed:', err);
  }
}

export function resetAetnaQuestions(role, origin) {
  toggleDisplay('solo', [`${role}${origin}aetnaQuestionsQ`], 'disable');
  const container = document.getElementById(`${role}${origin}aetnaQuestionsQcontainer`);
  if (container) container.innerHTML = '';
}
