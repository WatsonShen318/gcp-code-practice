import axios from 'axios';
// eslint-disable-next-line import/no-extraneous-dependencies
import axiosRetry from 'axios-retry';
import { getEnvironmentVariables } from '../../../../environment/config';

axiosRetry(axios, {
  retries: 2,
  retryCondition: (error) => error.response?.status >= 500,
  retryDelay: (retryCount) => retryCount * 1000,
});

async function fetchAetnaQuestions(gpi, ndc) {
  const { AUTO_NOTE_BACKEND } = getEnvironmentVariables();
  const response = await axios.post(
    `${AUTO_NOTE_BACKEND}/aetna-questions/fetch`,
    { gpi, ndc },
    { timeout: 30000 }
  );
  return response.data.data.questions;
}

export default fetchAetnaQuestions;
