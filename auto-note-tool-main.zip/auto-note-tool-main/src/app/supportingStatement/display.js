import { toggleDisplay } from "../utils/notetool.display";

function toggleToll(o, r, a) {
  if (a === "No") {
    toggleDisplay("solo", [`${r}${o}subspprSatementQ`], "enable");
  } else {
    toggleDisplay("solo", [`${r}${o}subspprSatementQ`], "disable");
  }
}

function toggleSupportStatementLocation(o, r, a) {
  if (a === "Yes") {
    toggleDisplay(
      "solo",
      [`${r}${o}subspprSatementLocationQ`],
      "enable"
    );
  } else {
    toggleDisplay(
      "solo",
      [`${r}${o}subspprSatementLocationQ`],
      "disable"
    );
  }
}

export { toggleToll, toggleSupportStatementLocation };
