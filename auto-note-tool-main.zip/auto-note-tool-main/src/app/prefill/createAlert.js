/* eslint-disable no-restricted-syntax */
/* eslint-disable no-plusplus */

import { toggleDisplay } from "../utils/notetool.display";

const {
    alertMessages
  } = require("./alertMessage");

export function createAlertMessage(origins, customAlertProps){
    let createdAlert = "";
    for (const origin in origins){
        if (origins[origin]){
            let fieldName = "";
            const drugNameValue = customAlertProps?.drugNameValue?.trim()?.split(" ")[0] || ''
            if (origins[origin] === "Drug Details"){
                fieldName = `Drug: ${drugNameValue}`;   
            } else if (origins[origin] === 'HIV Drug'){
                fieldName = `Drug Specific: ${drugNameValue}`
            } else {
                fieldName = `${origin}: ${origins[origin]}`;
            }
            if(fieldName && alertMessages[origins[origin]]){
                createdAlert += `<h5 style='color: #333'>${fieldName}</h4>${alertMessages[origins[origin]]}<hr style ='border-top: 3px solid #1c1c1c; margin: 10px 0;'>`
            }
        }
    }
    return createdAlert
};

document.getElementById("alertPopupBtn").addEventListener('click', () =>{
    toggleDisplay('solo', ["alertPopup"], 'enable');  
})

document.getElementById("alertCloseBtn").addEventListener('click', (e) =>{
    e.preventDefault();
    toggleDisplay('solo', ["alertPopup"], 'disable'); 
})

export function displayAlert(createdAlertMessage){
    const alertPopupBody = document.getElementById("alertPopupBody");

    if(createdAlertMessage) {
        toggleDisplay('solo', ["alertPopupBtn", "alertPopup"], 'enable');
        alertPopupBody.innerHTML = createdAlertMessage;
    }
};
