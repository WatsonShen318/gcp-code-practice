import { requestReason } from "../qsets/fields";

/* Helper to get Flow is Automated or not */
const isFlowAutomated = () => {
    const workFlow = sessionStorage.getItem('workFlow') || 'Manual';

    return workFlow === 'Automated'
}

const isRequestReasonAutomated = (role, origin) => {
      const requestReasonValue = requestReason(role, origin, "value");
      return requestReasonValue !== "";
}

export {
    isFlowAutomated,
    isRequestReasonAutomated
}