import { caseIdInfo } from "../qsets/fields";
import retrieveCaseDetails from "../medhok/apis/retrieveCaseDetails";
import { toggleDisplay } from "../utils/notetool.display";
import { validateCaseId } from "../utils/inputValidation";
import preFillTechQueue from "./preFillTechQ";
import preFillRphQueue from "./preFillRphQ";
import removeFields from "./removeFields";
import { manualTemplateButtonHandler } from "./manualTemplate";
import preFillTechSR from "./preFillTechSR";
import preFillRphTAT from "./preFillRphTAT";
import preFillTechTAT from "./preFillTechTAT";
import preFillRphIBC from "./preFillRphIBC";
import preFillTechIBC from "./preFillTechIBC";
import { prefillCDRD } from "./prefillCDRD";
import { automateDLTGuidelines } from "../dlt_guidelines/automation";
import resetNote from "../reset/notetool.reset";
import { resetOriginLabels } from "../reset/reset";
import { isRequestReasonAutomated } from "./helpers";
import { hideManualDrugSearch } from "../shared/manualFlow";

/**
 * Handler method to validate caseId input and conditionally show fields
 */
export const caseIdInputHandler = (role, origin) => {
  caseIdInfo(role, origin, "event").addEventListener("click", async (e) => {
    toggleDisplay(
      "solo",
      [
        `${role}${origin}caseIdQtt`,
        `${role}${origin}manualTemplateAboveTxt`,
        `${role}${origin}manualTemplateBtn`,
      ],
      "disable"
    );

    const caseId = document.getElementById(`${role}${origin}caseIdQlt`).value?.trim();
    const isValidCaseId = validateCaseId(caseId);

    const showQs = document.querySelectorAll(".initiallyHidden");

    if (isValidCaseId) {
      toggleDisplay("solo", [`${role}${origin}caseIdQbtn`], "disable");
      toggleDisplay("solo", [`${role}${origin}caseIdQbtnSpinner`], "enable");

      // prefilling data received from Medhok
      const responseData = await retrieveCaseDetails(caseId);

      const caseIdInputTimeList = JSON.parse(
        sessionStorage.getItem("caseIdInputTimeList")
      );
      caseIdInputTimeList.push(new Date().toISOString());
      sessionStorage.setItem(
        "caseIdInputTimeList",
        JSON.stringify(caseIdInputTimeList)
      );

      if (!responseData) {
        toggleDisplay("solo", [`${role}${origin}caseIdQbtn`], "enable");
        toggleDisplay("solo", [`${role}${origin}caseIdQbtnSpinner`], "disable");
        toggleDisplay(
          "solo",
          [
            `${role}${origin}manualTemplateAboveTxt`,
            `${role}${origin}manualTemplateBtn`,
          ],
          "enable"
        );
      } else {
        toggleDisplay(
          "solo",
          [
            `${role}${origin}manualTemplateAboveTxt`,
            `${role}${origin}manualTemplateBtn`,
          ],
          "disable"
        );
        const medhokData = responseData?.medhokData?.[0];

        if (medhokData?.statusReason?.toLowerCase() === "epa pending answers") {
          const qttEl = document.getElementById(`${role}${origin}caseIdQtt`);
          if (qttEl) qttEl.textContent = "This case is in ePA Pending Answers, for a new inbound call request please use the Inbound Call option and create a new note or use a different case number.";
          toggleDisplay("solo", [`${role}${origin}caseIdQtt`], "enable");
          toggleDisplay("solo", [`${role}${origin}caseIdQbtn`], "enable");
          toggleDisplay("solo", [`${role}${origin}caseIdQbtnSpinner`], "disable");
          toggleDisplay(
            "solo",
            [
              `${role}${origin}manualTemplateAboveTxt`,
              `${role}${origin}manualTemplateBtn`,
            ],
            "enable"
          );
          return;
        }

        sessionStorage.setItem("prefillStatus", "Processing");
        let prefill = false;
        /** Skipping prefilling when we get error or no response from Medhok */
        if (medhokData) {
          sessionStorage.setItem("originalMedhokResponse", JSON.stringify(medhokData));
          // Hide drug search field now that medhok provides drug data (switches to automated flow)
          hideManualDrugSearch(role, origin);
          if (role === "tech" && origin === "Queue") {
            preFillTechQueue(role, origin, medhokData);
            prefillCDRD(role, origin, medhokData);
            /*
              Automate DLT Guidelines only when Request Reason is  not Automated - If automated event listener would have already triggered 
              the same automateDLTGuidelines and we'd like to avoid duplicate action for DLT Guideline Automation 
            */
            if(!isRequestReasonAutomated(role, origin)) {
              automateDLTGuidelines(role, origin, medhokData);
            }
            prefill = true;
          } else if (role === "tech" && origin === "SR") {
            preFillTechSR(role, origin, medhokData);
            prefill = true;
          } else if (role === "tech" && origin === "TAT") {
            preFillTechTAT(role, origin, medhokData);
            prefillCDRD(role, origin, medhokData);
            /*
              Automate DLT Guidelines only when Request Reason is  not Automated - If automated event listener would have already triggered 
              the same automateDLTGuidelines and we'd like to avoid duplicate action for DLT Guideline Automation 
            */
            if(!isRequestReasonAutomated(role, origin)) {
              automateDLTGuidelines(role, origin, medhokData);
            }
            prefill = true;
          } else if (role === "rph" && origin === "Queue") {
            preFillRphQueue(role, origin, medhokData);
            prefill = true;
          } else if (role === "rph" && origin === "TAT") {
            preFillRphTAT(role, origin, medhokData);
            prefill = true;
          } else if (role === "rph" && origin === "IBC") {
            preFillRphIBC(role, origin, medhokData);
            prefill = true;
          } else if (role === "tech" && origin === "IBC") {
            preFillTechIBC(role, origin, medhokData);
            prefillCDRD(role, origin, medhokData);
            /*
              Automate DLT Guidelines only when Request Reason is  not Automated - If automated event listener would have already triggered 
              the same automateDLTGuidelines and we'd like to avoid duplicate action for DLT Guideline Automation 
            */
            if(!isRequestReasonAutomated(role, origin)) {
              automateDLTGuidelines(role, origin, medhokData);
            }
            prefill = true;
          }
        }

        if (prefill === true) {
          sessionStorage.setItem("workFlow", "Automated");
          sessionStorage.setItem("prefillStatus", "Completed");

          if(role === "tech" && ["Queue", "TAT", "IBC"].includes(origin)) {
            toggleDisplay("solo", [`${role}${origin}guidelineQ`, `${role}${origin}subguidelineQ`], "enable");
          }
        } else {
          sessionStorage.setItem("prefillStatus", "Failed");
        }

        toggleDisplay(
          "solo",
          [
            "generateNotebtn",
            "buttonSection",
            origin !== "SR" ? `${role}${origin}validatedMemberQ` : "",
          ],
          "enable"
        );
        toggleDisplay(
          "solo",
          [
            `${role}${origin}caseIdQtt`,
            `${role}${origin}caseIdQbtn`,
            `${role}${origin}caseIdQbtnSpinner`,
          ],
          "disable"
        );

        showQs.forEach((s) => {
          s.style.display = "block";
          // s.disabled = false;

          if (s.id === "techSRvalidatedMemberQ") {
            s.style.display = "none";
            // s.disabled = true;
          }
        });

        // if (prefill) {
        //   removeFields(role, origin);
        // }
        // remove "Do not need" fields from manual fields as well
        removeFields(role, origin);
      }
    } else {
      toggleDisplay("solo", ["generateNotebtn", "buttonSection"], "disable");
      const qttEl = document.getElementById(`${role}${origin}caseIdQtt`);
      if (qttEl) qttEl.textContent = "Note: Please fill out valid Case Id. Valid Case Id e.g., M26XXXXXXXX.";
      toggleDisplay("solo", [`${role}${origin}caseIdQtt`], "enable");

      showQs.forEach((s) => {
        s.style.display = "none";
        // s.disabled = true;

        if (s.id === "techIBCcaseIdQ") {
          s.style.display = "block";
          // s.disabled = false;
        }
      });
    }
  });
};

/**
 * Handler to reset conditionally shown fields based on caseId
 */
export const handleOriginClickEvent = (role, origin) => {
  /* Resetting fields to avoid showing stale data/fields when origin is changed */
  resetNote();
  document.querySelectorAll('[id$="drugNameWSearchNoteQ"], [id$="drugPickerNoteQ"]').forEach(el => {
    el.style.display = 'none';
    const textDiv = el.querySelector('.d-flex > div:last-child');
    if (textDiv) textDiv.innerHTML = '';
  });
  document.getElementById('alertPopupBody')?.querySelector('.ant-drug-note-alert')?.remove();

  const showQs = document.querySelectorAll(".initiallyHidden");
  showQs.forEach((s) => {
    s.style.display = "none";
  });

  // HideAll does not cover dynamically-shown "Fill Manually" buttons — hide all of them
  // regardless of which origin had them visible (any prior invalid case ID lookup).
  document.querySelectorAll('[id$="manualTemplateBtn"], [id$="manualTemplateAboveTxt"]')
    .forEach((el) => { el.style.display = 'none'; });

  // Keeping track for startTime when filling Queue is started to send it to BigTable
  const timestamp = new Date().toISOString();
  sessionStorage.setItem("startTime", timestamp);

  toggleDisplay(
    "solo",
    [`${role}${origin}caseIdQtt`, "alertPopupBtn", "alertPopup"],
    "disable"
  );
  if(role === 'tech' && origin === 'IBC') {
    toggleDisplay(
      "solo",
      [`${role}${origin}caseIdQbtn`, `${role}${origin}caseIdQ`],
      "disable"
    );
  } else {
    toggleDisplay(
      "solo",
      [`${role}${origin}caseIdQbtn`, `${role}${origin}caseIdQ`],
      "enable"
    );
  }

  // set active color for selected origin
  resetOriginLabels(role, origin);
};

manualTemplateButtonHandler("tech", "Queue");
manualTemplateButtonHandler("tech", "SR");
manualTemplateButtonHandler("rph", "Queue");
manualTemplateButtonHandler("rph", "TAT");
manualTemplateButtonHandler("tech", "TAT");
manualTemplateButtonHandler("rph", "IBC");
manualTemplateButtonHandler("tech", "IBC");
