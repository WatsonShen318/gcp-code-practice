/* eslint-disable dot-notation */
import {
    preFillClient, 
    preFillPriority,
    preFillDrugName,
    preFillQuantity,
    preFillDaysSupply,
    preFillDiagnosis,
    preFillRqstReason,
    preFillrqstType,
    preFillMdRouting,
    preFillMdRational,
    preFillMdDiagnosis,
    preFillMdClaims,
    preFillIntake,
    preFillManualTimestamp,
    prefillSubClaimTodayCode,
    prefillSupportingStatement
} from './preFillValues';
import  {createAlertMessage, displayAlert} from "./createAlert";

export default function preFillRphQueue(role, origin, medhokData){
    const [clientValue, clientAlert] = preFillClient(role, origin, medhokData);
    const [priorityValue, priorityAlert] = preFillPriority(role, origin, medhokData);
    const [drugNameValue, drugNameAlert, drugSpecificAlert] = preFillDrugName(role, origin, medhokData);
    const drugQtyValue = preFillQuantity(role, origin, medhokData);
    const daysSupplyText = preFillDaysSupply(role, origin, medhokData);
    if (drugQtyValue && daysSupplyText) {
        document.getElementById(`${role}${origin}qtyDSQPA`).style.display = 'none';
    }
    const diagnosisValue = preFillDiagnosis(role, origin, medhokData);
    const [rqstReasonValue, rqstReasonAlert] = preFillRqstReason(role, origin, medhokData);
    const supportingStatementRequiredDesc = prefillSupportingStatement(role, origin, medhokData);
    const rqstTypeValue = preFillrqstType(role, origin, medhokData);
    const [routingValue, routingAlert] = preFillMdRouting(role, origin, medhokData);
    const intakeValue = preFillIntake(role, origin, medhokData);
    const [timestampValue, manualTimestampAlert] = preFillManualTimestamp(role, origin, medhokData);
    const rejectCodes = prefillSubClaimTodayCode(role, origin, medhokData);

    let mdRationalValue = "";
    let mdDiagnosisValue = "";
    let mdClaimsValue = "";
    if (routingValue === "Send to MD"){
        mdRationalValue = preFillMdRational(role, origin, medhokData);
        mdDiagnosisValue = preFillMdDiagnosis(role, origin, medhokData);
        mdClaimsValue = preFillMdClaims(role, origin, medhokData);
    };

    const origins = {
        'Client': clientAlert,
        'Priority': priorityAlert,
        'Drug': drugNameAlert,
        'Request Reason': rqstReasonAlert,
        'Routing': routingAlert,
        'Drug Specific': drugSpecificAlert,
        'Timestamp': manualTimestampAlert
    }

    const customAlertProps = {
        drugNameValue
    }

    const createdAlert = createAlertMessage(origins, customAlertProps);
    displayAlert(createdAlert);

    const eslRsp = {};
    eslRsp["rxId"] = medhokData.rxId;
    eslRsp["memberEligibility.company"] = clientValue;
    eslRsp["priority"] = priorityValue;
    eslRsp["drugName"] = drugNameValue;
    eslRsp["quantity"] = drugQtyValue;
    eslRsp["daysSupply"] = daysSupplyText;
    eslRsp["diagnosis"] = diagnosisValue;
    eslRsp["requestReason"] = rqstReasonValue;
    eslRsp["supportingStatementRequiredDesc"] = supportingStatementRequiredDesc;
    eslRsp["requestType"] = rqstTypeValue;
    eslRsp["rational"] = mdRationalValue;
    eslRsp["status"] = routingValue;
    eslRsp["mdDiagnosis"] = mdDiagnosisValue;
    eslRsp["rejectMessage"] = mdClaimsValue;
    eslRsp["intakeValue"] = intakeValue;
    eslRsp["manualReceived"] = timestampValue;
    eslRsp["rejectCodes"] = rejectCodes;

    sessionStorage.setItem('eslRsp', JSON.stringify(eslRsp));
};
