import { requestReasonOptions } from "./mapping";
import { toggleDisplay } from "../utils/notetool.display";
import { isHIVDrug } from "../drugs/drugs";
import { approved } from "../decision/decision.checks";

const clientList = require("../../app/client/clients.json");

const hidePrefilledValues = true;

/* eslint-disable prefer-destructuring */
// eslint-disable-next-line import/prefer-default-export
export function preFillClient(role, origin, medhokData) {
  try {
    const client = document.getElementById(`${role}${origin}clientQsel`);

    let clientValue = medhokData.memberEligibility.company;
    let clientAlert = "";
    const clientTerms = clientValue.split(" ");

    if (clientTerms.includes("SilverScript")) {
      clientValue = "SSI";
      clientAlert = "";
    } else {
      // eslint-disable-next-line no-lonely-if
      if (clientValue === "SilverScript (Main)") {
        clientValue = "SSI";
      } else if (clientValue === "Joint Enterprise") {
        clientValue = "JE";
      } else if (clientValue === "Martin's Point Generations, LLC") {
        clientValue = "Martin's Point";
      } else if (clientValue === "Paramount Health Plan") {
        clientValue = "Paramount";
      } else if (clientValue === "Aetna") {
        clientValue = "Aetna MAPD";
        clientAlert = "";
      } else if (clientValue === "Community Care Oklahoma") {
        clientValue = "Community Care of Oklahoma (CCOK)";
        clientAlert = "Community Care of Oklahoma";
      } else if (clientValue === "Johns Hopkins") {
        clientValue = "Johns Hopkins";
      // } else if (clientValue === "KelseyCare Adv") {
      //   clientValue = "KelseyCare";
      //   clientAlert = "KelseyCare";
      } else if (clientValue === "Neighborhood Health Plan Rhode Island") {
        clientValue = "Neighborhood Health Plan Rhode Island";
        clientAlert = "Neighborhood Health Plan Rhode Island";
      } else if (clientValue === "PacificSource") {
        clientValue = "Pacific Source";
        clientAlert = "Pacific Source";
      } else if (clientValue === "Sharp Health Plan") {
        clientValue = "Sharp Health Plan";
        clientAlert = "Sharp Health Plan";
      } else if (clientValue === "BCBS of MASS" || clientValue === "BCBS Of MASS") {
        clientValue = "BCBS Of MASS";
        clientAlert = "BCBS Of MASS";
      } else if (clientValue === "Devoted Health dSNP") {
        clientValue = "Devoted Health dSNP";
        clientAlert = "Devoted Health dSNP";
      } else if (clientValue === "FEP") {
        clientValue = "FEP";
        clientAlert = "FEP";
      } else if (clientValue === "MMM Florida") {
        clientValue = "MMM Florida";
        clientAlert = "MMM Florida";
      } else if (clientValue === "Pacific Source") {
        clientValue = "Pacific Source";
        clientAlert = "Pacific Source";
      } else if (clientValue === "Clearstone") {
        clientValue = "Clearstone";
        clientAlert = "Clearstone";
      } else if (
        clientValue === "HealthFirst" ||
        clientValue === "Healthfirst"
      ) {
        clientValue = "Healthfirst";
        clientAlert = "Healthfirst";
      } else if (clientValue === "HMSA") {
        clientValue = "HMSA";
        clientAlert = "HMSA";
      }
    }

    const listOfClientNames = clientList.list.map((client) => client.value);

    clientValue = listOfClientNames?.includes(clientValue) ? clientValue : "";

    client.value = clientValue;
    const event = new Event("change");
    client.dispatchEvent(event);

    if (clientValue === "EGWP" || clientValue === "other") {
      const secondFillUp = document.getElementById(
        `${role}${origin}subegwpQtxt`
      );
      secondFillUp.value = medhokData.memberEligibility.company;
      clientAlert = "EGWP";
    }
    if (hidePrefilledValues && clientValue) {
      document.getElementById(`${role}${origin}clientQPA`).style.display =
        "none";
    }
    return [clientValue, clientAlert];
  } catch (error) {
    return "";
  }
}

export function preFillTechSRClient(role, origin, medhokData) {
  try {
    let clientValue = medhokData.memberEligibility.company;
    let clientAlert = "";

    if (clientValue) {
      if (hidePrefilledValues) {
        (document.getElementById(
          `${role}${origin}clientKeyinQPA`
        ).style.display = "none");
      }
      const drugNameText = document.getElementById(
        `${role}${origin}clientKeyinQtxt`
      );
      drugNameText.value = clientValue;
    }

    return [clientValue, clientAlert];
  } catch (error) {
    return "";
  }
}

export function preFillPriority(role, origin, medhokData) {
  try {
    const priorityValue = medhokData.priority;
    let radiobtn = "";
    let priorityAlert = "";
    if (priorityValue === "Expedited") {
      radiobtn = document.getElementById(`${role}${origin}iPriorityQExpedited`);
      priorityAlert = "Expedited";
    } else if (priorityValue === "Standard") {
      radiobtn = document.getElementById(`${role}${origin}iPriorityQStandard`);
      priorityAlert = "Standard";
    }

    if (radiobtn) {
      radiobtn.checked = true;
      radiobtn.click();
    }

    // Unhiding Priority field if it is prefilled as requested by Business for 05/12/2025 release
    // if (hidePrefilledValues && priorityValue) {
    //   document.getElementById(`${role}${origin}iPriorityQPA`).style.display =
    //     "none";
    // }
    return [priorityValue, priorityAlert];
  } catch (error) {
    return "";
  }
}

export function preFillDrugName(role, origin, medhokData) {
  try {
    let drugNameValue = medhokData.drugName;

    // Handling edge case if drugName is not valid
    if (drugNameValue?.toLowerCase()?.startsWith("manual")) {
      drugNameValue = "";
    }
    let drugNameAlert = "";
    let drugSpecificAlert = "";
    if (drugNameValue) {
      if (hidePrefilledValues) {
        document.getElementById(`${role}${origin}drugNameQPA`).style.display =
          "none";
      }
      const drugNameText = document.getElementById(
        `${role}${origin}drugNameQtxt`
      );
      drugNameText.value = drugNameValue;

      if (drugNameValue?.split(" ")[0].toLowerCase() === "zolpidem") {
        drugSpecificAlert = "ZOLPIDEM";
      } else if (isHIVDrug(drugNameValue)) {
        drugSpecificAlert = "HIV Drug";
      }

      drugNameAlert = "Drug Details";
    }
    return [drugNameValue, drugNameAlert, drugSpecificAlert];
  } catch (error) {
    return "";
  }
}

export function preFillQuantity(role, origin, medhokData) {
  try {
    const drugQtyValue = medhokData.quantity;
    const druQtyText = document.getElementById(`${role}${origin}qtytxt`);
    druQtyText.value = drugQtyValue;

    return drugQtyValue;
  } catch (error) {
    return "";
  }
}

export function preFillDaysSupply(role, origin, medhokData) {
  try {
    const daysSupplyValue = medhokData.daysSupply;
    const daysSupplyText = document.getElementById(`${role}${origin}dstxt`);
    daysSupplyText.value = daysSupplyValue;

    return daysSupplyValue;
  } catch (error) {
    return "";
  }
}

export function preFillDiagnosis(role, origin, medhokData) {
  try {
    const diagnosisText = document.getElementById(
      `${role}${origin}diagnosisQlt`
    );
    const diagnosisCode =
      medhokData.diagnosis1 && medhokData.diagnosis1 !== "Not Available"
        ? medhokData.diagnosis1
        : "";
    const diagnosisDescription =
      medhokData.diagnosisDescription1 &&
      medhokData.diagnosisDescription1 !== "Not Available"
        ? medhokData.diagnosisDescription1
        : "";
    let diagnosisValue = "";
    if (diagnosisCode && diagnosisDescription) {
      diagnosisValue = diagnosisCode.concat(" ", diagnosisDescription);
    } else {
      diagnosisValue = diagnosisCode || diagnosisDescription;
    }
    diagnosisText.value = diagnosisValue;

    return diagnosisValue;
  } catch (error) {
    return "";
  }
}

export function preFillRqstReason(role, origin, medhokData) {
  try {
    const event = new Event("change");
    const rqstReason = document.getElementById(
      `${role}${origin}rqstReasonQsel`
    );
    let rqstReasonValue = medhokData?.requestReason?.trim();
    let rqstReasonAlert = "";
    if (rqstReasonValue === null) {
      rqstReasonAlert = "rqstReasonNA";
    } else if (
      rqstReasonValue === "Step Therapy" ||
      rqstReasonValue === "Tier Change" ||
      rqstReasonValue === "Hospice"
    ) {
      if(role === 'tech' && origin === 'IBC') {
        toggleDisplay("solo", [`${role}${origin}isCaseInRFIQ`], "enable");
      }
      rqstReasonAlert = rqstReasonValue;
    } else if (
      rqstReasonValue?.toLowerCase() === "Tier Change Requests"?.toLowerCase()
    ) {
      rqstReasonValue = "Tier Change";
      rqstReasonAlert = "Tier Change";
    } else if (
      rqstReasonValue?.toLowerCase() === "Non-Formulary"?.toLowerCase()
    ) {
      rqstReasonValue = "Non-formulary";
    } else if (
      rqstReasonValue?.toLowerCase().startsWith("quantity limit")
    ) {
      rqstReasonValue = "Quantity Limit";
    } else {
      rqstReasonAlert = "";
    }

    rqstReasonValue = requestReasonOptions?.includes(rqstReasonValue)
      ? rqstReasonValue
      : "";

    rqstReason.value = rqstReasonValue;
    rqstReason.dispatchEvent(event);
    if (hidePrefilledValues && rqstReasonValue) {
      document.getElementById(`${role}${origin}rqstReasonQPA`).style.display =
        "none";
    }
    return [rqstReasonValue, rqstReasonAlert];
  } catch (error) {
    return "";
  }
}

// Note: This will be disabled for tech - Q, TAT, IBC when CDRD automation is enabled as
// requestType will be automated based on CDRD automation logic.
export function preFillrqstType(role, origin, medhokData) {
  try {
    const rqstValue = medhokData.requestType;
    let radiobtn = "";
    if (rqstValue === "Coverage Determination") {
      radiobtn = document.getElementById(`${role}${origin}rqstTypeQCD`);
      radiobtn.checked = true;
      radiobtn.click();
    } else if (rqstValue === "Redetermination") {
      radiobtn = document.getElementById(`${role}${origin}rqstTypeQRD`);
      radiobtn.checked = true;
      radiobtn.click();
    }
    // For request from UAT testing, skip hiding of request type field if prefilled
    // if (rqstValue) {
    //   document.getElementById(`${role}${origin}rqstTypeQPA`).style.display =
    //     "none";
    // }

    return rqstValue;
  } catch (error) {
    return "";
  }
}

export function preFillMdRational(role, origin, medhokData) {
  try {
    const rational = document.getElementById(`${role}${origin}mdRationaleQlt`);
    const status = medhokData.status;
    const statusReason = medhokData.statusReason;
    const statusValue = status.concat(" ", statusReason);
    rational.value = statusValue;
    if (hidePrefilledValues && statusValue) {
      document.getElementById(`${role}${origin}mdRationaleQPA`).style.display =
        "none";
    }
    return statusValue;
  } catch (error) {
    return "";
  }
}

export function preFillMdRouting(role, origin, medhokData) {
  try {
    const mdStatusMapper = {
      Dismiss: "Dismissed",
    };
    const event = new Event("change");
    const routing = document.getElementById(`${role}${origin}routingQsel`);
    const routingValue =
      mdStatusMapper?.[medhokData?.status] || medhokData?.status;
    routing.value = routingValue;
    routing.dispatchEvent(event);
    let routingAlert = "";
    if (routingValue === "Approved") {
      routingAlert = "Case Decision/Routing Approved";
      approved(origin, role, "Approved", "Automated");
    } else if (routingValue === "Dismissed") {
      routingAlert = "Case Decision/Routing Denied";
    } else if (routingValue === "Send to RFI") {
      routingAlert = "Case Decision/Routing Send To RFI";
    } else if (routingValue === "Send to MD") {
      routingAlert = "Case Decision/Routing Send to MD";
    } else if (routingValue === "Transferred to Pharmacist") {
      if(role === 'tech' && origin === 'IBC') {
        routingAlert = "Case Decision/Routing Transferred to Pharmacist";
      } else {
        routingAlert = "";
      }
    } else {
      routingAlert = "";
    }

    if (routingValue === "Approved" || routingValue === "Dismissed") {
      toggleDisplay("solo", [`${role}${origin}LetterPreviewQ`], "disable");
    }

    return [routingValue, routingAlert];
  } catch (error) {
    return "";
  }
}

export function preFillMdDiagnosis(role, origin, medhokData) {
  try {
    const diagnosisText = document.getElementById(
      `${role}${origin}mdDiagnosisQlt`
    );
    const diagnosisDescription1 = medhokData.diagnosisDescription1;
    const diagnosisDescription2 = medhokData.diagnosisDescription2;
    const diagnosisDescription3 = medhokData.diagnosisDescription3;

    let diagnosisValue = diagnosisDescription1;
    if (diagnosisDescription2) {
      diagnosisValue = diagnosisValue.concat(" ", diagnosisDescription2);
    }
    if (diagnosisDescription3) {
      diagnosisValue = diagnosisValue.concat(" ", diagnosisDescription3);
    }

    diagnosisText.value = diagnosisValue;
    return diagnosisValue;
  } catch (error) {
    return "";
  }
}

export function preFillMdClaims(role, origin, medhokData) {
  try {
    const claimsValue = medhokData.rejectMessage;
    const claimsText = document.getElementById(`${role}${origin}mdClaimsQtxt`);
    claimsText.value = claimsValue;
    if (hidePrefilledValues && claimsValue) {
      document.getElementById(`${role}${origin}mdClaimsQPA`).style.display =
        "none";
    }
    return claimsValue;
  } catch (error) {
    return "";
  }
}

export function preFillIntake(role, origin, medhokData) {
  try {
    const intakeValue = medhokData.intake;
    if (intakeValue === "NCPDP ePA") {
      toggleDisplay(
        "solo",
        [
          `${role}${origin}claimQPA`,
          `${role}${origin}claimQ`,
          `${role}${origin}subclaimTodayDQPA`,
          `${role}${origin}subclaimTodayDQ`,
          `${role}${origin}subclaimTodayRefillQPA`,
          `${role}${origin}subclaimTodayRefillQ`,
          `${role}${origin}subclaimTodayCodeQPA`,
          `${role}${origin}subclaimTodayCodeQ`,
          `${role}${origin}claim90dQPA`,
          `${role}${origin}claim90dQ`,
          `${role}${origin}subclaim90dQPA`,
          `${role}${origin}subclaim90dQ`,
          `${role}${origin}spprSatementQPA`,
          `${role}${origin}spprSatementQ`,
        ],
        "disable"
      );
    }
    return intakeValue;
  } catch (error) {
    return "";
  }
}

export function preFillManualTimestamp(role, origin, medhokData) {
  try {
    const timestampValue = medhokData.manualReceived;
    let radiobtn = "";
    let manualTimestampAlert = "";
    if (!timestampValue || timestampValue == "N/A") {
      radiobtn = document.getElementById(`${role}${origin}timestampQNo`);
    } else {
      radiobtn = document.getElementById(`${role}${origin}timestampQYes`);
      manualTimestampAlert = "Manual";
    }

    if (radiobtn) {
      radiobtn.checked = true;
      radiobtn.click();
    }

    if (hidePrefilledValues) {
      document.getElementById(`${role}${origin}timestampQPA`).style.display =
        "none";
    }

    return [timestampValue, manualTimestampAlert];
  } catch (error) {
    return "";
  }
}

export function prefillSubClaimTodayCode(role, origin, medhokData) {
  try {
    const rejectCodes = medhokData.rejectCodes || "";
    const subClaimTodayCodeQText = document.getElementById(
      `${role}${origin}subclaimTodayCodeQtxt`
    );
    subClaimTodayCodeQText.value = rejectCodes;

    if (hidePrefilledValues && rejectCodes) {
      document.getElementById(
        `${role}${origin}subclaimTodayCodeQPA`
      ).style.display = "none";
    }

    return rejectCodes;
  } catch (error) {
    return "";
  }
}

export function prefillSupportingStatement(role, origin, medhokData) {
  try {
    const supportingStatementRequiredDesc = medhokData.supportingStatementRequiredDesc;
    let radiobtn = "";

    if (supportingStatementRequiredDesc === "No") {
      radiobtn = document.getElementById(`${role}${origin}spprSatementQNo`);
    } else if (supportingStatementRequiredDesc === "Yes") {
      radiobtn = document.getElementById(`${role}${origin}spprSatementQYes`);
    } else {
      radiobtn = document.getElementById(`${role}${origin}spprSatementQNA`);
    }

    if (radiobtn && !radiobtn.disabled) {
      radiobtn.checked = true;
      radiobtn.click();
    }

    return supportingStatementRequiredDesc;
  } catch (error) {
    return "";
  }
}
