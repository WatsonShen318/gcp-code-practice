import { manualFormTemplate } from "./manualTemplate";

/* Helper to skip prefilling and enable manual templates */
const skipPrefilling = (role, origin) => {
  const userInfo = JSON.parse(sessionStorage.getItem("userInfo") || "{}");
  if (userInfo?.isHoldoutUser) {
    manualFormTemplate(role, origin);
  }
};

export { skipPrefilling };
