import { toggleDisplay } from "../utils/notetool.display";
import { isFlowAutomated } from "./helpers";

function removeTechQueueFields(role, origin) {
  const fieldsToBeRemoved = [
    "subExpReasonQ",
    "rqstByQ",
    "caseVerifiedQ",
    "mdoInfoQ",
    "qtyDSMHK",
    "ePAQ",
  ];
  const techQueueFieldsDoNotNeededForAutomation = fieldsToBeRemoved.map(
    (field) => `${role}${origin}${field}`
  );
  toggleDisplay("solo", techQueueFieldsDoNotNeededForAutomation, "disable");
}

function removeTechTATFields(role, origin) {
  const fieldsToBeRemoved = [
    "subExpReasonQ",
    "rqstByQ",
    "caseVerifiedQ",
    "mdoInfoQ",
    "qtyDSMHK",
    "ePAQ",
  ];
  const techQueueFieldsDoNotNeededForAutomation = fieldsToBeRemoved.map(
    (field) => `${role}${origin}${field}`
  );
  toggleDisplay("solo", techQueueFieldsDoNotNeededForAutomation, "disable");
}

function removeTechSRFields(role, origin) {
  const fieldsToBeRemoved = [
    "subExpReasonQ",
    "rqstByQ",
    "caseVerifiedQ",
    "mdoInfoQ",
    "qtyDSMHK",
    "ePAQ",
  ];
  const techQueueFieldsDoNotNeededForAutomation = fieldsToBeRemoved.map(
    (field) => `${role}${origin}${field}`
  );
  toggleDisplay("solo", techQueueFieldsDoNotNeededForAutomation, "disable");
}

function removeRPHQueueFields(role, origin) {
  const fieldsToBeRemoved = [
    "subExpReasonQ",
    "rqstByQ",
    "caseVerifiedQ",
    "mdoInfoQ",
    "qtyDSMHK",
    "ePAQ",
  ];
  const rphQueueFieldsDoNotNeededForAutomation = fieldsToBeRemoved.map(
    (field) => `${role}${origin}${field}`
  );
  toggleDisplay("solo", rphQueueFieldsDoNotNeededForAutomation, "disable");
}

function removeRPHTATFields(role, origin) {
  const fieldsToBeRemoved = [
    "subExpReasonQ",
    "rqstByQ",
    "rqstTATChecksQ",
    "caseVerifiedQ",
    "mdoInfoQ",
    "qtyDSMHK",
    "ePAQ",
    "exceptionRdoQ",
  ];
  const rphQueueFieldsDoNotNeededForAutomation = fieldsToBeRemoved.map(
    (field) => `${role}${origin}${field}`
  );
  toggleDisplay("solo", rphQueueFieldsDoNotNeededForAutomation, "disable");
}

function removeRPHIBCFields(role, origin) {
  const fieldsToBeRemoved = [
    "subExpReasonQ",
    "timestampQ",
    "subrqstInfoQ",
    // "rqstByQ",
    "rqstTATChecksQ",
    "caseVerifiedQ",
    "mdoInfoQ",
    "qtyDSMHK",
    "ePAQ",
    "exceptionRdoQ",
  ];
  const rphIBCFieldsDoNotNeededForAutomation = fieldsToBeRemoved.map(
    (field) => `${role}${origin}${field}`
  );
  toggleDisplay("solo", rphIBCFieldsDoNotNeededForAutomation, "disable");
}

function removeTechIBCFields(role, origin) {
  const fieldsToBeRemoved = [
    "inProgressCaseQ",
    "subExpReasonQ",
    "timestampQ",
    // "rqstByQ",
    "subrqstInfoQ",
    "caseVerifiedQ",
    "mdoInfoQ",
    "qtyDSMHK",
    "ePAQ",
  ];
  const techIBCFieldsDoNotNeededForAutomation = fieldsToBeRemoved.map(
    (field) => `${role}${origin}${field}`
  );
  toggleDisplay("solo", techIBCFieldsDoNotNeededForAutomation, "disable");
}

export function removeTechIBCFieldsForNewCase(role, origin) {
  const fieldsToBeRemoved = [
    "timestampQ",
    // "rqstByQ",
    "subrqstInfoQ",
    "caseVerifiedQ",
    "mdoInfoQ",
    "qtyDSMHK",
  ];
  const techIBCFieldsDoNotNeededForAutomation = fieldsToBeRemoved.map(
    (field) => `${role}${origin}${field}`
  );
  toggleDisplay("solo", techIBCFieldsDoNotNeededForAutomation, "disable");
}

export const getObcFieldsToBeRemoved = (role, origin, alt = false) => {
  let fieldsToBeRemoved = [];
  if (alt) {
    fieldsToBeRemoved = [
      "subobPurposeQalt",
      "subobCIrecQalt",
      "subobcalloutcoQalt",
      "subobRFIQalt",
      "subobinfoGatherQalt",
    ];
  } else {
    fieldsToBeRemoved = [
      "subobPurposeQ",
      "subobCIrecQ",
      "subobcalloutcoQ",
      "subobRFIQ",
      "subobinfoGatherQ",
    ];
  }
  const obcFieldsDoNotNeededForAutomation = fieldsToBeRemoved.map(
    (field) => `${role}${origin}${field}`
  );

  return obcFieldsDoNotNeededForAutomation;
};

export default function removeFields(role, origin) {
  if (role == "tech" && origin == "Queue") {
    removeTechQueueFields(role, origin);
  } else if (role == "tech" && origin == "SR") {
    removeTechSRFields(role, origin);
  } else if (role == "tech" && origin == "TAT") {
    removeTechTATFields(role, origin);
  } else if (role == "rph" && origin == "Queue") {
    removeRPHQueueFields(role, origin);
  } else if (role == "rph" && origin == "TAT") {
    removeRPHTATFields(role, origin);
  } else if (role == "rph" && origin == "IBC") {
    removeRPHIBCFields(role, origin);
  } else if (role == "tech" && origin == "IBC") {
    removeTechIBCFields(role, origin);
  }
}
