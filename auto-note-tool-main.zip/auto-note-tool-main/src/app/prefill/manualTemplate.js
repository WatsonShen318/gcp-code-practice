import { toggleDisplay } from "../utils/notetool.display";
import removeFields from "./removeFields";
import toggleDrugNameWSearchQ from "../dlt_guidelines/display";
import { resolveFormularyForClient, onManualDrugSelected } from "../form_alts/formAlts";
import { onManualDrugSelectedQl } from "../quantity_limit/quantityLimit";
import { setupManualDrugSearch } from "../shared/manualFlow";
import { initAetnaQuestions } from "../aetna_questions/aetnaQuestions";
import { initSearchableSelectForOrigin } from "../customInputs/searchableSelect/searchableSelect";

export function manualFormTemplate(role, origin) {
  const showQs = document.querySelectorAll(".initiallyHidden");
  showQs.forEach((s) => {
    s.style.display = "block";
    // s.disabled = false;

    if (s.id === "techSRvalidatedMemberQ") {
      s.style.display = "none";
      // s.disabled = true;
    }
  });

  const techcaseIdtxtField = document.getElementById(
    `${role}${origin}caseIdQlt`
  );
  techcaseIdtxtField.removeAttribute("required");

  const disableList = [
    `${role}${origin}caseIdQtt`,
    `${role}${origin}caseIdQbtn`,
    `${role}${origin}caseIdQbtnSpinner`,
    `${role}${origin}caseIdQ`,
    `${role}${origin}manualTemplateBtn`,
    `${role}${origin}manualTemplateAboveTxt`,
  ];
  toggleDisplay(
    "solo",
    [
      "generateNotebtn",
      "buttonSection",
      origin != "SR" ? `${role}${origin}validatedMemberQ` : "",
    ],
    "enable"
  );
  toggleDisplay("solo", disableList, "disable");

  // Show drug name search field immediately in manual mode (hides plain text drug name field)
  toggleDrugNameWSearchQ(role, origin);
  // (Re-)initialize the searchable select for this origin — gives a clean instance each time
  initSearchableSelectForOrigin(role, origin);

  // Register drug search handler once for the session - fires for both NF and QL
  setupManualDrugSearch(role, origin, (gpi, drugName) => {
    onManualDrugSelected(role, origin, gpi, drugName);
    onManualDrugSelectedQl(role, origin, gpi, drugName);
    initAetnaQuestions(role, origin);
  });

  // If client is already selected when Fill Manually is clicked, resolve formulary immediately
  // so Q254/Q255/Q249 are ready before the user reaches request reason
  const clientEl = document.getElementById(`${role}${origin}clientQsel`);
  if (clientEl?.value) {
    resolveFormularyForClient(role, origin);
  }
}

export const manualTemplateButtonHandler = (role, origin) => {
  document
    .getElementById(`${role}${origin}manualTemplateBtn`)
    .addEventListener("click", (e) => {
      e.preventDefault();
      manualFormTemplate(role, origin);
      // remove "Do not need" fields from manual fields as well
      removeFields(role, origin);
    });
};
