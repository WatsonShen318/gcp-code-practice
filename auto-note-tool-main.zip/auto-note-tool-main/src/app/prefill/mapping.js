const requestReasonOptions = [
  "Non-formulary",
  "Prior Authorization",
  "Quantity Limit",
  "Quantity Opioid 7 Day",
  "Safety Edit",
  "Step Therapy",
  "Tier Change",
  "Hospice",
];

export {
    requestReasonOptions
}
