import getCDRDResponse from "../caseHistory/getCDRDResponse";

/* CDRD Notes for notes summary */
const formulateCDRDGridNotes = (cdrdResponse) => {
  const cdrdGridAnswers = cdrdResponse?.cdrdGridAnswers;

  const filteredEntries = Object.entries(cdrdGridAnswers)
        .filter(([key, value]) => key !== 'requestType' && value)
        .map(([key, value]) => `${key}=${value}`);

  return `CD/RD Grid Answers: ${filteredEntries.join(', ')}`;
};

/* Method to prefill denied case based field on CDRD automation response from Backend API */
export function prefillDeniedCase(role, origin, cdrdResponse) {
  try {
    const deniedCase = cdrdResponse?.cdrdGridAnswers?.Q1;
    let radiobtn = "";
    const requestTypeRadioButton = document.getElementById(
      `${role}${origin}rqstTypeQ`
    );
    if (deniedCase === "Yes") {
      radiobtn = document.getElementById(`${role}${origin}rqstTypeDeniedQYes`);
      radiobtn.checked = true;
      // radiobtn.click();
    } else if (deniedCase === "No") {
      radiobtn = document.getElementById(`${role}${origin}rqstTypeDeniedQNo`);
      radiobtn.checked = true;
      // radiobtn.click();
    }

    const hiddenCDRDAnswer = document.getElementById(
      `${role}${origin}rqstTypeDeniedQhidden`
    );

    // Enable requestType field when deniedRequestType is prefilled
    if (radiobtn) {
      requestTypeRadioButton.disabled = false;
      hiddenCDRDAnswer.value = formulateCDRDGridNotes(cdrdResponse)
    }

    return deniedCase;
  } catch (error) {
    return "";
  }
}

/* Method to prefill request type based on CDRD automation response from Backend API */
export function prefillrqstType(role, origin, cdrdResponse) {
  try {
    const requestType = cdrdResponse?.cdrdGridAnswers?.requestType;
    sessionStorage.setItem('cdrdPredOutcome', requestType);
    let radiobtn = "";
    if (requestType?.includes("CD")) {
      radiobtn = document.getElementById(`${role}${origin}rqstTypeQCD`);
      radiobtn.checked = true;
      radiobtn.click();
    } else if (requestType?.includes("RD")) {
      radiobtn = document.getElementById(`${role}${origin}rqstTypeQRD`);
      radiobtn.setAttribute('data-automated', 'true')
      radiobtn.checked = true;
      radiobtn.click();
    }
    // For request from UAT testing, skip hiding of request type field if prefilled
    // if (rqstValue) {
    //   document.getElementById(`${role}${origin}rqstTypeQPA`).style.display =
    //     "none";
    // }

    return requestType;
  } catch (error) {
    return "";
  }
}

/* Method to automated CDRD template fields based on backend API response */
export function automateCDRDGridFields(grid, answers) {
  Object.entries(answers).forEach(([key, value]) => {
    if (key.startsWith("Q") && value) {
      const questionKey = key.replace("Q", "Number");
      const yesButton = grid.document.getElementById(`${questionKey}RdoYes`);
      const noButton = grid.document.getElementById(`${questionKey}RdoNo`);

      if (value === "Yes" && yesButton) {
        yesButton.click();
      } else if (value === "No" && noButton) {
        noButton.click();
      }
    }
  });
}

/* Helper to prefill CDRD primary fields(Denied case in past 65 days Field and Request Type Field) before opening CDRD template */
export async function prefillCDRD(role, origin, medhokData) {
  const cdrdResponse = await getCDRDResponse(medhokData);
  prefillDeniedCase(role, origin, cdrdResponse);
  prefillrqstType(role, origin, cdrdResponse);
}
