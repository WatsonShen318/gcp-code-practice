/* eslint-disable dot-notation */
import { 
    preFillPriority,
    preFillDrugName,
    preFillQuantity,
    preFillDaysSupply,
    preFillDiagnosis,
    preFillRqstReason,
    preFillTechSRClient,
    preFillManualTimestamp,
} from './preFillValues';

import  {createAlertMessage, displayAlert} from "./createAlert";

export default function preFillTechSR(role, origin, medhokData){
    const [clientValue, clientAlert] = preFillTechSRClient(role, origin, medhokData);
    const [priorityValue, priorityAlert] = preFillPriority(role, origin, medhokData);
    const [drugNameValue, drugNameAlert, drugSpecificAlert] = preFillDrugName(role, origin, medhokData);
    const drugQtyValue = preFillQuantity(role, origin, medhokData);
    const daysSupplyText = preFillDaysSupply(role, origin, medhokData);
    if (drugQtyValue && daysSupplyText) {
        document.getElementById(`${role}${origin}qtyDSQPA`).style.display = 'none';
    }
    const diagnosisValue = preFillDiagnosis(role, origin, medhokData);
    const [rqstReasonValue, rqstReasonAlert] = preFillRqstReason(role, origin, medhokData);

    const [timestampValue, manualTimestampAlert] = preFillManualTimestamp(role, origin, medhokData);

    const origins = {
        'Client': clientAlert,
        'Priority': priorityAlert,
        'Drug': drugNameAlert,
        'Request Reason': rqstReasonAlert,
        'Drug Specific': drugSpecificAlert,
        'Timestamp': manualTimestampAlert
    }

    const customAlertProps = {
        drugNameValue
    }

    const createdAlert = createAlertMessage(origins, customAlertProps);
    displayAlert(createdAlert);

    const eslRsp = {};
    eslRsp["rxId"] = medhokData.rxId;
    eslRsp["memberEligibility.company"] = clientValue;
    eslRsp["priority"] = priorityValue;
    eslRsp["drugName"] = drugNameValue;
    eslRsp["quantity"] = drugQtyValue;
    eslRsp["daysSupply"] = daysSupplyText;
    eslRsp["diagnosis"] = diagnosisValue;
    eslRsp["requestReason"] = rqstReasonValue;
    eslRsp["manualReceived"] = timestampValue;

    sessionStorage.setItem('eslRsp', JSON.stringify(eslRsp));
};
