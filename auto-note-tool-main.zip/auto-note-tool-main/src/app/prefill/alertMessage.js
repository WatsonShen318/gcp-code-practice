const alertMessages = {
    "Devoted Health dSNP" : "Alert: Do NOT decision cases for Devoted Health dSNP<br>Guidance: Refer to Technicians: Case Handling Instructions for Health Plan Clients",
    "FEP" : "Alert: Refer to client specific job aid FEP Client Specific Instructions- Med D CD&A",
    "BCBS Of MASS": "Alert: Client delegates DMP reviews only - Refer to BCBS of MASS Client specific job aid",
    "Clearstone": "Guidance: ClearStone Client Specific Job Aid MHK",
    "MMM Florida": "Alert: CVS Caremark does NOT process Redeterminations for this plan.<br>Guidance:<br>- If the request is for a Redetermination, follow the instructions provided in the Appeals Process section of the CIF<br>- Refer to WI for further details.<br>- Inbound Calls - Document the call in the Notes section of the 360Member tab.",
    "Community Care of Oklahoma": "Alert: CVS Caremark does NOT process Redeterminations for this plan.<br>Guidance: Refer to CCOK Client specific job aid CCOK- Rejection 65 Job Aid- Med D CD&A TSRC-PROD-017657<br>Guidance:<br>- If the request is for a Redetermination, follow the instructions provided in the Appeals Process section of the CIF<br>- Refer to WI for further details.<br>- Inbound Calls - Document the call in the Notes section of the 360Member tab.",
    "EGWP": "Guidance:<br>- Refer to Handling EGWP Requests MHK",
    "Healthfirst": "Guidance: Client delegates Oncology regimens to eviCore-refer to Healthfirst Client Specific WI",
    "HMSA": "Alert: Restricted Client",
    // "KelseyCare": "Alert: Refer to KelseyCare Client Specific Work Instruction",
    "Neighborhood Health Plan Rhode Island": "Guidance: Refer to NHPRI Client specific job aid NHPRI - Med D CD&A TSRC-PROD-017645",
    "Pacific Source": "RESTRICTED CLIENT - Guidance: Refer to Client Specific Process for Pacific Source - Med D CD&A CMS-PRD1-078523",
    "Sharp Health Plan": "Alert: Refer to Sharp Client Specific Work Instruction",
    "Expedited": "Alert: Please Don't forget<br>- Please verify the expedited radio button has been populated in MHK",
    "Standard": "Alert: Please Don't forget<br>- If the fax contains a letter of medical necessity from the MDO, did you check the letter completely for priority indicators?<br> - If not, review for priority indicators prior to continuing.",
    // Disabling Drug related alert messages in the alert popup for enabling Drug Notes based on tblDrugNameNotes and logic in the alert popup.  The Drug Notes will be displayed in the alert popup when the drug is supported and has a note in the tblDrugNameNotes table.
    // "Drug Details": "Alert: For a compound medication Refer to: Processing Compound Cases - Med D CD&A",
    "ZOLPIDEM": "Potential smart edit medication",
    "HIV Drug": "Potential HIV PrEP medication - Refer to: APRETUDE, DESCOVY, & TRUVADA (emtricitabine and tenofovir disoproxil fumarate) - Med D CD&A",
    "rqstReasonNA": "Guidance: Refer to Classification of Case Type and Handling Multiple Requests",
    "Step Therapy": "Alert: Please Don't forget<br>- Step Therapy medications must be reviewed by a pharmacist. Forward to clinical for review.",
    "Tier Change": "Alert: Please Don't forget<br>- Tier change exceptions must be reviewed by a pharmacist. Forward to clinical for review.",
    "Hospice": "Guidance: Refer to Processing Hospice Requests MHK",
    "Case Decision/Routing Approved": "Guidance:<br>- Refer to Backdating Requests Job Aid and Duration of Approval for MHK work instructions<br>- If for an opioid (excluding buprenorphine products used for medication assisted treatment), and not for SilverScript PDP and Aetna MAPD/EGWP, confirm selection of 925 in reject message dropdown has been selected with any additional reject messages required",
    "Case Decision/Routing Denied": "Guidance:<br>- Refer to MHK Clinical Documentation Template<br>- Note: If denied case is for a Devoted Health dSNP plan refer to the Dual Special Needs Plan (dSNP) for Devoted Health Plan Work Instruction for further details.",
    "Case Decision/Routing Send To RFI": "Guidance:<br>- Refer to Pharmacist Exception RFI Verbiage",
    "Case Decision/Routing Send to MD": "Alert: Please Don't forget<br>- This should only be used for select medications that require Medical Director review and CDs that were denied by a Medical Director. If this is not the scenario, review the Case Decision/Routing drop down and select the appropriate option.",
    "Case Decision/Routing Transferred to Pharmacist": "Alert: Please Don't forget<br>- Only specific scenarios require transfer to pharmacist. Please validate against “Representatives: Handling Inbound Calls – Med D CD&A” Work Instruction before transferring.",
    "Manual": "Alert: Please Don't forget<br>- Verify the \"Manual Received\" field has been updated with the correct timestamp in MHK.<br/>- Ensure that the timestamp has been converted into Central Time, if needed.<br/>- Refer to Work Instruction Fax Time Stamp Job Aid and Timestamp Checklist."
};


module.exports = {
    alertMessages
};