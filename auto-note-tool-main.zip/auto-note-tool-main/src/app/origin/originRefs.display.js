import { toggleDisplay } from '../utils/notetool.display';

export default function toggleOriginRefs(r, o) {
  if (r === 'tech' && o === 'Queue') {
    toggleDisplay('solo', [`${r}Queuerefs`], 'enable');
    toggleDisplay('solo', [`${r}IBCrefs`, `${r}SRrefs`], 'disable');
  }
  if (r === 'tech' && o === 'IBC') {
    toggleDisplay('solo', [`${r}IBCrefs`], 'enable');
    toggleDisplay('solo', [`${r}SRrefs`, `${r}Queuerefs`], 'disable');
  }
  if (r === 'tech' && o === 'SR') {
    toggleDisplay('solo', [`${r}SRrefs`], 'enable');
    toggleDisplay('solo', [`${r}IBCrefs`, `${r}Queuerefs`], 'disable');
  }

  if (r === 'tech' && o === 'TAT') {
    toggleDisplay('solo', [`${r}IBCrefs`, `${r}Queuerefs`, `${r}SRrefs`], 'disable');
  }

  if (r === 'rph' && o === 'Queue') {
    toggleDisplay('solo', [`${r}Queuerefs`], 'enable');
    toggleDisplay('solo', [`${r}IBCrefs`], 'disable');
  }
  if (r === 'rph' && o === 'IBC') {
    toggleDisplay('solo', [`${r}IBCrefs`], 'enable');
    toggleDisplay('solo', [`${r}Queuerefs`], 'disable');
  }
  if (r === 'rph' && o === 'TAT') {
    toggleDisplay('solo', [`${r}IBCrefs`, `${r}Queuerefs`], 'disable');
  }
  toggleDisplay('solo', ['alertPopupBtn', 'alertPopup', `${r}${o}manualTemplateBtn`,`${r}${o}manualTemplateAboveTxt`], 'disable');
}
