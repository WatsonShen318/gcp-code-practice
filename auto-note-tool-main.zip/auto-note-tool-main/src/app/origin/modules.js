export const isQ = (answer) => {
  const output = answer === 'Queue';
  return output;
};
export const isIBC = (answer) => {
  const output = answer === 'IBC';
  return output;
};
export const isSR = (answer) => {
  const output = answer === 'SR';
  return output;
};
export const isTAT = (answer) => {
  const output = answer === 'TAT';
  return output;
};
