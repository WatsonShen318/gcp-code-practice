import { clearInputs } from '../utils/clearInput';

/**
 * * Clear all RM Task sub question input fields to be blank
 * @param {string} origin
 * @param {string} role
 */
export default function clearEAGquestions(origin, role) {
  const radioFields = document.getElementsByName(`${role}${origin}eagQrdo`);
  clearInputs(radioFields, 'radio');
}
