import { GeneralModal } from '../modal/alert.service';
import { bold } from '../utils/font.formatter';

export function msgAAFNRmsg(a) {
  if (a === 'Yes') {
    GeneralModal({
      message: bold(
        'Refer to test claims guidelines for additional instructions.'
      ),
      icon: 'notification_important',
    });
  }
}

export function msgAAFNRtr(a) {
  if (a === 'Yes') {
    GeneralModal({
      message: bold('This is a Tiering Case. Case must be created.'),
      icon: 'notification_important',
    });
  }
}

export function msgGPI(a) {
  if (a === 'No') {
    GeneralModal({
      message: bold('Review test claim guidelines.'),
      icon: 'notification_important',
    });
  }
}
