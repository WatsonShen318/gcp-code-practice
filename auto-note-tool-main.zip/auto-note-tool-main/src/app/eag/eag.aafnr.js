import { ShowSideNote } from '../buttons/buttons';
import { msgEAG, msgExpire, msgRx, msgTier } from './eag.dialogs';
import {
  toggleEAGExpire,
  toggleeagNoteBtn,
  toggleEAGrxClaim,
  toggleEAGtestClaim,
  toggleEAGtierRqst,
} from './eag.display';
import { clearEAGAAFNRs } from '../reset/reset';
import {
  toggleAAFNRgpi,
  toggleAAFNRmsg,
  toggleaafnrNoteBtn,
  toggleAAFNRtestClaim,
  toggleAAFNRtr,
} from './aafnr.display';
import { msgAAFNRmsg, msgAAFNRtr, msgGPI } from './aafnr.dialogs';
import {
  eag,
  subAAFNRCase,
  subAAFNRGpi,
  subAAFNRMsg,
  subAAFNRTestClaim,
  subAAFNRTierRequest,
  subEAGCase,
  subEAGExpire,
  subEAGRxClaim,
  subEAGTestClaim,
  subEAGTierRequest,
} from '../qsets/fields';
import { toggleEAGAAFNRsubQs } from './eagAafnr.display';

let answer = null;

export default function eagAAFNR(origin, role) {
  //* EAG Case?
  eag(role, origin, 'event').forEach((elem) => {
    elem.addEventListener('click', (e) => {
      const eagQ = `${role}${origin}eagQPA`;
      answer = e.target.value;
      clearEAGAAFNRs(eagQ, 'EAG');
      clearEAGAAFNRs(eagQ, 'AAFNR');
      toggleEAGAAFNRsubQs(origin, role, answer);
    });
  });

  //* EAG case check?
  subEAGCase(role, origin, 'event').forEach((elem) => {
    elem.addEventListener('click', (e) => {
      const eagCase = `${role}${origin}subeagCaseQPA`;
      answer = e.target.value;
      clearEAGAAFNRs(eagCase, 'EAG');
      msgEAG(answer);
      toggleEAGExpire(origin, role, answer);
    });
  });

  //* EAG expire in  100 days?
  subEAGExpire(role, origin, 'event').forEach((elem) => {
    elem.addEventListener('click', (e) => {
      const eagExpi = `${role}${origin}subeagExpireQPA`;
      answer = e.target.value;
      clearEAGAAFNRs(eagExpi, 'EAG');
      toggleEAGrxClaim(origin, role, answer, eagExpi);
      msgExpire(answer);
    });
  });

  //* EAG override in RX Claim?
  subEAGRxClaim(role, origin, 'event').forEach((elem) => {
    elem.addEventListener('click', (e) => {
      const eagRx = `${role}${origin}subeagRxClaimQPA`;
      answer = e.target.value;
      clearEAGAAFNRs(eagRx, 'EAG');
      toggleEAGtierRqst(origin, role, answer, eagRx);
      msgRx(answer);
    });
  });

  //* EAG Tier Request?
  subEAGTierRequest(role, origin, 'event').forEach((elem) => {
    elem.addEventListener('click', (e) => {
      const eagTR = `${role}${origin}subeagTierRqstQPA`;
      answer = e.target.value;
      clearEAGAAFNRs(eagTR, 'EAG');
      toggleEAGtestClaim(origin, role, answer, eagTR);
      msgTier(answer);
    });
  });

  //* EAG Test claim Guidelines?
  subEAGTestClaim(role, origin, 'event').addEventListener('change', (e) => {
    answer = e.target.value;
    toggleeagNoteBtn(origin, role, answer);
  });
  //* * Generate EAG Note */
  ShowSideNote(origin, role, 'EAG');

  //* AAFNR Case?
  subAAFNRCase(role, origin, 'event').forEach((elem) => {
    elem.addEventListener('click', (e) => {
      const aafnrCase = `${role}${origin}subaafnrCaseQPA`;
      answer = e.target.value;
      clearEAGAAFNRs(aafnrCase, 'AAFNR');
      toggleAAFNRmsg(origin, role, answer, aafnrCase);
    });
  });

  //* AAFNR transitional fill message?
  subAAFNRMsg(role, origin, 'event').forEach((elem) => {
    elem.addEventListener('click', (e) => {
      const aafnrfMsg = `${role}${origin}subaafnrMSGQPA`;
      answer = e.target.value;
      clearEAGAAFNRs(aafnrfMsg, 'AAFNR');
      toggleAAFNRtr(origin, role, answer, aafnrfMsg);
      msgAAFNRmsg(answer);
    });
  });

  //* AAFNR Tier Requst?
  subAAFNRTierRequest(role, origin, 'event').forEach((elem) => {
    elem.addEventListener('click', (e) => {
      const aafnrTR = `${role}${origin}subaafnrTierRqstQPA`;
      answer = e.target.value;
      clearEAGAAFNRs(aafnrTR, 'AAFNR');
      toggleAAFNRgpi(origin, role, answer, aafnrTR);
      msgAAFNRtr(answer);
    });
  });

  //* AAFNR GPI?
  subAAFNRGpi(role, origin, 'event').forEach((elem) => {
    elem.addEventListener('click', (e) => {
      const aafnrGPI = `${role}${origin}subaafnrGPIQPA`;
      answer = e.target.value;
      clearEAGAAFNRs(aafnrGPI, 'AAFNR');
      toggleAAFNRtestClaim(origin, role, answer, aafnrGPI);
      msgGPI(answer);
    });
  });

  //* AAFNR Test claim Guidelines?
  subAAFNRTestClaim(role, origin, 'event').addEventListener('change', (e) => {
    answer = e.target.value;
    toggleaafnrNoteBtn(origin, role, answer);
  });

  //* * Generate AAFNR Note */
  ShowSideNote(origin, role, 'AAFNR');
}
