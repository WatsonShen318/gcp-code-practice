import { GeneralModal } from '../modal/alert.service';
import { bold } from '../utils/font.formatter';

export function msgEAG(a) {
  if (a === 'No') {
    GeneralModal({
      message: bold('This is not an EAG. Case must be created.'),
      icon: 'notification_important',
    });
  }
}

export function msgExpire(a) {
  if (a === 'Yes') {
    GeneralModal({
      message: bold('This is not an EAG. Case must be created.'),
      icon: 'notification_important',
    });
  }
}

export function msgRx(a) {
  if (a === 'Yes') {
    GeneralModal({
      message: bold('This is not an EAG. Case must be created.'),
      icon: 'notification_important',
    });
  }
}

export function msgTier(a) {
  if (a === 'Yes') {
    GeneralModal({
      message: bold('This is a tiering case. Case must be created.'),
      icon: 'notification_important',
    });
  }
}
