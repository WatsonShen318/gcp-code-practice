import { isRequestReasonAutomated } from '../prefill/helpers';
import { toggleDisplay } from '../utils/notetool.display';

export const EAGs = (r, o) =>
  document.querySelectorAll(
    // `#${i} ~ fieldset[data-tag*='EAG']>fieldset[data-tag='EAG']`
    `div.tab-content>fieldset[id="${r}${o}"].active fieldset[data-tag='EAG']:not(#${r}${o}eagQ), #${r}${o}buttoneagbtn`
  );
export const AAFNRs = (r, o) =>
  document.querySelectorAll(
    // `#${i} ~ fieldset[data-tag*='AAFNR']>fieldset[data-tag='AAFNR']`
    `div.tab-content>fieldset[id="${r}${o}"].active fieldset[data-tag='AAFNR']:not(#${r}${o}eagQ), #${r}${o}buttonaafnrbtn`
  );

export const notesBelow = (r, o, status) => {
  toggleDisplay('rest', `#${r}${o}eagbtnPA`, status);
  toggleDisplay('solo', ['generateNotebtn'], status);

  // Skip enabling Request Reason Dropdown if Request Reason is already prefilled in Automated Flow
  if(status === 'enable' && isRequestReasonAutomated(r, o)) {
    toggleDisplay('button', [`${r}${o}rqstReasonQ`], 'disable');
  }
};

export function toggleEAGAAFNRsubQs(o, r, a) {
  if (a === 'EAG') {
    toggleDisplay('solo', [`${r}${o}subeagCaseQ`], 'enable');
    toggleDisplay('tag', AAFNRs(r, o), 'disable');
    notesBelow(r, o, 'disable');
  } else if (a === 'AAFNR') {
    toggleDisplay('solo', [`${r}${o}subaafnrCaseQ`], 'enable');
    toggleDisplay('tag', EAGs(r, o), 'disable');
    notesBelow(r, o, 'disable');
  } else {
    toggleDisplay('tag', EAGs(r, o), 'disable');
    toggleDisplay('tag', AAFNRs(r, o), 'disable');
    notesBelow(r, o, 'enable');
  }
}

/**
 * * Toggle EAG AAFNR question when Is request a RM Task = Yes is selected
 * @param {origin} origin
 * @param {role} role
 * @param {answer} answer
 */

export function toggleEAGAAFNRQs(origin, role, answer) {
  if (answer === 'No') {
    notesBelow(role, origin, 'enable');
    toggleDisplay('solo', [`${role}${origin}eagQ`], 'enable');
    toggleDisplay('tag', EAGs(role, origin), 'disable');
    toggleDisplay('tag', AAFNRs(role, origin), 'disable');
  } else {
    toggleDisplay('solo', [`${role}${origin}eagQ`], 'disable');
  }
}
