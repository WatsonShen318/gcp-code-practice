import { toggleDisplay } from '../utils/notetool.display';
import { AAFNRs, notesBelow } from './eagAafnr.display';

export function toggleAAFNRmsg(o, r, a) {
  if (a === 'Yes') {
    toggleDisplay('solo', [`${r}${o}subaafnrMSGQ`], 'enable');
    notesBelow(r, o, 'disable');
  } else {
    toggleDisplay('tag', AAFNRs(r, o), 'disable');
    notesBelow(r, o, 'enable');
  }
}

export function toggleAAFNRtr(o, r, a) {
  if (a === 'No') {
    toggleDisplay('solo', [`${r}${o}subaafnrTierRqstQ`], 'enable');
    notesBelow(r, o, 'disable');
  } else {
    toggleDisplay('tag', AAFNRs(r, o), 'disable');
    notesBelow(r, o, 'enable');
  }
}

export function toggleAAFNRgpi(o, r, a) {
  if (a === 'No') {
    toggleDisplay('solo', [`${r}${o}subaafnrGPIQ`], 'enable');
    notesBelow(r, o, 'disable');
  } else {
    toggleDisplay('tag', AAFNRs(r, o), 'disable');
    notesBelow(r, o, 'enable');
  }
}

export function toggleAAFNRtestClaim(o, r, a) {
  if (a === 'Yes') {
    toggleDisplay('solo', [`${r}${o}subaafnrTestClaimQ`], 'enable');
    notesBelow(r, o, 'disable');
  } else {
    toggleDisplay('tag', AAFNRs(r, o), 'disable');
    notesBelow(r, o, 'enable');
  }
}

export function toggleaafnrNoteBtn(o, r, a) {
  if (a !== '') {
    toggleDisplay('button', [`${r}${o}buttonaafnrbtn`], 'enable');
  } else {
    toggleDisplay('button', [`${r}${o}buttonaafnrbtn`], 'disable');
  }
}
