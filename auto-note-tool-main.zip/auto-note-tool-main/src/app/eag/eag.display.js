import { toggleDisplay } from '../utils/notetool.display';
import { EAGs, notesBelow } from './eagAafnr.display';

export function toggleEAGExpire(o, r, a) {
  if (a === 'Yes') {
    toggleDisplay('solo', [`${r}${o}subeagExpireQ`], 'enable');
    notesBelow(r, o, 'disable');
  } else {
    toggleDisplay('tag', EAGs(r, o), 'disable');
    notesBelow(r, o, 'enable');
  }
}

export function toggleEAGrxClaim(o, r, a) {
  if (a === 'No') {
    toggleDisplay('solo', [`${r}${o}subeagRxClaimQ`], 'enable');
    notesBelow(r, o, 'disable');
  } else {
    toggleDisplay('tag', EAGs(r, o), 'disable');
    notesBelow(r, o, 'enable');
  }
}

export function toggleEAGtierRqst(o, r, a) {
  if (a === 'No') {
    toggleDisplay('solo', [`${r}${o}subeagTierRqstQ`], 'enable');
    notesBelow(r, o, 'disable');
  } else {
    toggleDisplay('tag', EAGs(r, o), 'disable');
    notesBelow(r, o, 'enable');
  }
}

export function toggleEAGtestClaim(o, r, a) {
  if (a === 'No') {
    toggleDisplay('solo', [`${r}${o}subeagTestClaimQ`], 'enable');
    notesBelow(r, o, 'disable');
  } else {
    toggleDisplay('tag', EAGs(r, o), 'disable');
    notesBelow(r, o, 'enable');
  }
}

export function toggleeagNoteBtn(o, r, a) {
  if (a !== '') {
    toggleDisplay('button', [`${r}${o}buttoneagbtn`], 'enable');
  } else {
    toggleDisplay('button', [`${r}${o}buttoneagbtn`], 'disable');
  }
}
