import { automateDLTGuidelines } from "../../dlt_guidelines/automation";
import toggleDrugNameWSearchQ from "../../dlt_guidelines/display";
import getDrugList from "../../dlt_guidelines/data_sources/getDrugList";
import { currentProfile } from "../../user/user.data";
import { resetDLTGuideline } from "../../utils/automation";

export class SearchableSelect {
    constructor(container, options = {}) {
        this.container = container;
        this.fieldId = container.getAttribute('data-field-id');
        this.input = document.getElementById(this.fieldId + 'input');
        this.dropdown = document.getElementById(this.fieldId + 'dropdown');
        this.resultsContainer = document.getElementById(this.fieldId + 'results');
        this.loadingMsg = document.getElementById(this.fieldId + 'loading');
        this.noResultsMsg = document.getElementById(this.fieldId + 'noresults');
        this.minCharsMsg = document.getElementById(this.fieldId + 'minchars');

        // Configuration options
        // This can be extended to include API endpoints or helper methods to fetch data from different APIs
        this.options = {
            apiType: 'drug', // Default API type
            minSearchLength: 3,
            searchDelay: 300,
            mapResult: null, // Custom result mapping function
            ...options
        };

        this.searchTimeout = null;
        this.currentQuery = '';
        this.isOpen = false;
        this.selectedValue = '';
        this.selectedLabel = '';
        this._abortController = new AbortController();

        this.init();
    }

    init() {
        const signal = this._abortController.signal;

        // Show dropdown on focus
        this.input.addEventListener('focus', () => {
            this.showDropdown();
        }, { signal });

        // Show dropdown on click
        this.input.addEventListener('click', () => {
            this.showDropdown();
        }, { signal });

        // Handle input changes
        this.input.addEventListener('input', (e) => {
            const query = e.target.value.trim();

            // If user types something different than selected, clear selection
            if (e.target.value !== this.selectedLabel) {
                this.clearSelection();
            }

            this.handleSearch(query);
        }, { signal });

        // Handle option clicks
        this.resultsContainer.addEventListener('click', (e) => {
            const option = e.target.closest('.search-option');
            if (option && !option.classList.contains('loading-message') &&
                !option.classList.contains('no-results-message') &&
                !option.classList.contains('min-chars-message')) {
                this.selectOption(option);
            }
        }, { signal });

        // Close dropdown when clicking outside
        document.addEventListener('click', (e) => {
            if (!this.container.contains(e.target)) {
                this.hideDropdown();
            }
        }, { signal });

        // Handle keyboard navigation
        this.input.addEventListener('keydown', (e) => {
            if (!this.isOpen) {
                if (e.key === 'ArrowDown' || e.key === 'Enter') {
                    e.preventDefault();
                    this.showDropdown();
                    return;
                }
            }

            const options = this.container.querySelectorAll('.search-option:not([style*="display: none"]):not(.loading-message):not(.no-results-message):not(.min-chars-message)');
            const highlighted = this.container.querySelector('.search-option.highlighted');

            switch (e.key) {
                case 'ArrowDown':
                    e.preventDefault();
                    this.navigateOptions(options, highlighted, 'down');
                    break;
                case 'ArrowUp':
                    e.preventDefault();
                    this.navigateOptions(options, highlighted, 'up');
                    break;
                case 'Enter':
                    e.preventDefault();
                    if (highlighted && this.isOpen) {
                        this.selectOption(highlighted);
                    }
                    break;
                case 'Escape':
                    e.preventDefault();
                    this.hideDropdown();
                    break;
            }
        }, { signal });
    }

    showDropdown() {
        this.isOpen = true;
        this.container.classList.add('show');
        this.dropdown.style.display = 'block';

        const query = this.input.value.trim();
        if (query.length === 0) {
            this.showMinCharsMessage();
            this.showAllStaticOptions();
        } else {
            this.handleSearch(query);
        }
    }

    hideDropdown() {
        this.isOpen = false;
        this.container.classList.remove('show');
        this.dropdown.style.display = 'none';
        this.clearHighlight();
    }

    handleSearch(query) {
        clearTimeout(this.searchTimeout);
        // Mark any in-flight response for the previous query as stale
        this.currentQuery = query;

        if (query.length === 0) {
            this.showMinCharsMessage();
            this.showAllStaticOptions();
            return;
        }

        if (query.length < 3) {
            this.filterStaticOptions(query);
            this.showMinCharsMessage();
            return;
        }

        this.showLoading();

        this.searchTimeout = setTimeout(() => {
            this.performSearch(query);
        }, this.options.searchDelay);
    }

    filterStaticOptions(query) {
        const staticOptions = this.container.querySelectorAll('.search-option[data-value]:not(.dynamic)');
        let hasVisible = false;

        staticOptions.forEach(option => {
            const text = option.textContent.toLowerCase();
            if (text.includes(query.toLowerCase())) {
                option.style.display = 'block';
                hasVisible = true;
            } else {
                option.style.display = 'none';
            }
        });

        if (!hasVisible && query.length >= 3) {
            // this.showNoResults();
        } else {
            this.hideNoResults();
        }
    }

    showAllStaticOptions() {
        const staticOptions = this.container.querySelectorAll('.search-option[data-value]:not(.dynamic)');
        staticOptions.forEach(option => {
            option.style.display = 'block';
        });
        this.hideNoResults();
    }

    performSearch(query) {
        this.filterStaticOptions(query);

        const apiMethod = this.getApiMethod();

        if (apiMethod) {
            apiMethod(query).then(resultSet => {
                // Ignore responses that arrived after the user changed their query
                if (query !== this.currentQuery) return;

                this.hideLoading();

                if (resultSet) {
                    const mapper = resultMapper(this.options.apiType);
                    let results = resultSet.map(mapper);
                    results = [...results, { value: 'Other', label: 'Other' }];
                    this.addDynamicOptions(results);
                } else {
                    this.showNoResults();
                }
            }).catch(error => {
                if (query !== this.currentQuery) return;
                console.error('Search API error:', error);
                this.hideLoading();
                this.showNoResults();
            });
        } else {
            console.warn('No API method found for type:', this.options.apiType);
            this.hideLoading();
            this.showNoResults();
        }
    }

    getApiMethod() {
        switch (this.options.apiType) {
            case 'drug':
                return getDrugList;
            // Add more API methods as needed
            default:
                return this.options.searchFunction; // Allow custom search function - currently this is not supported by can be added as more use-cases come in for searchable select
        }
    }

    addDynamicOptions(results) {
        this.container.querySelectorAll('.search-option.dynamic').forEach(el => el.remove());

        results.forEach((result, index) => {
            const option = document.createElement('div');
            option.className = 'search-option dynamic';
            option.setAttribute('data-value', result.value);
            option.setAttribute('id', this.fieldId + 'dyn' + index);
            option.textContent = result.label;

            this.resultsContainer.insertBefore(option, this.loadingMsg);
        });

        if (results.length === 0 && this.container.querySelectorAll('.search-option[data-value]:not([style*="display: none"]):not(.dynamic)').length === 0) {
            this.showNoResults();
        } else {
            this.hideNoResults();
        }
    }

    selectOption(option) {
        const value = option.getAttribute('data-value');
        const label = option.textContent.trim();

        this.selectedValue = value;
        this.selectedLabel = label;
        this.input.value = label;

        // Clear previous selection
        this.container.querySelectorAll('.search-option').forEach(opt => {
            opt.classList.remove('selected');
        });

        option.classList.add('selected');

        // Call API-specific method when option is selected
        this.handleOptionSelection(value, label);

        // Trigger custom event for form handling
        this.input.dispatchEvent(new CustomEvent('optionSelected', {
            bubbles: true,
            detail: { value, label }
        }));

        this.hideDropdown();
    }

    // Method to handle API-specific selection logic
    handleOptionSelection(value, label) {
        switch (this.options.apiType) {
            case 'drug':
                this.handleDrugSelection(value, label);
                break;
            // Add more cases as needed for other API types going forward
            default:
                break;
        }
    }

    // [apiType: drug]This method is specific to drug selection
    handleDrugSelection(value, label) {
        console.log('Drug selected:', { value, label });

        const userProfile = currentProfile();
        const role = userProfile.role;
        const origin = userProfile.origin;

        // Updating original drug name field based on selection
        const drugNameText = document.getElementById(
            `${role}${origin}drugNameQtxt`
        );
        if(label === 'Other'){
            drugNameText.value = '';
        } else if(label){
            drugNameText.value = label;
        }

        // Logic to automate DLT Guideline if gpi is missed from MHK based on selected drug by user
        const originalMedhokResponse = JSON.parse(sessionStorage.getItem("originalMedhokResponse"));
        const gpiSelected = value;
        sessionStorage.setItem("gpiSelectedWDrugNameSearch", gpiSelected || '');
        if(gpiSelected === 'Other' || !gpiSelected){
            if (role === 'tech') {
                resetDLTGuideline(origin, role);
                console.log("Resetting DLT Guideline for", role, origin);
            }
            // Hide search field, show plain-text drug name field for manual entry
            toggleDrugNameWSearchQ(role, origin, 'disable');
        }

        // DLT Guideline automation is tech-only
        if (role === 'tech') {
            // Read the current UI request reason so that if the user has already selected
            // "Quantity Limit" (or similar) before re-selecting the drug, the QL guideline
            // path is honoured instead of falling through to the NF path from the GPI lookup.
            const uiRR = document.getElementById(`${role}${origin}rqstReasonQsel`)?.value?.trim() || '';
            const updatedMedhokeResponse = {
                ...originalMedhokResponse,
                gpiCode: gpiSelected,
                ...(uiRR && { requestReason: uiRR }),
            };
            automateDLTGuidelines(role, origin, updatedMedhokeResponse, gpiSelected);
        }

        // Notify manual-flow subscribers (formAlts, QL) on every drug selection change.
        // gpi: null signals "Other" so subscribers can clear drug-dependent state (Q251, QL results).
        this.container.dispatchEvent(new CustomEvent('drugSelected', {
            bubbles: true,
            detail: { gpi: (gpiSelected && gpiSelected !== 'Other') ? gpiSelected : null, drugName: label },
        }));
    }

    clearSelection() {
        this.selectedValue = '';
        this.selectedLabel = '';

        this.container.querySelectorAll('.search-option').forEach(opt => {
            opt.classList.remove('selected');
        });
    }

    reset() {
        this.input.value = '';
        this.selectedValue = '';
        this.selectedLabel = '';
        this.currentQuery = '';
        this.container.querySelectorAll('.search-option.dynamic').forEach(el => el.remove());
        this.hideDropdown();
    }

    destroy() {
        this._abortController.abort();
        this.container.querySelectorAll('.search-option.dynamic').forEach(el => el.remove());
        this.hideDropdown();
    }

    navigateOptions(options, highlighted, direction) {
        if (options.length === 0) return;

        this.clearHighlight();

        let index = -1;
        if (highlighted) {
            index = Array.from(options).indexOf(highlighted);
        }

        if (direction === 'down') {
            index = index < options.length - 1 ? index + 1 : 0;
        } else {
            index = index > 0 ? index - 1 : options.length - 1;
        }

        if (options[index]) {
            options[index].classList.add('highlighted');
            options[index].scrollIntoView({ block: 'nearest' });
        }
    }

    clearHighlight() {
        this.container.querySelectorAll('.search-option').forEach(opt => {
            opt.classList.remove('highlighted');
        });
    }

    showLoading() {
        this.hideMessages();
        this.loadingMsg.style.display = 'block';
    }

    hideLoading() {
        this.loadingMsg.style.display = 'none';
    }

    showNoResults() {
        this.hideMessages();
        this.noResultsMsg.style.display = 'block';
    }

    hideNoResults() {
        this.noResultsMsg.style.display = 'none';
    }

    showMinCharsMessage() {
        this.hideMessages();
        this.minCharsMsg.style.display = 'block';
    }

    hideMessages() {
        this.loadingMsg.style.display = 'none';
        this.noResultsMsg.style.display = 'none';
        this.minCharsMsg.style.display = 'none';
    }
}

const resultMapper = (apiType) => {
    switch (apiType) {
        case 'drug':
            return (result) => ({
                value: result.gpi,
                label: result.drug_name
            });
        // Add more cases as needed - currently only drug is implemented but this can be extended if more use-cases arise with searchable select
        default:
            return (result) => result;
    }
}

const _instanceMap = new Map();

/* Initialize (or re-initialize) the searchable select for a specific role+origin.
   Called from manualFormTemplate each time the origin form opens, so each session
   starts with a clean instance — no stale search results or prior selection. */
export const initSearchableSelectForOrigin = (role, origin) => {
    const wrapper = document.getElementById(`${role}${origin}drugNameWSearchQ`);
    if (!wrapper) return;
    const searchContainer = wrapper.querySelector('.searchable-select');
    if (!searchContainer) return;

    _instanceMap.get(searchContainer)?.destroy();
    _instanceMap.set(searchContainer, new SearchableSelect(searchContainer));
};