import { getToday } from '../utils/calculateDates';
import * as c from '../utils/clearInput';
import { letterPreview } from '../qsets/fields';
import { toggleDisplay } from '../utils/notetool.display';
import * as origins from '../origin/modules';

/**
 * Clear sub questions for REquested By when answer changes
 * @param {*} o User origin
 * @param {*} r User role
 */
export function clearRqstBy(o, r) {
  if (origins.isQ(o)) {
    c.clearInput('radio', [`${r}${o}subAorOnFileQrdo`]);
    c.clearInput('text', [`${r}${o}subAorOnFileDocQtxt`]);
  }
  if (origins.isIBC(o)) {
    const techfield = r === 'tech' ? `${r}${o}subrqstByCallerQrdo` : '';
    c.clearInput(
      'radio',
      [
        `${r}${o}subrqstByAORmemberQrdo`,
        `${r}${o}subAorOnFileQrdo`,
        techfield,
      ].filter(Boolean)
    );
    c.clearInput('text', [
      `${r}${o}subrqstInfoQtxt`,
      `${r}${o}subAorOnFileDocQtxt`,
      `${r}${o}subMemberWaorQtxt`,
    ]);
  }
}

export function clearRejects(o, r) {
  const claims = document.querySelectorAll(
    `[data-tag="claim"][id*="${r}${o}"] input`
  );
  claims.forEach((g) => {
    if (g.type === 'text') {
      c.clearInput('text', [g.id]);
    }
    if (g.type === 'radio') {
      c.clearInput('radio', [g.name]);
    }
  });
  // $ put default value back in for today's date
  document.getElementById(`${r}${o}subclaimTodayDQtxt`).value = getToday();
}

export function clearTodayRefill(o, r) {
  toggleDisplay('solo', [`${r}${o}subclaimTodayCodeQ`], 'disable');
  c.clearInput('radio', [`${r}${o}subclaimTodayRefillQrdo`]);
}

export function clearRjcode90Ds(o, r) {
  c.clearInput('radio', [`${r}${o}claim90dQrdo`]);
  const rejectCodes = JSON.parse(sessionStorage.getItem('eslRsp') || '{}')?.rejectCodes;
  // Skip clearing reject codes if it's prefilled
  if(!rejectCodes) {
    c.clearInput('text', [`${r}${o}subclaimTodayCodeQtxt`]);
  }
}

//AMN 5/16/23 - May 2023 Enhancements - #125: Add red note for drug name field
export function clearDrugs(o, r) {
  c.clearInput('text', [`${r}${o}drugNameQtxt`]);
  toggleDisplay('solo', [`${r}${o}drugHUP`], 'disable');
  toggleDisplay('solo', [`${r}${o}drugHUP_MedHOK`], 'disable');
  toggleDisplay('solo', [`${r}${o}drugSpecial`], 'disable');
  toggleDisplay('solo', [`${r}${o}drugHIV`], 'disable');
}

export function clearToll(o, r) {
  c.clearInput('radio', [`${r}${o}subspprSatementQrdo`]);
}

export function clearEAGAAFNRs(v, t) {
  const rdos = document.querySelectorAll(
    `#${v} ~ fieldset[data-tag*=${t}] > fieldset[data-tag*=${t}]>div>div>input[type="radio"]`
  );
  const txts = document.querySelectorAll(
    `#${v} ~ fieldset[data-tag*=${t}] > fieldset[data-tag*=${t}]>div>div>input[type="text"]`
  );
  c.clearInputs(rdos, 'radio');
  c.clearInputs(txts, 'text');
}

export function clearDLTrdo(o, r) {
  if (origins.isIBC(o)) {
    c.clearInput('radio', [`${r}${o}approveDiagoQrdo`]);
  }
}

export function clearMember(o, r) {
  const chcks = document.querySelectorAll(
    `#${r}${o}memberidsQ > div > input[type="checkbox"]`
  );
  c.clearInputs(chcks, 'check');
}

export function clearValidatedMember(o, r) {
  c.clearInput('radio', [`${r}${o}validatedMemberQrdo`]);
}

export function clearGuidelines(o, r) {
  c.clearInput('select', [`${r}${o}guidelineQsel`]);
}

export function clearDecision(o, r) {
  c.clearInput('select', [`${r}${o}routingQsel`]);
}

export function clearMatchCase(o, r) {
  c.clearInput('radio', [`${r}${o}matchCaseQrdo`]);
}
export function clearTierCaseCreate(o, r) {
  c.clearInput('radio', [`${r}${o}subtierRqstQrdo`]);
}

export function clearRest(id) {
  let i;
  const parent = document.getElementById(id).parentElement.parentElement.id;
  const QNum = document.querySelectorAll(
    `#${parent} ~ div>fieldset>input[type="radio"][name*=Number]:checked`
  );
  const QnumLen = QNum.length;

  for (i = 0; i < QnumLen; i += 1) {
    if (QNum[i].checked) document.getElementById(QNum[i].id).checked = false;
  }
}

export function clearMDReview(o, r) {
  c.clearInput('radio', [`${r}${o}mdReviewQrdo`]);
}

export function clearNewMDInfo(o, r) {
  c.clearInput('radio', [`${r}${o}mdNewInfoQ`]);
}

export function clearLetterPreview(o, r) {
  c.clearInput('radio', [letterPreview(r, o, 'field')]);
}

/* Helper to reset origin labels */
export function resetOriginLabels(role, origin) {
  const allOriginLabels = ['techoriginQQueue', 'techoriginQSR', 'techoriginQTAT', 'techoriginQIBC', 'rphoriginQQueue', 'rphoriginQTAT', 'rphoriginQIBC'];
  allOriginLabels.forEach(labelId => {
    const originLabel = document.querySelector(`label[for="${labelId}"]`);
    if (originLabel) {
      if(labelId === `${role}originQ${origin}`) {
        originLabel.style.backgroundColor = '#c00';
        originLabel.style.color = 'rgba(255, 255, 255, 1)';
        originLabel.classList.add('active');
      } else {
        originLabel.style.backgroundColor = 'rgba(255, 255, 255, 1)';
        originLabel.style.color = '#c00';
        originLabel.classList.remove('active');
      }
    }
  });
}
