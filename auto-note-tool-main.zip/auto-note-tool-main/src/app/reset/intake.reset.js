import { AlertService } from '../modal/alert.service';
import { clearInput } from '../utils/clearInput';
import resetNote from './notetool.reset';
import { toggleDisplay } from '../utils/notetool.display';

const notetool = document.getElementById('notetool');

export function ClearPriorityDetails() {
  clearInput('text', ['subiExpQIndtxt', 'subiExpQPgtxt']);
}

export function ClearTierRqst() {
  clearInput('radio', ['iTierRqstQrdo']); // TierRequest
}

export function ClearMemPplSafe() {
  clearInput('radio', ['imempplsafeQrdo']); // MemberPplSafeRdo
}

export function ClearRqstType() {
  clearInput('radio', ['iRqstTypeQrdo']); // RequestType
}

function ClearRTReRrouteRation() {
  clearInput('select', ['iReRouteRatQsel']); // ReRouting the fax to drop down
}

export function ClearByRqstType(RequestType) {
  const RqstTypeSecondaryRational = 'iRTsecondRationQlt';
  const DrugName = document.getElementById('iDrugNameQtxt');
  const MultiMemberRdo = 'iMultiMemberQrdo';
  const subMultiMemRdo = 'subiMultiMemberQrdo';
  const MultiRqstRdo = 'iMultirqstQrdo';
  const Priority = 'iPriorityQrdo';

  ClearRTReRrouteRation();
  clearInput('textarea', [RqstTypeSecondaryRational]);

  if (RequestType === 'Forward Fax' || RequestType === 'Re-route') {
    clearInput('radio', [
      MultiMemberRdo,
      MultiRqstRdo,
      Priority,
      subMultiMemRdo,
    ]);
    toggleDisplay('solo', ['subiMultiMemberQ'], 'disable'); // hide Multi Member Sub Q Section
    ClearTierRqst();
    DrugName.value = 'n/a';
  } else if (RequestType === 'Secondary Review') {
    clearInput('radio', [MultiMemberRdo, MultiRqstRdo, subMultiMemRdo]);
    clearInput('text', ['iDrugNameQtxt']);
    ClearTierRqst();
    toggleDisplay('solo', ['subiMultiMemberQ'], 'disable'); // hide Multi Member Sub Q Section
  } else {
    clearInput('text', ['iDrugNameQtxt']);
  }
}

function clearFieldsNextBtn() {
  const ForwardFaxTo = document.getElementById('iRtFFaxQwheretxt');
  const drugName = document.getElementById('iDrugNameQtxt');
  const FinalVerifyChecks = document.querySelectorAll("[id*='iFverifyQ']");
  // * clear all secondary member details fields
  ClearRTReRrouteRation();
  // * clear enter where you are forwarding the fax to
  ForwardFaxTo.value = '';
  // * clear drug name text
  drugName.value = '';
  // *  Clear does the fax indicate this a compound & clear multiple request reason radio buttons
  clearInput('radio', ['subiDrugNameCompQrdo', 'subiRqstReasonQrdo']);
  // * clear final verification checkboxes
  FinalVerifyChecks.forEach(
    (FinalVerifyChecks) => (FinalVerifyChecks.checked = false)
  );
}

export function resetNoteCreateNextbtn() {
  notetool.classList.remove('was-validated');
  clearFieldsNextBtn();

  document.getElementById('pills-tabContent').style.display = 'block';
  document.getElementById('finalNoteDiv').style.display = 'none';
  document.getElementById('finalNoteReminder').style.display = 'none';
  document.getElementById('intakeNextCasebtn').style.display = 'none';
  document.getElementById('generateNotebtn').style.display = 'block';

  // & go back to the top of the page
  window.scrollTo(0, 0);
  // AlertService('reset');
}
