/* eslint-disable no-return-assign */
import { AlertService } from '../modal/alert.service';
import { catputreAnswers, carryOvers } from '../multiCase/automation';
import { destoryClones } from '../outbound/clone';
import { currentProfile } from '../user/user.data';
import { HideAll, toggleDisplay } from '../utils/notetool.display';

/**
 * *Fire functions and take actions, when reset function is ran at the window level
 */
export default function resetNote() {
  const notetool = document.getElementById('notetool');
  const preQrdos = document.querySelectorAll(
    'div.nav[role="tablist"]>label.active'
  );
  const originSection = document.querySelectorAll(
    'div[id*=origin] ~ div.tab-content>fieldset.active.show'
  );
  const disabledPA = document.querySelectorAll(
    'div[id*=origin] ~ div.tab-content>fieldset.active.show > fieldset[id*=PA][disabled], div[id*=origin] ~ div.tab-content>fieldset.active.show > fieldset[id*=PA][style*="display: none;"]'
  );

  disabledPA.forEach((d) => (d.disabled = false));
  disabledPA.forEach((d) => (d.style.display = 'block'));
  destoryClones();
  preQrdos.forEach((p) => p.classList.remove('active'));
  originSection.forEach((s) => s.classList.remove('active', 'show'));

  notetool.reset();
  notetool.classList.remove('was-validated');
  sessionStorage.removeItem('indicationBasedApprovableDiagnosis');

  HideAll();
  // Remove dynamically injected plan-ql-ref elements (not part of the form, not cleared by HideAll)
  document.querySelectorAll('.plan-ql-ref').forEach(el => el.remove());
  document.querySelectorAll('[id$="drugNameWSearchNoteQ"], [id$="drugPickerNoteQ"]').forEach(el => {
    el.style.display = 'none';
    const textDiv = el.querySelector('.d-flex > div:last-child');
    if (textDiv) textDiv.innerHTML = '';
  });
  document.getElementById('alertPopupBody')?.querySelector('.ant-drug-note-alert')?.remove();
  document.getElementById('pills-tabContent').style.display = 'block';
  document.getElementById('finalNoteDiv').style.display = 'none';
  document.getElementById('finalNoteReminder').style.display = 'none';

  // & go back to the top of the page
  window.scrollTo(0, 0);
}

window.addEventListener('reset', resetNote);

/**
 * * Fire functions when Reset Button is clicked.
 */
document.getElementById('Resetbtn').addEventListener('click', () => {
  const profile = currentProfile();
  const multiCaseCount = document.getElementById(
    `${profile.role}${profile.origin}submemberCaseCountQhidden`
  );
  resetNote();
  if (profile.role !== 'intake' && multiCaseCount) multiCaseCount.value = '';
  AlertService('reset');
  toggleDisplay('solo', ['alertPopupBtn', 'alertPopup', `${profile.role}${profile.origin}manualTemplateBtn`,`${profile.role}${profile.origin}manualTemplateAboveTxt`], 'disable');
});

/**
 * * This function is used for IBC and Case Queue origins only for Tech and RPh
 */
export function resetByCreateNextbtn(origin, role) {
  const notetool = document.getElementById('notetool');

  const originSel = document.querySelector(
    `label[aria-controls="${role}${origin}"][for=${role}originQ${origin}]`
  );
  const previousVals = catputreAnswers(origin, role);

  notetool.classList.remove('was-validated');
  notetool.reset();

  originSel.click();
  carryOvers(previousVals);

  document.getElementById('pills-tabContent').style.display = 'block';
  document.getElementById('finalNoteDiv').style.display = 'none';
  document.getElementById('finalNoteReminder').style.display = 'none';
  document.getElementById(`${role}${origin}moreBtn`).style.display = 'none';
  document.getElementById('generateNotebtn').style.display = 'block';

  // * go back to the top of the page
  window.scrollTo(0, 0);
  // * AlertService('reset');
}
