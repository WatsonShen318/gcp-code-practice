import { GeneralModal } from '../modal/alert.service';
import { bold } from '../utils/font.formatter';

export default function msgCareAgentAuthen(a) {
  if (a === 'Yes') {
    GeneralModal({
      message: bold('Ask CARE agent if caller was authenticated'),
      icon: 'notification_important',
    });
  }
}
