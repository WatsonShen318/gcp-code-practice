import { toggleDisplay } from '../utils/notetool.display';

export default function CAREagentDetail(o, r, a) {
  if (a === 'Yes') {
    toggleDisplay('solo', [`${r}${o}subcareAgentQ`], 'enable');
  } else {
    toggleDisplay('solo', [`${r}${o}subcareAgentQ`], 'disable');
  }
}
