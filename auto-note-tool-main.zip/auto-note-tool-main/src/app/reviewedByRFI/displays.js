import { additionalOutboundCallNeeded } from '../qsets/fields';
import { toggleDisplay } from '../utils/notetool.display';

/* Toggle Sub Questions for case reviewed by RFI TAT */
export default function toggleSubQuestionsForRFITATCaseReviewed(o, r, a) {
  const additionalOutboundCallValue = additionalOutboundCallNeeded(r, o, "value");
  if(a == 'Yes') {
    toggleDisplay('solo', [`${r}${o}subRFIButtonPopulatedQ`, `${r}${o}addInfoCheckQ`, `${r}${o}subAdditionalOutBoundCallQ`, `${r}${o}rfi`], 'enable');
    toggleDisplay('solo', [`${r}${o}rfi`, `${r}${o}outboundQ`], 'disable');

    /* Covering edge case when additional obc call needed selected yes and then toggle happened for RFI TAT Case reviewed field */
    if(additionalOutboundCallValue === 'Yes') {
      toggleDisplay('solo', [`${r}${o}outboundQalt`], 'enable');
    } else {
      toggleDisplay('solo', [`${r}${o}outboundQalt`], 'disable');
    }
  } else {
    toggleDisplay('solo', [`${r}${o}subRFIButtonPopulatedQ`, `${r}${o}addInfoCheckQ`, `${r}${o}subAdditionalOutBoundCallQ`, `${r}${o}outboundQalt`], 'disable');
    toggleDisplay('solo', [`${r}${o}rfi`, `${r}${o}outboundQ`], 'enable');
  }
}