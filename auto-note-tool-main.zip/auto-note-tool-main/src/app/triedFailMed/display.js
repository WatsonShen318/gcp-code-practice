import { toggleDisplay } from '../utils/notetool.display';

export default function toggleTFMed(o, r, a) {
  if (r === 'tech') {
    const status = a?.toLowerCase() === 'non-formulary' ? 'enable' : 'disable';
    toggleDisplay('solo', [`${r}${o}treidFailQ`], status);
  }
}
