import getInputValue from '../utils/getInputValue';
import { toggleDisplay } from '../utils/notetool.display';

export function toggleTCaseCreate(o, r, a) {
  if (a === 'Yes') {
    toggleDisplay('solo', [`${r}${o}subtierRqstQ`], 'enable');
  } else {
    toggleDisplay('solo', [`${r}${o}subtierRqstQ`], 'disable');
  }
}

export function toggleApprovedTier(o, r) {
  const input = getInputValue('text', [
    `${r}${o}routingQsel`,
    `${r}${o}rqstReasonQsel`,
  ]);
  const requestReason = input[`${r}${o}rqstReasonQsel`];
  const decision = input[`${r}${o}routingQsel`];

  if (decision === 'Approved' && requestReason === 'Tier Change') {
    toggleDisplay('solo', [`${r}${o}subapprovedTierQ`], 'enable');
  } else {
    toggleDisplay('solo', [`${r}${o}subapprovedTierQ`], 'disable');
  }
}

export function toggleCurrentTier(o, r, a) {
  const status = a === 'Tier Change' ? 'enable' : 'disable';
  toggleDisplay('solo', [`${r}${o}currentTierQ`], status);
}
