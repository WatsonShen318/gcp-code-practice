import { GeneralModal } from '../modal/alert.service';
import { bold } from '../utils/font.formatter';

export default function msgTierCaseCreate(a) {
  if (a === 'Yes') {
    GeneralModal({
      message: bold(
        'Document indication for Tiering Request in Decision/Routing Rationale'
      ),
      icon: 'notification_important',
    });
  } else {
    GeneralModal({
      message: bold(
        'Document indication for Tiering Request in Decision/Routing Rationale'
      ),
      icon: 'notification_important',
    });
  }
}
