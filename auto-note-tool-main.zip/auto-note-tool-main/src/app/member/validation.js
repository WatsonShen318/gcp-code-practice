export default function validateChecks(o, r) {
  const all = document.querySelectorAll(
    `input[id*=${r}${o}memberidsQ][type="checkbox"]`
  );
  const checked = document.querySelectorAll(
    `input[id*=${r}${o}memberidsQ][type="checkbox"]:checked`
  );
  const notChecked = document.querySelectorAll(
    `input[id*=${r}${o}memberidsQ][type="checkbox"]:not(:checked)`
  );
  const ePA = document.getElementById(`${r}${o}memberidsQePAchb`).checked;
  const care = document.getElementById(
    `${r}${o}memberidsQCAREAgentchb`
  ).checked;
  const inbound = document.getElementById(
    `${r}${o}memberidsQInboundcallchb`
  ).checked;

  if (ePA || care || inbound) {
    notChecked.forEach((c) => c.removeAttribute('required'));
  } else if ((!ePA || !care || !inbound) && checked.length < 3) {
    all.forEach((c) => c.setAttribute('required', ''));
  } else {
    notChecked.forEach((c) => c.removeAttribute('required'));
  }
}
