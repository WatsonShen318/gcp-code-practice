import { toggleDisplay } from '../utils/notetool.display';

export function toggleMemberChecks(o, r) {
  if (r === 'tech' || (r === 'rph' && o === 'IBC')) {
    toggleDisplay('solo', [`${r}${o}Inboundcall`], 'disable');
  }

  if (o === 'Queue' || o === 'SR') {
    toggleDisplay('solo', [`${r}${o}CAREAgent`], 'disable');
  }
}

//AMN 12/8/22 - December 2022 Enhancement - #113: Intake Update for BCBS of MASS
export function toggleAllMemeberChecks(o, r, a) {
  switch (a) {
    case 'black text':
    case 'BCBS of MASS': 
    case 'MA':
      toggleDisplay('solo', [`${r}${o}memberidsQ`], 'disable');
      toggleDisplay('solo', [`${r}${o}validatedMemberQ`], 'enable');
      break;
    default:
      toggleDisplay('solo', [`${r}${o}memberidsQ`], 'disable');
      toggleDisplay('solo', [`${r}${o}validatedMemberQ`], 'disable');
      break;
  }
}

export function initHideMember(o, r) {
  switch (o) {
    case 'SR':
      toggleDisplay('solo', [`${r}${o}memberidsQ`], 'disable');
      toggleDisplay('solo', [`${r}${o}validatedMemberQ`], 'disable');
      break;
    case 'IBC':
      if(r === 'tech') {
        toggleDisplay('solo', [`${r}${o}memberidsQ`], 'disable');
        toggleDisplay('solo', [`${r}${o}validatedMemberQ`], 'enable');
        break;
      }
    default:
      toggleDisplay('solo', [`${r}${o}memberidsQ`], 'disable');
      toggleDisplay('solo', [`${r}${o}validatedMemberQ`], 'disable');
      break;
  }
}
