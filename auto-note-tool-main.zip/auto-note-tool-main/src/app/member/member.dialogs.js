import { GeneralModal } from '../modal/alert.service';
import { bold } from '../utils/font.formatter';

export default function msgMemberIDMHK(answer) {
  if (answer === 'highlighted in blue') {
    GeneralModal({
      message: bold(
        'Locate the member in Compass, COS or RxClaim, or as directed by WI'
      ),
      icon: 'notification_important',
    });
    return;
  }
  if (answer === 'Not found') {
    GeneralModal({
      message: bold(
        'Perform additional member searches in Compass, COS, or RxClaim, as directed by WI'
      ),
      icon: 'notification_important',
    });
    return;
  }
  if (answer === 'MA') {
    GeneralModal({
      message: bold(
        "Update 'Request Type' to 'Organization Determination' and select the 'Request Reason' of 'Prior Authorization."
      ),
      icon: 'notification_important',
    });
  }
  //AMN 12/8/22 - December 2022 Enhancement - #113: Intake Update for BCBS of MASS
  if (answer === 'BCBS of MASS') {
    GeneralModal({
      message: bold(
        'Request Type is Redetermination. Refer to BCBS of MASS client specific job aid.'
      ),
      icon: 'notification_important',
    });
  }
}
