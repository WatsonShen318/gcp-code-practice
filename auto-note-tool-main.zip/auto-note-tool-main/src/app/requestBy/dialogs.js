import { GeneralModal } from '../modal/alert.service';
import { bold } from '../utils/font.formatter';

//AMN 5/9/23 - May 2023 Enhancements - #124: Add pop-up for Inbound Call [Requested By] = AOR
export default function msgAOR(a) {
  if (a === 'AOR') {
    GeneralModal({
      message: bold(
        "If the caller is from a pharmaceutical company or is calling as a delegate of a pharmaceutical company on the behalf of the member or prescriber, document the Caller’s affiliation AND Company name in the Requester's Name and Callback Number field then continue with current process."
      ),
      icon: 'notification_important',
    });
  }
}
