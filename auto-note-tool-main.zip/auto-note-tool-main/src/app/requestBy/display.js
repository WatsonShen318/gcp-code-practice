import { isFlowAutomated } from '../prefill/helpers';
import { toggleDisplay } from '../utils/notetool.display';

export default function toggleRqstBy(o, r, a) {
  switch (a) {
    case 'Not found':
    case 'highlighted in blue':
      toggleDisplay('solo', [`${r}${o}rqstByQ`], 'disable');
      break;

    default:
      if(!isFlowAutomated()) {
        toggleDisplay('solo', [`${r}${o}rqstByQ`], 'enable');
      }
      break;
  }
}
