import { toggleDisplay } from '../utils/notetool.display';
import { DENIED_NF_GENERAL, DENIED_LMN_DIAGNOSIS, DENIED_QL_GENERAL, PLACEHOLDER_LABELS } from './templates';

const SS_DENIAL_REASON   = 'DENIAL_REASON_SELECTED';
const SS_CASE_VERBIAGE   = 'CASE_VERBIAGE_GENERATED';

const DENIAL_OPTIONS = [
  { value: 'Non-Formulary - General',                              build: _buildNfGeneral },
  { value: 'General - Lack of Medical Necessity Due to Diagnosis', build: _buildLmn },
  { value: 'Quantity Limit - General',                             build: _buildQlGeneral },
  { value: 'Other',                                                build: null },
];

function _replace(template, data) {
  return Object.entries(data).reduce(
    (str, [k, v]) => str.replaceAll(`{${k}}`, (v && v !== 'N/A') ? v : (PLACEHOLDER_LABELS[k] || `{${k}}`)),
    template
  );
}

function _formatAlts(str) {
  if (!str || str === 'N/A') return '';
  return str;
}

function _getFormAltsAudit() { return JSON.parse(sessionStorage.getItem('formAltsAudit') || 'null') || {}; }
function _getQlAudit()       { return JSON.parse(sessionStorage.getItem('qlAudit')       || 'null') || {}; }

function _buildNfGeneral() {
  return _replace(DENIED_NF_GENERAL, { DENIAL_FORM_ALTS: _formatAlts(_getFormAltsAudit().denialFormAlts) });
}

function _buildLmn(role, origin) {
  const indication = _getFormAltsAudit().indicationSelected;
  // Fall back to diagnosisQlt when None of the above was selected ('N/A') or no indication
  // was chosen. 'N/A - no diagnosis' keeps its own value unchanged.
  let value = indication;
  if (!indication || indication === 'N/A') {
    value = document.getElementById(`${role}${origin}diagnosisQlt`)?.value?.trim() || null;
  }
  return _replace(DENIED_LMN_DIAGNOSIS, { INDICATION_SELECTED: value });
}

function _buildQlGeneral() {
  const ql = _getQlAudit();
  return _replace(DENIED_QL_GENERAL, {
    DRUG_AND_REQUESTED_QL: ql.finalDrugAndRequestedQl,
    DRUG_AND_PLAN_QL:      ql.finalDrugAndPlanQl,
  });
}

export function showDenialSection(role, origin) {
  const container = document.getElementById(`${role}${origin}denialSectionQcontainer`);
  if (!container) return;

  const selId = `${role}${origin}denialReasonSel`;
  const btnId = `${role}${origin}denialCopyBtn`;

  container.innerHTML = `
    <p class="fw-semibold">Denial Reason</p>
    <div class="position-relative">
      <select class="form-select" id="${selId}" required>
        <option value="">Select denial reason...</option>
        ${DENIAL_OPTIONS.map(o => `<option value="${o.value}">${o.value}</option>`).join('')}
      </select>
      <div class="invalid-tooltip">Please select a denial reason</div>
    </div>
    <div class="mt-3">
      <button type="button" class="btn btn-copy btn-sm" id="${btnId}" style="display:none">📋 Copy Verbiage</button>
    </div>`;

  const sel = document.getElementById(selId);
  const btn = document.getElementById(btnId);

  sel.onchange = () => {
    const opt = DENIAL_OPTIONS.find(o => o.value === sel.value);
    if (!opt) {
      sessionStorage.setItem(SS_DENIAL_REASON, '');
      sessionStorage.setItem(SS_CASE_VERBIAGE, '');
      btn.style.display = 'none';
      return;
    }
    if (!opt.build) {
      sessionStorage.setItem(SS_DENIAL_REASON, opt.value);
      sessionStorage.setItem(SS_CASE_VERBIAGE, '');
      btn.style.display = 'none';
      return;
    }
    const verbiage = opt.build(role, origin);
    sessionStorage.setItem(SS_DENIAL_REASON, opt.value);
    sessionStorage.setItem(SS_CASE_VERBIAGE, verbiage);
    btn.style.display = '';
    btn.onclick = () => {
      const currentOpt = DENIAL_OPTIONS.find(o => o.value === sel.value);
      const text = (currentOpt?.build ? currentOpt.build(role, origin) : null) || sessionStorage.getItem(SS_CASE_VERBIAGE) || '';
      navigator.clipboard.writeText(text).then(() => {
        btn.textContent = '✓ Copied!';
        btn.classList.replace('btn-copy', 'btn-copy-success');
        setTimeout(() => {
          btn.textContent = '📋 Copy Verbiage';
          btn.classList.replace('btn-copy-success', 'btn-copy');
        }, 1500);
      });
    };
  };

  toggleDisplay('solo', [`${role}${origin}denialSectionQ`], 'enable');
}

export function refreshDenialVerbiage(role, origin) {
  const sel = document.getElementById(`${role}${origin}denialReasonSel`);
  if (!sel?.value) return;
  const opt = DENIAL_OPTIONS.find(o => o.value === sel.value);
  if (!opt?.build) return;
  sessionStorage.setItem(SS_CASE_VERBIAGE, opt.build(role, origin));
}

export function hideDenialSection(role, origin) {
  const sel = document.getElementById(`${role}${origin}denialReasonSel`);
  if (sel) sel.value = '';
  sessionStorage.setItem(SS_DENIAL_REASON, '');
  sessionStorage.setItem(SS_CASE_VERBIAGE, '');
  toggleDisplay('solo', [`${role}${origin}denialSectionQ`], 'disable');
}
