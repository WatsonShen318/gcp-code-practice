import { toggleDisplay } from '../utils/notetool.display';
import {
  APPROVAL_NF, APPROVAL_QL, APPROVAL_PA_ST,
  APPROVAL_NARCAN_APPEND, PLACEHOLDER_LABELS,
} from './templates';

const SS_CASE_VERBIAGE = 'CASE_VERBIAGE_GENERATED';

// Q62 rqstReasonQ choice values:
//   "Non-formulary" | "Quantity Limit" | "Quantity Opioid 7 Day" | "Prior Authorization"
//   "Step Therapy"  | "Safety Edit"    | "Tier Change"           | "Hospice"
// Returns null for request reasons where approval verbiage is not applicable (section is hidden).
function _getTemplate(requestReason) {
  switch (requestReason) {
    case 'Quantity Limit':
    case 'Quantity Opioid 7 Day': return 'QL';
    case 'Prior Authorization':
    case 'Step Therapy':          return 'PA_ST';
    case 'Safety Edit':
    case 'Tier Change':
    case 'Hospice':               return null;
    default:                      return 'NF';
  }
}

function _replace(template, data) {
  return Object.entries(data).reduce(
    (str, [k, v]) => str.replaceAll(`{${k}}`, (v && v !== 'N/A') ? v : (PLACEHOLDER_LABELS[k] || `{${k}}`)),
    template
  );
}

function _extractDrugForm(drugAndRequestedQl) {
  if (!drugAndRequestedQl || drugAndRequestedQl.startsWith('<')) return '';
  const idx = drugAndRequestedQl.indexOf(', ');
  return idx !== -1 ? drugAndRequestedQl.slice(0, idx) : drugAndRequestedQl;
}

function _extractRequestedQl(drugAndRequestedQl) {
  if (!drugAndRequestedQl || drugAndRequestedQl.startsWith('<')) return '';
  const idx = drugAndRequestedQl.indexOf(', ');
  return idx !== -1 ? drugAndRequestedQl.slice(idx + 2) : '';
}

export function showApprovalSection(role, origin) {
  // Read request reason live from the DOM — not stored in sessionStorage
  const requestReason = document.getElementById(`${role}${origin}rqstReasonQsel`)?.value || '';
  const ql     = JSON.parse(sessionStorage.getItem('qlAudit')               || 'null') || {};
  const medhok = JSON.parse(sessionStorage.getItem('originalMedhokResponse') || 'null') || {};
  const drugName = medhok.drugName || '';

  const key = _getTemplate(requestReason);

  // No approval verbiage for Tier Change, Safety Edit, or Hospice
  if (key === null) {
    hideApprovalSection(role, origin);
    return;
  }

  let verbiage;
  if (key === 'QL') {
    const automated = sessionStorage.getItem('qlAutomatedDrugAndRequestedQl') || '';
    const final     = sessionStorage.getItem('qlFinalDrugAndRequestedQl')     || '';
    const drugAndReqQl = (automated && automated === final) ? automated : '';
    verbiage = _replace(APPROVAL_QL, {
      DRUG_FORM:    _extractDrugForm(drugAndReqQl),
      REQUESTED_QL: _extractRequestedQl(drugAndReqQl),
    });
  } else if (key === 'PA_ST') {
    verbiage = APPROVAL_PA_ST;
  } else {
    verbiage = APPROVAL_NF;
  }

  // Narcan rule: append after standard verbiage
  if (drugName.toLowerCase().includes('narcan')) {
    verbiage += '\n\n' + APPROVAL_NARCAN_APPEND;
  }
  // TODO: Add Wegovy/Zepbound specific approval verbiage here following the same Narcan pattern above.
  //       Define the template in templates.js and append/replace verbiage based on drugName.

  sessionStorage.setItem(SS_CASE_VERBIAGE, verbiage);
  console.log('[Approval] Verbiage generated for request reason:', requestReason, '\n', verbiage);

  const container = document.getElementById(`${role}${origin}approvalLetterQcontainer`);
  if (container) {
    const btnId = `${role}${origin}approvalCopyBtn`;
    container.innerHTML = `
      <p class="fw-semibold">Approval Letter</p>
      <button type="button" class="btn btn-copy btn-sm" id="${btnId}">📋 Copy Verbiage</button>`;
    const btn = document.getElementById(btnId);
    btn.onclick = () => {
      const text = sessionStorage.getItem(SS_CASE_VERBIAGE) || '';
      navigator.clipboard.writeText(text).then(() => {
        btn.textContent = '✓ Copied!';
        btn.classList.replace('btn-copy', 'btn-copy-success');
        setTimeout(() => {
          btn.textContent = '📋 Copy Verbiage';
          btn.classList.replace('btn-copy-success', 'btn-copy');
        }, 1500);
      });
    };
  }

  toggleDisplay('solo', [`${role}${origin}approvalLetterQ`], 'enable');
}

export function refreshApprovalVerbiage(role, origin) {
  const routing = document.getElementById(`${role}${origin}routingQsel`)?.value || '';
  if (routing !== 'Approved') return;
  const requestReason = document.getElementById(`${role}${origin}rqstReasonQsel`)?.value || '';
  const key = _getTemplate(requestReason);
  if (key !== 'QL') return;
  const medhok    = JSON.parse(sessionStorage.getItem('originalMedhokResponse') || 'null') || {};
  const automated = sessionStorage.getItem('qlAutomatedDrugAndRequestedQl') || '';
  const final     = sessionStorage.getItem('qlFinalDrugAndRequestedQl')     || '';
  const drugAndReqQl = (automated && automated === final) ? automated : '';
  let verbiage = _replace(APPROVAL_QL, {
    DRUG_FORM:    _extractDrugForm(drugAndReqQl),
    REQUESTED_QL: _extractRequestedQl(drugAndReqQl),
  });
  if (medhok.drugName?.toLowerCase().includes('narcan')) {
    verbiage += '\n\n' + APPROVAL_NARCAN_APPEND;
  }
  sessionStorage.setItem(SS_CASE_VERBIAGE, verbiage);
}

export function hideApprovalSection(role, origin) {
  sessionStorage.setItem(SS_CASE_VERBIAGE, '');
  toggleDisplay('solo', [`${role}${origin}approvalLetterQ`], 'disable');
}
