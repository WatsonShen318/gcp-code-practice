// ─── RFI ──────────────────────────────────────────────────────────────────────

export const RFI_NF_V2 =
`The medication requested is non-formulary on the member's plan.

Current formulary alternatives include:
{RFI_FORM_ALTS}

Please provide all ICD Codes and diagnoses associated with the requested medication:
____________________________________________________________
____________________________________________________________

Please provide all previous tried and failed medications for the provided diagnosis.

___________________________________________________________
__________________________________________________________

• Would any of the above formulary alternatives be as effective for the member?
___________________________________________________________

• Would any of the above formulary alternatives likely have adverse effects for the member?
___________________________________________________________
___________________________________________________________`;

export const RFI_NF_OPIOID =
`The requested medication has a safety edit that limits the day supply of the medication to a 7 day supply.

Is greater than a 7 day supply of this medication medically necessary for your patient?

____________________________________


The medication requested is non-formulary on the member's plan.

Current formulary alternatives include:
{RFI_FORM_ALTS}

Please provide all previous tried and failed medications for the provided diagnosis.

_____________________________________

Would any of the above formulary alternatives be as effective for the member?

Would any of these likely have adverse effects for the member?

Please provide all ICD Codes and diagnoses associated with the requested medication:  ____________________`;

export const RFI_INHALATION_NF_V2 =
`Is the patient using the medication with a nebulizer?:
       Yes                           No

The medication requested is non-formulary on the member's plan.

Current formulary alternatives include:
{RFI_FORM_ALTS}

Please provide all ICD Codes and diagnoses associated with the requested medication:
_______________________________________________
_______________________________________________

Please provide all previous tried and failed medications for the provided diagnosis.
______________________________________________
______________________________________________

∙ Would any of the above formulary alternatives be as effective for the member?
______________________________________________
______________________________________________

∙ Would any of these likely have adverse effects for the member?
________________________________________________
________________________________________________`;

export const RFI_QL_GENERAL_V2 =
`The requested medication has a quantity limit of {PLAN_QL}.

The request for {DRUG_AND_REQUESTED_QL}, exceeds the amount allowed by the member's plan.

• Has the member taken the quantity allowed by the plan (indicated above) and was it ineffective in the treatment of the member's disease or medical condition?

_____________________________________________________________
_____________________________________________________________

• Would the quantity allowed by the plan (indicated above) likely be ineffective or adversely affect the drug's effectiveness or patient compliance, based on both sound clinical evidence and medical and scientific evidence, the known relevant physical or mental characteristics of the member, and known characteristics of the drug regimen?

___________________________________________________________
___________________________________________________________

Please provide all ICD Codes and diagnoses associated with the requested medication: _____________________`;

export const RFI_QL_DOSE_CONSOLIDATION_V2 =
`The requested medication has a quantity limit of {PLAN_QL}.

The request for {DRUG_AND_REQUESTED_QL}, exceeds the amount allowed by the member's plan.

• This drug is available in a higher strength that would be the same as the requested dose. Would taking {DRUG_AND_PLAN_QL} be as effective for the member?

_________________________________________________________
_________________________________________________________

If dose consolidation is not an option for this member, please address the following:

• Has the member taken the quantity allowed by the plan (as indicated above) and was it ineffective in the treatment of the member's disease or medical condition?
_______________________________________________________
_______________________________________________________

• Would the quantity allowed by the plan (as indicated above) likely be ineffective or adversely affect the drug's effectiveness or patient compliance, based on both sound clinical evidence and medical and scientific evidence, the known relevant physical or mental characteristics of the member, and known characteristics of the drug regimen?
______________________________________________________
______________________________________________________

Please provide all ICD Codes and diagnoses associated with the requested medication: ____________________`;

export const RFI_QL_925 =
`The requested medication has a safety edit that limits the day supply of the medication to a 7 day supply.

Is greater than a 7 day supply of this medication medically necessary for your patient?`;

// ─── Denial ───────────────────────────────────────────────────────────────────

export const DENIED_NF_GENERAL =
`The requested drug is not on your plan's formulary (list of covered drugs). Your Medicare Part D drug plan was asked to cover a drug that is not on the formulary (this is called a formulary exception). Your prescriber did not provide the detailed information that is required in order to approve the request. To receive a formulary exception, per the Part D Coverage Determination guidance Section 40.5.2 and 40.5.3, your prescriber must provide information that documents at least one of the following has occurred:

- You have tried the formulary drugs for the treatment of your condition and they did not work for you.
OR
- The formulary drugs could cause adverse effects.
OR
- The formulary drugs would be less effective for your condition than the requested drug.

Talk to your prescriber to see if the following covered alternative(s) would be right for you:

{DENIAL_FORM_ALTS}`;

export const DENIED_LMN_DIAGNOSIS =
`In order for a drug to be considered for coverage under Medicare Part D, it must be used for a medically-accepted indication as defined in section 1860(D)-2(e)(4) of the Social Security Act. Medically-accepted indications (medical conditions that the drug is used for) are supported by the Food and Drug Administration (FDA) labeling of the drug and/or medical references approved by Medicare Part D. This information is described in your plan materials.

We must deny this request because the information provided by your prescriber (diagnosis of {INDICATION_SELECTED}) did not meet the requirement(s) of a medically-accepted indication.`;

export const DENIED_QL_GENERAL =
`Your Medicare Part D plan limits the quantity of the requested drug covered over a certain period of time.

The request for {DRUG_AND_REQUESTED_QL}, exceeds the amount allowed by your Plan.

In order for your Medicare Part D drug plan to cover a higher quantity of the requested drug (this is called a quantity exception), your prescriber must provide detailed information that indicates that the quantity of drug allowed by your plan is not effective or is not likely to be effective for the treatment of your medical condition per the Part D Coverage Determination guidance Sections 40.5.2 and 40.5.3.

The current quantity covered by your Medicare Part D drug plan for this drug is:  {DRUG_AND_PLAN_QL}`;

// ─── Approval ─────────────────────────────────────────────────────────────────

// Non-Formulary: static
export const APPROVAL_NF =
`Depending upon the strength and/or formulation of the drug prescribed by your physician, different quantity limits or safety edits may apply in the future.`;

// Quantity Limit / Quantity Opioid 7 Day
// {DRUG_FORM}     = drug name/form/strength (strip QL suffix from finalDrugAndRequestedQl)
// {REQUESTED_QL}  = requested quantity e.g. "60 CAPSULES PER 30 DAYS" (strip drug prefix from finalDrugAndRequestedQl)
export const APPROVAL_QL =
`This approval for {DRUG_FORM}, authorizes you to receive a quantity up to {REQUESTED_QL}, as prescribed by your physician. To determine if your plan covers a 90-day supply, refer to your Evidence of Coverage.`;

// Prior Authorization AND Step Therapy AND Safety Edit: static
export const APPROVAL_PA_ST =
`Depending upon the strength and/or formulation of the drug prescribed by your physician, different quantity limits apply. Please consult your Medicare Part D plan's formulary for the specific quantity limit.`;

// Tier Change — DISABLED (Phase 5.0). Implemented but never shown.
// {APPROVED_TIER} = tier value from case screen (TBD)
export const APPROVAL_TIER_CHANGE =
`This approval authorizes you to receive the medication listed above at tier {APPROVED_TIER}. Your cost share (the amount you pay) may be subject to change depending on your coverage phase and plan benefit. Depending upon the strength and/or formulation of the drug prescribed by your physician, different quantity limits or safety edits may apply. Please consult your Medicare Part D plan's formulary for the specific quantity limit.`;

// Friendly fallback labels shown in verbiage when data is not yet available.
// Matches the human-readable placeholder style from the original MD templates.
export const PLACEHOLDER_LABELS = {
  RFI_FORM_ALTS:         '<insert form alts>',
  PLAN_QL:               '<insert allowed quantity>',
  REQUESTED_QL:          '<insert requested quantity>',
  DRUG_AND_REQUESTED_QL: '<drug, strength; requested amount>',
  DRUG_AND_PLAN_QL:      '<drug, strength; quantity dosage form/day>',
  DENIAL_FORM_ALTS:      '<insert form alts>',
  INDICATION_SELECTED:   '<indication/diagnosis>',
  DRUG_FORM:             '<drug, form, strength>',
};

// Appended AFTER standard approval verbiage when drugName contains "narcan" (case-insensitive)
export const APPROVAL_NARCAN_APPEND =
`This review was completed for Narcan Nasal Spray.`;
