import { showRfiSection, hideRfiSection, refreshRfiVerbiage }             from './rfi';
import { showDenialSection, hideDenialSection, refreshDenialVerbiage }     from './denial';
import { showApprovalSection, hideApprovalSection, refreshApprovalVerbiage } from './approval';

export function handleRoutingChange(role, origin, routingAnswer) {
  hideRfiSection(role, origin);
  hideDenialSection(role, origin);
  hideApprovalSection(role, origin);

  // Lock QL verbiage fields when routing is Approved and automation has populated them.
  // Guard prevents locking manual-entry fields where no lookup result exists.
  const hasAutomatedQl = !!sessionStorage.getItem('qlAutomatedDrugAndRequestedQl') ||
    !!(JSON.parse(sessionStorage.getItem('qlLookupResult') || 'null')?.selectedOption);
  if (hasAutomatedQl) {
    const isApproved = routingAnswer === 'Approved';
    ['qlDrugAndRequestedQlQ', 'qlDrugAndPlanQlQ', 'qlPlanQlQ'].forEach((internal) => {
      const el = document.getElementById(`${role}${origin}${internal}txt`);
      if (el) el.readOnly = isApproved;
    });
  }

  if (routingAnswer === 'Sent to RFI') {
    showRfiSection(role, origin);
  } else if (routingAnswer === 'Denied') {
    showDenialSection(role, origin);
  } else if (routingAnswer === 'Approved') {
    showApprovalSection(role, origin);
  }
}

export function refreshVerbiageIfActive(role, origin) {
  refreshApprovalVerbiage(role, origin);
  refreshRfiVerbiage(role, origin);
  refreshDenialVerbiage(role, origin);
}
