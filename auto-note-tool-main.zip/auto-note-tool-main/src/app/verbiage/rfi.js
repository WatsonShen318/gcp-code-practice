import { toggleDisplay } from '../utils/notetool.display';
import {
  RFI_NF_V2, RFI_NF_OPIOID, RFI_INHALATION_NF_V2,
  RFI_QL_GENERAL_V2, RFI_QL_DOSE_CONSOLIDATION_V2, RFI_QL_925,
  PLACEHOLDER_LABELS,
} from './templates';

const SS_RFI_REASON     = 'RFI_REASON_SELECTED';
const SS_CASE_VERBIAGE  = 'CASE_VERBIAGE_GENERATED';

// Note: RFI-Quantity – Dose Consolidation_V2 has a special character in the name (–) that is different from the normal dash (-). This is intentional and must be preserved to match the option value in the select element.
const RFI_OPTIONS = [
  { value: 'RFI-Inhalation Solution Non-Formulary_V2', build: _buildInhalationNfV2 },
  { value: 'RFI-Non Formulary Opioid',                 build: _buildNfOpioid },
  { value: 'RFI-Non Formulary_V2',                     build: _buildNfV2 },
  { value: 'RFI-Quantity - General_V2',                build: _buildQlGeneralV2 },
  { value: 'RFI-Quantity – Dose Consolidation_V2',     build: _buildQlDoseConsolidation },
  { value: 'RFI-Quantity Limit-925',                   build: () => RFI_QL_925 },
  { value: 'Other',                                    build: null },
];

function _replace(template, data) {
  return Object.entries(data).reduce(
    (str, [k, v]) => str.replaceAll(`{${k}}`, (v && v !== 'N/A') ? v : (PLACEHOLDER_LABELS[k] || `{${k}}`)),
    template
  );
}

function _formatAlts(str) {
  if (!str || str === 'N/A') return '';
  return str;
}

function _getFormAltsAudit() { return JSON.parse(sessionStorage.getItem('formAltsAudit') || 'null') || {}; }
function _getQlAudit()       { return JSON.parse(sessionStorage.getItem('qlAudit')       || 'null') || {}; }

function _buildNfV2()           { return _replace(RFI_NF_V2,            { RFI_FORM_ALTS: _formatAlts(_getFormAltsAudit().rfiFormAlts) }); }
function _buildNfOpioid()       { return _replace(RFI_NF_OPIOID,        { RFI_FORM_ALTS: _formatAlts(_getFormAltsAudit().rfiFormAlts) }); }
function _buildInhalationNfV2() { return _replace(RFI_INHALATION_NF_V2, { RFI_FORM_ALTS: _formatAlts(_getFormAltsAudit().rfiFormAlts) }); }

function _buildQlGeneralV2() {
  const ql = _getQlAudit();
  return _replace(RFI_QL_GENERAL_V2, {
    PLAN_QL:               ql.finalPlanQl,
    DRUG_AND_REQUESTED_QL: ql.finalDrugAndRequestedQl,
  });
}

function _buildQlDoseConsolidation() {
  const ql = _getQlAudit();
  return _replace(RFI_QL_DOSE_CONSOLIDATION_V2, {
    PLAN_QL:               ql.finalPlanQl,
    DRUG_AND_REQUESTED_QL: ql.finalDrugAndRequestedQl,
    DRUG_AND_PLAN_QL:      ql.finalDrugAndPlanQl,
  });
}

export function showRfiSection(role, origin) {
  const container = document.getElementById(`${role}${origin}rfiSectionQcontainer`);
  if (!container) return;

  const selId  = `${role}${origin}rfiReasonSel`;
  const btnId  = `${role}${origin}rfiCopyBtn`;

  container.innerHTML = `
    <p class="fw-semibold">RFI Reason</p>
    <div class="position-relative">
      <select class="form-select" id="${selId}" required>
        <option value="">Select RFI reason...</option>
        ${RFI_OPTIONS.map(o => `<option value="${o.value}">${o.value}</option>`).join('')}
      </select>
      <div class="invalid-tooltip">Please select an RFI reason</div>
    </div>
    <div class="mt-3">
      <button type="button" class="btn btn-copy btn-sm" id="${btnId}" style="display:none">📋 Copy Verbiage</button>
    </div>`;

  const sel = document.getElementById(selId);
  const btn = document.getElementById(btnId);

  sel.onchange = () => {
    const opt = RFI_OPTIONS.find(o => o.value === sel.value);
    if (!opt) {
      sessionStorage.setItem(SS_RFI_REASON, '');
      sessionStorage.setItem(SS_CASE_VERBIAGE, '');
      btn.style.display = 'none';
      return;
    }
    if (!opt.build) {
      sessionStorage.setItem(SS_RFI_REASON, opt.value);
      sessionStorage.setItem(SS_CASE_VERBIAGE, '');
      btn.style.display = 'none';
      return;
    }
    const verbiage = opt.build();
    sessionStorage.setItem(SS_RFI_REASON, opt.value);
    sessionStorage.setItem(SS_CASE_VERBIAGE, verbiage);
    btn.style.display = '';
    btn.onclick = () => {
      const currentOpt = RFI_OPTIONS.find(o => o.value === sel.value);
      const text = (currentOpt?.build ? currentOpt.build() : null) || sessionStorage.getItem(SS_CASE_VERBIAGE) || '';
      navigator.clipboard.writeText(text).then(() => {
        btn.textContent = '✓ Copied!';
        btn.classList.replace('btn-copy', 'btn-copy-success');
        setTimeout(() => {
          btn.textContent = '📋 Copy Verbiage';
          btn.classList.replace('btn-copy-success', 'btn-copy');
        }, 1500);
      });
    };
  };

  toggleDisplay('solo', [`${role}${origin}rfiSectionQ`], 'enable');
}

export function refreshRfiVerbiage(role, origin) {
  const sel = document.getElementById(`${role}${origin}rfiReasonSel`);
  if (!sel?.value) return;
  const opt = RFI_OPTIONS.find(o => o.value === sel.value);
  if (!opt?.build) return;
  sessionStorage.setItem(SS_CASE_VERBIAGE, opt.build());
}

export function hideRfiSection(role, origin) {
  const sel = document.getElementById(`${role}${origin}rfiReasonSel`);
  if (sel) sel.value = '';
  sessionStorage.setItem(SS_RFI_REASON, '');
  sessionStorage.setItem(SS_CASE_VERBIAGE, '');
  toggleDisplay('solo', [`${role}${origin}rfiSectionQ`], 'disable');
}
