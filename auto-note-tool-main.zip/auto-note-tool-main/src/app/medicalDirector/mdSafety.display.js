import { toggleDisplay } from '../utils/notetool.display';

export default function toggleSafetyConcern(o, r, a) {
  const status = a === 'No' ? 'enable' : 'disable';
  toggleDisplay('solo', [`${r}${o}submdSafetyQ`], status);
}
