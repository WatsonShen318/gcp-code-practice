import { GeneralModal } from '../modal/alert.service';
import { bold } from '../utils/font.formatter';

export default function msgMdInfoReview(a) {
  if (a === 'No') {
    GeneralModal({
      message: bold(
        'NOTE: All information MUST be reviewed including telephonic, fax, internal notes, attachments, case history, claims history, etc.; i.e., everything.'
      ),
      icon: 'notification_important',
    });
  }
}
