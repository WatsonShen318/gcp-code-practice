import { toggleDisplay } from '../utils/notetool.display';

export default function toggleNewInfoRec(o, r, a) {
  const status = a === 'Yes' ? 'enable' : 'disable';
  toggleDisplay('solo', [`${r}${o}submdNewInfoQ`], status);
}
