import {
  setMDoffLabelCompendiaNA,
  setMDoffLabelCompendiaNo,
} from '../utils/automation';
import {
  mdFDA,
  mdInfoReview,
  mdNewInfo,
  mdOffLabel,
  mdResolution,
  mdSafety,
} from '../qsets/fields';
import toggleMDapprovalchecks from './mdApprovalCheck.display';
import msgMdInfoReview from './mdInfoReview.dialog';
import toggleNewInfoRec from './mdNewInfo.display';
import toggleMDResolution from './mdResolution.display';
import toggleSafetyConcern from './mdSafety.display';

let answer = null;

export default function mdTemplate(origin, role) {
  //* All Safety Issues Resolved
  mdSafety(role, origin, 'event').forEach((elem) => {
    elem.addEventListener('click', (e) => {
      answer = e.target.value;
      toggleSafetyConcern(origin, role, answer);
    });
  });
  //* New Clinical Information Received for RD

  mdNewInfo(role, origin, 'event').forEach((elem) => {
    elem.addEventListener('click', (e) => {
      answer = e.target.value;
      toggleNewInfoRec(origin, role, answer);
    });
  });
  //* Resolution
  mdResolution(role, origin, 'event').forEach((elem) => {
    elem.addEventListener('click', (e) => {
      answer = e.target.value;
      toggleMDapprovalchecks(origin, role, answer);
      toggleMDResolution(origin, role, answer);
    });
  });

  //* All Clinical Information Submitted Reviewed
  mdInfoReview(role, origin, 'event').forEach((elem) => {
    elem.addEventListener('click', (e) => {
      answer = e.target.value;
      msgMdInfoReview(answer);
    });
  });

  //* FDA-Labeled Indication(s)
  mdFDA(role, origin, 'event').forEach((elem) => {
    elem.addEventListener('click', (e) => {
      answer = e.target.value;
      setMDoffLabelCompendiaNA(origin, role, answer);
      setMDoffLabelCompendiaNo(origin, role, answer);
    });
  });

  //* Off-Label Indication/Compendium-Supported(s)
  mdOffLabel(role, origin, 'event').forEach((elem) => {
    elem.addEventListener('click', (e) => {
      answer = e.target.value;
      setMDoffLabelCompendiaNo(origin, role, answer);
    });
  });
}
