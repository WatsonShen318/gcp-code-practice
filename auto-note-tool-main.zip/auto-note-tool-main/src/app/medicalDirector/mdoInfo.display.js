import { isFlowAutomated } from '../prefill/helpers';
import { toggleDisplay } from '../utils/notetool.display';

export default function toggleMDInfo(o, r, a) {
  switch (a) {
    case 'Not found':
    case 'highlighted in blue':
      toggleDisplay('solo', [`${r}${o}mdoInfoQ`], 'disable');
      break;

    default:
        if(!isFlowAutomated()) {
          toggleDisplay('solo', [`${r}${o}mdoInfoQ`], 'enable');
        }
      break;
  }
}
