import { toggleDisplay } from '../utils/notetool.display';

export default function toggleMDapprovalchecks(o, r, a) {
  let status = 'disable';
  const workFlow = sessionStorage.getItem("workFlow");
  if (workFlow !== 'Automated' && a === 'Consider Approval') {
    status = 'enable';
  }

  toggleDisplay(
    'solo',
    [
      `${r}${o}overrideBackDate`,
      `${r}${o}overrideBackDateHUP`,
      `${r}${o}completeMSC`,
      `${r}${o}completeMSCHUP`,
      `${r}${o}submdResolutionQ`,
    ],
    status
  );
}
