import { toggleDisplay } from '../utils/notetool.display';

export default function toggleMDResolution(o, r, a) {
  const status = a === 'Consider Approval' ? 'enable' : 'disable';
  toggleDisplay('solo', [`${r}${o}submdResolutionQ`], status);
}
