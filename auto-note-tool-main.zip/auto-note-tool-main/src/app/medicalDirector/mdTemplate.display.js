import { setMDdxNo, setMDnewInfo, setMDrational } from '../utils/automation';
import { decisionRouting, mdReview } from '../qsets/fields';
import { toggleDisplay } from '../utils/notetool.display';

export default function toggleMDTemplate(o, r) {
  const mds = (r, o) =>
    document.querySelectorAll(
      `div.tab-content>fieldset[id="${r}${o}"].active [data-tag="MD"]`
    );
  const d = decisionRouting(r, o, 'value');
  const mdr = mdReview(r, o, 'value');

  const status =
    (mdr === 'No' && d === 'Denied') || d === 'Send to MD'
      ? 'enable'
      : 'disable';
  toggleDisplay('tag', mds(r, o), status);
  if (status === 'enable') {
    //* lazyload!
    import(
      /* webpackPrefetch: true */ /* webpackChunkName: "MDTemplate" */ './mdTemplate'
    ).then((module) => {
      module.default(o, r);
    });
    setMDrational(o, r);
    setMDnewInfo(o, r);
    if (o === 'TAT') setMDdxNo(o, r);
  }
}
