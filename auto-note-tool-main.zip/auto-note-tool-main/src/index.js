import './main.scss';
import './data/render.handlebar.templates';
import './app/app';
