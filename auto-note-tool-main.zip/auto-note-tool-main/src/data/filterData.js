import {
  getCurrentYear,
  getForwardDate,
  getLastDate,
  getLastQtr,
  getToday,
} from '../app/utils/calculateDates';

const client = require('../app/client/clients.json');

export function copy(o) {
  return { ...o };
}

export function filterIntake(dataSet, order) {
  const IntakeData = {
    questions: dataSet
      .map(copy)
      .filter((i) => i.roles.includes('intake') && i.origin.includes('intake'))
      .map((k) => {
        // $ filter sub data headsup that is only for title(role) and queue
        if (k.headsup) {
          const headsup = k.headsup
            .map((i) =>
              i.origin === 'getLastQtr'
                ? { ...i, origin: getLastQtr() }
                : { ...i }
            )
            //AMN 11/2/22 - #110: Reminder doesn't show up for Was the member found in Compass with 3 identifiers question
            // .filter(
            //   (i) => i.origin.includes('intake') && i.roles.includes('intake')
            // )
            .filter(
              (i) =>  (i.origin.includes('intake') || i.origin.includes('all')) && i.roles.includes('intake')
            )
            .map((i) => ({ ...i, origin: null }));
          k = { ...k, headsup };
        }
        return k;
      })
      .map((v) => ({ ...v, origin: null }))
      .sort((a, b) => order.indexOf(a.id) - order.indexOf(b.id)),
  };
  return IntakeData;
}

export function filterOriginData(dataSet, title) {
  const preData = {
    questions: dataSet
      .map(copy)
      .filter((i) => i.roles.includes(title))
      .map((k) => {
        // $ filter choices that is only for title(role)
        if (k.choices && k.choices.length) {
          const choices = k.choices
            .filter((j) => j.role.includes(title) || j.role.includes('all'))
            .map((b) => ({ ...b }));
          k = { ...k, choices, title };
        }
        return k;
      })
      .map((k) => {
        // $ filter reference that is only for title(role)
        if (k.references && k.references.length) {
          const references = k.references
            .filter((j) => j.role.includes(title))
            .map((b) => ({ ...b }));
          k = { ...k, references, title };
        }
        return k;
      }),
  };
  return preData;
}

export function filterData(dataSet, title, que, order) {
  const clientlist = client.list.sort((a, b) => a.internal - b.internal);
  let newData = {
    questions: dataSet
      .map(copy)
      .map((i) =>
        i.origin === 'getLastQtr' ? { ...i, origin: getLastQtr() } : { ...i }
      )
      .filter(
        // $ Get all data including title(role) and queue
        (i) => i.roles.includes(title) && i.origin.includes(que)
      )

      .map((i) =>
        i.choices === 'clientlist' ? { ...i, choices: clientlist } : { ...i }
      )
      .map((i) =>
        i.note === 'getForwardDate90'
          ? { ...i, note: getForwardDate(90) }
          : { ...i }
      )
      .map((i) =>
        i.note === 'getLastDate65' ? { ...i, note: getLastDate(65) } : { ...i }
      )
      .map((i) =>
        i.replaceText === 'getCurrentYear'
          ? {
              ...i,
              questionText: i.questionText.replace(
                'getCurrentYear',
                getCurrentYear()
              ),
            }
          : { ...i }
      )
      .map((k) => {
        // $ choice default
        if (k.choices) {
          const choices = k.choices.map((i) =>
            i.default === 'getToday' ? { ...i, default: getToday() } : { ...i }
          );
          k = { ...k, choices };
        }
        return k;
      })
      .map((k) => {
        // $ filter sub data headsup that is only for title(role) and queue
        if (k.headsup) {
          const headsup = k.headsup
            .map((i) =>
              i.origin === 'getLastQtr'
                ? { ...i, origin: getLastQtr() }
                : { ...i }
            )
            .filter((i) => i.origin.includes(que) && i.roles.includes(title))
            .map((i) => ({ ...i, origin: que, roles: title }));
          k = { ...k, headsup };
        }
        return k;
      })
      .map((k) => {
        // $ filter sub data headsup that is only for title(role) and queue
        if (k.preheadsup) {
          const preheadsup = k.preheadsup
            .map((i) =>
              i.origin === 'getLastQtr'
                ? { ...i, origin: getLastQtr() }
                : { ...i }
            )
            .filter((i) => i.origin.includes(que) && i.roles.includes(title))
            .map((i) => ({ ...i, origin: que, roles: title }));
          k = { ...k, preheadsup };
        }
        return k;
      })
      .map((g) => {
        // $ filter accordion contents that is only for title(role) and queue
        if (g.contents) {
          const contents = g.contents
            .filter((j) => j.origin.includes(que) && j.roles.includes(title))
            .map((b) => ({
              ...b,
              origin: que,
              roles: title,
              title,
              accordion: true,
            }));
          g = { ...g, contents };
        }
        return g;
      })
      .map((g) => {
        // $ filter Repeating Section contents that is only for title(role) and queue
        if (g.repeats) {
          const repeats = g.repeats
            .filter((j) => j.origin.includes(que) && j.roles.includes(title))
            .map((b) => ({
              ...b,
              origin: que,
              roles: title,
              title,
              isRepeat: true,
            }));
          g = { ...g, repeats };
        }
        return g;
      })
      .map((c) => {
        // $ filter out the checklist high level by queue and title(role)
        if (c.checklist) {
          const checklist = c.checklist
            .filter((w) => w.origin.includes(que) && w.roles.includes(title))
            .map((k) => {
              // $ filter sub data headsup that is only for title(role) and queue
              if (k.headsup) {
                const headsup = k.headsup
                  .map((i) =>
                    i.origin === 'getLastQtr'
                      ? { ...i, origin: getLastQtr() }
                      : { ...i }
                  )
                  .filter(
                    (j) => j.origin.includes(que) && j.roles.includes(title)
                  )
                  .map((b) => ({ ...b, origin: que, roles: title }));
                k = { ...k, headsup };
              }
              return k;
            })

            .map((y) => ({ ...y, origin: que, roles: title }));
          c = { ...c, checklist };
        }
        return c;
      })
      .map((v) => ({ ...v, origin: que, title }))
      .sort((a, b) => order.indexOf(a.id) - order.indexOf(b.id)),
  };

  if(['Queue', 'SR', 'TAT', 'IBC'].includes(que)) {
    if(title === 'tech' && que === 'IBC') {
      newData = {
        questions: newData.questions.map((question) => {
          return {
            ...question,
            /* Initially only shown "Call being transferred", "Member Info", and "Is this an in-progress CASE?"  */
            initiallyHidden: question.defaultShow && !([22, 149, 166].includes(question.id))
          }
        }) 
      }
    } else {
      newData = {
        questions: newData.questions.map((question) => {
          return {
            ...question,
            /* Initially only show caseId field and hide fields having defaulShow=true till getting valid input from caseId input field */
            initiallyHidden: question.defaultShow && question.id !== 148
          }
        }) 
      }
    }
  }
  return newData;
}
