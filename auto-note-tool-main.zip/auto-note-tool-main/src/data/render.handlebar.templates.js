import { filterData, filterOriginData, filterIntake } from './filterData';
import translate from './translate.handlebar';
import {
  IntakeOrder,
  techIBCorder,
  techSRorder,
  techQorder,
  techTATorder,
  rphIBCorder,
  rphQorder,
  rphTATorder,
} from './question.orders';

//* Import data
const qset = require('./questions.json');
const originData = require('../app/origin/data/origin.json');
const intakePreData = require('./intakePreQuestions.json');
const roles = require('../app/nav/data/roles.json');
const moreCaseRoles = require('../app/buttons/data/moreButton.json');

//* Import templates
const temp = require('../app/qsets/partials/questions.hbs');
const oTemp = require('../app/origin/partials/origin.hbs');
const nTemp = require('../app/nav/partials/component/roles.hbs');
const moreCaseBtnTemp = require('../app/buttons/partials/buttonMore.hbs');

//* Sort the data by ID numbers
const preIntake = filterIntake(intakePreData.questions, [1]);
const intake = filterIntake(qset.questions, IntakeOrder);

const techOrigin = filterOriginData(originData.questions, 'tech');
const techIBC = filterData(qset.questions, 'tech', 'IBC', techIBCorder);
const techQue = filterData(qset.questions, 'tech', 'Queue', techQorder);
const techSR = filterData(qset.questions, 'tech', 'SR', techSRorder);
const techTAT = filterData(qset.questions, 'tech', 'TAT', techTATorder);

const rphOrigin = filterOriginData(originData.questions, 'rph');
const rphIBC = filterData(qset.questions, 'rph', 'IBC', rphIBCorder);
const rphQue = filterData(qset.questions, 'rph', 'Queue', rphQorder);
const rphTAT = filterData(qset.questions, 'rph', 'TAT', rphTATorder);

// //* Render!
translate(moreCaseBtnTemp(moreCaseRoles), 'moreBtns');
translate(nTemp(roles), 'pills-tab');
translate(oTemp(preIntake), 'iPreQuestion');
translate(temp(intake), 'itrashFaxNOgrp');
translate(oTemp(techOrigin), 'origin');
translate(oTemp(rphOrigin), 'rphorigin');
translate(temp(techIBC), 'techIBC');
translate(temp(techQue), 'techQueue');
translate(temp(techTAT), 'techTAT');
translate(temp(techSR), 'techSR');
translate(temp(rphIBC), 'rphIBC');
translate(temp(rphQue), 'rphQueue');
translate(temp(rphTAT), 'rphTAT');
