export default function translate(hbsTemplate, elementID) {
  const container = document.getElementById(elementID);
  container.innerHTML = hbsTemplate;
}
