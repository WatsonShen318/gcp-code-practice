# Contributing to the project

## Bug reporting

As the bug or an issue identified in the tool/process, you shall open MS intake task to describe the issue. Please reach out the team who is a SME on the tool.

## Cloning, Branching, and Deploying

Git allows multiple branches of a project.

When you clone a project and ready to begin working, you must create a new branch from `develop` branch.

General naming convention of the branch is following:

- **develop**: develop_month
- **Hot fix**: fix_topic

When you are making a change to any file, you must update the [Changelog](CHANGELOG.md) to document the changes high level.

> Update the Changelog file at the cloned branch

### Testing

We encourage contributors to debug the solution locally prior to pushing the code the `develop` branch. Once your local debugging is completed, then go through deployment process.

## Deployment

Deployments are done through CI/CD pipeline. Follow these steps to deploy the application to the servers.

Each version of deployed application will also be archived and saved to the archive link.

### Test Deployment

The tool will get deployed to [bitools-test](https://bitools-test.cvshealth.com/notetool/Internal%20Note%20Tool.html). There are 2 ways to deploy the application to the test server.

- Commit your files with a key phrase `DEPLOY-TEST-APP` in the commit message. Once you push your commit, the pipeline will run to deploy the application to the test server.

> You can perform this from any branch

- Run Git command below to deploy the app

  ```bash
    git commit --allow-empty -m "DEPLOY-TEST-APP"

    git push origin <source branch>
  ```

- Utilize GitLab CI/CD pipeline page to run pipeline manually by providing variable value

  ![pipeline](/.gitlab/images/cicd.png)

### Production Deployment

The tool will get deployed to [bitools](https://bitools.cvshealth.com/notetool/Internal%20Note%20Tool.html). There are 2 ways to deploy the application to the production server.

- Commit your files with a key phrase `DEPLOY-PROD-APP` in the commit message. Once you push your commit, the pipeline will run to deploy the application to the test server.

- Run Git command below to deploy the app

  ```bash
    git commit --allow-empty -m "DEPLOY-PROD-APP"

    git push origin <source branch>
  ```

- Utilize GitLab CI/CD pipeline page to run pipeline manually by providing variable value

  ![pipeline](/.gitlab/images/cicd-prod.png)

### Release

After the code files are merged to the `main` branch, a new tag and release needs to be created. Run 'release.sh' file from the local machine.

1. Open Git Bash
2. Run bash command

```bash
bash release.sh
```

3. Follow the prompt and provide values

### Rollback

If you wish to rollback to the previous version, you can utilize rollback function in Environments.

> Use this if deployed production app has an issue

![rollback](/.gitlab/images/rollback.png)
