#!/bin/bash

# merge your code from any working branch to main and then create a tag
echo "👋 Let's Merge your code to main first."
echo "Which branch would you like to merge to the main branch?"
read sourceBranch
if [ -z "$sourceBranch" ];
then
    echo "You have to provide source branch name to move forward. Try again"
    exit
fi
echo "🏷️  Next - Enter the Tag Name (Usually it's the version number from your changelog file)"
read tag
if [ -z "$tag" ];
then
    echo "You have to provide tag name to move forward. Try again"
    exit
fi
echo "Let's make sure we get the latest files from remote $sourceBranch branch..."
git checkout $sourceBranch
git push
git fetch origin
git pull
echo "Let's make sure we get the latest files from remote main branch..."
git checkout main
git fetch origin
git pull
echo "Now let's merge your code from $sourceBranch to main"
git merge --no-ff $sourceBranch -m "Version bump to $tag"
git push origin main
git tag $tag
git push origin $tag
echo "🔀 Switching back to $sourceBranch"
git checkout $sourceBranch

echo "🎉 All Set"
