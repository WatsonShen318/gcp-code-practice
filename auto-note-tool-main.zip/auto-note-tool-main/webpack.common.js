const path = require('path');
const ProgressBarPlugin = require('progress-bar-webpack-plugin');
const appDetails = require('./package.json');
const CopyWebPackPlugin = require('copy-webpack-plugin');
const { AUTO_NOTE_EXTENSIONS_MAPPER_LIST, ADDITIONAL_ROUTE_PLUGINS } = require('./autonoteextns/config');

const { name } = appDetails;

const webserver = () => {
  let link = '';
  if (process.env.NODE_ENV !== 'production') {
    link = '//PAZ1WQAWTW10V/e$/BITools/notetool/';
  } else {
    link = '//PAZ1WQAWPW10V/e$/BITools/notetool/';
  }
  return link;
};

const PATHS = {
  src: path.join(__dirname, 'src'),
  static: `${name}/static/`,
  dist: path.resolve(__dirname, 'dist'),
  deployURL: webserver(),
  environment: path.join(__dirname, 'environment'),
  autoNoteExtns: path.join(__dirname, 'autonoteextns'),
};

const common = {
  entry: {
    main: {
      import: path.join(PATHS.src, '/index.js'),
      dependOn: 'vendor',
    },
    vendor: [
      path.join(PATHS.src, 'vendor.js'),
      path.join(PATHS.src, 'data/translate.handlebar.js'),
      path.join(PATHS.src, 'data/render.handlebar.templates.js'),
    ],
  },
  externals: [
    {
      'handlebars/runtime': {
        root: 'Handlebars',
        amd: 'handlebars/runtime',
        commonjs2: 'handlebars/runtime',
        commonjs: 'handlebars/runtime',
      },
    },
  ],
  module: {
    rules: [
      {
        test: /\.js$/, // using regex to tell babel exactly what files to transpile
        exclude: /node_modules/, // files to be ignored
        include: /src/,
        use: {
          loader: 'babel-loader', // specify the loader
        },
      },
      {
        test: /\.(handlebars|hbs)$/i,
        use: {
          loader: 'handlebars-loader?runtime=handlebars/runtime',
          options: {
            helperDirs: [path.resolve(__dirname, './helpers')],
            partialDirs: [path.resolve(PATHS.src, 'app')],
            precompileOptions: {
              knownHelpersOnly: false,
            },
            inlineRequires: /\/assets\//,
          },
        },
      },
      // {
      //   test: /\.html$/i,
      //   use: ['html-loader'],
      // },
      {
        test: /\.(svg|png|gif)$/i,
        use: {
          loader: 'file-loader',
          options: {
            name: '[name].[ext]',
            outputPath: `${PATHS.static}/imgs/`,
            publicPath: `${PATHS.static}/imgs/`,
            esModule: false,
          },
        },
      },
    ],
  },
  plugins: [
    new ProgressBarPlugin({
      format: `build [:bar] :percent  (:elapsed seconds)`,
      clear: false,
    }),
    new CopyWebPackPlugin({
      patterns: [
        ...AUTO_NOTE_EXTENSIONS_MAPPER_LIST
      ]
    }),
    ...ADDITIONAL_ROUTE_PLUGINS
  ],
};

module.exports = {
  PATHS,
  common,
};
