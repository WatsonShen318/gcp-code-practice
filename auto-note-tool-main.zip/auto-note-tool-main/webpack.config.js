/* eslint-disable import/no-extraneous-dependencies */
const path = require('path');
const { merge } = require('webpack-merge');
const { CleanWebpackPlugin } = require('clean-webpack-plugin');
const MiniCssExtractPlugin = require('mini-css-extract-plugin');
const CssMinimizerPlugin = require('css-minimizer-webpack-plugin');
const TerserPlugin = require('terser-webpack-plugin');
const HtmlWebpackPlugin = require('html-webpack-plugin');
const FileManagerPlugin = require('filemanager-webpack-plugin');
const { common, PATHS } = require('./webpack.common');
const appDetails = require('./package.json');

const { version } = appDetails;
const { noteToolName } = appDetails;
const { name } = appDetails;

module.exports = merge(common, {
  mode: 'production',
  output: {
    filename: `${PATHS.static}[name].[contenthash].js`,
    path: PATHS.dist,
  },
  optimization: {
    moduleIds: 'deterministic',
    runtimeChunk: {
      name: 'manifest',
    },
    splitChunks: {
      cacheGroups: {
        vendors: {
          test: /[\\/]node_modules[\\/]/,
          chunks: 'all',
          minSize: 0,
          minChunks: 1,
          reuseExistingChunk: true,
          enforce: true,
        },
      },
    },
    minimize: true,
    minimizer: [
      new CssMinimizerPlugin(),
      (compiler) => {
        new TerserPlugin({
          terserOptions: {
            compress: {
              defaults: true,
              // dead_code: true, conditionals: true
            },
          },
        }).apply(compiler);
      },
      new HtmlWebpackPlugin({
        title: `${noteToolName}`,
        template: path.join(PATHS.src, '/index.hbs'),
        inject: 'body',
        filename: `index.html`,
        favicon: './src/assets/heart-logo.png',
        excludeChunks: ['dev.helper'],
        meta: {
          charset: 'utf-8',
          description: `${noteToolName} Version ${version}`,
          viewport: 'width=device-width, initial-scale=1, shrink-to-fit=no',
        },
        minify: {
          removeAttributeQuotes: true,
          collapseWhitespace: true,
          removeComments: true,
          removeRedundantAttributes: true,
          removeScriptTypeAttributes: true,
          removeStyleLinkTypeAttributes: true,
          useShortDoctype: true,
        },
      }),
    ],
  },
  plugins: [
    new MiniCssExtractPlugin({
      filename: `${PATHS.static}[name].[contenthash].css`,
    }),
    new CleanWebpackPlugin(),
    new FileManagerPlugin({
      events: {
        onEnd: [
          {
            delete: [
              {
                source: `${PATHS.deployURL}${name}`,
                options: {
                  force: true,
                },
              },
            ],
          },
          {
            copy: [
              {
                source: PATHS.dist,
                destination: PATHS.deployURL,
                options: {
                  overwrite: true,
                },
              },
            ],
          },
        ],
      },
    }),
    // new HtmlWebpackPlugin({
    //   template: path.join(PATHS.autoNoteExtns, `standard-nf-exception/Standard Non-Formulary Exception Guideline.html`),
    //   filename: `_new_Standard Non-Formulary Exception Guideline.html`
    // }),
    // new HtmlWebpackPlugin({
    //   template: path.join(PATHS.autoNoteExtns, `bvd-nf-exception/BvD Non-Formulary Exception Guideline.html`),
    //   filename: `_new_BvD Non-Formulary Exception Guideline.html`
    // })
  ],
  // devServer: {
  //     host: '0.0.0.0',
  //     port: 8080
  //   },
  module: {
    rules: [
      {
        test: /\.s[ac]ss$/i,
        use: [
          MiniCssExtractPlugin.loader,
          'css-loader',
          'postcss-loader',
          'sass-loader',
        ],
      },
    ],
  },
});
