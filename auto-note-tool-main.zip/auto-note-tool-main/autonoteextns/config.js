const path = require('path');
const HtmlWebpackPlugin = require('html-webpack-plugin');

/** Config List of AUTO_NOTE_EXTENSIONS to be part of build assets  */
const AUTO_NOTE_EXTENSIONS_MAPPER_LIST = [
    {
        from: path.resolve(__dirname, '../autonoteextns/standard-nf-exception/'),
        to: path.resolve(__dirname, '../dist/')
    },
    {
        from: path.resolve(__dirname, '../autonoteextns/bvd-nf-exception/'),
        to: path.resolve(__dirname, '../dist/')
    },
    {
        from: path.resolve(__dirname, '../autonoteextns/cda-part-b-internal-note-tool/'),
        to: path.resolve(__dirname, '../dist/')
    },
    {
        from: path.resolve(__dirname, '../autonoteextns/nlx-part-b-internal-note-tool/'),
        to: path.resolve(__dirname, '../dist/')
    },
    {
        from: path.resolve(__dirname, '../autonoteextns/cdrd-grid/'),
        to: path.resolve(__dirname, '../dist/')
    },
    {
      from: path.resolve(__dirname, '../autonoteextns/quantity-limit-exception/'),
      to: path.resolve(__dirname, '../dist/')
    },
    {
      from: path.resolve(__dirname, '../autonoteextns/diagnosis-required-standard-nf-exception/'),
      to: path.resolve(__dirname, '../dist/')
    },
    {
      from: path.resolve(__dirname, '../autonoteextns/diagnosis-required-protected-drug-class-nf-exception/'),
      to: path.resolve(__dirname, '../dist/')
    },
    {
      from: path.resolve(__dirname, '../autonoteextns/opioid-quantity-limit-925-exception/'),
      to: path.resolve(__dirname, '../dist/')
    },
    {
      from: path.resolve(__dirname, '../autonoteextns/opioid-nf-exception/'),
      to: path.resolve(__dirname, '../dist/')
    },
    {
      from: path.resolve(__dirname, '../autonoteextns/antibacterials-nf-exception/'),
      to: path.resolve(__dirname, '../dist/')
    },
    {
      from: path.resolve(__dirname, '../autonoteextns/diagnosis-required-opioid-nf-exception/'),
      to: path.resolve(__dirname, '../dist/')
    },
    {
      from: path.resolve(__dirname, '../autonoteextns/diagnosis-required-oral-chemotherapy-nf-exception/'),
      to: path.resolve(__dirname, '../dist/')
    },
    {
      from: path.resolve(__dirname, '../autonoteextns/high-risk-drug-class-nf-exception/'),
      to: path.resolve(__dirname, '../dist/')
    },
    {
      from: path.resolve(__dirname, '../autonoteextns/protected-drug-class-nf-exception/'),
      to: path.resolve(__dirname, '../dist/')
    },
    {
      from: path.resolve(__dirname, '../autonoteextns/proton-pump-inhibitor-nf-exception/'),
      to: path.resolve(__dirname, '../dist/')
    },
    {
      from: path.resolve(__dirname, '../autonoteextns/protected-drug-class-infusion-nf-exception/'),
      to: path.resolve(__dirname, '../dist/')
    }
]

/** Additional route Plugins other than index.html entry point to support guideline, part b & part d internal note tools */
const ADDITIONAL_ROUTE_PLUGINS = [
    new HtmlWebpackPlugin({
        template: path.join(__dirname, `standard-nf-exception/Standard Non-Formulary Exception Guideline.html`),
        filename: `_new_Standard Non-Formulary Exception Guideline.html`
      }),
      new HtmlWebpackPlugin({
        template: path.join(__dirname, `bvd-nf-exception/BvD Non-Formulary Exception Guideline.html`),
        filename: `_new_BvD Non-Formulary Exception Guideline.html`
      }),
      new HtmlWebpackPlugin({
        template: path.join(__dirname, `cda-part-b-internal-note-tool/MHK Part B Internal Note Tool.html`),
        filename: `_new_MHK Part B Internal Note Tool.html`
      }),
      new HtmlWebpackPlugin({
        template: path.join(__dirname, `nlx-part-b-internal-note-tool/NLX Part B Internal Note Tool.html`),
        filename: `_new_NLX Part B Internal Note Tool.html`
      }),
      new HtmlWebpackPlugin({
        template: path.join(__dirname, `cdrd-grid/CDRD Grid.html`),
        filename: `_new_CDRD Grid.html`
      }),
      new HtmlWebpackPlugin({
        template: path.join(__dirname, `quantity-limit-exception/Quantity Limit Exception Guideline.html`),
        filename: `_new_Quantity Limit Exception Guideline.html`
      }),
      new HtmlWebpackPlugin({
        template: path.join(__dirname, `diagnosis-required-standard-nf-exception/Diagnosis Required Standard Non-Formulary Exception Guideline.html`),
        filename: `_new_Diagnosis Required Standard Non-Formulary Exception Guideline.html`
      }),
      new HtmlWebpackPlugin({
        template: path.join(__dirname, `diagnosis-required-protected-drug-class-nf-exception/Diagnosis Required Protected Drug Class Non-Formulary Exception Guideline.html`),
        filename: `_new_Diagnosis Required Protected Drug Class Non-Formulary Exception Guideline.html`
      }),
      new HtmlWebpackPlugin({
        template: path.join(__dirname, `opioid-quantity-limit-925-exception/Opioid Quantity Limit - 925 Exception Guidelines.html`),
        filename: `_new_Opioid Quantity Limit - 925 Exception Guidelines.html`
      }),
      new HtmlWebpackPlugin({
        template: path.join(__dirname, `opioid-nf-exception/Opioid Non-Formulary Exception Guideline.html`),
        filename: `_new_Opioid Non-Formulary Exception Guideline.html`
      }),
      new HtmlWebpackPlugin({
        template: path.join(__dirname, `antibacterials-nf-exception/Antibacterials Non-Formulary Exception Guideline.html`),
        filename: `_new_Antibacterials Non-Formulary Exception Guideline.html`
      }),
      new HtmlWebpackPlugin({
        template: path.join(__dirname, `diagnosis-required-opioid-nf-exception/Diagnosis Required Opioid Non-Formulary Exception Guideline.html`),
        filename: `_new_Diagnosis Required Opioid Non-Formulary Exception Guideline.html`
      }),
      new HtmlWebpackPlugin({
        template: path.join(__dirname, `diagnosis-required-oral-chemotherapy-nf-exception/Diagnosis Required Oral Chemotherapy Non-Formulary Exception Guideline.html`),
        filename: `_new_Diagnosis Required Oral Chemotherapy Non-Formulary Exception Guideline.html`
      }),
      new HtmlWebpackPlugin({
        template: path.join(__dirname, `high-risk-drug-class-nf-exception/High Risk Drug Class Non-Formulary Exception Guideline.html`),
        filename: `_new_High Risk Drug Class Non-Formulary Exception Guideline.html`
      }),
      new HtmlWebpackPlugin({
        template: path.join(__dirname, `protected-drug-class-nf-exception/Protected Drug Class Non-Formulary Exception Guideline.html`),
        filename: `_new_Protected Drug Class Non-Formulary Exception Guideline.html`
      }),
      new HtmlWebpackPlugin({
        template: path.join(__dirname, `proton-pump-inhibitor-nf-exception/Proton Pump Inhibitor Non-Formulary Exception Guideline.html`),
        filename: `_new_Proton Pump Inhibitor Non-Formulary Exception Guideline.html`
      }),
      new HtmlWebpackPlugin({
        template: path.join(__dirname, `protected-drug-class-infusion-nf-exception/Protected Drug Class Infusion Non-Formulary Exception Guideline.html`),
        filename: `_new_Protected Drug Class Infusion Non-Formulary Exception Guideline.html`
      })
]

module.exports = {
    AUTO_NOTE_EXTENSIONS_MAPPER_LIST,
    ADDITIONAL_ROUTE_PLUGINS
};