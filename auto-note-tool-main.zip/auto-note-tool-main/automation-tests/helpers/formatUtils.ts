/**
 * Gets the current date in the specified format.
 *
 * @param formatType - The format type for the date. Options:
 *                     - "MM/dd/yyyy" (default): 07/25/2025
 *                     - "MM-dd-yyyy": 07-25-2025
 *                     - "yyyy-MM-dd": 2025-07-25
 *                     - "dd/MM/yyyy": 25/07/2025
 *                     - "MM/dd/yy": 07/25/25
 * @returns Current date in the specified format.
 */
export function getCurrentDate(formatType: string = "MM/dd/yyyy"): string {
    const currentDate = new Date();

    try {
        switch (formatType) {
            case "MM/dd/yyyy":
                return `${pad(currentDate.getMonth() + 1)}/${pad(currentDate.getDate())}/${currentDate.getFullYear()}`;
            case "MM-dd-yyyy":
                return `${pad(currentDate.getMonth() + 1)}-${pad(currentDate.getDate())}-${currentDate.getFullYear()}`;
            case "yyyy-MM-dd":
                return `${currentDate.getFullYear()}-${pad(currentDate.getMonth() + 1)}-${pad(currentDate.getDate())}`;
            case "dd/MM/yyyy":
                return `${pad(currentDate.getDate())}/${pad(currentDate.getMonth() + 1)}/${currentDate.getFullYear()}`;
            case "MM/dd/yy":
                return `${pad(currentDate.getMonth() + 1)}/${pad(currentDate.getDate())}/${currentDate.getFullYear().toString().slice(-2)}`;
            default:
                console.warn(`Unknown format '${formatType}', using default MM/dd/yyyy`);
                return `${pad(currentDate.getMonth() + 1)}/${pad(currentDate.getDate())}/${currentDate.getFullYear()}`;
        }
    } catch (error) {
        console.error(`Error formatting date: ${error}`);
        return `${pad(currentDate.getMonth() + 1)}/${pad(currentDate.getDate())}/${currentDate.getFullYear()}`; // Fallback to default
    }
}

export function pad(value: number): string {
    // Helper function to pad single-digit numbers with a leading zero
    return value.toString().padStart(2, "0");
}