import { Page } from '@playwright/test';

const SHOW_CONSOLE_LOG = true;

/**
 * Clicks an element by its ID and waits for specified time after the click.
 */
export async function clickByElementId(
  page: Page,
  elementId: string,
  delay: number = 0,
  induceDelay: boolean = true,
  enableScrolling: boolean = true
): Promise<void> {
  SHOW_CONSOLE_LOG && console.log(`       -> Clicking element with ID: ${elementId}`);
  try {
    const locator = page.locator(`#${elementId}`);
    if(enableScrolling) {
      await locator.scrollIntoViewIfNeeded();
    }
    if (induceDelay) {
      await page.waitForTimeout(delay);
    }
    await locator.click();
    SHOW_CONSOLE_LOG && console.log(`       -> Successfully clicked element: ${elementId}`);
  } catch (error) {
    console.error(`Failed to click element ${elementId}: ${error}`);
    throw error;
  }
}

/**
 * Fills a text input element by its ID and waits for specified time after filling.
 */
export async function fillTextByElementId(
  page: Page,
  elementId: string,
  text: string,
  delay: number = 0,
  induceDelay: boolean = true
): Promise<void> {
  SHOW_CONSOLE_LOG && console.log(`       -> Filling element with ID: ${elementId} with text: '${text}'`);
  try {
    const locator = page.locator(`#${elementId}`);
    await locator.scrollIntoViewIfNeeded();
    if (induceDelay) {
      await page.waitForTimeout(delay);
    }
    await locator.fill(text);
    SHOW_CONSOLE_LOG && console.log(`       -> Successfully filled element: ${elementId}`);
  } catch (error) {
    console.error(`Failed to fill element ${elementId}: ${error}`);
    throw error;
  }
}

/**
 * Scrolls an element to the bottom.
 */
export async function scrollElementToBottom(page: Page, elementId: string): Promise<void> {
  SHOW_CONSOLE_LOG && console.log(`       -> Scrolling element to bottom: ${elementId}`);
  try {
    await page.evaluate((id) => {
      const element = document.getElementById(id);
      if (element) {
        element.scrollTop = element.scrollHeight;
      }
    }, elementId);
    SHOW_CONSOLE_LOG && console.log(`       -> Successfully scrolled element to bottom: ${elementId}`);
  } catch (error) {
    console.error(`Failed to scroll element ${elementId} to bottom: ${error}`);
    throw error;
  }
}

/**
 * Clicks the OK button in a modal if it appears.
 */
export async function clickModalOkButton(page: Page, timeout: number = 1000): Promise<void> {
  SHOW_CONSOLE_LOG && console.log('       -> Checking for modal OK button');
  try {
    const okButton = page.locator('div.modal-footer >> button.btn.btn-primary');
    await okButton.click({ timeout });
  } catch (error) {
    console.warn(`Modal handling: ${error}`);
    // Modal might not appear, continue with test
  }
}

/**
 * Checks a radio button by its ID, enables it if disabled, and waits for specified time.
 */
export async function checkRadioButtonById(
  page: Page,
  elementId: string,
  delay: number = 0,
  induceDelay: boolean = true,
  enableIfDisabled: boolean = true
): Promise<void> {
  SHOW_CONSOLE_LOG && console.log(`       -> Checking radio button with ID: ${elementId}`);
  try {
    const locator = page.locator(`#${elementId}`);
    await locator.scrollIntoViewIfNeeded();

    const isDisabled = await locator.isDisabled();
    if (isDisabled && enableIfDisabled) {
      SHOW_CONSOLE_LOG && console.log(`       -> Radio button ${elementId} is disabled, enabling it`);
      await page.evaluate((id) => {
        const element = document.getElementById(id);
        if (element) {
          element.removeAttribute('disabled');
        }
      }, elementId);
      SHOW_CONSOLE_LOG && console.log(`       -> Enabled radio button: ${elementId}`);
    }

    const isChecked = await locator.isChecked();
    if (isChecked) {
      SHOW_CONSOLE_LOG && console.log(`       -> Radio button ${elementId} is already checked`);
    } else {
      await page.evaluate((selector) => {
        const element = document.querySelector(selector) as HTMLInputElement;
        if(element) {
            element.checked = true;
        }
      }, `#${elementId}`)
      SHOW_CONSOLE_LOG && console.log(`       -> Successfully checked radio button: ${elementId}`);
    }

    if (induceDelay) {
      await page.waitForTimeout(delay);
    }
  } catch (error) {
    console.error(`Failed to check radio button ${elementId}: ${error}`);
    throw error;
  }
}

/**
 * Removes an attribute from an element by its ID.
 */
export async function removeAttributeById(
  page: Page,
  elementId: string,
  attributeName: string
): Promise<void> {
  SHOW_CONSOLE_LOG && console.log(`       -> Removing '${attributeName}' attribute from element with ID: ${elementId}`);
  try {
    await page.evaluate(
      (args) => {
        const { id, attr } = args;
        const element = document.getElementById(id);
        if (element) {
          element.removeAttribute(attr);
        }
      },
      { id: elementId, attr: attributeName }
    );
    SHOW_CONSOLE_LOG && console.log(`       -> Successfully removed '${attributeName}' attribute from element: ${elementId}`);
  } catch (error) {
    console.error(`Failed to remove attribute from element ${elementId}: ${error}`);
    throw error;
  }
}

/**
 * Selects an option from a dropdown/select element by its ID.
 */
export async function selectOptionById(
  page: Page,
  elementId: string,
  optionValue: string,
  delay: number = 0,
  induceDelay: boolean = true
): Promise<void> {
  SHOW_CONSOLE_LOG && console.log(`       -> Selecting option '${optionValue}' from element with ID: ${elementId}`);
  try {
    const locator = page.locator(`#${elementId}`);
    await locator.scrollIntoViewIfNeeded();
    if (induceDelay) {
      await page.waitForTimeout(delay);
    }
    await locator.selectOption(optionValue);
    SHOW_CONSOLE_LOG && console.log(`       -> Successfully selected option '${optionValue}' from element: ${elementId}`);
  } catch (error) {
    console.error(`Failed to select option from element ${elementId}: ${error}`);
    throw error;
  }
}