import { defineConfig } from '@playwright/test';

export default defineConfig({
  testDir: './automation-tests',
  use: {
    headless: false,
    // baseURL: 'https://auto-note-tool.pdev.cvshealth.com',
    baseURL: 'http://localhost:8080',
    screenshot: 'only-on-failure',
    video: 'retain-on-failure',
  },
});