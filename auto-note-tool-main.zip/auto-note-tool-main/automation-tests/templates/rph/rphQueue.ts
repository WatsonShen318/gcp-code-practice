import { Page, expect } from '@playwright/test';
import {
  clickByElementId,
  fillTextByElementId,
  clickModalOkButton,
  checkRadioButtonById,
  removeAttributeById,
  selectOptionById,
} from '../../helpers/webPageActions';
import { getCurrentDate } from '../../helpers/formatUtils';

const templateName = 'rphQueue';

export async function rphQueueAutomatedFlow(page: Page) {
  console.log('Starting Rph Queue Automated flow\n');
  console.log('Actions:');

  await clickByElementId(page, 'RphRoletab', 500);
  await page.click('label[for="rphoriginQQueue"]');
  await page.waitForTimeout(500);
  await fillTextByElementId(page, `${templateName}caseIdQlt`, 'M25Z74E3BCM');
  await clickByElementId(page, `${templateName}caseIdQbtn`, 1000);
  await fillTextByElementId(page, `${templateName}subFormularyIDQtxt`, '00023356');
  await clickByElementId(page, `${templateName}validatedMemberQYes`);
  await fillTextByElementId(page, `${templateName}diagnosisQlt`, 'Test Diagnosis');
  await clickByElementId(page, `${templateName}approveDiagoQNA`);
  await clickByElementId(page, `${templateName}claimQNo`);
  await clickByElementId(page, `${templateName}claim90dQYes`);
  await fillTextByElementId(page, `${templateName}subclaim90dQtxt`, '11/11/1111');
  await fillTextByElementId(page, `${templateName}subreject90dQtxt`, '06');
  await clickByElementId(page, `${templateName}spprSatementQYes`);
  await fillTextByElementId(page, `${templateName}subspprSatementLocationQspprSatementtxt`, 'Test Location');
  await clickByElementId(page, `${templateName}tierRqstQNo`);
  await clickByElementId(page, `${templateName}matchCaseQNo`);
  await clickByElementId(page, `${templateName}RFITATCaseReviewedQNo`);
  await fillTextByElementId(page, `${templateName}rationalQlt`, 'Test Decision/Routing Rationale');
  await clickByElementId(page, `${templateName}LetterPreviewQLetterpreviewed`);
  await clickByElementId(page, `${templateName}mdReviewQYes`);
  await clickByElementId(page, `${templateName}rphDck`);
  await clickByElementId(page, `${templateName}outboundQNo`, 0, true, false);
  await clickByElementId(page, `${templateName}memberMultiDrugQNo`, 0, true, false);
  await clickByElementId(page, `${templateName}newAttachQNo`, 0, true, false);

  await clickByElementId(page, 'generateNotebtn', 100, true, false);
  const noteValue = await page.inputValue('#finalNote');
  console.log(`\nGenerated Notes:\n${noteValue}`);
  const expectedContent = `Title: Rph\nValidated Member using 3 identifiers: Yes\nPriority: Expedited\nClient: Aetna MAPD\nFormulary ID: 00023356\nDoes case have a manual time stamp?: No\nDiagnosis: Test Diagnosis\nCompendia supported?: N/A\nDrug: PERCOCET Tablet 5/325/MG    Qty/DS: 120/30\nReject Code: 06 on 11/11/1111. Paid on ${getCurrentDate()}.\nRequest Reason: Non-formulary\nTiering: No\nMatching In-Progress Cases: No\nRequest Type: RD\nSupporting Statement: Yes \nLocation of Supporting Statement: Test Location\nRFI TAT case reviewed by a technician: No\nDecision/Routing Rationale: Test Decision/Routing Rationale\nCase Decision/Routing: Denied\nNew Attachments Received: No\nIs the denial for a status reason that does NOT require MD review for RD denial?: Yes\nOutbound Call Made and Documented on Outbound Contact Tab: No`;

  expect(noteValue).toContain(expectedContent);
  console.log('Rph Q Automated flow completed successfully');
}

export async function rphQueueManualFlow(page: Page) {
  console.log('Starting Rph Queue Manual flow\n');
  console.log('Actions:');

  await clickByElementId(page, 'RphRoletab', 500);
  await page.click('label[for="rphoriginQQueue"]');
  await page.waitForTimeout(500);
  await fillTextByElementId(page, `${templateName}caseIdQlt`, 'M24XXXXXXXX');
  await clickByElementId(page, `${templateName}caseIdQbtn`, 1000);
  await clickByElementId(page, `${templateName}manualTemplateBtn`);
  await selectOptionById(page, `${templateName}clientQsel`, 'Aetna MAPD');
  await fillTextByElementId(page, `${templateName}subFormularyIDQtxt`, '00023356');
  await clickByElementId(page, `${templateName}validatedMemberQYes`);
  await clickByElementId(page, `${templateName}iPriorityQStandard`);
  await clickByElementId(page, `${templateName}timestampQNo`);
  // await clickByElementId(page, `${templateName}rqstByQMember`);
  // await clickByElementId(page, `${templateName}memberCaseVerifyck`);
  // await clickByElementId(page, `${templateName}hosrdock`);
  // await clickByElementId(page, `${templateName}prescriberVerifyck`);
  // await clickByElementId(page, `${templateName}memberPhVerifyck`);
  // await fillTextByElementId(page, `${templateName}mdoInfoQlt`, 'Test MDO Information');
  await fillTextByElementId(page, `${templateName}drugNameQtxt`, 'Aspirin 100mg');
  await fillTextByElementId(page, `${templateName}qtytxt`, '120');
  await fillTextByElementId(page, `${templateName}dstxt`, '30');
  // await clickByElementId(page, `${templateName}qtyDSMHKck`);
  await fillTextByElementId(page, `${templateName}diagnosisQlt`, 'Test Diagnosis');
  await clickByElementId(page, `${templateName}approveDiagoQNA`);
  // await clickByElementId(page, `${templateName}ePAQNo`);
  await clickByElementId(page, `${templateName}claimQNo`);
  await clickByElementId(page, `${templateName}claim90dQYes`);
  await fillTextByElementId(page, `${templateName}subclaim90dQtxt`, '11/11/1111');
  await fillTextByElementId(page, `${templateName}subreject90dQtxt`, '06');
  await selectOptionById(page, `${templateName}rqstReasonQsel`, 'Non-formulary');
  await clickByElementId(page, `${templateName}spprSatementQYes`);
  await fillTextByElementId(page, `${templateName}subspprSatementLocationQspprSatementtxt`, 'Test Location');
  await clickByElementId(page, `${templateName}tierRqstQNo`);
  await clickByElementId(page, `${templateName}matchCaseQNo`);
  await clickByElementId(page, `${templateName}rqstTypeQCD`);
  await clickByElementId(page, `${templateName}RFITATCaseReviewedQNo`);
  await fillTextByElementId(page, `${templateName}rationalQlt`, 'Test Decision/Routing Rationale');
  await selectOptionById(page, `${templateName}routingQsel`, 'Denied');
  await clickByElementId(page, `${templateName}LetterPreviewQLetterpreviewed`, 0, true, false);
  await clickByElementId(page, `${templateName}outboundQNo`, 0, true, false);
  await clickByElementId(page, `${templateName}memberMultiDrugQNo`, 0, true, false);
  await clickByElementId(page, `${templateName}newAttachQNo`, 0, true, false);

  await clickByElementId(page, 'generateNotebtn', 100, true, false);
  const noteValue = await page.inputValue('#finalNote');
  console.log(`\nGenerated Notes:\n${noteValue}`);
  const expectedContent = `Title: Rph\nValidated Member using 3 identifiers: Yes\nPriority: Standard\nClient: Aetna MAPD\nFormulary ID: 00023356\nDoes case have a manual time stamp?: No\nDiagnosis: Test Diagnosis\nCompendia supported?: N/A\nDrug: Aspirin 100mg    Qty/DS: 120/30\nReject Code: 06 on 11/11/1111. Paid on ${getCurrentDate()}.\nRequest Reason: Non-formulary\nTiering: No\nMatching In-Progress Cases: No\nRequest Type: CD\nSupporting Statement: Yes \nLocation of Supporting Statement: Test Location\nRFI TAT case reviewed by a technician: No\nDecision/Routing Rationale: Test Decision/Routing Rationale\nCase Decision/Routing: Denied\nNew Attachments Received: No\nOutbound Call Made and Documented on Outbound Contact Tab: No`;

  expect(noteValue).toContain(expectedContent);
  console.log('Rph Q Manual flow completed successfully');
}

export async function rphQueueValidationError(page: Page) {
  console.log('Starting Rph Queue Validation Error flow\n');
  console.log('Actions:');

  await clickByElementId(page, 'RphRoletab', 500);
  await page.click('label[for="rphoriginQQueue"]');
  await page.waitForTimeout(500);
  await fillTextByElementId(page, `${templateName}caseIdQlt`, 'M24XXXXXXXX');
  await clickByElementId(page, `${templateName}caseIdQbtn`, 1000);
  await clickByElementId(page, `${templateName}manualTemplateBtn`);
  await selectOptionById(page, `${templateName}clientQsel`, 'Aetna MAPD');
  await fillTextByElementId(page, `${templateName}subFormularyIDQtxt`, '00023356');
  await clickByElementId(page, `${templateName}validatedMemberQYes`);
  await clickByElementId(page, `${templateName}iPriorityQStandard`);
  await clickByElementId(page, `${templateName}timestampQNo`);
  // await clickByElementId(page, `${templateName}rqstByQMember`);
  // await clickByElementId(page, `${templateName}memberCaseVerifyck`);
  // await clickByElementId(page, `${templateName}hosrdock`);
  // await clickByElementId(page, `${templateName}prescriberVerifyck`);
  // await clickByElementId(page, `${templateName}memberPhVerifyck`);
  // await fillTextByElementId(page, `${templateName}mdoInfoQlt`, 'Test MDO Information');
  await fillTextByElementId(page, `${templateName}drugNameQtxt`, 'Aspirin 100mg');
  await fillTextByElementId(page, `${templateName}qtytxt`, '120');
  await fillTextByElementId(page, `${templateName}dstxt`, '30');
  // await clickByElementId(page, `${templateName}qtyDSMHKck`);
  await fillTextByElementId(page, `${templateName}diagnosisQlt`, 'Test Diagnosis');
  await clickByElementId(page, `${templateName}approveDiagoQNA`);
  // await clickByElementId(page, `${templateName}ePAQNo`);
  await clickByElementId(page, `${templateName}claimQNo`);
  await clickByElementId(page, `${templateName}claim90dQYes`);
  await fillTextByElementId(page, `${templateName}subclaim90dQtxt`, '11/11/1111');
  await fillTextByElementId(page, `${templateName}subreject90dQtxt`, '06');
  await selectOptionById(page, `${templateName}rqstReasonQsel`, 'Non-formulary');
  await clickByElementId(page, `${templateName}spprSatementQYes`);
  await fillTextByElementId(page, `${templateName}subspprSatementLocationQspprSatementtxt`, 'Test Location');
  await clickByElementId(page, `${templateName}tierRqstQNo`);
  await clickByElementId(page, `${templateName}matchCaseQNo`);
  await clickByElementId(page, `${templateName}rqstTypeQCD`);
  await clickByElementId(page, `${templateName}RFITATCaseReviewedQNo`);
  await fillTextByElementId(page, `${templateName}rationalQlt`, 'Test Decision/Routing Rationale');
  await selectOptionById(page, `${templateName}routingQsel`, 'Denied');
  await clickByElementId(page, `${templateName}LetterPreviewQLetterpreviewed`, 0, true, false);
  // await clickByElementId(page, `${templateName}outboundQNo`, 0, true, false);
  await clickByElementId(page, `${templateName}memberMultiDrugQNo`, 0, true, false);
  await clickByElementId(page, `${templateName}newAttachQNo`, 0, true, false);

  await clickByElementId(page, 'generateNotebtn', 100, true, false);
  const noteValue = await page.inputValue('#finalNote');

  expect(noteValue).toBe('');
  const tooltip = page.locator(`#${templateName}outboundQ .invalid-tooltip`);
  await expect(tooltip).toBeVisible();
  await expect(tooltip).toHaveText('please answer outbound call');

  console.log('Rph Q Validation Error flow completed successfully. No notes generated.');
}