import { Page, expect } from '@playwright/test';
import { clickByElementId, fillTextByElementId } from '../../helpers/webPageActions';

export async function techSRAutomatedFlow(page: Page) {
  await clickByElementId(page, 'TechRoletab', 200);
  await page.click('label[for="techoriginQSR"]');
  await page.waitForTimeout(100);
  await fillTextByElementId(page, 'techSRcaseIdQlt', 'M25Z74E3BCM');
  await clickByElementId(page, 'techSRcaseIdQbtn', 1000);
  await clickByElementId(page, 'techSRmemberQblacktext');
  await clickByElementId(page, 'techSRvalidatedMemberQYes');
  await clickByElementId(page, 'techSRiPriorityQStandard');
  await fillTextByElementId(page, 'techSRdiagnosisQlt', 'Test Diagnosis');
  await fillTextByElementId(page, 'techSRrationalQlt', 'Test Decision/Routing Rationale');
  await page.selectOption('#techSRroutingQsel', 'Dismissed');
  await clickByElementId(page, 'techSRoutboundQNo', 0, true, false);

  await clickByElementId(page, 'generateNotebtn', 100, true, false);
  const noteValue = await page.inputValue('#finalNote');
  expect(noteValue).toContain('Title: Tech\nValidated Member using 3 identifiers: Yes\nPriority: Standard\nClient: Aetna\nDoes case have a manual time stamp?: No\nDrug: PERCOCET Tablet 5/325/MG    Qty/DS: 120/30\nDiagnosis: Test Diagnosis\nRequest Reason: Non-formulary\nTiering: N/A\nDecision/Routing Rationale: Test Decision/Routing Rationale\nCase Decision/Routing: Dismissed. \nOutbound Call Made and Documented on Outbound Contact Tab: No');
}

export async function techSRManualFlow(page: Page) {
  await clickByElementId(page, 'TechRoletab', 200);
  await page.click('label[for="techoriginQSR"]');
  await page.waitForTimeout(100);
  await fillTextByElementId(page, 'techSRcaseIdQlt', 'M25XXXXXXXX');
  await clickByElementId(page, 'techSRcaseIdQbtn', 1000);
  await clickByElementId(page, 'techSRmanualTemplateBtn');
  await clickByElementId(page, 'techSRmemberQblacktext');
  await clickByElementId(page, 'techSRvalidatedMemberQYes');
  await clickByElementId(page, 'techSRiPriorityQStandard');
  await fillTextByElementId(page, 'techSRclientKeyinQtxt', 'Aetna');
  await clickByElementId(page, 'techSRtimestampQNo');
  // await fillTextByElementId(page, 'techSRmdoInfoQlt', 'Test MDO Information');
  // await clickByElementId(page, 'techSRrqstByQMember');
  // await clickByElementId(page, 'techSRhosrdock');
  // await clickByElementId(page, 'techSRprescriberVerifyck');
  // await clickByElementId(page, 'techSRmemberPhVerifyck');
  await fillTextByElementId(page, 'techSRdrugNameQtxt', 'Test Drug Name');
  await fillTextByElementId(page, 'techSRqtytxt', '120');
  await fillTextByElementId(page, 'techSRdstxt', '30');
  // await clickByElementId(page, 'techSRqtyDSMHKck');
  await fillTextByElementId(page, 'techSRdiagnosisQlt', 'Test Diagnosis');
  // await clickByElementId(page, 'techSRePAQNo');
  await page.selectOption('#techSRrqstReasonQsel', 'Non-formulary');
  await fillTextByElementId(page, 'techSRrationalQlt', 'Test Decision/Routing Rationale');
  await page.selectOption('#techSRroutingQsel', 'Dismissed');
  await clickByElementId(page, 'techSRoutboundQNo', 0, true, false);

  await clickByElementId(page, 'generateNotebtn', 100, true, false);
  const noteValue = await page.inputValue('#finalNote');
  expect(noteValue).toContain('Title: Tech\nValidated Member using 3 identifiers: Yes\nPriority: Standard\nClient: Aetna\nDoes case have a manual time stamp?: No\nDrug: Test Drug Name    Qty/DS: 120/30\nDiagnosis: Test Diagnosis\nRequest Reason: Non-formulary\nTiering: N/A\nDecision/Routing Rationale: Test Decision/Routing Rationale\nCase Decision/Routing: Dismissed. \nOutbound Call Made and Documented on Outbound Contact Tab: No');
}

export async function techSRValidationError(page: Page) {
  await clickByElementId(page, 'TechRoletab', 200);
  await page.click('label[for="techoriginQSR"]');
  await page.waitForTimeout(100);
  await fillTextByElementId(page, 'techSRcaseIdQlt', 'M25XXXXXXXX');
  await clickByElementId(page, 'techSRcaseIdQbtn', 1000);
  await clickByElementId(page, 'techSRmanualTemplateBtn');
  await clickByElementId(page, 'techSRmemberQblacktext');
  await clickByElementId(page, 'techSRvalidatedMemberQYes');
  await clickByElementId(page, 'techSRiPriorityQStandard');
  await fillTextByElementId(page, 'techSRclientKeyinQtxt', 'Aetna');
  await clickByElementId(page, 'techSRtimestampQNo');
  // await fillTextByElementId(page, 'techSRmdoInfoQlt', 'Test MDO Information');
  // await clickByElementId(page, 'techSRrqstByQMember');
  // await clickByElementId(page, 'techSRhosrdock');
  // await clickByElementId(page, 'techSRprescriberVerifyck');
  // await clickByElementId(page, 'techSRmemberPhVerifyck');
  await fillTextByElementId(page, 'techSRdrugNameQtxt', 'Test Drug Name');
  await fillTextByElementId(page, 'techSRqtytxt', '120');
  await fillTextByElementId(page, 'techSRdstxt', '30');
  // await clickByElementId(page, 'techSRqtyDSMHKck');
  await fillTextByElementId(page, 'techSRdiagnosisQlt', 'Test Diagnosis');
  // await clickByElementId(page, 'techSRePAQNo');
  await page.selectOption('#techSRrqstReasonQsel', 'Non-formulary');
  await fillTextByElementId(page, 'techSRrationalQlt', 'Test Decision/Routing Rationale');
  await page.selectOption('#techSRroutingQsel', 'Dismissed');
  // await clickByElementId(page, 'techSRoutboundQNo', 0, true, false);

  await clickByElementId(page, 'generateNotebtn', 100, true, false);
  const noteValue = await page.inputValue('#finalNote');
  expect(noteValue).toContain('');
  const tooltip = page.locator('#techSRoutboundQ .invalid-tooltip');
  await expect(tooltip).toBeVisible();
  await expect(tooltip).toHaveText('please answer outbound call');
}