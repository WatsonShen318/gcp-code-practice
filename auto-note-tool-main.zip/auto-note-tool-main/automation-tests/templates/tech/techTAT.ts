import { Page, expect } from '@playwright/test';
import {
  clickByElementId,
  fillTextByElementId,
  clickModalOkButton,
  checkRadioButtonById,
  removeAttributeById,
  selectOptionById,
} from '../../helpers/webPageActions';
import { getCurrentDate } from '../../helpers/formatUtils';

const templateName = 'techTAT';

export async function techTATAutomatedFlow(page: Page) {
  console.log('Starting Tech TAT Automated flow\n');
  console.log('Actions:');

  await clickByElementId(page, 'TechRoletab', 1000);
  await page.click('label[for="techoriginQTAT"]');
  await page.waitForTimeout(1000);
  await fillTextByElementId(page, `${templateName}caseIdQlt`, 'M25Z74E3BCM');
  await clickByElementId(page, `${templateName}caseIdQbtn`, 1000);
  await clickByElementId(page, `${templateName}validatedMemberQYes`);
  await fillTextByElementId(page, `${templateName}diagnosisQlt`, 'Test Diagnosis');
  await clickByElementId(page, `${templateName}approveDiagoQNA`);
  await clickByElementId(page, `${templateName}rqstTCck`);
  await clickByElementId(page, `${templateName}checkASTATck`);
  await clickByElementId(page, `${templateName}spptInfoTATcheckck`);
  await clickByElementId(page, `${templateName}ConsiderspptCheckck`);
  await clickByElementId(page, `${templateName}tierRqstQNo`);
  await clickByElementId(page, `${templateName}matchCaseQNo`);
  await selectOptionById(page, `${templateName}guidelineQsel`, 'N/A');
  await fillTextByElementId(page, `${templateName}subguidelineQlt`, 'N/A');
  await fillTextByElementId(page, `${templateName}rationalQlt`, 'Test Decision/Routing Rationale');
  await selectOptionById(page, `${templateName}routingQsel`, 'Forward to Clinical');
  await clickByElementId(page, `${templateName}rfiFaxTemplateQYes`);
  await clickByElementId(page, `${templateName}threeOutreachAttemptsQYes`);
  await clickByElementId(page, `${templateName}failedFaxQNo`);
  await clickByElementId(page, `${templateName}outboundQNo`, 0, true, false);
  await clickByElementId(page, `${templateName}newAttachQNo`, 0, true, false);
  await clickModalOkButton(page);
  await clickByElementId(page, 'generateNotebtn', 100, true, false);

  const noteValue = await page.inputValue('#finalNote');
  console.log(`\nGenerated Notes:\n${noteValue}`);
  const expectedContent = `Title: Tech
Validated Member using 3 identifiers: Yes
Priority: Expedited
Client: Aetna MAPD
Does case have a manual time stamp?: No
Diagnosis: Test Diagnosis
Compendia supported?: N/A
Drug: PERCOCET Tablet 5/325/MG    Qty/DS: 120/30
Request Reason: Non-formulary
Tiering: No
Matching In-Progress Cases: No
Denied case on the member's current line of eligibility in the past 65 days: No
Request Type: CD CD/RD Grid Answers: Q1=No, Q1a=No
Exception Guideline: N/A
Exception Question Answers: N/A
Decision/Routing Rationale: Test Decision/Routing Rationale
Case Decision/Routing: Forward to Clinical
New Attachments Received: No
Outbound Call Made and Documented on Outbound Contact Tab: No`;

  expect(noteValue).toContain(expectedContent);
  console.log('Tech TAT Automated flow completed successfully');
}

export async function techTATManualFlow(page: Page) {
  console.log('Starting Tech TAT Manual flow\n');
  console.log('Actions:');

  await clickByElementId(page, 'TechRoletab', 1000);
  await page.click('label[for="techoriginQTAT"]');
  await page.waitForTimeout(1000);
  await fillTextByElementId(page, `${templateName}caseIdQlt`, 'M24XXXXXXXX');
  await clickByElementId(page, `${templateName}caseIdQbtn`, 1000);
  await clickByElementId(page, `${templateName}manualTemplateBtn`);
  await selectOptionById(page, `${templateName}clientQsel`, 'Aetna MAPD');
  await clickByElementId(page, `${templateName}validatedMemberQYes`);
  await clickByElementId(page, `${templateName}iPriorityQStandard`);
  await clickByElementId(page, `${templateName}timestampQNo`);
  // await clickByElementId(page, `${templateName}memberCaseVerifyck`);
  // await clickByElementId(page, `${templateName}hosrdock`);
  // await clickByElementId(page, `${templateName}prescriberVerifyck`);
  // await clickByElementId(page, `${templateName}memberPhVerifyck`);
  // await fillTextByElementId(page, `${templateName}mdoInfoQlt`, 'Test MDO Information');
  await fillTextByElementId(page, `${templateName}drugNameQtxt`, 'Aspirin 100mg');
  await fillTextByElementId(page, `${templateName}qtytxt`, '120');
  await fillTextByElementId(page, `${templateName}dstxt`, '30');
  // await clickByElementId(page, `${templateName}qtyDSMHKck`);
  await fillTextByElementId(page, `${templateName}diagnosisQlt`, 'Test Diagnosis');
  await clickByElementId(page, `${templateName}approveDiagoQNA`);
  await selectOptionById(page, `${templateName}rqstReasonQsel`, 'Non-formulary');
  await clickByElementId(page, `${templateName}rqstTCck`);
  await clickByElementId(page, `${templateName}checkASTATck`);
  await clickByElementId(page, `${templateName}spptInfoTATcheckck`);
  await clickByElementId(page, `${templateName}ConsiderspptCheckck`);
  await clickByElementId(page, `${templateName}tierRqstQNo`);
  await clickByElementId(page, `${templateName}matchCaseQNo`);
  await checkRadioButtonById(page, `${templateName}rqstTypeDeniedQNo`);
  await removeAttributeById(page, `${templateName}rqstTypeQ`, 'disabled');
  await clickByElementId(page, `${templateName}rqstTypeQCD`);
  await selectOptionById(page, `${templateName}guidelineQsel`, 'N/A');
  await fillTextByElementId(page, `${templateName}subguidelineQlt`, 'N/A');
  await fillTextByElementId(page, `${templateName}rationalQlt`, 'Test Decision/Routing Rationale');
  await selectOptionById(page, `${templateName}routingQsel`, 'Forward to Clinical');
  await clickByElementId(page, `${templateName}rfiFaxTemplateQYes`);
  await clickByElementId(page, `${templateName}threeOutreachAttemptsQYes`);
  await clickByElementId(page, `${templateName}failedFaxQNo`);
  await clickByElementId(page, `${templateName}outboundQNo`, 0, true, false);
  await clickByElementId(page, `${templateName}newAttachQNo`, 0, true, false);
  await clickModalOkButton(page);

  await clickByElementId(page, 'generateNotebtn', 100, true, false);
  const noteValue = await page.inputValue('#finalNote');
  console.log(`\nGenerated Notes:\n${noteValue}`);
  const expectedContent = `Title: Tech
Validated Member using 3 identifiers: Yes
Priority: Standard
Client: Aetna MAPD
Does case have a manual time stamp?: No
Diagnosis: Test Diagnosis
Compendia supported?: N/A
Drug: Aspirin 100mg    Qty/DS: 120/30
Request Reason: Non-formulary
Tiering: No
Matching In-Progress Cases: No
Denied case on the member's current line of eligibility in the past 65 days: No
Request Type: CD CD/RD Grid Answers: Q1=No, Q1a=No
Exception Guideline: N/A
Exception Question Answers: N/A
Decision/Routing Rationale: Test Decision/Routing Rationale
Case Decision/Routing: Forward to Clinical
New Attachments Received: No
Outbound Call Made and Documented on Outbound Contact Tab: No`;

  expect(noteValue).toContain(expectedContent);
  console.log('Tech TAT Manual flow completed successfully');
}

export async function techTATValidationError(page: Page) {
  console.log('Starting Tech TAT Validation Error flow\n');
  console.log('Actions:');

  await clickByElementId(page, 'TechRoletab', 1000);
  await page.click('label[for="techoriginQTAT"]');
  await page.waitForTimeout(1000);
  await fillTextByElementId(page, `${templateName}caseIdQlt`, 'M24XXXXXXXX');
  await clickByElementId(page, `${templateName}caseIdQbtn`, 1000);
  await clickByElementId(page, `${templateName}manualTemplateBtn`);
  await selectOptionById(page, `${templateName}clientQsel`, 'Aetna MAPD');
  await clickByElementId(page, `${templateName}validatedMemberQYes`);
  await clickByElementId(page, `${templateName}iPriorityQStandard`);
  await clickByElementId(page, `${templateName}timestampQNo`);
  // await clickByElementId(page, `${templateName}memberCaseVerifyck`);
  // await clickByElementId(page, `${templateName}hosrdock`);
  // await clickByElementId(page, `${templateName}prescriberVerifyck`);
  // await clickByElementId(page, `${templateName}memberPhVerifyck`);
  // await fillTextByElementId(page, `${templateName}mdoInfoQlt`, 'Test MDO Information');
  await fillTextByElementId(page, `${templateName}drugNameQtxt`, 'Aspirin 100mg');
  await fillTextByElementId(page, `${templateName}qtytxt`, '120');
  await fillTextByElementId(page, `${templateName}dstxt`, '30');
  // await clickByElementId(page, `${templateName}qtyDSMHKck`);
  await fillTextByElementId(page, `${templateName}diagnosisQlt`, 'Test Diagnosis');
  await clickByElementId(page, `${templateName}approveDiagoQNA`);
  await selectOptionById(page, `${templateName}rqstReasonQsel`, 'Non-formulary');
  await clickByElementId(page, `${templateName}rqstTCck`);
  await clickByElementId(page, `${templateName}checkASTATck`);
  await clickByElementId(page, `${templateName}spptInfoTATcheckck`);
  await clickByElementId(page, `${templateName}ConsiderspptCheckck`);
  await clickByElementId(page, `${templateName}tierRqstQNo`);
  await clickByElementId(page, `${templateName}matchCaseQNo`);
  await checkRadioButtonById(page, `${templateName}rqstTypeDeniedQNo`);
  await removeAttributeById(page, `${templateName}rqstTypeQ`, 'disabled');
  await clickByElementId(page, `${templateName}rqstTypeQCD`);
  await selectOptionById(page, `${templateName}guidelineQsel`, 'N/A');
  await fillTextByElementId(page, `${templateName}subguidelineQlt`, 'N/A');
  await fillTextByElementId(page, `${templateName}rationalQlt`, 'Test Decision/Routing Rationale');
  await selectOptionById(page, `${templateName}routingQsel`, 'Forward to Clinical');
  await clickByElementId(page, `${templateName}rfiFaxTemplateQYes`);
  await clickByElementId(page, `${templateName}threeOutreachAttemptsQYes`);
  await clickByElementId(page, `${templateName}failedFaxQNo`, 0, true, false);
  await clickByElementId(page, `${templateName}newAttachQNo`, 0, true, false);
  await clickModalOkButton(page);

  await clickByElementId(page, 'generateNotebtn', 100, true, false);
  const noteValue = await page.inputValue('#finalNote');

  expect(noteValue).toBe('');
  const tooltip = page.locator(`#${templateName}outboundQ .invalid-tooltip`);
  await expect(tooltip).toBeVisible();
  await expect(tooltip).toHaveText('please answer outbound call');

  console.log('Tech TAT Validation Error flow completed successfully. No notes generated.');
}