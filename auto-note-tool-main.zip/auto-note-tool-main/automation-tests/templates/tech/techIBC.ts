import { Page, expect } from '@playwright/test';
import {
  clickByElementId,
  fillTextByElementId,
  clickModalOkButton,
  checkRadioButtonById,
  removeAttributeById,
  selectOptionById,
} from '../../helpers/webPageActions';
import { getCurrentDate } from '../../helpers/formatUtils';

const templateName = 'techIBC';

export async function techIBCAutomatedFlow(page: Page) {
  console.log('Starting Tech IBC Automated flow\n');
  console.log('Actions:');

  await clickByElementId(page, 'TechRoletab', 1000);
  await page.click('label[for="techoriginQIBC"]');
  await page.waitForTimeout(1000);
  await clickByElementId(page, `${templateName}careAgentQNo`);
  await clickByElementId(page, `${templateName}validatedMemberQNo`);
  await clickByElementId(page, `${templateName}inProgressCaseQYes`);
  await fillTextByElementId(page, `${templateName}caseIdQlt`, 'M25Z74E3BCM');
  await clickByElementId(page, `${templateName}caseIdQbtn`, 1000);
  await fillTextByElementId(page, `${templateName}subFormularyIDQtxt`, '00023356');
  await clickByElementId(page, `${templateName}rqstByQMember`);
  await clickByElementId(page, `${templateName}subrqstByCallerQNo`);
  await clickByElementId(page, `${templateName}inquiryQNo`);
  await clickByElementId(page, `${templateName}claimQNo`);
  await clickByElementId(page, `${templateName}claim90dQYes`);
  await fillTextByElementId(page, `${templateName}subclaim90dQtxt`, '11/11/1111');
  await fillTextByElementId(page, `${templateName}subreject90dQtxt`, '06');
  await clickByElementId(page, `${templateName}eagQAAFNR`);
  await clickByElementId(page, `${templateName}subaafnrCaseQNo`);
  await clickByElementId(page, `${templateName}tierRqstQNo`);
  await clickByElementId(page, `${templateName}matchCaseQNo`);
  await selectOptionById(page, `${templateName}guidelineQsel`, 'N/A');
  await fillTextByElementId(page, `${templateName}subguidelineQlt`, 'N/A');
  await fillTextByElementId(page, `${templateName}treidFailQtxt`, 'Test Medications');
  await fillTextByElementId(page, `${templateName}diagnosisQlt`, 'Test Diagnosis');
  await clickByElementId(page, `${templateName}approveDiagoQNA`);
  await fillTextByElementId(page, `${templateName}rationalQlt`, 'Test Decision/Routing Rationale');
  await selectOptionById(page, `${templateName}routingQsel`, 'Forward to Clinical');
  await clickByElementId(page, `${templateName}outboundQNo`, 0, true, false);
  await clickByElementId(page, `${templateName}memberMultiDrugQNo`, 0, true, false);
  await clickByElementId(page, `${templateName}newAttachQNo`, 0, true, false);

  await clickByElementId(page, 'generateNotebtn', 100, true, false);
  const noteValue = await page.inputValue('#finalNote');
  console.log(`\nGenerated Notes:\n${noteValue}`);
  const expectedContent = `Title: IBC Tech
Call being transferred to you from CARE agent: No
Validated Member using 3 identifiers: No
Priority: Expedited
Client: Aetna MAPD
Formulary ID: 00023356
Requested by: Member - Spoke with .
Diagnosis: Test Diagnosis
Drug: PERCOCET Tablet 5/325/MG    Qty/DS: 120/30
Reject Code: 06 on 11/11/1111. Paid on ${getCurrentDate()}.
Request Reason: Non-formulary
Tiering: No
Matching In-Progress Cases: No
Denied case on the member's current line of eligibility in the past 65 days: No
Request Type: CD CD/RD Grid Answers: Q1=No, Q1a=No
Exception Guideline: N/A
Exception Question Answers: N/A
Tried and Failed Medications: Test Medications
Decision/Routing Rationale: Test Decision/Routing Rationale
Case Decision/Routing: Forward to Clinical
New Attachments Received: No
Outbound Call Made and Documented on Outbound Contact Tab: No`;

  expect(noteValue).toContain(expectedContent);
  console.log('Tech IBC Automated flow completed successfully');
}

export async function techIBCManualFlow(page: Page) {
  console.log('Starting Tech IBC Manual flow\n');
  console.log('Actions:');

  await clickByElementId(page, 'TechRoletab', 1000);
  await page.click('label[for="techoriginQIBC"]');
  await page.waitForTimeout(1000);
  await clickByElementId(page, `${templateName}careAgentQNo`);
  await clickByElementId(page, `${templateName}validatedMemberQNo`);
  await clickByElementId(page, `${templateName}inProgressCaseQNo`);
  await fillTextByElementId(page, `${templateName}inqcallerQcallertxt`, 'Test First Name, Last Name');
  await selectOptionById(page, `${templateName}clientQsel`, 'Aetna MAPD');
  await fillTextByElementId(page, `${templateName}subFormularyIDQtxt`, '00023356');
  await clickByElementId(page, `${templateName}rqstByQMember`);
  await clickByElementId(page, `${templateName}subrqstByCallerQNo`);
  await fillTextByElementId(page, `${templateName}drugNameQtxt`, 'Aspirin 100mg');
  await fillTextByElementId(page, `${templateName}qtytxt`, '120');
  await fillTextByElementId(page, `${templateName}dstxt`, '30');
  await clickByElementId(page, `${templateName}inquiryQNo`);
  await clickByElementId(page, `${templateName}claimQNo`);
  await clickByElementId(page, `${templateName}claim90dQYes`);
  await fillTextByElementId(page, `${templateName}subclaim90dQtxt`, '11/11/1111');
  await fillTextByElementId(page, `${templateName}subreject90dQtxt`, '06');
  await clickByElementId(page, `${templateName}eagQAAFNR`);
  await clickByElementId(page, `${templateName}subaafnrCaseQNo`);
  await clickByElementId(page, `${templateName}tierRqstQNo`);
  await selectOptionById(page, `${templateName}rqstReasonQsel`, 'Non-formulary');
  await clickByElementId(page, `${templateName}matchCaseQNo`);
  await checkRadioButtonById(page, `${templateName}rqstTypeDeniedQNo`);
  await removeAttributeById(page, `${templateName}rqstTypeQ`, 'disabled');
  await clickByElementId(page, `${templateName}rqstTypeQCD`);
  await selectOptionById(page, `${templateName}guidelineQsel`, 'N/A');
  await fillTextByElementId(page, `${templateName}subguidelineQlt`, 'N/A');
  await fillTextByElementId(page, `${templateName}treidFailQtxt`, 'Test Medications');
  await fillTextByElementId(page, `${templateName}diagnosisQlt`, 'Test Diagnosis');
  await clickByElementId(page, `${templateName}approveDiagoQNA`);
  await clickByElementId(page, `${templateName}iPriorityQStandard`);
  await fillTextByElementId(page, `${templateName}rationalQlt`, 'Test Decision/Routing Rationale');
  await selectOptionById(page, `${templateName}routingQsel`, 'Forward to Clinical');
  await clickByElementId(page, `${templateName}outboundQNo`, 0, true, false);
  await clickByElementId(page, `${templateName}memberMultiDrugQNo`, 0, true, false);
  await clickByElementId(page, `${templateName}newAttachQNo`, 0, true, false);

  await clickByElementId(page, 'generateNotebtn', 100, true, false);
  const noteValue = await page.inputValue('#finalNote');
  console.log(`\nGenerated Notes:\n${noteValue}`);
  const expectedContent = `Title: IBC Tech
Call being transferred to you from CARE agent: No
Validated Member using 3 identifiers: No
Caller: Test First Name, Last Name
Priority: Standard
Client: Aetna MAPD
Formulary ID: 00023356
Requested by: Member - Spoke with .
Diagnosis: Test Diagnosis
Drug: Aspirin 100mg    Qty/DS: 120/30
Reject Code: 06 on 11/11/1111. Paid on ${getCurrentDate()}.
Request Reason: Non-formulary
Tiering: No
Matching In-Progress Cases: No
Denied case on the member's current line of eligibility in the past 65 days: No
Request Type: CD CD/RD Grid Answers: Q1=No, Q1a=No
Exception Guideline: N/A
Exception Question Answers: N/A
Tried and Failed Medications: Test Medications
Decision/Routing Rationale: Test Decision/Routing Rationale
Case Decision/Routing: Forward to Clinical
New Attachments Received: No
Outbound Call Made and Documented on Outbound Contact Tab: No`;

  expect(noteValue).toContain(expectedContent);
  console.log('Tech IBC Manual flow completed successfully');
}

export async function techIBCValidationError(page: Page) {
  console.log('Starting Tech IBC Validation Error flow\n');
  console.log('Actions:');

  await clickByElementId(page, 'TechRoletab', 1000);
  await page.click('label[for="techoriginQIBC"]');
  await page.waitForTimeout(1000);
  await clickByElementId(page, `${templateName}careAgentQNo`);
  await clickByElementId(page, `${templateName}validatedMemberQNo`);
  await clickByElementId(page, `${templateName}inProgressCaseQNo`);
  await fillTextByElementId(page, `${templateName}inqcallerQcallertxt`, 'Test First Name, Last Name');
  await selectOptionById(page, `${templateName}clientQsel`, 'Aetna MAPD');
  await fillTextByElementId(page, `${templateName}subFormularyIDQtxt`, '00023356');
  await fillTextByElementId(page, `${templateName}drugNameQtxt`, 'Aspirin 100mg');
  await fillTextByElementId(page, `${templateName}qtytxt`, '120');
  await fillTextByElementId(page, `${templateName}dstxt`, '30');
  await clickByElementId(page, `${templateName}inquiryQNo`);
  await clickByElementId(page, `${templateName}claimQNo`);
  await clickByElementId(page, `${templateName}claim90dQYes`);
  await fillTextByElementId(page, `${templateName}subclaim90dQtxt`, '11/11/1111');
  await fillTextByElementId(page, `${templateName}subreject90dQtxt`, '06');
  await clickByElementId(page, `${templateName}eagQAAFNR`);
  await clickByElementId(page, `${templateName}subaafnrCaseQNo`);
  await clickByElementId(page, `${templateName}tierRqstQNo`);
  await selectOptionById(page, `${templateName}rqstReasonQsel`, 'Non-formulary');
  await clickByElementId(page, `${templateName}matchCaseQNo`);
  await checkRadioButtonById(page, `${templateName}rqstTypeDeniedQNo`);
  await removeAttributeById(page, `${templateName}rqstTypeQ`, 'disabled');
  await clickByElementId(page, `${templateName}rqstTypeQCD`);
  await selectOptionById(page, `${templateName}guidelineQsel`, 'N/A');
  await fillTextByElementId(page, `${templateName}subguidelineQlt`, 'N/A');
  await fillTextByElementId(page, `${templateName}treidFailQtxt`, 'Test Medications');
  await fillTextByElementId(page, `${templateName}diagnosisQlt`, 'Test Diagnosis');
  await clickByElementId(page, `${templateName}approveDiagoQNA`);
  await clickByElementId(page, `${templateName}iPriorityQStandard`);
  await fillTextByElementId(page, `${templateName}rationalQlt`, 'Test Decision/Routing Rationale');
  await selectOptionById(page, `${templateName}routingQsel`, 'Forward to Clinical');
  await clickByElementId(page, `${templateName}memberMultiDrugQNo`, 0, true, false);
  await clickByElementId(page, `${templateName}newAttachQNo`, 0, true, false);

  await clickByElementId(page, 'generateNotebtn', 100, true, false);
  const noteValue = await page.inputValue('#finalNote');

  expect(noteValue).toBe('');
  const tooltip = page.locator(`#${templateName}outboundQ .invalid-tooltip`);
  await expect(tooltip).toBeVisible();
  await expect(tooltip).toHaveText('please answer outbound call');

  console.log('Tech IBC Validation Error flow completed successfully. No notes generated.');
}