import { Page, expect } from '@playwright/test';
import { clickByElementId, fillTextByElementId, scrollElementToBottom } from '../../helpers/webPageActions';

export async function intakeNoAndValidatedMemberFlow(page: Page) {
  await clickByElementId(page, 'IntakeRoletab', 200);
  await page.click('label[for="itrashFaxQNo"]');
  await page.waitForTimeout(100);
  await clickByElementId(page, 'ibarcodeFaxQYes');
  await clickByElementId(page, 'ihopsiceFaxQNo');
  await clickByElementId(page, 'memberQblacktext');
  await clickByElementId(page, 'validatedMemberQYes');
  await clickByElementId(page, 'iPriorityQStandard');
  await clickByElementId(page, 'iMultiMemberQNo');
  await fillTextByElementId(page, 'iDrugNameQtxt', 'Aspirin 100mg');
  await clickByElementId(page, 'subiDrugNameCompQNo');
  await clickByElementId(page, 'iMultirqstQNo');
  await clickByElementId(page, 'iTierRqstQNo');
  await clickByElementId(page, 'iFverifyQreqBychb');
  await clickByElementId(page, 'iFverifyQintakechb');
  await clickByElementId(page, 'iFverifyQtimestampchb');
  await clickByElementId(page, 'generateNotebtn', 100, true, false);
  const noteValue = await page.inputValue('#finalNote');
  expect(noteValue).toContain('Intake Standard  barcode case for Aspirin 100mg. Forwarding to tech for review. Validated Member using 3 identifiers: Yes');
}


export async function intakeNoAndNotValidatedMemberFlow(page: Page) {
  await clickByElementId(page, 'IntakeRoletab', 200);
  await page.click('label[for="itrashFaxQNo"]');
  await page.waitForTimeout(100);
  await clickByElementId(page, 'ibarcodeFaxQYes');
  await clickByElementId(page, 'ihopsiceFaxQNo');
  await clickByElementId(page, 'memberQblacktext');
  await clickByElementId(page, 'validatedMemberQNo');
  await clickByElementId(page, 'iPriorityQStandard');
  await clickByElementId(page, 'iMultiMemberQNo');
  await fillTextByElementId(page, 'iDrugNameQtxt', 'Aspirin 100mg');
  await clickByElementId(page, 'subiDrugNameCompQNo');
  await clickByElementId(page, 'iMultirqstQNo');
  await clickByElementId(page, 'iTierRqstQNo');
  await clickByElementId(page, 'iFverifyQreqBychb');
  await clickByElementId(page, 'iFverifyQintakechb');
  await clickByElementId(page, 'iFverifyQtimestampchb');
  await clickByElementId(page, 'generateNotebtn', 100, true, false);
  const noteValue = await page.inputValue('#finalNote');
  expect(noteValue).toContain('Intake Standard  barcode case for Aspirin 100mg. Forwarding to tech for review. Validated Member using 3 identifiers: No');
}

export async function intakeNoValidationError(page: Page) {
  await clickByElementId(page, 'IntakeRoletab', 200);
  await page.click('label[for="itrashFaxQNo"]');
  await page.waitForTimeout(100);
  await clickByElementId(page, 'ibarcodeFaxQYes');
  await clickByElementId(page, 'ihopsiceFaxQNo');
  await clickByElementId(page, 'memberQblacktext');
  await clickByElementId(page, 'validatedMemberQNo');
  await clickByElementId(page, 'iPriorityQStandard');
  await clickByElementId(page, 'iMultiMemberQNo');
  await fillTextByElementId(page, 'iDrugNameQtxt', 'Aspirin 100mg');
  await clickByElementId(page, 'subiDrugNameCompQNo');
  await clickByElementId(page, 'iMultirqstQNo');
  await clickByElementId(page, 'iTierRqstQNo');
  await clickByElementId(page, 'iFverifyQreqBychb');
  await clickByElementId(page, 'iFverifyQintakechb');
  await clickByElementId(page, 'generateNotebtn', 100, true, false);
  scrollElementToBottom(page, 'finalNote');
  const noteValue = await page.inputValue('#finalNote');
  expect(noteValue).toContain('');
  const tooltip = page.locator('#iFverifyQ .invalid-tooltip');
  await expect(tooltip).toBeVisible();
  await expect(tooltip).toHaveText('Please validate Requested by, Intake Dropdown and timestamp populated with earliest time');
}

export async function intakeNoRDRqstTypeAlertMessage(page: Page) {
  await clickByElementId(page, 'IntakeRoletab', 200);
  await page.click('label[for="itrashFaxQNo"]');
  await page.waitForTimeout(100);
  await clickByElementId(page, 'ibarcodeFaxQYes');
  await clickByElementId(page, 'ihopsiceFaxQNo');
  await clickByElementId(page, 'memberQBCBSofMASS');
  const modal = page.locator('#NoteToolModal');
  await expect(modal).toBeVisible();
  const displayValue = await modal.evaluate(el => window.getComputedStyle(el).display);
  expect(displayValue).toBe('block');

  const modalText = await modal.locator('.text-primary.fw-bold');
  await expect(modalText).toHaveText('Request Type is Redetermination. Refer to BCBS of MASS client specific job aid.');
}