import { Page, expect, test } from '@playwright/test';
import { clickByElementId } from '../../helpers/webPageActions';

export async function intakeYesFlow(page: Page) {
  await clickByElementId(page, 'IntakeRoletab');
  await page.click('label[for="itrashFaxQYes"]');
  await page.waitForTimeout(100);
  const noteValue = await page.inputValue('#finalNote');
  expect(noteValue).toContain('Intake TRASH FAX');
}