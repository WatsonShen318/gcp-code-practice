import { test } from '@playwright/test';
import { rphQueueAutomatedFlow, rphQueueManualFlow, rphQueueValidationError } from '../../templates/rph/rphQueue';

const flows = [
  { name: 'Rph - Case Queue (Automated)', fn: rphQueueAutomatedFlow },
  { name: 'Rph - Case Queue (Manual)', fn: rphQueueManualFlow },
  { name: 'Rph - Case Queue Validation Error', fn: rphQueueValidationError }
];

let page;

test.beforeAll(async ({ browser }) => {
  const context = await browser.newContext();
  page = await context.newPage();
  // await page.goto('https://auto-note-tool.pdev.cvshealth.com/?skipAuthentication=true');
  await page.goto('http://localhost:8080/?skipAuthentication=true');

  // Wait 2 seconds for page load
  await page.waitForTimeout(2000);
});

test.afterAll(async () => {
  await page.close();
});

for (const flow of flows) {
  test(`Flow: ${flow.name}`, async () => {
    // await page.reload();
    await flow.fn(page);
  });
}