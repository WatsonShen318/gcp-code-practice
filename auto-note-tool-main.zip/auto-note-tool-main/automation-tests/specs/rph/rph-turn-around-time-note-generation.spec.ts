import { test } from '@playwright/test';
import { rphTATAutomatedFlow, rphTATManualFlow, rphTATValidationError } from '../../templates/rph/rphTAT';

const flows = [
  { name: 'Rph - Turn Around Time (Automated)', fn: rphTATAutomatedFlow },
  { name: 'Rph - Turn Around Time (Manual)', fn: rphTATManualFlow },
  { name: 'Rph - Turn Around Time Validation Error', fn: rphTATValidationError }
];

let page;

test.beforeAll(async ({ browser }) => {
  const context = await browser.newContext();
  page = await context.newPage();
  // await page.goto('https://auto-note-tool.pdev.cvshealth.com/?skipAuthentication=true');
  await page.goto('http://localhost:8080/?skipAuthentication=true');

  // Wait 2 seconds for page load
  await page.waitForTimeout(2000);
});

test.afterAll(async () => {
  await page.close();
});

for (const flow of flows) {
  test(`Flow: ${flow.name}`, async () => {
    // await page.reload();
    await flow.fn(page);
  });
}