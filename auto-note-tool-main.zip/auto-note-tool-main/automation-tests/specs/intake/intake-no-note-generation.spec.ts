import { test } from '@playwright/test';
import { intakeNoAndValidatedMemberFlow, intakeNoAndNotValidatedMemberFlow, intakeNoValidationError, intakeNoRDRqstTypeAlertMessage } from '../../templates/intake/intakeNo';

const flows = [
  { name: 'Intake - No > Validated Member', fn: intakeNoAndValidatedMemberFlow },
  { name: 'Intake - No > Not Validated Member', fn: intakeNoAndNotValidatedMemberFlow },
  { name: 'Intake - No > Validation Error', fn: intakeNoValidationError },
  { name: 'Intake - No > Redetermination Request Type Alert Message', fn: intakeNoRDRqstTypeAlertMessage }
];

let page;

test.beforeAll(async ({ browser }) => {
  const context = await browser.newContext();
  page = await context.newPage();
  // await page.goto('https://auto-note-tool.pdev.cvshealth.com/?skipAuthentication=true');
  await page.goto('http://localhost:8080/?skipAuthentication=true');

  // Wait 2 seconds for page load
  await page.waitForTimeout(2000);
});

test.afterAll(async () => {
  await page.close();
});

for (const flow of flows) {
  test(`Flow: ${flow.name}`, async () => {
    // await page.reload();
    await flow.fn(page);
  });
}