import { test } from '@playwright/test';
import { techIBCAutomatedFlow, techIBCManualFlow, techIBCValidationError } from '../../templates/tech/techIBC';

const flows = [
  { name: 'Tech - Inbound call (Automated)', fn: techIBCAutomatedFlow },
  { name: 'Tech - Inbound call (Manual)', fn: techIBCManualFlow },
  { name: 'Tech - Inbound call Validation Error', fn: techIBCValidationError }
];

let page;

test.beforeAll(async ({ browser }) => {
  const context = await browser.newContext();
  page = await context.newPage();
  // await page.goto('https://auto-note-tool.pdev.cvshealth.com/?skipAuthentication=true');
  await page.goto('http://localhost:8080/?skipAuthentication=true');

  // Wait 2 seconds for page load
  await page.waitForTimeout(2000);
});

test.afterAll(async () => {
  await page.close();
});

for (const flow of flows) {
  test(`Flow: ${flow.name}`, async () => {
    // await page.reload();
    await flow.fn(page);
  });
}