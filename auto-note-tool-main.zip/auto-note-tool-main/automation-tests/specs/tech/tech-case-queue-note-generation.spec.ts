import { test } from '@playwright/test';
import { techQueueAutomatedFlow, techQueueManualFlow, techQueueValidationError } from '../../templates/tech/techQueue';

const flows = [
  { name: 'Tech - Case Queue (Automated)', fn: techQueueAutomatedFlow },
  { name: 'Tech - Case Queue (Manual)', fn: techQueueManualFlow },
  { name: 'Tech - Case Queue Validation Error', fn: techQueueValidationError }
];

let page;

test.beforeAll(async ({ browser }) => {
  const context = await browser.newContext();
  page = await context.newPage();
  // await page.goto('https://auto-note-tool.pdev.cvshealth.com/?skipAuthentication=true');
  await page.goto('http://localhost:8080/?skipAuthentication=true');

  // Wait 2 seconds for page load
  await page.waitForTimeout(2000);
});

test.afterAll(async () => {
  await page.close();
});

for (const flow of flows) {
  test(`Flow: ${flow.name}`, async () => {
    // await page.reload();
    await flow.fn(page);
  });
}