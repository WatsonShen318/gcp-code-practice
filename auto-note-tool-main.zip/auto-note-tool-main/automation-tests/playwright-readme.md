## Playwright Test Commands

### About Playwright
[Playwright](https://playwright.dev/) is a modern end-to-end testing framework for web applications. It supports multiple browsers (Chromium, Firefox, and WebKit) and provides powerful tools for automating browser interactions. Playwright is ideal for testing complex workflows, ensuring reliability, and generating detailed reports.

### Playwright for Auto Note Generation
In the GSO Auto Note Tool use case, Playwright is used for validations to:
- Automate user interactions with the web application.
- Validate workflows for generating notes based on specific inputs and configurations.
- Ensure the correctness of generated notes by comparing them with expected outputs.
- Provide detailed reports for test execution, helping in debugging and improving workflows.

### Installation
- npx playwright install-deps

### Run All Tests

#### Headed Mode with HTML Reporter
npx playwright test --headed --reporter=html --workers=1

#### Headless Mode with HTML Reporter
npx playwright test --reporter=html --workers=1

#### Headless Mode with Dot Reporter
npx playwright test --reporter=dot --workers=1

#### Headless Mode with List Reporter
npx playwright test --reporter=list --workers=1

#### Headed Mode with List Reporter
npx playwright test --headed --reporter=list --workers=1

#### Headless Mode, List Reporter, Quiet logs
npx playwright test --reporter=list --workers=1 --quiet

#### Headed Mode, List Reporter, Quiet logs
npx playwright test --headed --reporter=list --workers=1 --quiet

### Run Specific Test Files in Headed Mode with HTML Reporter

#### Intake

##### Intake - No Note Generation
npx playwright test intake-no-note-generation.spec.ts --headed --reporter=html --workers=1

##### Intake - Yes Note Generation
npx playwright test intake-yes-note-generation.spec.ts --headed --reporter=html --workers=1

#### Tech

##### Tech - Case Queue Note Generation
npx playwright test tech-case-queue-note-generation.spec.ts --headed --reporter=html --workers=1

##### Tech - Inbound Call Note Generation
npx playwright test tech-inbound-call-note-generation.spec.ts --headed --reporter=html --workers=1

##### Tech - Turn Around Time Note Generation
npx playwright test tech-turn-around-time-note-generation.spec.ts --headed --reporter=html --workers=1

##### Tech - Secondary Review Note Generation
npx playwright test tech-secondary-review-note-generation.spec.ts --headed --reporter=html --workers=1

#### Rph
##### Rph - Case Queue Note Generation
npx playwright test rph-case-queue-note-generation.spec.ts --headed --reporter=html --workers=1

##### Rph - TAT Note Generation
npx playwright test rph-turn-around-time-generation.spec.ts --headed --reporter=html --workers=1

##### Rph - IBC Note Generation
npx playwright test rph-inbound-call-note-generation.spec.ts --headed --reporter=html --workers=1

### View Automation Test Report
npm run show-automation-tests-report

## Demo
**Running all tests**
npx playwright test --headed --reporter=html --workers=1 --quiet
npx playwright show-report
file:///C:/Users/N869031/Downloads/Playwright%20Test%20Report-all%20tests.html

**Running failure test suite**
npx playwright test intake-no-note-generation.spec.ts --headed --reporter=html --workers=1
file:///C:/Users/N869031/Downloads/Playwright%20Test%20Report-failed.html

**Code Base:**
https://github.com/cvs-legacy-source-code/auto-note-tool/tree/master/automation-tests

**Playwright Documentation:**
https://playwright.dev/
