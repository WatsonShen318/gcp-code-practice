const environmentVariables = {
    'localhost': {
        'AUTO_NOTE_BACKEND': 'http://localhost:3000'
    },
    'dev': {
        'AUTO_NOTE_BACKEND': 'https://auto-note-backend.pdev.cvshealth.com'
    },
    'test': {
        'AUTO_NOTE_BACKEND': 'https://auto-note-backend.pqa.cvshealth.com',
        'PROD_AUTO_NOTE_BACKEND':  'https://auto-note-backend.prod.cvshealth.com',
        'PROD_AUTO_NOTE_TOOL':     'https://autonotetool-mhk.aetna.com',
    },
    'prod': {
        'AUTO_NOTE_BACKEND': 'https://auto-note-backend.prod.cvshealth.com',
        'BETA_AUTO_NOTE_TOOL':      'https://auto-note-tool.pqa.cvshealth.com',
    },
    'beta': {
        'AUTO_NOTE_BACKEND':       'https://auto-note-backend.pqa.cvshealth.com',
        'PROD_AUTO_NOTE_BACKEND':  'https://auto-note-backend.prod.cvshealth.com',
        'PROD_AUTO_NOTE_TOOL':     'https://autonotetool-mhk.aetna.com',
    }
};

const cvshealthEnvMap = { pdev: 'dev', pqa: 'test', prod: 'prod' };

export const getEnvironmentVariables = () => {
    const appDomain = window.location.host;
    const cvshealthMatch = appDomain?.match(/\.(pdev|pqa|prod)\.cvshealth\.com/);
    const environment = cvshealthMatch ? cvshealthEnvMap[cvshealthMatch[1]] : '';

    if (environment) {
        return environmentVariables[environment];
    // removing beta URL as autonotetool-mhk-beta.aetna.com is not used for any environment, so pqa is used for test environment instead of beta
    // } else if (appDomain == 'autonotetool-mhk-beta.aetna.com') {
    //     return environmentVariables['beta'];
    } else if (appDomain == 'autonotetool-mhk.aetna.com') {
        return environmentVariables['prod'];
    } else {
        // Update this to localhost for local development
        return environmentVariables['localhost'];
        // return environmentVariables['dev'];
    }
}
