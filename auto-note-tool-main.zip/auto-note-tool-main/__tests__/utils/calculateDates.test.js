import {
  getToday,
  getNextYear,
  getCurrentYear,
  getFoward90daysDate,
  getLastDate,
  getForwardDate,
  getLastQtr,
} from '../../src/app/utils/calculateDates';

describe('calculateDates', () => {
  const now = new Date();
  const currentYear = now.getFullYear();

  test('getToday returns date in MM/DD/YYYY format', () => {
    expect(getToday()).toMatch(/^\d{2}\/\d{2}\/\d{4}$/);
  });

  test('getToday contains the current year', () => {
    expect(getToday()).toContain(String(currentYear));
  });

  test('getCurrentYear returns the current calendar year', () => {
    expect(getCurrentYear()).toBe(currentYear);
  });

  test('getNextYear returns current year + 1', () => {
    expect(getNextYear()).toBe(currentYear + 1);
  });

  test('getFoward90daysDate returns a date string in M/D/YYYY format', () => {
    expect(getFoward90daysDate()).toMatch(/^\d{1,2}\/\d{1,2}\/\d{4}$/);
  });

  test('getLastDate includes the day count in the output', () => {
    expect(getLastDate(7)).toContain('7 days in the past was');
  });

  test('getLastDate returns a date portion in M/D/YYYY format', () => {
    const result = getLastDate(7);
    expect(result).toMatch(/\d{1,2}\/\d{1,2}\/\d{4}$/);
  });

  test('getForwardDate includes the day count and a bold HTML date', () => {
    const result = getForwardDate(30);
    expect(result).toContain('30 days from today is');
    expect(result).toContain('<b>');
  });

  test('getForwardDate result includes Q4 guidance with current year', () => {
    const result = getForwardDate(30);
    expect(result).toContain(`12/31/${currentYear}`);
  });
});

// ── getLastQtr ────────────────────────────────────────────────────────────────
// Q4 window: Oct 15 – Dec 31  →  ['IBC', 'Queue', 'SR', 'TAT']
// All other dates              →  ['noshow']
describe('getLastQtr', () => {
  afterEach(() => {
    jest.useRealTimers();
  });

  function setDate(isoString) {
    jest.useFakeTimers();
    jest.setSystemTime(new Date(isoString));
  }

  test('returns ["noshow"] in January', () => {
    setDate('2025-01-15T12:00:00Z');
    expect(getLastQtr()).toEqual(['noshow']);
  });

  test('returns ["noshow"] in September', () => {
    setDate('2025-09-30T12:00:00Z');
    expect(getLastQtr()).toEqual(['noshow']);
  });

  test('returns ["noshow"] on October 14 (before Q4 window)', () => {
    setDate('2025-10-14T12:00:00Z');
    expect(getLastQtr()).toEqual(['noshow']);
  });

  test('returns Q4 array on October 15 (start of Q4 window)', () => {
    setDate('2025-10-15T12:00:00Z');
    expect(getLastQtr()).toEqual(['IBC', 'Queue', 'SR', 'TAT']);
  });

  test('returns Q4 array in November', () => {
    setDate('2025-11-01T12:00:00Z');
    expect(getLastQtr()).toEqual(['IBC', 'Queue', 'SR', 'TAT']);
  });

  test('returns Q4 array in December', () => {
    setDate('2025-12-31T12:00:00Z');
    expect(getLastQtr()).toEqual(['IBC', 'Queue', 'SR', 'TAT']);
  });
});
