/**
 * @jest-environment jsdom
 */
jest.mock('cleave.js', () => jest.fn());

import Cleave from 'cleave.js';
import InputFormat, { toTitleCase } from '../../src/app/utils/input-format';

beforeEach(() => {
  jest.clearAllMocks();
  document.body.innerHTML = '';
});

// ── InputFormat — Cleave instances ────────────────────────────────────────────

describe('InputFormat — Cleave instances', () => {
  test('creates a Cleave instance for each .input-date element', () => {
    const inp = document.createElement('input');
    inp.classList.add('input-date');
    document.body.appendChild(inp);
    InputFormat();
    expect(Cleave).toHaveBeenCalledWith(inp, { date: true, datePattern: ['m', 'd', 'Y'], delimiter: '/' });
  });

  test('creates a Cleave instance for each .input-ph element', () => {
    const inp = document.createElement('input');
    inp.classList.add('input-ph');
    document.body.appendChild(inp);
    InputFormat();
    expect(Cleave).toHaveBeenCalledWith(inp, { numericOnly: true, blocks: [3, 3, 4], delimiter: '-' });
  });

  test('creates a Cleave instance for each .input-dt element', () => {
    const inp = document.createElement('input');
    inp.classList.add('input-dt');
    document.body.appendChild(inp);
    InputFormat();
    expect(Cleave).toHaveBeenCalledWith(inp, {
      numericOnly: true,
      delimiters: ['/', '/', ' ', ':'],
      blocks: [2, 2, 4, 2, 2],
    });
  });

  test('creates a Cleave instance for each .input-numbers element', () => {
    const inp = document.createElement('input');
    inp.classList.add('input-numbers');
    document.body.appendChild(inp);
    InputFormat();
    expect(Cleave).toHaveBeenCalledWith(inp, { numeral: true, numeralDecimalMark: '', delimiter: '' });
  });

  test('does not call Cleave when no matching elements exist', () => {
    InputFormat();
    expect(Cleave).not.toHaveBeenCalled();
  });
});

// ── InputFormat — change event sanitisation ───────────────────────────────────

describe('InputFormat — change event sanitisation', () => {
  function fireChange(el) {
    el.dispatchEvent(new Event('change'));
  }

  test('removes special characters { } ~ & ^ < > " from text input', () => {
    const inp = document.createElement('input');
    inp.type = 'text';
    document.body.appendChild(inp);
    InputFormat();
    inp.value = 'hello{world}&test"ok<>';
    fireChange(inp);
    expect(inp.value).toBe('helloworldtestok');
  });

  test('removes special characters from textarea', () => {
    const ta = document.createElement('textarea');
    document.body.appendChild(ta);
    InputFormat();
    ta.value = 'clean~data^here';
    fireChange(ta);
    expect(ta.value).toBe('cleandatahere');
  });

  test('leaves normal text unchanged', () => {
    const inp = document.createElement('input');
    inp.type = 'text';
    document.body.appendChild(inp);
    InputFormat();
    inp.value = 'Normal note text 123';
    fireChange(inp);
    expect(inp.value).toBe('Normal note text 123');
  });
});

// ── toTitleCase ───────────────────────────────────────────────────────────────

describe('toTitleCase', () => {
  test('capitalises the first letter of each word', () => {
    expect(toTitleCase('hello world')).toBe('Hello World');
  });

  test('lowercases the remaining letters of each word', () => {
    expect(toTitleCase('JOHN DOE')).toBe('John Doe');
  });

  test('handles mixed case input', () => {
    expect(toTitleCase('jOhN dOe')).toBe('John Doe');
  });

  test('handles a single word', () => {
    expect(toTitleCase('aetna')).toBe('Aetna');
  });

  test('handles an empty string', () => {
    expect(toTitleCase('')).toBe('');
  });

  test('handles words with numbers', () => {
    expect(toTitleCase('abc123def')).toBe('Abc123def');
  });
});
