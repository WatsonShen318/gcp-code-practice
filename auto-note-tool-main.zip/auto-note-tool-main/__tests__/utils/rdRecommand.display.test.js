jest.mock('../../src/app/utils/notetool.display', () => ({ toggleDisplay: jest.fn() }));
jest.mock('../../src/app/qsets/fields', () => ({
  decisionRouting: jest.fn(),
  requestType: jest.fn(),
}));

import toggleRecommand from '../../src/app/utils/rdRecommand.display';
import { toggleDisplay } from '../../src/app/utils/notetool.display';
import { decisionRouting, requestType } from '../../src/app/qsets/fields';

beforeEach(() => { jest.clearAllMocks(); });

describe('toggleRecommand', () => {
  test('enables rdRecommandQ when routing includes "Forward to Clinical" and requestType is "RD"', () => {
    decisionRouting.mockReturnValue('Forward to Clinical');
    requestType.mockReturnValue('RD');

    toggleRecommand('Queue', 'tech');

    expect(toggleDisplay).toHaveBeenCalledWith('solo', ['techQueuerdRecommandQ'], 'enable');
  });

  test('disables rdRecommandQ when routing is "Forward to Clinical" but requestType is not "RD"', () => {
    decisionRouting.mockReturnValue('Forward to Clinical');
    requestType.mockReturnValue('PA');

    toggleRecommand('Queue', 'tech');

    expect(toggleDisplay).toHaveBeenCalledWith('solo', ['techQueuerdRecommandQ'], 'disable');
  });

  test('disables rdRecommandQ when requestType is "RD" but routing does not include "Forward to Clinical"', () => {
    decisionRouting.mockReturnValue('Denied');
    requestType.mockReturnValue('RD');

    toggleRecommand('Queue', 'tech');

    expect(toggleDisplay).toHaveBeenCalledWith('solo', ['techQueuerdRecommandQ'], 'disable');
  });

  test('disables rdRecommandQ when neither condition matches', () => {
    decisionRouting.mockReturnValue('Approved');
    requestType.mockReturnValue('PA');

    toggleRecommand('IBC', 'rph');

    expect(toggleDisplay).toHaveBeenCalledWith('solo', ['rphIBCrdRecommandQ'], 'disable');
  });

  test('reads routing and requestType using the supplied role and origin', () => {
    decisionRouting.mockReturnValue('Denied');
    requestType.mockReturnValue('PA');

    toggleRecommand('TAT', 'rph');

    expect(decisionRouting).toHaveBeenCalledWith('rph', 'TAT', 'value');
    expect(requestType).toHaveBeenCalledWith('rph', 'TAT', 'value');
  });
});
