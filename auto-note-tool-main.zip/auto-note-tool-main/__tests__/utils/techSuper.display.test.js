jest.mock('../../src/app/utils/notetool.display', () => ({ toggleDisplay: jest.fn() }));

import toggleTechSuper from '../../src/app/utils/techSuper.display';
import { toggleDisplay } from '../../src/app/utils/notetool.display';

beforeEach(() => { jest.clearAllMocks(); });

describe('toggleTechSuper', () => {
  test('enables techSupUserQ when answer is "Approved"', () => {
    toggleTechSuper('Queue', 'tech', 'Approved');
    expect(toggleDisplay).toHaveBeenCalledWith('solo', ['techQueuetechSupUserQ'], 'enable');
  });

  test('disables techSupUserQ when answer is "Denied"', () => {
    toggleTechSuper('Queue', 'tech', 'Denied');
    expect(toggleDisplay).toHaveBeenCalledWith('solo', ['techQueuetechSupUserQ'], 'disable');
  });

  test('disables techSupUserQ when answer is empty string', () => {
    toggleTechSuper('IBC', 'tech', '');
    expect(toggleDisplay).toHaveBeenCalledWith('solo', ['techIBCtechSupUserQ'], 'disable');
  });

  test('uses the supplied role and origin in the field ID', () => {
    toggleTechSuper('TAT', 'rph', 'Approved');
    expect(toggleDisplay).toHaveBeenCalledWith('solo', ['rphTATtechSupUserQ'], 'enable');
  });
});
