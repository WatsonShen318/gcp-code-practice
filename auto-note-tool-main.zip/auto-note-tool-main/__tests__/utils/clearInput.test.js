/**
 * @jest-environment jsdom
 */
import { clearInput, clearInputs } from '../../src/app/utils/clearInput';

afterEach(() => { document.body.innerHTML = ''; });

// ── helpers ───────────────────────────────────────────────────────────────────

function addRadio(name, id, checked = false) {
  const r = document.createElement('input');
  r.type = 'radio'; r.name = name; r.id = id; r.checked = checked;
  document.body.appendChild(r);
  return r;
}

function addText(id, value = 'hello') {
  const t = document.createElement('input');
  t.type = 'text'; t.id = id; t.value = value;
  document.body.appendChild(t);
  return t;
}

// ── clearInput ────────────────────────────────────────────────────────────────

describe('clearInput — radio', () => {
  test('unchecks checked radio buttons for each named group', () => {
    addRadio('grp1', 'grp1yes', true);
    addRadio('grp1', 'grp1no', false);
    clearInput('radio', ['grp1']);
    expect(document.getElementById('grp1yes').checked).toBe(false);
    expect(document.getElementById('grp1no').checked).toBe(false);
  });

  test('handles multiple named groups', () => {
    addRadio('a', 'aYes', true);
    addRadio('b', 'bYes', true);
    clearInput('radio', ['a', 'b']);
    expect(document.getElementById('aYes').checked).toBe(false);
    expect(document.getElementById('bYes').checked).toBe(false);
  });

  test('leaves unchecked radios unchanged', () => {
    addRadio('g', 'gNo', false);
    clearInput('radio', ['g']);
    expect(document.getElementById('gNo').checked).toBe(false);
  });
});

describe('clearInput — text', () => {
  test('clears the value of text inputs by ID', () => {
    addText('txt1'); addText('txt2');
    clearInput('text', ['txt1', 'txt2']);
    expect(document.getElementById('txt1').value).toBe('');
    expect(document.getElementById('txt2').value).toBe('');
  });

  test('works with type "textarea"', () => {
    const ta = document.createElement('textarea');
    ta.id = 'ta1'; ta.value = 'some notes';
    document.body.appendChild(ta);
    clearInput('textarea', ['ta1']);
    expect(document.getElementById('ta1').value).toBe('');
  });

  test('works with type "select"', () => {
    const sel = document.createElement('select');
    sel.id = 'sel1';
    const opt = document.createElement('option');
    opt.value = 'foo'; opt.selected = true;
    sel.appendChild(opt);
    document.body.appendChild(sel);
    clearInput('select', ['sel1']);
    expect(document.getElementById('sel1').value).toBe('');
  });
});

// ── clearInputs ───────────────────────────────────────────────────────────────

describe('clearInputs — radio', () => {
  test('unchecks checked elements from array', () => {
    const r1 = addRadio('x', 'x1', true);
    const r2 = addRadio('x', 'x2', false);
    clearInputs([r1, r2], 'radio');
    expect(document.getElementById('x1').checked).toBe(false);
    expect(document.getElementById('x2').checked).toBe(false);
  });

  test('type "check" also unchecks checked elements', () => {
    const cb = document.createElement('input');
    cb.type = 'checkbox'; cb.id = 'cb1'; cb.checked = true;
    document.body.appendChild(cb);
    clearInputs([cb], 'check');
    expect(document.getElementById('cb1').checked).toBe(false);
  });
});

describe('clearInputs — text', () => {
  test('clears value of each element in the array', () => {
    const t1 = addText('t1', 'val1');
    const t2 = addText('t2', 'val2');
    clearInputs([t1, t2], 'text');
    expect(t1.value).toBe('');
    expect(t2.value).toBe('');
  });
});
