jest.mock('../../src/app/utils/notetool.display', () => ({ toggleDisplay: jest.fn() }));
jest.mock('../../src/app/qsets/fields', () => ({
  decisionRouting: jest.fn(),
  mdReview: jest.fn(),
  requestType: jest.fn(),
}));

import { toggledeniedRD, toggledeniedRDrphDecision } from '../../src/app/utils/deniedRD.display';
import { toggleDisplay } from '../../src/app/utils/notetool.display';
import { decisionRouting, mdReview, requestType } from '../../src/app/qsets/fields';

beforeEach(() => jest.clearAllMocks());

// ── toggledeniedRD ────────────────────────────────────────────────────────────

describe('toggledeniedRD', () => {
  test('enables mdReviewQ when requestType is "RD" and decision is "Denied"', () => {
    decisionRouting.mockReturnValue('Denied');
    requestType.mockReturnValue('RD');
    toggledeniedRD('Queue', 'tech');
    expect(toggleDisplay).toHaveBeenCalledWith('solo', ['techQueuemdReviewQ'], 'enable');
  });

  test('disables mdReviewQ when requestType is not "RD"', () => {
    decisionRouting.mockReturnValue('Denied');
    requestType.mockReturnValue('PA');
    toggledeniedRD('Queue', 'tech');
    expect(toggleDisplay).toHaveBeenCalledWith('solo', ['techQueuemdReviewQ'], 'disable');
  });

  test('disables mdReviewQ when decision is not "Denied"', () => {
    decisionRouting.mockReturnValue('Approved');
    requestType.mockReturnValue('RD');
    toggledeniedRD('Queue', 'tech');
    expect(toggleDisplay).toHaveBeenCalledWith('solo', ['techQueuemdReviewQ'], 'disable');
  });

  test('uses the supplied role and origin to build the field ID', () => {
    decisionRouting.mockReturnValue('Denied');
    requestType.mockReturnValue('RD');
    toggledeniedRD('TAT', 'rph');
    expect(toggleDisplay).toHaveBeenCalledWith('solo', ['rphTATmdReviewQ'], 'enable');
  });

  test('reads routing and requestType with (r, o, "value")', () => {
    decisionRouting.mockReturnValue('Approved');
    requestType.mockReturnValue('PA');
    toggledeniedRD('IBC', 'tech');
    expect(decisionRouting).toHaveBeenCalledWith('tech', 'IBC', 'value');
    expect(requestType).toHaveBeenCalledWith('tech', 'IBC', 'value');
  });
});

// ── toggledeniedRDrphDecision ─────────────────────────────────────────────────

describe('toggledeniedRDrphDecision', () => {
  test('enables rphDecisionQ when non-TAT, mdReview is "Yes", decision is "Denied"', () => {
    decisionRouting.mockReturnValue('Denied');
    mdReview.mockReturnValue('Yes');
    toggledeniedRDrphDecision('Queue', 'rph');
    expect(toggleDisplay).toHaveBeenCalledWith('solo', ['rphQueuerphDecisionQ'], 'enable');
  });

  test('disables rphDecisionQ when non-TAT and mdReview is "No"', () => {
    decisionRouting.mockReturnValue('Denied');
    mdReview.mockReturnValue('No');
    toggledeniedRDrphDecision('Queue', 'rph');
    expect(toggleDisplay).toHaveBeenCalledWith('solo', ['rphQueuerphDecisionQ'], 'disable');
  });

  test('disables rphDecisionQ when non-TAT, mdReview is "Yes" but decision is not "Denied"', () => {
    decisionRouting.mockReturnValue('Approved');
    mdReview.mockReturnValue('Yes');
    toggledeniedRDrphDecision('Queue', 'rph');
    expect(toggleDisplay).toHaveBeenCalledWith('solo', ['rphQueuerphDecisionQ'], 'disable');
  });

  test('enables rphDecisionQ when origin is "TAT" and mdReview is "Yes"', () => {
    mdReview.mockReturnValue('Yes');
    toggledeniedRDrphDecision('TAT', 'rph');
    expect(toggleDisplay).toHaveBeenCalledWith('solo', ['rphTATrphDecisionQ'], 'enable');
  });

  test('disables rphDecisionQ when origin is "TAT" and mdReview is "No"', () => {
    mdReview.mockReturnValue('No');
    toggledeniedRDrphDecision('TAT', 'rph');
    expect(toggleDisplay).toHaveBeenCalledWith('solo', ['rphTATrphDecisionQ'], 'disable');
  });

  test('TAT branch does not use decisionRouting result for status', () => {
    decisionRouting.mockReturnValue('Approved'); // not 'Denied'
    mdReview.mockReturnValue('Yes');
    toggledeniedRDrphDecision('TAT', 'rph');
    // Status is 'enable' purely because mdReview is 'Yes', regardless of decisionRouting
    expect(toggleDisplay).toHaveBeenCalledWith('solo', ['rphTATrphDecisionQ'], 'enable');
  });
});
