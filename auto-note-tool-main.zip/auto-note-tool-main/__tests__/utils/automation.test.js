/**
 * @jest-environment jsdom
 */

jest.mock('../../src/app/dlt_guidelines/automation', () => ({
  automateDLTGuidelines: jest.fn(),
}));

jest.mock('../../src/app/qsets/fields', () => ({
  approvedDiagnosis: jest.fn(),
  clientKeyIn: jest.fn(),
  diagnosis: jest.fn(),
  guideline: jest.fn(),
  guidelineRationale: jest.fn(),
  mdRationale: jest.fn(),
  rationale: jest.fn(),
  requestBy: jest.fn(),
  requestType: jest.fn(),
  subInquiryCaller: jest.fn(),
  subInquiryRejectCode: jest.fn(),
  subInquiryTR: jest.fn(),
  subMemberWAOR: jest.fn(),
  subRequestByCaller: jest.fn(),
  subRequestInfo: jest.fn(),
  triedFail: jest.fn(),
}));

jest.mock('../../src/app/utils/notetool.display', () => ({
  toggleDisable: jest.fn(),
  toggleDisplay: jest.fn(),
}));

import {
  setTriedFail,
  setTriedFailNA,
  setClientNA,
  setinqRejectCodeNA,
  setinqRqstReasonNA,
  setRqstByRdo,
  setGuideline,
  setGuidelineFromMapper,
  resetDLTGuideline,
  setMDnewInfo,
  filterDLTGuidelineOptions,
  setSupprtStatement,
  setMDdxNo,
  setMDoffLabelCompendiaNA,
  setMDoffLabelCompendiaNo,
  resetDLTGuidelineFields,
} from '../../src/app/utils/automation';
import {
  triedFail, guideline, guidelineRationale, requestType, approvedDiagnosis,
  clientKeyIn, subInquiryRejectCode, subInquiryTR, rationale, mdRationale,
} from '../../src/app/qsets/fields';
import { toggleDisplay, toggleDisable } from '../../src/app/utils/notetool.display';
import { automateDLTGuidelines } from '../../src/app/dlt_guidelines/automation';

const R = 'tech', O = 'Queue';

beforeEach(() => {
  jest.clearAllMocks();
  document.body.innerHTML = '';
  sessionStorage.clear();
});

// ── setTriedFail ──────────────────────────────────────────────────────────────

describe('setTriedFail', () => {
  test('sets element value to "" for "Opioid Quantity Limit - 925"', () => {
    const el = { value: 'old' };
    triedFail.mockReturnValue(el);
    setTriedFail(O, R, 'Opioid Quantity Limit - 925');
    expect(el.value).toBe('');
  });

  test('sets element value to "N/A" for "Prior Authorization"', () => {
    const el = { value: '' };
    triedFail.mockReturnValue(el);
    setTriedFail(O, R, 'Prior Authorization');
    expect(el.value).toBe('N/A');
  });

  test('sets element value to "N/A" for "Safety Edit"', () => {
    const el = { value: '' };
    triedFail.mockReturnValue(el);
    setTriedFail(O, R, 'Safety Edit');
    expect(el.value).toBe('N/A');
  });

  test('sets element value to "" for unknown picked value', () => {
    const el = { value: 'prev' };
    triedFail.mockReturnValue(el);
    setTriedFail(O, R, 'Unknown');
    expect(el.value).toBe('');
  });

  test('calls triedFail with (r, o, "element")', () => {
    triedFail.mockReturnValue({ value: '' });
    setTriedFail(O, R, 'Safety Edit');
    expect(triedFail).toHaveBeenCalledWith(R, O, 'element');
  });
});

// ── NA setters ────────────────────────────────────────────────────────────────

describe('setTriedFailNA', () => {
  test('sets triedFail element value to "N/A"', () => {
    const el = { value: '' };
    triedFail.mockReturnValue(el);
    setTriedFailNA(O, R);
    expect(el.value).toBe('N/A');
  });
});

describe('setClientNA', () => {
  test('sets clientKeyIn element value to "N/A"', () => {
    const el = { value: '' };
    clientKeyIn.mockReturnValue(el);
    setClientNA(O, R);
    expect(el.value).toBe('N/A');
  });
});

describe('setinqRejectCodeNA', () => {
  test('sets subInquiryRejectCode element value to "N/A"', () => {
    const el = { value: '' };
    subInquiryRejectCode.mockReturnValue(el);
    setinqRejectCodeNA(O, R);
    expect(el.value).toBe('N/A');
  });
});

describe('setinqRqstReasonNA', () => {
  test('sets subInquiryTR element value to "N/A"', () => {
    const el = { value: '' };
    subInquiryTR.mockReturnValue(el);
    setinqRqstReasonNA(O, R);
    expect(el.value).toBe('N/A');
  });
});

// ── setRqstByRdo ──────────────────────────────────────────────────────────────

describe('setRqstByRdo', () => {
  test('clicks the radio element matching the value', () => {
    const btn = document.createElement('input');
    btn.type = 'radio';
    btn.id = `${R}${O}rqstByQYes`;
    const spy = jest.spyOn(btn, 'click');
    document.body.appendChild(btn);
    setRqstByRdo(O, R, 'Yes');
    expect(spy).toHaveBeenCalledTimes(1);
  });

  test('does not throw when element is not found', () => {
    expect(() => setRqstByRdo(O, R, 'Missing')).not.toThrow();
  });
});

// ── setGuideline ──────────────────────────────────────────────────────────────

describe('setGuideline', () => {
  let gl, glanswer;
  beforeEach(() => {
    gl = { value: 'prev' };
    glanswer = { value: 'prev' };
    guideline.mockReturnValue(gl);
    guidelineRationale.mockReturnValue(glanswer);
  });

  test('"Quantity Opioid 7 Day" → Opioid guideline, clears rationale, enables button', () => {
    setGuideline(O, R, 'Quantity Opioid 7 Day');
    expect(gl.value).toBe('Opioid Quantity Limit - 925');
    expect(glanswer.value).toBe('');
    expect(toggleDisplay).toHaveBeenCalledWith('solo', [`${R}${O}guidelineQbtn`], 'enable');
  });

  test('"Quantity Limit" → Quantity Limit Exception guideline, enables button', () => {
    setGuideline(O, R, 'Quantity Limit');
    expect(gl.value).toBe('Quantity Limit Exception');
    expect(glanswer.value).toBe('');
    expect(toggleDisplay).toHaveBeenCalledWith('solo', [`${R}${O}guidelineQbtn`], 'enable');
  });

  test('"Step Therapy" without Automated workflow → sets both to N/A', () => {
    setGuideline(O, R, 'Step Therapy');
    expect(gl.value).toBe('N/A');
    expect(glanswer.value).toBe('N/A');
  });

  test('"Prior Authorization" without Automated workflow → sets both to N/A', () => {
    setGuideline(O, R, 'Prior Authorization');
    expect(gl.value).toBe('N/A');
    expect(glanswer.value).toBe('N/A');
  });

  test('"Safety Edit" without Automated workflow → sets both to N/A', () => {
    setGuideline(O, R, 'Safety Edit');
    expect(gl.value).toBe('N/A');
    expect(glanswer.value).toBe('N/A');
  });

  test('"Tier Change" → sets both to N/A when not Automated', () => {
    setGuideline(O, R, 'Tier Change');
    expect(gl.value).toBe('N/A');
    expect(glanswer.value).toBe('N/A');
  });

  test('"Step Therapy" with Automated workflow → does NOT set N/A', () => {
    sessionStorage.setItem('workFlow', 'Automated');
    setGuideline(O, R, 'Step Therapy');
    expect(gl.value).toBe('prev');
    expect(glanswer.value).toBe('prev');
  });

  test('default case → clears both values and disables button', () => {
    setGuideline(O, R, 'Other');
    expect(gl.value).toBe('');
    expect(glanswer.value).toBe('');
    expect(toggleDisplay).toHaveBeenCalledWith('solo', [`${R}${O}guidelineQbtn`], 'disable');
  });
});

// ── setGuidelineFromMapper ────────────────────────────────────────────────────

describe('setGuidelineFromMapper', () => {
  const consoleSpy = jest.spyOn(console, 'log').mockImplementation(() => {});
  afterAll(() => consoleSpy.mockRestore());

  test('sets guideline value, clears rationale, enables button when mappedGuideline is truthy', () => {
    const gl = { value: '' };
    const glanswer = { value: 'old' };
    guideline.mockReturnValue(gl);
    guidelineRationale.mockReturnValue(glanswer);
    setGuidelineFromMapper(O, R, 'My Guideline');
    expect(gl.value).toBe('My Guideline');
    expect(glanswer.value).toBe('');
    expect(toggleDisplay).toHaveBeenCalledWith('solo', [`${R}${O}guidelineQbtn`], 'enable');
  });

  test('does nothing when mappedGuideline is null', () => {
    const gl = { value: 'existing' };
    guideline.mockReturnValue(gl);
    guidelineRationale.mockReturnValue({ value: '' });
    setGuidelineFromMapper(O, R, null);
    expect(gl.value).toBe('existing');
    expect(toggleDisplay).not.toHaveBeenCalled();
  });
});

// ── resetDLTGuideline ─────────────────────────────────────────────────────────

describe('resetDLTGuideline', () => {
  test('clears guideline and rationale, disables button', () => {
    const gl = { value: 'some guideline' };
    const glanswer = { value: 'some rationale' };
    guideline.mockReturnValue(gl);
    guidelineRationale.mockReturnValue(glanswer);
    resetDLTGuideline(O, R);
    expect(gl.value).toBe('');
    expect(glanswer.value).toBe('');
    expect(toggleDisplay).toHaveBeenCalledWith('solo', [`${R}${O}guidelineQbtn`], 'disable');
  });
});

// ── setMDnewInfo ──────────────────────────────────────────────────────────────

describe('setMDnewInfo', () => {
  test('disables mdNewInfoQ when requestType is "CD"', () => {
    requestType.mockReturnValue('CD');
    setMDnewInfo(O, R);
    expect(toggleDisplay).toHaveBeenCalledWith('solo', [`${R}${O}mdNewInfoQ`], 'disable');
  });

  test('enables mdNewInfoQ when requestType is not "CD"', () => {
    requestType.mockReturnValue('PA');
    setMDnewInfo(O, R);
    expect(toggleDisplay).toHaveBeenCalledWith('solo', [`${R}${O}mdNewInfoQ`], 'enable');
  });

  test('enables mdNewInfoQ when requestType is "RD"', () => {
    requestType.mockReturnValue('RD');
    setMDnewInfo(O, R);
    expect(toggleDisplay).toHaveBeenCalledWith('solo', [`${R}${O}mdNewInfoQ`], 'enable');
  });
});

// ── filterDLTGuidelineOptions ─────────────────────────────────────────────────

describe('filterDLTGuidelineOptions', () => {
  function makeOptions(...values) {
    return values.map(v => ({ value: v, style: { display: '' } }));
  }

  test('hides non-Quantity options when answer includes "Quantity"', () => {
    const options = makeOptions('Quantity Limit Exception', 'Prior Authorization', 'N/A', 'Safety Edit');
    guideline.mockReturnValue({ options });
    filterDLTGuidelineOptions(R, O, 'Quantity Opioid 7 Day');
    expect(options[0].style.display).toBe('block'); // Quantity Limit Exception
    expect(options[1].style.display).toBe('none');  // Prior Authorization
    expect(options[2].style.display).toBe('block'); // N/A
    expect(options[3].style.display).toBe('none');  // Safety Edit
  });

  test('shows all options when answer does not include "Quantity"', () => {
    const options = makeOptions('Quantity Limit Exception', 'Prior Authorization', 'N/A');
    options[0].style.display = 'none'; // pre-hidden
    guideline.mockReturnValue({ options });
    filterDLTGuidelineOptions(R, O, 'Prior Authorization');
    options.forEach(o => expect(o.style.display).toBe('block'));
  });

  test('"Quantity Limit" also activates Quantity filter', () => {
    const options = makeOptions('Quantity Limit Exception', 'Safety Edit');
    guideline.mockReturnValue({ options });
    filterDLTGuidelineOptions(R, O, 'Quantity Limit');
    expect(options[0].style.display).toBe('block');
    expect(options[1].style.display).toBe('none');
  });
});

// ── setSupprtStatement ────────────────────────────────────────────────────────

describe('setSupprtStatement — RequestReason', () => {
  function createEls() {
    ['NA', 'Yes', 'No'].forEach(sfx => {
      const el = document.createElement('input');
      el.type = 'radio';
      el.id = `${R}${O}spprSatementQ${sfx}`;
      document.body.appendChild(el);
    });
  }

  test('"Step Therapy" → NA checked, Yes/No disabled, toggle disable', () => {
    createEls();
    setSupprtStatement(O, R, 'Step Therapy', 'RequestReason');
    expect(document.getElementById(`${R}${O}spprSatementQNA`).checked).toBe(true);
    expect(document.getElementById(`${R}${O}spprSatementQNo`).disabled).toBe(true);
    expect(document.getElementById(`${R}${O}spprSatementQYes`).disabled).toBe(true);
    expect(toggleDisplay).toHaveBeenCalledWith('solo', expect.arrayContaining([`${R}${O}subspprSatementLocationQ`]), 'disable');
  });

  test('"Prior Authorization" → NA checked, Yes/No disabled', () => {
    createEls();
    setSupprtStatement(O, R, 'Prior Authorization', 'RequestReason');
    expect(document.getElementById(`${R}${O}spprSatementQNA`).checked).toBe(true);
  });

  test('"Safety Edit" → NA checked, Yes/No disabled', () => {
    createEls();
    setSupprtStatement(O, R, 'Safety Edit', 'RequestReason');
    expect(document.getElementById(`${R}${O}spprSatementQNA`).checked).toBe(true);
  });

  test('default → NA unchecked, Yes/No re-enabled', () => {
    createEls();
    document.getElementById(`${R}${O}spprSatementQNA`).checked = true;
    setSupprtStatement(O, R, 'Quantity Limit', 'RequestReason');
    expect(document.getElementById(`${R}${O}spprSatementQNA`).checked).toBe(false);
    expect(document.getElementById(`${R}${O}spprSatementQNo`).disabled).toBe(false);
    expect(document.getElementById(`${R}${O}spprSatementQYes`).disabled).toBe(false);
  });
});

describe('setSupprtStatement — comdenpia', () => {
  function createEls() {
    ['NA', 'Yes', 'No'].forEach(sfx => {
      const el = document.createElement('input');
      el.type = 'radio';
      el.id = `${R}${O}spprSatementQ${sfx}`;
      document.body.appendChild(el);
    });
  }

  test('"Yes" → supportY checked, enables location, then disables subQ', () => {
    createEls();
    setSupprtStatement(O, R, 'Yes', 'comdenpia');
    expect(document.getElementById(`${R}${O}spprSatementQYes`).checked).toBe(true);
    expect(toggleDisplay).toHaveBeenCalledWith('solo', [`${R}${O}subspprSatementLocationQ`, `${R}${O}subspprSatementQ`], 'enable');
    expect(toggleDisplay).toHaveBeenCalledWith('solo', [`${R}${O}subspprSatementQ`], 'disable');
  });

  test('"No" → same as "Yes"', () => {
    createEls();
    setSupprtStatement(O, R, 'No', 'comdenpia');
    expect(document.getElementById(`${R}${O}spprSatementQYes`).checked).toBe(true);
  });

  test('default → all unchecked, toggle disable for location and subQ', () => {
    createEls();
    const na = document.getElementById(`${R}${O}spprSatementQNA`);
    const yes = document.getElementById(`${R}${O}spprSatementQYes`);
    const no = document.getElementById(`${R}${O}spprSatementQNo`);
    setSupprtStatement(O, R, 'Other', 'comdenpia');
    expect(na.checked).toBe(false);
    expect(yes.checked).toBe(false);
    expect(no.checked).toBe(false);
    expect(toggleDisplay).toHaveBeenCalledWith('solo', [`${R}${O}subspprSatementLocationQ`, `${R}${O}subspprSatementQ`], 'disable');
  });
});

// ── setMDdxNo ─────────────────────────────────────────────────────────────────

describe('setMDdxNo', () => {
  function createEls() {
    ['mdFDAQNo', 'mdOffLabelQNo'].forEach(id => {
      const el = document.createElement('input');
      el.type = 'radio'; el.id = `${R}${O}${id}`;
      document.body.appendChild(el);
    });
  }

  test('checks both elements when approvedDiagnosis is "No"', () => {
    createEls();
    approvedDiagnosis.mockReturnValue('No');
    setMDdxNo(O, R);
    expect(document.getElementById(`${R}${O}mdFDAQNo`).checked).toBe(true);
    expect(document.getElementById(`${R}${O}mdOffLabelQNo`).checked).toBe(true);
  });

  test('unchecks both when approvedDiagnosis is not "No"', () => {
    createEls();
    document.getElementById(`${R}${O}mdFDAQNo`).checked = true;
    document.getElementById(`${R}${O}mdOffLabelQNo`).checked = true;
    approvedDiagnosis.mockReturnValue('Yes');
    setMDdxNo(O, R);
    expect(document.getElementById(`${R}${O}mdFDAQNo`).checked).toBe(false);
    expect(document.getElementById(`${R}${O}mdOffLabelQNo`).checked).toBe(false);
  });
});

// ── setMDoffLabelCompendiaNA ──────────────────────────────────────────────────

describe('setMDoffLabelCompendiaNA', () => {
  function createEls() {
    ['mdOffLabelQNA', 'mdOffLabelQYes'].forEach(id => {
      const el = document.createElement('input');
      el.type = 'radio'; el.id = `${R}${O}${id}`;
      document.body.appendChild(el);
    });
  }

  test('checks NA and disables Yes when a is "Yes"', () => {
    createEls();
    setMDoffLabelCompendiaNA(O, R, 'Yes');
    expect(document.getElementById(`${R}${O}mdOffLabelQNA`).checked).toBe(true);
    expect(document.getElementById(`${R}${O}mdOffLabelQYes`).disabled).toBe(true);
  });

  test('unchecks NA and enables Yes when a is "No"', () => {
    createEls();
    document.getElementById(`${R}${O}mdOffLabelQNA`).checked = true;
    document.getElementById(`${R}${O}mdOffLabelQYes`).disabled = true;
    setMDoffLabelCompendiaNA(O, R, 'No');
    expect(document.getElementById(`${R}${O}mdOffLabelQNA`).checked).toBe(false);
    expect(document.getElementById(`${R}${O}mdOffLabelQYes`).disabled).toBe(false);
  });
});

// ── setMDoffLabelCompendiaNo ──────────────────────────────────────────────────

describe('setMDoffLabelCompendiaNo', () => {
  function createEl() {
    const el = document.createElement('input');
    el.type = 'radio'; el.id = `${R}${O}mdOffLabelQNo`;
    document.body.appendChild(el);
    return el;
  }

  test('unchecks and disables when a is "Yes"', () => {
    const el = createEl();
    el.checked = true;
    setMDoffLabelCompendiaNo(O, R, 'Yes');
    expect(el.checked).toBe(false);
    expect(el.disabled).toBe(true);
  });

  test('enables (only) when a is not "Yes"', () => {
    const el = createEl();
    el.disabled = true;
    setMDoffLabelCompendiaNo(O, R, 'No');
    expect(el.disabled).toBe(false);
  });
});

// ── resetDLTGuidelineFields ───────────────────────────────────────────────────

describe('resetDLTGuidelineFields', () => {
  const consoleSpy = jest.spyOn(console, 'log').mockImplementation(() => {});
  afterAll(() => consoleSpy.mockRestore());

  test('"Non-formulary" with gpiSelectedWDrugNameSearch → calls automateDLTGuidelines with updated response', async () => {
    const original = { gpiCode: '123', requestReason: 'PA' };
    sessionStorage.setItem('originalMedhokResponse', JSON.stringify(original));
    sessionStorage.setItem('gpiSelectedWDrugNameSearch', 'gpi456');
    guideline.mockReturnValue({ value: '' });
    guidelineRationale.mockReturnValue({ value: '' });
    await resetDLTGuidelineFields(R, O, 'Non-formulary');
    expect(automateDLTGuidelines).toHaveBeenCalledWith(R, O, { ...original, gpiCode: 'gpi456' }, 'gpi456');
  });

  test('"Non-formulary" without gpiSelected and no gpiCode → skips automateDLTGuidelines', async () => {
    sessionStorage.setItem('originalMedhokResponse', JSON.stringify({}));
    await resetDLTGuidelineFields(R, O, 'Non-formulary');
    expect(automateDLTGuidelines).not.toHaveBeenCalled();
  });

  test('"Quantity Limit" saves lastDLTAutomatedAnswer and calls automateDLTGuidelines with requestReason override', async () => {
    const original = { gpiCode: '999' };
    sessionStorage.setItem('originalMedhokResponse', JSON.stringify(original));
    await resetDLTGuidelineFields(R, O, 'Quantity Limit');
    expect(sessionStorage.getItem('lastDLTAutomatedAnswer')).toBe('Quantity Limit');
    expect(automateDLTGuidelines).toHaveBeenCalledWith(R, O, { ...original, requestReason: 'Quantity Limit' });
  });

  test('other answer → removes lastDLTAutomatedAnswer, resets guideline, disables dropdown', async () => {
    const original = {};
    sessionStorage.setItem('originalMedhokResponse', JSON.stringify(original));
    sessionStorage.setItem('lastDLTAutomatedAnswer', 'old');
    const gl = { value: 'old guideline' };
    const glanswer = { value: 'old rationale' };
    guideline.mockReturnValue(gl);
    guidelineRationale.mockReturnValue(glanswer);
    await resetDLTGuidelineFields(R, O, 'Prior Authorization');
    expect(sessionStorage.getItem('lastDLTAutomatedAnswer')).toBeNull();
    expect(gl.value).toBe('');
    expect(glanswer.value).toBe('');
    expect(toggleDisplay).toHaveBeenCalledWith('solo', [`${R}${O}guidelineQ`, `${R}${O}subguidelineQ`], 'disable');
  });
});
