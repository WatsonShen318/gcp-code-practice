jest.mock('../../src/app/modal/alert.service', () => ({ GeneralModal: jest.fn() }));

import msgDeniedRD from '../../src/app/utils/deniedRD.dialog';
import { GeneralModal } from '../../src/app/modal/alert.service';

beforeEach(() => jest.clearAllMocks());

describe('msgDeniedRD', () => {
  test('calls GeneralModal exactly once when answer is "No"', () => {
    msgDeniedRD('No');
    expect(GeneralModal).toHaveBeenCalledTimes(1);
  });

  test('passes the correct icon to GeneralModal', () => {
    msgDeniedRD('No');
    expect(GeneralModal).toHaveBeenCalledWith(expect.objectContaining({
      icon: 'notification_important',
    }));
  });

  test('message contains the RD reminder text', () => {
    msgDeniedRD('No');
    const { message } = GeneralModal.mock.calls[0][0];
    expect(message).toContain('Most redetermination denials');
  });

  test('does not call GeneralModal when answer is "Yes"', () => {
    msgDeniedRD('Yes');
    expect(GeneralModal).not.toHaveBeenCalled();
  });

  test('does not call GeneralModal when answer is empty string', () => {
    msgDeniedRD('');
    expect(GeneralModal).not.toHaveBeenCalled();
  });

  test('does not call GeneralModal when answer is undefined', () => {
    msgDeniedRD(undefined);
    expect(GeneralModal).not.toHaveBeenCalled();
  });
});
