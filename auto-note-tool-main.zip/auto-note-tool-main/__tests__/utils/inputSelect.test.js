/**
 * @jest-environment jsdom
 */
import { rdoBtn, ele, checkbox, eventElement } from '../../src/app/utils/inputSelect';

afterEach(() => { document.body.innerHTML = ''; });

// ── rdoBtn ────────────────────────────────────────────────────────────────────

describe('rdoBtn', () => {
  function buildContainer(name) {
    const container = document.createElement('div');
    container.id = name;
    const r1 = document.createElement('input');
    r1.type = 'radio'; r1.name = `${name}rdo`; r1.id = `${name}r1`;
    const r2 = document.createElement('input');
    r2.type = 'radio'; r2.name = `${name}rdo`; r2.id = `${name}r2`;
    // unrelated radio that should NOT be returned
    const other = document.createElement('input');
    other.type = 'radio'; other.name = 'other'; other.id = 'otherR';
    container.append(r1, r2, other);
    document.body.appendChild(container);
  }

  test('returns radio inputs with name="${n}rdo" from container', () => {
    buildContainer('techQueue');
    const result = rdoBtn('techQueue');
    expect(result.length).toBe(2);
    expect(result[0].name).toBe('techQueuerdo');
  });

  test('excludes radios with a different name', () => {
    buildContainer('techQueue');
    const result = rdoBtn('techQueue');
    expect([...result].some(r => r.id === 'otherR')).toBe(false);
  });
});

// ── ele ───────────────────────────────────────────────────────────────────────

describe('ele', () => {
  test('returns element by id "${n}" when no index provided', () => {
    const div = document.createElement('div');
    div.id = 'myField';
    document.body.appendChild(div);
    expect(ele('myField')).toBe(div);
  });

  test('returns element by id "${n}${i}" when index provided', () => {
    const div = document.createElement('div');
    div.id = 'myField2';
    document.body.appendChild(div);
    expect(ele('myField', 2)).toBe(div);
  });

  test('returns null when element does not exist', () => {
    expect(ele('doesNotExist')).toBeNull();
  });
});

// ── checkbox ──────────────────────────────────────────────────────────────────

describe('checkbox', () => {
  function buildContainer(name) {
    const container = document.createElement('div');
    container.id = name;
    const cb1 = document.createElement('input');
    cb1.type = 'checkbox'; cb1.id = `${name}cb1`;
    const cb2 = document.createElement('input');
    cb2.type = 'checkbox'; cb2.id = `${name}cb2`;
    // radio that should NOT be returned
    const radio = document.createElement('input');
    radio.type = 'radio'; radio.id = `${name}r1`;
    container.append(cb1, cb2, radio);
    document.body.appendChild(container);
  }

  test('returns only checkbox inputs with id containing the container name', () => {
    buildContainer('techQueuecompendia');
    const result = checkbox('techQueuecompendia');
    expect(result.length).toBe(2);
    expect([...result].every(cb => cb.type === 'checkbox')).toBe(true);
  });
});

// ── eventElement ──────────────────────────────────────────────────────────────

describe('eventElement', () => {
  test('returns NodeList of radio inputs by name for type "radio"', () => {
    const r1 = document.createElement('input');
    r1.type = 'radio'; r1.name = 'myRadio';
    document.body.appendChild(r1);
    const result = eventElement('radio', 'myRadio');
    expect(result.length).toBe(1);
    expect(result[0].name).toBe('myRadio');
  });

  test('returns single element by id for type "text"', () => {
    const inp = document.createElement('input');
    inp.type = 'text'; inp.id = 'myText';
    document.body.appendChild(inp);
    const result = eventElement('text', 'myText');
    expect(result).toBe(inp);
  });

  test('returns single element by id for type "select"', () => {
    const sel = document.createElement('select');
    sel.id = 'mySel';
    document.body.appendChild(sel);
    expect(eventElement('select', 'mySel')).toBe(sel);
  });

  test('returns single element by id for type "button"', () => {
    const btn = document.createElement('button');
    btn.id = 'myBtn';
    document.body.appendChild(btn);
    expect(eventElement('button', 'myBtn')).toBe(btn);
  });

  test('returns checkboxes inside container for type "check"', () => {
    const container = document.createElement('div');
    container.id = 'myCheck';
    const cb = document.createElement('input');
    cb.type = 'checkbox'; cb.id = 'myCheckcb1';
    container.appendChild(cb);
    document.body.appendChild(container);
    const result = eventElement('check', 'myCheck');
    expect(result.length).toBe(1);
    expect(result[0].type).toBe('checkbox');
  });
});
