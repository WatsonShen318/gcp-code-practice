import { bold } from '../../src/app/utils/font.formatter';

describe('font.formatter', () => {
  describe('bold', () => {
    test('wraps the text in a primary bold span', () => {
      expect(bold('hello')).toBe('<span class="text-primary fw-bold">hello</span>');
    });

    test('wraps an empty string correctly', () => {
      expect(bold('')).toBe('<span class="text-primary fw-bold"></span>');
    });

    test('wraps HTML content without double-encoding', () => {
      const result = bold('<em>word</em>');
      expect(result).toBe('<span class="text-primary fw-bold"><em>word</em></span>');
    });
  });
});
