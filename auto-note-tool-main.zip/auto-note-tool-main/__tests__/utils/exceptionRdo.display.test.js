jest.mock('../../src/app/utils/notetool.display', () => ({ toggleDisplay: jest.fn() }));

import toggleExceptionRdo from '../../src/app/utils/exceptionRdo.display';
import { toggleDisplay } from '../../src/app/utils/notetool.display';

beforeEach(() => { jest.clearAllMocks(); });

describe('toggleExceptionRdo', () => {
  test('disables exceptionRdoQ when answer is "Sent to RFI"', () => {
    toggleExceptionRdo('Queue', 'tech', 'Sent to RFI');
    expect(toggleDisplay).toHaveBeenCalledWith('solo', ['techQueueexceptionRdoQ'], 'disable');
  });

  test('enables exceptionRdoQ when answer is not "Sent to RFI"', () => {
    toggleExceptionRdo('Queue', 'tech', 'Denied');
    expect(toggleDisplay).toHaveBeenCalledWith('solo', ['techQueueexceptionRdoQ'], 'enable');
  });

  test('enables exceptionRdoQ when answer is "Approved"', () => {
    toggleExceptionRdo('IBC', 'rph', 'Approved');
    expect(toggleDisplay).toHaveBeenCalledWith('solo', ['rphIBCexceptionRdoQ'], 'enable');
  });

  test('enables exceptionRdoQ when answer is empty string', () => {
    toggleExceptionRdo('TAT', 'rph', '');
    expect(toggleDisplay).toHaveBeenCalledWith('solo', ['rphTATexceptionRdoQ'], 'enable');
  });
});
