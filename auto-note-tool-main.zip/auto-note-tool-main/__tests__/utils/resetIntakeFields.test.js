jest.mock('../../src/app/utils/notetool.display', () => ({ toggleDisplay: jest.fn() }));

import resetFillIntake from '../../src/app/utils/resetIntakeFields';
import { toggleDisplay } from '../../src/app/utils/notetool.display';

beforeEach(() => { jest.clearAllMocks(); });

describe('resetFillIntake', () => {
  test('calls toggleDisplay with all intake field IDs and "enable"', () => {
    resetFillIntake('tech', 'Queue');

    expect(toggleDisplay).toHaveBeenCalledTimes(1);
    expect(toggleDisplay).toHaveBeenCalledWith(
      'solo',
      [
        'techQueueclaimQPA', 'techQueueclaimQ',
        'techQueuesubclaimTodayDQPA', 'techQueuesubclaimTodayDQ',
        'techQueueclaim90dQPA', 'techQueueclaim90dQ',
        'techQueuesubclaim90dQPA', 'techQueuesubclaim90dQ',
        'techQueuespprSatementQPA', 'techQueuespprSatementQ',
      ],
      'enable'
    );
  });

  test('uses the supplied role and origin for all field IDs', () => {
    resetFillIntake('rph', 'IBC');

    const [, fields] = toggleDisplay.mock.calls[0];
    expect(fields.every(id => id.startsWith('rphIBC'))).toBe(true);
  });

  test('enables exactly 10 fields', () => {
    resetFillIntake('tech', 'TAT');

    const [, fields] = toggleDisplay.mock.calls[0];
    expect(fields).toHaveLength(10);
  });
});
