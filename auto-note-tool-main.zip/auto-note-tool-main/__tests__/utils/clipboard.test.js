import copyToClipBoard from '../../src/app/utils/clipboard.api';

describe('copyToClipBoard', () => {
  afterEach(() => {
    delete global.navigator;
    delete global.document;
  });

  test('calls navigator.clipboard.writeText with the supplied text', () => {
    const mockWriteText = jest.fn();
    Object.defineProperty(global, 'navigator', {
      value: { clipboard: { writeText: mockWriteText } },
      writable: true,
      configurable: true,
    });

    copyToClipBoard('hello world');

    expect(mockWriteText).toHaveBeenCalledTimes(1);
    expect(mockWriteText).toHaveBeenCalledWith('hello world');
  });

  test('falls back to document.execCommand("copy") when navigator.clipboard is unavailable', () => {
    const mockExecCommand = jest.fn();
    Object.defineProperty(global, 'navigator', {
      value: {},
      writable: true,
      configurable: true,
    });
    Object.defineProperty(global, 'document', {
      value: { execCommand: mockExecCommand },
      writable: true,
      configurable: true,
    });

    copyToClipBoard('fallback text');

    expect(mockExecCommand).toHaveBeenCalledTimes(1);
    expect(mockExecCommand).toHaveBeenCalledWith('copy');
  });

  test('does not call execCommand when clipboard API is available', () => {
    const mockWriteText = jest.fn();
    const mockExecCommand = jest.fn();
    Object.defineProperty(global, 'navigator', {
      value: { clipboard: { writeText: mockWriteText } },
      writable: true,
      configurable: true,
    });
    Object.defineProperty(global, 'document', {
      value: { execCommand: mockExecCommand },
      writable: true,
      configurable: true,
    });

    copyToClipBoard('text');

    expect(mockWriteText).toHaveBeenCalled();
    expect(mockExecCommand).not.toHaveBeenCalled();
  });
});
