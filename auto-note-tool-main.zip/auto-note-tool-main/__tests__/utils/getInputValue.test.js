/**
 * @jest-environment jsdom
 */
import getInputValue, {
  getValue,
  getCompendiaChecks,
  getDurgdexChecks,
  getMembers,
} from '../../src/app/utils/getInputValue';

afterEach(() => { document.body.innerHTML = ''; });

// ── helpers ───────────────────────────────────────────────────────────────────

function addRadio(name, id, value, checked = false) {
  const r = document.createElement('input');
  r.type = 'radio'; r.name = name; r.id = id; r.value = value; r.checked = checked;
  document.body.appendChild(r);
  return r;
}

function addText(id, value = '') {
  const t = document.createElement('input');
  t.type = 'text'; t.id = id; t.value = value;
  document.body.appendChild(t);
  return t;
}

function addCheckbox(id, value, checked = false) {
  const cb = document.createElement('input');
  cb.type = 'checkbox'; cb.id = id; cb.value = value; cb.checked = checked;
  document.body.appendChild(cb);
  return cb;
}

// ── getInputValue ─────────────────────────────────────────────────────────────

describe('getInputValue — radio', () => {
  test('returns the checked radio value for each named group', () => {
    addRadio('grp1', 'grp1yes', 'Yes', true);
    addRadio('grp1', 'grp1no', 'No', false);
    const result = getInputValue('radio', ['grp1']);
    expect(result['grp1']).toBe('Yes');
  });

  test('returns empty string when no radio is checked', () => {
    addRadio('grp2', 'grp2a', 'A', false);
    const result = getInputValue('radio', ['grp2']);
    expect(result['grp2']).toBe('');
  });

  test('handles multiple named groups in one call', () => {
    addRadio('alpha', 'alphaY', 'Yes', true);
    addRadio('beta', 'betaN', 'No', true);
    const result = getInputValue('radio', ['alpha', 'beta']);
    expect(result['alpha']).toBe('Yes');
    expect(result['beta']).toBe('No');
  });
});

describe('getInputValue — text', () => {
  test('returns text input values by ID', () => {
    addText('txt1', 'Hello');
    addText('txt2', 'World');
    const result = getInputValue('text', ['txt1', 'txt2']);
    expect(result['txt1']).toBe('Hello');
    expect(result['txt2']).toBe('World');
  });

  test('returns empty string for empty text inputs', () => {
    addText('empty1', '');
    const result = getInputValue('text', ['empty1']);
    expect(result['empty1']).toBe('');
  });
});

// ── getValue ──────────────────────────────────────────────────────────────────

describe('getValue — radio', () => {
  test('returns the checked radio value', () => {
    addRadio('singleGrp', 'sgYes', 'Yes', true);
    addRadio('singleGrp', 'sgNo', 'No', false);
    expect(getValue('radio', 'singleGrp')).toBe('Yes');
  });

  test('returns empty string when no radio is checked', () => {
    addRadio('unchecked', 'ucA', 'A', false);
    expect(getValue('radio', 'unchecked')).toBe('');
  });
});

describe('getValue — text / select', () => {
  test('returns text input value', () => {
    addText('myTxt', 'SomeValue');
    expect(getValue('text', 'myTxt')).toBe('SomeValue');
  });

  test('returns empty string when text input is empty', () => {
    addText('emptyTxt', '');
    expect(getValue('text', 'emptyTxt')).toBe('');
  });

  test('returns select value', () => {
    const sel = document.createElement('select');
    sel.id = 'mySel';
    const opt = document.createElement('option');
    opt.value = 'RD'; opt.selected = true; sel.appendChild(opt);
    document.body.appendChild(sel);
    expect(getValue('select', 'mySel')).toBe('RD');
  });
});

// ── getCompendiaChecks ────────────────────────────────────────────────────────

describe('getCompendiaChecks', () => {
  test('returns comma-separated checked compendia values with leading comma', () => {
    addCheckbox('techQueuesubcompendiaRefsQ_1', 'Micromedex', true);
    addCheckbox('techQueuesubcompendiaRefsQ_2', 'Drugdex', true);
    addCheckbox('techQueuesubcompendiaRefsQ_3', 'Other', false);
    expect(getCompendiaChecks('tech', 'Queue')).toBe(', Micromedex, Drugdex');
  });

  test('returns empty string when no checkboxes are checked', () => {
    addCheckbox('techQueuesubcompendiaRefsQ_1', 'Micromedex', false);
    expect(getCompendiaChecks('tech', 'Queue')).toBe('');
  });
});

// ── getDurgdexChecks ──────────────────────────────────────────────────────────

describe('getDurgdexChecks', () => {
  test('returns referenced drugdex values in parentheses with leading comma', () => {
    addCheckbox('techQueuesubcompendiaRefsDdexQ_1', 'Vol1', true);
    addCheckbox('techQueuesubcompendiaRefsDdexQ_2', 'Vol2', true);
    expect(getDurgdexChecks('tech', 'Queue')).toBe(', (Referenced Vol1, Vol2 in Drugdex)');
  });

  test('returns empty string when nothing is checked', () => {
    expect(getDurgdexChecks('tech', 'Queue')).toBe('');
  });
});

// ── getMembers ────────────────────────────────────────────────────────────────

describe('getMembers', () => {
  test('returns member IDs prefixed with "Member: "', () => {
    addCheckbox('techQueuememberidsQ_1', 'ID001', true);
    addCheckbox('techQueuememberidsQ_2', 'ID002', true);
    expect(getMembers('tech', 'Queue')).toBe('Member: ID001, ID002');
  });

  test('returns "Member: " with empty string when none are checked', () => {
    expect(getMembers('tech', 'Queue')).toBe('Member: ');
  });
});
