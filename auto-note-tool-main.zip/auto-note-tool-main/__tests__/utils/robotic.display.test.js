jest.mock('../../src/app/utils/notetool.display', () => ({ toggleDisplay: jest.fn() }));
jest.mock('../../src/app/prefill/helpers', () => ({ isFlowAutomated: jest.fn() }));

import toggleRobotic from '../../src/app/utils/robotic.display';
import { toggleDisplay } from '../../src/app/utils/notetool.display';
import { isFlowAutomated } from '../../src/app/prefill/helpers';

beforeEach(() => { jest.clearAllMocks(); });

describe('toggleRobotic', () => {
  test('disables ePAQ when answer is "Not found"', () => {
    toggleRobotic('Queue', 'tech', 'Not found');
    expect(toggleDisplay).toHaveBeenCalledWith('solo', ['techQueueePAQ'], 'disable');
  });

  test('disables ePAQ when answer is "highlighted in blue"', () => {
    toggleRobotic('Queue', 'tech', 'highlighted in blue');
    expect(toggleDisplay).toHaveBeenCalledWith('solo', ['techQueueePAQ'], 'disable');
  });

  test('does not check isFlowAutomated when answer is "Not found"', () => {
    toggleRobotic('Queue', 'tech', 'Not found');
    expect(isFlowAutomated).not.toHaveBeenCalled();
  });

  test('enables ePAQ for any other answer when flow is not automated', () => {
    isFlowAutomated.mockReturnValue(false);
    toggleRobotic('Queue', 'tech', 'is displayed in black text');
    expect(toggleDisplay).toHaveBeenCalledWith('solo', ['techQueueePAQ'], 'enable');
  });

  test('does not enable ePAQ when flow is automated', () => {
    isFlowAutomated.mockReturnValue(true);
    toggleRobotic('Queue', 'tech', 'is displayed in black text');
    expect(toggleDisplay).not.toHaveBeenCalled();
  });

  test('uses the supplied role and origin in the field ID', () => {
    isFlowAutomated.mockReturnValue(false);
    toggleRobotic('TAT', 'rph', 'some answer');
    expect(toggleDisplay).toHaveBeenCalledWith('solo', ['rphTATePAQ'], 'enable');
  });
});
