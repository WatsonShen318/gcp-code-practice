import { validateCaseId } from '../../src/app/utils/inputValidation';

describe('validateCaseId', () => {
  test('returns true for a valid case ID (example from docs: M24R7FYPL9Z)', () => {
    expect(validateCaseId('M24R7FYPL9Z')).toBe(true);
  });

  test('returns true for a valid case ID with lowercase letters', () => {
    expect(validateCaseId('a99bcdefgh1')).toBe(true);
  });

  test('returns true for a valid mixed-case case ID', () => {
    expect(validateCaseId('A26XYZABCD9')).toBe(true);
  });

  test('returns false for an empty string', () => {
    expect(validateCaseId('')).toBe(false);
  });

  test('returns false if the first character is a digit', () => {
    expect(validateCaseId('124R7FYPL9Z')).toBe(false);
  });

  test('returns false if the ID is shorter than 11 characters', () => {
    expect(validateCaseId('M24R7FY')).toBe(false);
  });

  test('returns false if the ID is longer than 11 characters', () => {
    expect(validateCaseId('M24R7FYPL9ZX')).toBe(false);
  });

  test('returns false if the ID contains a special character', () => {
    expect(validateCaseId('M24R7FYP-9Z')).toBe(false);
  });

  test('returns false if the 2nd or 3rd characters are not digits', () => {
    expect(validateCaseId('MABR7FYPL9Z')).toBe(false);
  });
});
