jest.mock('../../src/app/utils/notetool.display', () => ({ toggleDisplay: jest.fn() }));
jest.mock('../../src/app/prefill/helpers', () => ({ isFlowAutomated: jest.fn() }));

import toggleCaseVeri from '../../src/app/utils/caseVerified.display';
import { toggleDisplay } from '../../src/app/utils/notetool.display';
import { isFlowAutomated } from '../../src/app/prefill/helpers';

beforeEach(() => { jest.clearAllMocks(); });

describe('toggleCaseVeri', () => {
  test('disables caseVerifiedQ when answer is "Not found"', () => {
    toggleCaseVeri('Queue', 'tech', 'Not found');
    expect(toggleDisplay).toHaveBeenCalledWith('solo', ['techQueuecaseVerifiedQ'], 'disable');
  });

  test('disables caseVerifiedQ when answer is "highlighted in blue"', () => {
    toggleCaseVeri('Queue', 'tech', 'highlighted in blue');
    expect(toggleDisplay).toHaveBeenCalledWith('solo', ['techQueuecaseVerifiedQ'], 'disable');
  });

  test('does not check isFlowAutomated when answer is "Not found"', () => {
    toggleCaseVeri('Queue', 'tech', 'Not found');
    expect(isFlowAutomated).not.toHaveBeenCalled();
  });

  test('enables caseVerifiedQ for any other answer when flow is not automated', () => {
    isFlowAutomated.mockReturnValue(false);
    toggleCaseVeri('Queue', 'tech', 'is displayed in black text');
    expect(toggleDisplay).toHaveBeenCalledWith('solo', ['techQueuecaseVerifiedQ'], 'enable');
  });

  test('does not enable caseVerifiedQ when flow is automated', () => {
    isFlowAutomated.mockReturnValue(true);
    toggleCaseVeri('Queue', 'tech', 'is displayed in black text');
    expect(toggleDisplay).not.toHaveBeenCalled();
  });

  test('uses the supplied role and origin in the field ID', () => {
    isFlowAutomated.mockReturnValue(false);
    toggleCaseVeri('IBC', 'rph', 'some answer');
    expect(toggleDisplay).toHaveBeenCalledWith('solo', ['rphIBCcaseVerifiedQ'], 'enable');
  });
});
