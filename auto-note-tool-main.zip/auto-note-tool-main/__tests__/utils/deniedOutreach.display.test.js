jest.mock('../../src/app/utils/notetool.display', () => ({ toggleDisplay: jest.fn() }));

import toggleDeniedOutreach from '../../src/app/utils/deniedOutreach.display';
import { toggleDisplay } from '../../src/app/utils/notetool.display';

beforeEach(() => { jest.clearAllMocks(); });

describe('toggleDeniedOutreach', () => {
  test('enables suffOutreachQ when answer is "Denied"', () => {
    toggleDeniedOutreach('Queue', 'tech', 'Denied');
    expect(toggleDisplay).toHaveBeenCalledWith('solo', ['techQueuesuffOutreachQ'], 'enable');
  });

  test('disables suffOutreachQ when answer is not "Denied"', () => {
    toggleDeniedOutreach('Queue', 'tech', 'Approved');
    expect(toggleDisplay).toHaveBeenCalledWith('solo', ['techQueuesuffOutreachQ'], 'disable');
  });

  test('disables suffOutreachQ when answer is empty string', () => {
    toggleDeniedOutreach('IBC', 'rph', '');
    expect(toggleDisplay).toHaveBeenCalledWith('solo', ['rphIBCsuffOutreachQ'], 'disable');
  });

  test('uses the supplied role and origin in the field ID', () => {
    toggleDeniedOutreach('TAT', 'rph', 'Denied');
    expect(toggleDisplay).toHaveBeenCalledWith('solo', ['rphTATsuffOutreachQ'], 'enable');
  });
});
