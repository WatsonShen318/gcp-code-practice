jest.mock('../../src/app/form_alts/formAlts', () => ({
  clearFormAltsCache: jest.fn(),
}));

import resetSessionStorage from '../../src/app/utils/resetSessionStorage';
import { clearFormAltsCache } from '../../src/app/form_alts/formAlts';

// Provide a sessionStorage mock for the Node test environment
const sessionStorageMock = (() => {
  let store = {};
  return {
    getItem: jest.fn((key) => (key in store ? store[key] : null)),
    setItem: jest.fn((key, value) => { store[key] = String(value); }),
    removeItem: jest.fn((key) => { delete store[key]; }),
    clear() { store = {}; },
    _store() { return store; },
  };
})();
Object.defineProperty(global, 'sessionStorage', { value: sessionStorageMock, writable: true });

beforeEach(() => {
  sessionStorageMock.clear();
  jest.clearAllMocks();
});

describe('resetSessionStorage', () => {
  test('sets startTime to an ISO timestamp', () => {
    resetSessionStorage();
    const val = sessionStorageMock.setItem.mock.calls.find(([k]) => k === 'startTime')?.[1];
    expect(val).toMatch(/^\d{4}-\d{2}-\d{2}T/);
  });

  test('resets medhokStatus to an empty JSON array', () => {
    resetSessionStorage();
    const val = sessionStorageMock.setItem.mock.calls.find(([k]) => k === 'medhokStatus')?.[1];
    expect(val).toBe('[]');
  });

  test('resets workFlow to "Manual"', () => {
    resetSessionStorage();
    const val = sessionStorageMock.setItem.mock.calls.find(([k]) => k === 'workFlow')?.[1];
    expect(val).toBe('Manual');
  });

  test('clears RECOMMENDED_CASE_DCSN_ROUTING and FINAL_CASE_DCSN_ROUTING', () => {
    resetSessionStorage();
    const calls = sessionStorageMock.setItem.mock.calls;
    expect(calls.find(([k]) => k === 'RECOMMENDED_CASE_DCSN_ROUTING')?.[1]).toBe('');
    expect(calls.find(([k]) => k === 'FINAL_CASE_DCSN_ROUTING')?.[1]).toBe('');
  });

  test('removes lastDLTAutomatedAnswer from sessionStorage', () => {
    resetSessionStorage();
    expect(sessionStorageMock.removeItem).toHaveBeenCalledWith('lastDLTAutomatedAnswer');
  });

  test('removes manualFlowDrug from sessionStorage', () => {
    resetSessionStorage();
    expect(sessionStorageMock.removeItem).toHaveBeenCalledWith('manualFlowDrug');
  });

  test('calls clearFormAltsCache once', () => {
    resetSessionStorage();
    expect(clearFormAltsCache).toHaveBeenCalledTimes(1);
  });

  test('resets originalMedhokResponse to empty JSON object', () => {
    resetSessionStorage();
    const val = sessionStorageMock.setItem.mock.calls.find(([k]) => k === 'originalMedhokResponse')?.[1];
    expect(val).toBe('{}');
  });

  test('removes qlActive from sessionStorage', () => {
    resetSessionStorage();
    expect(sessionStorageMock.removeItem).toHaveBeenCalledWith('qlActive');
  });
});
