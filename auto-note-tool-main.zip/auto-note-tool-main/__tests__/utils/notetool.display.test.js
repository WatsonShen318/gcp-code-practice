/**
 * @jest-environment jsdom
 */
import { HideAll, toggleDisable, toggleDisplay } from '../../src/app/utils/notetool.display';

afterEach(() => { document.body.innerHTML = ''; });

// ── HideAll ──────────────────────────────────────────────────────────────────

describe('HideAll', () => {
  test('hides and disables elements with .ihide class', () => {
    const h = document.createElement('div');
    h.classList.add('ihide');
    document.body.appendChild(h);
    HideAll();
    expect(h.style.display).toBe('none');
    expect(h.disabled).toBe(true);
  });

  test('shows and enables elements with .defaultShow class', () => {
    const s = document.createElement('div');
    s.classList.add('defaultShow');
    document.body.appendChild(s);
    HideAll();
    expect(s.style.display).toBe('block');
    expect(s.disabled).toBe(false);
  });

  test('handles both classes simultaneously', () => {
    const h1 = document.createElement('div');
    h1.classList.add('ihide');
    const h2 = document.createElement('div');
    h2.classList.add('ihide');
    const s1 = document.createElement('div');
    s1.classList.add('defaultShow');
    document.body.append(h1, h2, s1);
    HideAll();
    expect(h1.style.display).toBe('none');
    expect(h2.style.display).toBe('none');
    expect(s1.style.display).toBe('block');
  });
});

// ── toggleDisable ─────────────────────────────────────────────────────────────

describe('toggleDisable', () => {
  function addEl(id) {
    const el = document.createElement('input');
    el.id = id;
    document.body.appendChild(el);
    return el;
  }

  test('disables elements by ID when status is "disable"', () => {
    addEl('foo'); addEl('bar');
    toggleDisable(['foo', 'bar'], 'disable');
    expect(document.getElementById('foo').disabled).toBe(true);
    expect(document.getElementById('bar').disabled).toBe(true);
  });

  test('enables elements by ID when status is not "disable"', () => {
    const el = addEl('foo');
    el.disabled = true;
    toggleDisable(['foo'], 'enable');
    expect(el.disabled).toBe(false);
  });

  test('processes every element in the array', () => {
    ['a', 'b', 'c'].forEach(id => addEl(id));
    toggleDisable(['a', 'b', 'c'], 'disable');
    ['a', 'b', 'c'].forEach(id => expect(document.getElementById(id).disabled).toBe(true));
  });
});

// ── toggleDisplay — tag ───────────────────────────────────────────────────────

describe('toggleDisplay — tag', () => {
  test('hides and disables element objects when status is "disable"', () => {
    const el = document.createElement('div');
    document.body.appendChild(el);
    toggleDisplay('tag', [el], 'disable');
    expect(el.style.display).toBe('none');
    expect(el.disabled).toBe(true);
  });

  test('shows and enables element objects when status is "enable"', () => {
    const el = document.createElement('div');
    el.style.display = 'none';
    el.disabled = true;
    document.body.appendChild(el);
    toggleDisplay('tag', [el], 'enable');
    expect(el.style.display).toBe('block');
    expect(el.disabled).toBe(false);
  });

  test('processes every element in the array', () => {
    const els = [1, 2, 3].map(() => { const e = document.createElement('div'); document.body.appendChild(e); return e; });
    toggleDisplay('tag', els, 'disable');
    els.forEach(e => expect(e.style.display).toBe('none'));
  });
});

// ── toggleDisplay — rest ──────────────────────────────────────────────────────

describe('toggleDisplay — rest', () => {
  test('hides sibling fieldsets when status is "disable"', () => {
    document.body.innerHTML = `
      <fieldset id="anchor"></fieldset>
      <fieldset id="sib1"></fieldset>
      <fieldset id="sib2"></fieldset>
    `;
    toggleDisplay('rest', '#anchor', 'disable');
    expect(document.getElementById('sib1').style.display).toBe('none');
    expect(document.getElementById('sib2').style.display).toBe('none');
    expect(document.getElementById('anchor').style.display).toBe('');
  });

  test('shows sibling fieldsets when status is "enable"', () => {
    document.body.innerHTML = `
      <fieldset id="anchor"></fieldset>
      <fieldset id="sib1" style="display:none" disabled></fieldset>
    `;
    toggleDisplay('rest', '#anchor', 'enable');
    expect(document.getElementById('sib1').style.display).toBe('block');
    expect(document.getElementById('sib1').disabled).toBe(false);
  });
});

// ── toggleDisplay — role ──────────────────────────────────────────────────────

describe('toggleDisplay — role', () => {
  test('hides elements whose data-role contains the value', () => {
    document.body.innerHTML = `
      <div id="a" data-role="tech"></div>
      <div id="b" data-role="tech rph"></div>
      <div id="c" data-role="rph"></div>
    `;
    toggleDisplay('role', 'tech', 'disable');
    expect(document.getElementById('a').style.display).toBe('none');
    expect(document.getElementById('b').style.display).toBe('none');
    expect(document.getElementById('c').style.display).toBe('');
  });

  test('shows elements whose data-role contains the value', () => {
    document.body.innerHTML = `<div id="a" data-role="tech" style="display:none"></div>`;
    toggleDisplay('role', 'tech', 'enable');
    expect(document.getElementById('a').style.display).toBe('block');
  });
});

// ── toggleDisplay — solo/button/tool ─────────────────────────────────────────

describe('toggleDisplay — solo / button / tool', () => {
  function addEl(id) {
    const el = document.createElement('div');
    el.id = id;
    document.body.appendChild(el);
    return el;
  }

  test('hides and disables element by ID when status is "disable"', () => {
    addEl('myEl');
    toggleDisplay('solo', ['myEl'], 'disable');
    expect(document.getElementById('myEl').style.display).toBe('none');
    expect(document.getElementById('myEl').disabled).toBe(true);
  });

  test('shows and enables element by ID when status is "enable"', () => {
    const el = addEl('myEl');
    el.style.display = 'none'; el.disabled = true;
    toggleDisplay('solo', ['myEl'], 'enable');
    expect(el.style.display).toBe('block');
    expect(el.disabled).toBe(false);
  });

  test('gracefully skips a missing element without throwing', () => {
    expect(() => toggleDisplay('solo', ['nonexistent'], 'disable')).not.toThrow();
  });

  test('applies to all IDs in the value array', () => {
    addEl('el1'); addEl('el2');
    toggleDisplay('solo', ['el1', 'el2'], 'disable');
    expect(document.getElementById('el1').style.display).toBe('none');
    expect(document.getElementById('el2').style.display).toBe('none');
  });

  test('"button" type behaves the same as "solo"', () => {
    addEl('btn');
    toggleDisplay('button', ['btn'], 'disable');
    expect(document.getElementById('btn').style.display).toBe('none');
  });

  test('"tool" type behaves the same as "solo"', () => {
    addEl('tl');
    toggleDisplay('tool', ['tl'], 'enable');
    expect(document.getElementById('tl').style.display).toBe('block');
  });
});
