/**
 * @jest-environment jsdom
 */
import togglePartialValidation from '../../src/app/utils/validation';

const R = 'tech', O = 'Queue';

function setup(extraTag = 'normal') {
  document.body.innerHTML = `
    <div class="tab-content">
      <fieldset id="${R}${O}" class="active">
        <fieldset data-tag="outboundcall"></fieldset>
        <fieldset data-tag="${extraTag}"></fieldset>
        <fieldset data-tag="outboundcallalt"></fieldset>
      </fieldset>
    </div>
    <div id="notetool" class="was-validated"></div>
  `;
}

afterEach(() => { document.body.innerHTML = ''; });

describe('togglePartialValidation — outboundcall', () => {
  test('disables fieldsets that do not match the "outboundcall" tag', () => {
    setup();
    togglePartialValidation(O, R, 'outboundcall');
    // Only the "normal" and "outboundcallalt" fieldsets are NOT tagged "outboundcall"
    const rest = document.querySelectorAll(
      `div.tab-content>fieldset[id=${R}${O}].active > fieldset:not([data-tag*="outboundcall"])`
    );
    rest.forEach(fs => expect(fs.disabled).toBe(true));
  });

  test('does not remove was-validated from notetool on outboundcall', () => {
    setup();
    togglePartialValidation(O, R, 'outboundcall');
    expect(document.getElementById('notetool').classList.contains('was-validated')).toBe(true);
  });
});

describe('togglePartialValidation — outboundcallalt', () => {
  test('disables non-matching fieldsets for "outboundcallalt"', () => {
    setup();
    togglePartialValidation(O, R, 'outboundcallalt');
    const rest = document.querySelectorAll(
      `div.tab-content>fieldset[id=${R}${O}].active > fieldset:not([data-tag*="outboundcallalt"])`
    );
    rest.forEach(fs => expect(fs.disabled).toBe(true));
  });
});

describe('togglePartialValidation — other tag', () => {
  test('enables all non-matching fieldsets', () => {
    setup('normal');
    const fs = document.querySelector(`div.tab-content>fieldset[id=${R}${O}].active > fieldset[data-tag="outboundcall"]`);
    fs.disabled = true;
    togglePartialValidation(O, R, 'normal');
    const rest = document.querySelectorAll(
      `div.tab-content>fieldset[id=${R}${O}].active > fieldset:not([data-tag*="normal"])`
    );
    rest.forEach(el => expect(el.disabled).toBe(false));
  });

  test('removes "was-validated" class from #notetool', () => {
    setup();
    togglePartialValidation(O, R, 'normal');
    expect(document.getElementById('notetool').classList.contains('was-validated')).toBe(false);
  });
});
