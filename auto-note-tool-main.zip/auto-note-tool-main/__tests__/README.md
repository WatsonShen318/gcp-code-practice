# auto-note-tool — Test Coverage Plan

## Goal

Cover every JS file under `src/app/` and `helpers/`. DOM-heavy files require `jest-environment-jsdom`; pure/axios files can be tested in Node today.

---

## Test Setup

- **Runner:** Jest 29 + `babel-jest` (Babel transforms ES module `import`/`export`)
- **Environment:** `node` (no DOM — DOM tests use per-file `@jest-environment jsdom` docblock)
- **Coverage provider:** v8
- **Coverage reports:** `text` (terminal) + `lcov` (for SonarQube at `coverage/lcov.info`)
- **Pre-commit hook:** `.git/hooks/pre-commit` runs `npx jest --coverage` and blocks commit on failure

---

## Folder Structure

Tests mirror the source tree under `__tests__/`:

```
__tests__/
  helpers/              → helpers/*.js
  utils/                → src/app/utils/*.js
  medhok/               → src/app/medhok/*.js
  aetna_questions/      → src/app/aetna_questions/api/*.js
  form_alts/            → src/app/form_alts/api/*.js          (TODO)
  quantity_limit/       → src/app/quantity_limit/api/*.js     (TODO)
  verbiage/             → src/app/verbiage/*.js               (TODO)
  prefill/              → src/app/prefill/*.js                (TODO)
  multiCase/            → src/app/multiCase/*.js              (TODO)
  decision/             → src/app/decision/*.js               (TODO)
  dlt_guidelines/       → src/app/dlt_guidelines/*.js         (TODO)
  finalnote/            → src/app/finalnote/*.js              (TODO)
  ...one folder per src/app/ subfolder
```

---

## Prerequisite: Install jsdom

All DOM-dependent tests require this package:

```bash
npm install --save-dev jest-environment-jsdom
```

Add a docblock to each DOM-heavy test file so Node tests are unaffected:

```js
/**
 * @jest-environment jsdom
 */
```

---

## TODO List — Ordered by Priority

### Phase 1 — Unblock DOM tests in `src/app/utils/` (install jsdom first)

| # | File | Lines | Approach | Status |
|---|---|---|---|---|
| 1 | `src/app/utils/notetool.display.js` | 100 | jsdom — `toggleDisplay` is called by many other files; test the show/hide/enable/disable DOM operations | ✅ DONE |
| 2 | `src/app/utils/validation.js` | 13 | jsdom — `togglePartialValidation` disables/enables fieldsets via DOM | ✅ DONE |
| 3 | `src/app/utils/clearInput.js` | 33 | jsdom — `clearInput`/`clearInputs` clear radio/text inputs via `document.getElementById` | ✅ DONE |
| 4 | `src/app/utils/inputSelect.js` | 31 | jsdom — `rdoBtn`, `ele`, `checkbox`, `eventElement` query DOM elements | ✅ DONE |
| 5 | `src/app/utils/getInputValue.js` | 108 | jsdom — `getInputValue`, `getValue`, `getRepeatSectionVals`, `getCompendiaChecks`, `getDurgdexChecks`, `getMembers` | ✅ DONE (partial — `getRepeatSectionVals` skipped, complex DOM traversal) |
| 6 | `src/app/utils/deniedRD.dialog.js` | 13 | mock `GeneralModal` + real `bold` — no jsdom needed | ✅ DONE |
| 7 | `src/app/utils/deniedRD.display.js` | 22 | mock `qsets/fields` + `toggleDisplay` — no jsdom needed | ✅ DONE |
| 8 | `src/app/utils/input-format.js` (default export) | 50 | jsdom — `InputFormat()` queries `.input-date`, `.input-ph`, `.input-dt`, `.input-numbers` and attaches `Cleave.js`; mock `Cleave` | ✅ DONE |
| 9 | `src/app/utils/showTool.js` | 108 | jsdom — `showTool()` reads active nav tab, calls `resetSessionStorage`/`toggleDisplay`; mock both | TODO |
| 10 | `src/app/utils/automation.js` | 365 | jsdom — large file; break into describe blocks per exported function | ✅ DONE (partial — `setInqryCaller`, `setDiagDLTNA`, `setSourceMDO`, `setMDrational`, `setCAREAgent`, `setOBCSendingtoRFINA` skipped) |

---

### Phase 2 — Axios / pure API callers (Node, no jsdom needed)

Add these to `collectCoverageFrom` as each is tested.

| # | File | Approach | Status |
|---|---|---|---|
| 11 | `src/app/medhok/apis/addOutboundContact.js` | Mock `axios`, mock `getEnvironmentVariables` | TODO |
| 12 | `src/app/medhok/apis/retrieveCaseDetails.js` | Mock `axios`, mock `getEnvironmentVariables` | TODO |
| 13 | `src/app/medhok/apis/updateRxCaseAttribute.js` | Mock `axios`, mock `getEnvironmentVariables` | TODO |
| 14 | `src/app/quantity_limit/api/lookupQl.js` | Mock `axios`, mock `getEnvironmentVariables` | TODO |
| 15 | `src/app/form_alts/api/getFormularyOptions.js` | Mock `axios`, mock `getEnvironmentVariables` | TODO |
| 16 | `src/app/form_alts/api/resolveFormulary.js` | Mock `axios`, mock `getEnvironmentVariables` | TODO |
| 17 | `src/app/form_alts/api/lookupDrug.js` | Mock `axios`, mock `window.location` (uses `window.location.href`) — needs jsdom or `global.window` mock | TODO |
| 18 | `src/app/form_alts/api/fetchFormAlts.js` | Same as above — `window.location.href` check | TODO |
| 19 | `src/app/medhok/constants.js` | Constants only — verify shape/keys | TODO |

---

### Phase 3 — Pure logic (Node, no jsdom needed)

| # | File | Approach | Status |
|---|---|---|---|
| 20 | `src/app/medhok/handler.js` | Mock `axios`, `getEnvironmentVariables`, medhok helpers | TODO |
| 21 | `src/app/verbiage/templates.js` | Pure string templates — no mocks expected | TODO |
| 22 | `src/app/verbiage/approval.js` | Mock `toggleDisplay`, `sessionStorage` | TODO |
| 23 | `src/app/verbiage/denial.js` | Mock `toggleDisplay`, `sessionStorage` | TODO |
| 24 | `src/app/verbiage/rfi.js` | Mock `toggleDisplay`, `sessionStorage` | TODO |
| 25 | `src/app/verbiage/index.js` | Mock all three verbiage modules + `sessionStorage` | TODO |
| 26 | `src/app/prefill/helpers.js` | Pure helper functions — check `isFlowAutomated`, `isManualFlow`, etc. | TODO |
| 27 | `src/app/prefill/mapping.js` | Data mapping logic — likely pure | TODO |
| 28 | `src/app/prefill/alertMessage.js` | Check if DOM-dependent or pure string logic | TODO |
| 29 | `src/app/prefill/createAlert.js` | Check if DOM-dependent or pure | TODO |
| 30 | `src/app/aetna_questions/fields.js` | Pure field config — verify exported structure | TODO |
| 31 | `src/app/user/user.data.js` | Check if pure data or calls APIs | TODO |
| 32 | `src/app/modal/alert.service.js` | Check if pure logic or DOM-dependent | TODO |

---

### Phase 4 — DOM + sessionStorage (jsdom required)

| # | File | Approach | Status |
|---|---|---|---|
| 33 | `src/app/prefill/prefillHandler.js` | jsdom + mock sessionStorage, `skipPrefilling` logic | TODO |
| 34 | `src/app/prefill/preFillValues.js` | jsdom + mock sessionStorage | TODO |
| 35 | `src/app/prefill/preFillRphQ.js` | jsdom + mock sessionStorage | TODO |
| 36 | `src/app/prefill/preFillRphTAT.js` | jsdom + mock sessionStorage | TODO |
| 37 | `src/app/prefill/preFillRphIBC.js` | jsdom + mock sessionStorage | TODO |
| 38 | `src/app/prefill/preFillTechQ.js` | jsdom + mock sessionStorage | TODO |
| 39 | `src/app/prefill/preFillTechTAT.js` | jsdom + mock sessionStorage | TODO |
| 40 | `src/app/prefill/preFillTechIBC.js` | jsdom + mock sessionStorage | TODO |
| 41 | `src/app/prefill/preFillTechSR.js` | jsdom + mock sessionStorage | TODO |
| 42 | `src/app/prefill/prefillCDRD.js` | jsdom + mock sessionStorage | TODO |
| 43 | `src/app/prefill/manualTemplate.js` | jsdom + mock `toggleDisplay` | TODO |
| 44 | `src/app/prefill/removeFields.js` | jsdom | TODO |
| 45 | `src/app/prefill/caseIdHandler.js` | jsdom + mock sessionStorage | TODO |
| 46 | `src/app/multiCase/math.js` | jsdom — `MultiCaseBalance`, `MultiCaseBalIncrement`, `memberCaseBalance`, `memberCaseIncrement` | TODO |
| 47 | `src/app/multiCase/automation.js` | jsdom | TODO |
| 48 | `src/app/multiCase/display.js` | jsdom | TODO |
| 49 | `src/app/form_alts/formAlts.js` | jsdom + mock axios, sessionStorage, toggleDisplay | TODO |
| 50 | `src/app/quantity_limit/quantityLimit.js` | jsdom + mock axios, sessionStorage | TODO |
| 51 | `src/app/decision/decision.checks.js` | jsdom | TODO |
| 52 | `src/app/decision/decision.display.js` | jsdom | TODO |
| 53 | `src/app/decision/decision.dialog.js` | jsdom | TODO |
| 54 | `src/app/decision/decision.routes.js` | jsdom | TODO |
| 55 | `src/app/shared/common.js` | jsdom | TODO |
| 56 | `src/app/shared/common.ibc.js` | jsdom | TODO |
| 57 | `src/app/shared/manualFlow.js` | jsdom + sessionStorage | TODO |
| 58 | `src/app/shared/resolveFormularyUI.js` | jsdom + sessionStorage | TODO |
| 59 | `src/app/shared/clickEvents.js` | jsdom | TODO |

---

### Phase 5 — Complex orchestration files (jsdom + heavy mocking)

| # | File | Notes | Status |
|---|---|---|---|
| 60 | `src/app/rph/rph.js` | Orchestrates rph flow — mock all sub-modules | TODO |
| 61 | `src/app/rph/rph.q.js` | Q-section logic | TODO |
| 62 | `src/app/rph/rph.tat.js` | TAT logic | TODO |
| 63 | `src/app/rph/clickEvents.js` | Event handler wiring | TODO |
| 64 | `src/app/rph/ibc/rph.ibc.js` | IBC-specific logic | TODO |
| 65 | `src/app/rph/ibc/clickEvents.js` | IBC event handlers | TODO |
| 66 | `src/app/rph/shared/common.rph.js` | Shared rph helpers | TODO |
| 67 | `src/app/tech/tech.js` | Orchestrates tech flow | TODO |
| 68 | `src/app/tech/tech.q.js` | Q-section logic | TODO |
| 69 | `src/app/tech/tech.tat.js` | TAT logic | TODO |
| 70 | `src/app/tech/tech.sr.js` | SR logic | TODO |
| 71 | `src/app/tech/common.tech.js` | Shared tech helpers | TODO |
| 72 | `src/app/tech/clickEvents.js` | Event handler wiring | TODO |
| 73 | `src/app/tech/ibc/tech.ibc.js` | IBC-specific logic | TODO |
| 74 | `src/app/tech/ibc/clickEvents.js` | IBC event handlers | TODO |
| 75 | `src/app/finalnote/final.note.js` | Final note composition | TODO |
| 76 | `src/app/finalnote/get.values.js` | Value extraction | TODO |
| 77 | `src/app/finalnote/rph.parse.inputs.js` | RPH input parsing | TODO |
| 78 | `src/app/finalnote/tech.parse.inputs.js` | Tech input parsing | TODO |
| 79 | `src/app/finalnote/intake.parse.inputs.js` | Intake input parsing | TODO |
| 80 | `src/app/finalnote/inquiry.parse.inputs.js` | Inquiry input parsing | TODO |
| 81 | `src/app/finalnote/eagAafnr.parse.inputs.js` | EAG/AAFNR input parsing | TODO |
| 82 | `src/app/finalnote/components/base.component.js` | Base component | TODO |
| 83 | `src/app/finalnote/components/common.component.js` | Common component | TODO |
| 84 | `src/app/finalnote/components/rph.q.components.js` | RPH Q component | TODO |
| 85 | `src/app/finalnote/components/rph.tat.component.js` | RPH TAT component | TODO |
| 86 | `src/app/finalnote/components/rph.ibc.component.js` | RPH IBC component | TODO |
| 87 | `src/app/finalnote/components/tech.q.component.js` | Tech Q component | TODO |
| 88 | `src/app/finalnote/components/tech.tat.component.js` | Tech TAT component | TODO |
| 89 | `src/app/finalnote/components/tech.sr.component.js` | Tech SR component | TODO |
| 90 | `src/app/finalnote/components/tech.ibc.component.js` | Tech IBC component | TODO |
| 91 | `src/app/finalnote/components/intake.component.js` | Intake component | TODO |
| 92 | `src/app/finalnote/components/inquiry.component.js` | Inquiry component | TODO |
| 93 | `src/app/finalnote/components/md.component.js` | MD component | TODO |
| 94 | `src/app/finalnote/components/ibc.commponent.js` | IBC component | TODO |
| 95 | `src/app/finalnote/components/eagAafnr.component.js` | EAG/AAFNR component | TODO |
| 96 | `src/app/finalnote/components/sidenote.component.js` | Sidenote component | TODO |
| 97 | `src/app/finalnote/components/get.values.js` | Value extraction | TODO |
| 98 | `src/app/dlt_guidelines/automation.js` | DLT automation logic | TODO |
| 99 | `src/app/dlt_guidelines/selection.js` | DLT selection logic | TODO |
| 100 | `src/app/dlt_guidelines/display.js` | DLT display logic | TODO |
| 101 | `src/app/dlt_guidelines/helpers.js` | DLT helpers | TODO |
| 102 | `src/app/dlt_guidelines/constants.js` | DLT constants — verify shape | TODO |
| 103 | `src/app/dlt_guidelines/dlt_guideline.display.js` | DLT guideline display | TODO |
| 104 | `src/app/dlt_guidelines/bvd/automation.js` | BvD automation | TODO |
| 105 | `src/app/dlt_guidelines/bvd/display.js` | BvD display | TODO |
| 106 | `src/app/dlt_guidelines/bvd/handlers.js` | BvD handlers | TODO |
| 107 | `src/app/dlt_guidelines/bvd/listeners.js` | BvD listeners | TODO |
| 108 | `src/app/dlt_guidelines/bvd/constants.js` | BvD constants | TODO |
| 109 | `src/app/dlt_guidelines/data_sources/getDLTGuidelineForm.js` | Mock axios | TODO |
| 110 | `src/app/dlt_guidelines/data_sources/getDLTMonthlyValidationData.js` | Mock axios | TODO |
| 111 | `src/app/dlt_guidelines/data_sources/getDrugDenormData.js` | Mock axios | TODO |
| 112 | `src/app/dlt_guidelines/data_sources/getDrugList.js` | Mock axios | TODO |
| 113 | `src/app/dlt_guidelines/data_sources/getInsulinPumpList.js` | Mock axios | TODO |
| 114 | `src/app/aetna_questions/aetnaQuestions.js` | jsdom + mock `fetchAetnaQuestions`, `toggleDisplay` | TODO |
| 115 | `src/app/aetna_questions/fields.js` | Pure field config | TODO |
| 116 | `src/app/intake/intake.js` | jsdom | TODO |
| 117 | `src/app/intake/intake.automation.js` | jsdom | TODO |
| 118 | `src/app/intake/intake.display.js` | jsdom | TODO |
| 119 | `src/app/intake/intake.dialogs.js` | jsdom | TODO |
| 120 | `src/app/inquiry/inquiry.js` | jsdom | TODO |
| 121 | `src/app/inquiry/inquiry.display.js` | jsdom | TODO |
| 122 | `src/app/inquiry/clear.js` | jsdom | TODO |
| 123 | `src/app/eag/eag.js` | jsdom | TODO |
| 124 | `src/app/eag/eag.display.js` | jsdom | TODO |
| 125 | `src/app/eag/eag.dialogs.js` | jsdom | TODO |
| 126 | `src/app/eag/eag.aafnr.js` | jsdom | TODO |
| 127 | `src/app/eag/aafnr.display.js` | jsdom | TODO |
| 128 | `src/app/eag/aafnr.dialogs.js` | jsdom | TODO |
| 129 | `src/app/eag/eagAafnr.display.js` | jsdom | TODO |
| 130 | `src/app/eag/clear.js` | jsdom | TODO |
| 131 | `src/app/medicalDirector/mdTemplate.js` | jsdom + mock axios | TODO |
| 132 | `src/app/medicalDirector/mdTemplate.display.js` | jsdom | TODO |
| 133 | `src/app/medicalDirector/mdApprovalCheck.display.js` | jsdom | TODO |
| 134 | `src/app/medicalDirector/mdInfoReview.dialog.js` | jsdom | TODO |
| 135 | `src/app/medicalDirector/mdNewInfo.display.js` | jsdom | TODO |
| 136 | `src/app/medicalDirector/mdResolution.display.js` | jsdom | TODO |
| 137 | `src/app/medicalDirector/mdSafety.display.js` | jsdom | TODO |
| 138 | `src/app/medicalDirector/mdoInfo.display.js` | jsdom | TODO |
| 139 | `src/app/caseHistory/getCDRDResponse.js` | Mock axios + sessionStorage | TODO |
| 140 | `src/app/bigTable/bigTable.js` | Mock axios + sessionStorage | TODO |
| 141 | `src/app/member/member.display.js` | jsdom | TODO |
| 142 | `src/app/member/member.dialogs.js` | jsdom | TODO |
| 143 | `src/app/member/validation.js` | jsdom or pure — check content | TODO |
| 144 | `src/app/drugs/drugs.js` | jsdom | TODO |
| 145 | `src/app/drugs/drugs.display.js` | jsdom | TODO |
| 146 | `src/app/outbound/outbound.js` | jsdom | TODO |
| 147 | `src/app/outbound/outbound.display.js` | jsdom | TODO |
| 148 | `src/app/outbound/dialog.js` | jsdom | TODO |
| 149 | `src/app/outbound/clone.js` | jsdom | TODO |
| 150 | `src/app/requestType/automation.js` | jsdom | TODO |
| 151 | `src/app/requestType/display.js` | jsdom | TODO |
| 152 | `src/app/requestType/dialog.js` | jsdom | TODO |
| 153 | `src/app/requestReason/requestReason.display.js` | jsdom | TODO |
| 154 | `src/app/requestReason/requestReason.dialogs.js` | jsdom | TODO |
| 155 | `src/app/claim/claim.js` | jsdom | TODO |
| 156 | `src/app/claim/claim.display.js` | jsdom | TODO |
| 157 | `src/app/claim/claim.dialog.js` | jsdom | TODO |
| 158 | `src/app/client/display.js` | jsdom | TODO |
| 159 | `src/app/client/modules.js` | Check if pure or DOM | TODO |
| 160 | `src/app/origin/modules.js` | Check if pure or DOM | TODO |
| 161 | `src/app/origin/originRefs.display.js` | jsdom | TODO |
| 162 | `src/app/caller/display.js` | jsdom | TODO |
| 163 | `src/app/caller/dialog.js` | jsdom | TODO |
| 164 | `src/app/care/display.js` | jsdom | TODO |
| 165 | `src/app/care/dialogs.js` | jsdom | TODO |
| 166 | `src/app/attachments/display.js` | jsdom | TODO |
| 167 | `src/app/attachments/dialog.js` | jsdom | TODO |
| 168 | `src/app/fax/fax.dialog.js` | jsdom | TODO |
| 169 | `src/app/priority/displays.js` | jsdom | TODO |
| 170 | `src/app/priority/priority.dialog.js` | jsdom | TODO |
| 171 | `src/app/tiering/display.js` | jsdom | TODO |
| 172 | `src/app/tiering/dialogs.js` | jsdom | TODO |
| 173 | `src/app/timestamp/display.js` | jsdom | TODO |
| 174 | `src/app/timestamp/dialogs.js` | jsdom | TODO |
| 175 | `src/app/triedFailMed/display.js` | jsdom | TODO |
| 176 | `src/app/rmTask/display.js` | jsdom | TODO |
| 177 | `src/app/rmTask/clear.answers.js` | jsdom | TODO |
| 178 | `src/app/reviewedByRFI/displays.js` | jsdom | TODO |
| 179 | `src/app/supportingStatement/display.js` | jsdom | TODO |
| 180 | `src/app/aor/aor.display.js` | jsdom | TODO |
| 181 | `src/app/aor/aorCheck.display.js` | jsdom | TODO |
| 182 | `src/app/compendia/display.js` | jsdom | TODO |
| 183 | `src/app/guidelines/guideline.display.js` | jsdom | TODO |
| 184 | `src/app/letterPreview/display.js` | jsdom | TODO |
| 185 | `src/app/letterPreview/dialogs.js` | jsdom | TODO |
| 186 | `src/app/buttons/buttons.js` | jsdom | TODO |
| 187 | `src/app/buttons/display.js` | jsdom | TODO |
| 188 | `src/app/requestBy/display.js` | jsdom | TODO |
| 189 | `src/app/requestBy/dialogs.js` | jsdom | TODO |
| 190 | `src/app/auth/index.js` | Mock axios or fetch | TODO |
| 191 | `src/app/customInputs/searchableSelect/searchableSelect.js` | jsdom | TODO |
| 192 | `src/app/prospectiveReview/get.values.js` | jsdom | TODO |
| 193 | `src/app/qsets/fields.js` | jsdom — DOM field accessors | TODO |
| 194 | `src/app/reset/reset.js` | jsdom | TODO |
| 195 | `src/app/reset/notetool.reset.js` | jsdom | TODO |
| 196 | `src/app/reset/intake.reset.js` | jsdom | TODO |
| 197 | `src/app/app.js` | Integration — low priority | TODO |

---

## Current Coverage (266 tests, 28 suites)

### ✅ 100% covered (28 files)

| File | What is tested |
|---|---|
| `helpers/bold.js` | Keyword wrapping in bold span |
| `helpers/boldUnderline.js` | Keyword wrapping in bold-underline span; also fixed undeclared `newStr` bug |
| `helpers/if_eq.js` | Handlebars equality helper — fn vs inverse |
| `helpers/nospace.js` | Non-alphanumeric stripping; also fixed undeclared `newStr` bug |
| `helpers/redAccent.js` | "ONLY" keyword coloring |
| `src/app/utils/calculateDates.js` | All 7 exports including `getLastQtr` Q4 date boundary (fake timers) |
| `src/app/utils/caseVerified.display.js` | "Not found"/"highlighted in blue" → disable; automated flag branches |
| `src/app/utils/clearInput.js` | `clearInput`/`clearInputs` — radio, text, textarea, select types |
| `src/app/utils/clipboard.api.js` | `navigator.clipboard` path + `document.execCommand` fallback |
| `src/app/utils/deniedOutreach.display.js` | "Denied" → enable; all else → disable |
| `src/app/utils/deniedRD.dialog.js` | `msgDeniedRD` — calls GeneralModal on "No"; silent on all other answers |
| `src/app/utils/deniedRD.display.js` | `toggledeniedRD` + `toggledeniedRDrphDecision` — all RT/decision/TAT branches |
| `src/app/utils/exceptionRdo.display.js` | "Sent to RFI" → disable; all else → enable |
| `src/app/utils/font.formatter.js` | `bold()` span wrapper |
| `src/app/utils/input-format.js` | `InputFormat()` Cleave instances (all 4 selectors) + change event sanitisation; `toTitleCase` all cases |
| `src/app/utils/inputSelect.js` | `rdoBtn`, `ele`, `checkbox`, `eventElement` — all 4 types |
| `src/app/utils/inputValidation.js` | `validateCaseId` — all format rules |
| `src/app/utils/notetool.display.js` | `HideAll`, `toggleDisable`, `toggleDisplay` — all 5 type branches (tag/rest/role/solo/button) |
| `src/app/utils/rdRecommand.display.js` | "Forward to Clinical" + "RD" → enable; all other combos → disable |
| `src/app/utils/resetIntakeFields.js` | 10 intake field IDs constructed from role+origin |
| `src/app/utils/resetSessionStorage.js` | All sessionStorage keys set/removed; `clearFormAltsCache` called |
| `src/app/utils/robotic.display.js` | "Not found"/"highlighted in blue" → disable; automated flag branches |
| `src/app/utils/techSuper.display.js` | "Approved" → enable; all else → disable |
| `src/app/utils/validation.js` | `togglePartialValidation` — outboundcall/outboundcallalt disables; other enables and removes was-validated |
| `src/app/aetna_questions/api/fetchAetnaQuestions.js` | URL, body, timeout, response unwrap, error throw |
| `src/app/medhok/helpers.js` | All 5 exports — status mapping, final status/reason, Yes/No helpers |

### ⚠️ Partial coverage

| File | Coverage | Notes |
|---|---|---|
| `src/app/utils/automation.js` | 84% stmts | `setInqryCaller`, `setDiagDLTNA`, `setSourceMDO`, `setMDrational`, `setCAREAgent`, `setOBCSendingtoRFINA` not yet tested |
| `src/app/utils/getInputValue.js` | 72% stmts | `getRepeatSectionVals` skipped — requires complex nested DOM structure (legend/closest) |
| `src/app/utils/notetool.display.js` | 84% stmts | `toggleDisplay('origin', ...)` branch (lines 68-83) not yet tested |

### ❌ Not yet tested (0% coverage)

| File | Notes |
|---|---|
| `src/app/utils/showTool.js` | jsdom + mock `resetSessionStorage`, `toggleDisplay`, nav tab DOM |
