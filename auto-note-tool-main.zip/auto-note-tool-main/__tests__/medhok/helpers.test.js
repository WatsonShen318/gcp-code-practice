jest.spyOn(console, 'warn').mockImplementation(() => {});

import {
  getMedhokStatusMapping,
  getFinalStatus,
  getFinalStatusReason,
  getYesOrNoByAddlInfoRequired,
  getYesOrNoBySupportingStatementRequired,
} from '../../src/app/medhok/helpers';

// ── getMedhokStatusMapping ────────────────────────────────────────────────────
describe('getMedhokStatusMapping', () => {
  test('returns correct mapping for "Approved"', () => {
    expect(getMedhokStatusMapping('Approved')).toEqual({ status: 'Approved', statusReason: 'Criteria Met' });
  });

  test('returns correct mapping for "Sent to RFI"', () => {
    expect(getMedhokStatusMapping('Sent to RFI')).toEqual({
      status: 'In Progress',
      statusReason: 'Pending Additional Information',
    });
  });

  test('returns correct mapping for "Denied"', () => {
    expect(getMedhokStatusMapping('Denied')).toEqual({ status: 'Denied', statusReason: '' });
  });

  test('returns correct mapping for "Returned to Intake"', () => {
    expect(getMedhokStatusMapping('Returned to Intake')).toEqual({
      status: 'Dismiss',
      statusReason: 'Sent Back to Intake',
    });
  });

  test('returns empty strings and warns for unknown routing value', () => {
    const result = getMedhokStatusMapping('Unknown Routing');
    expect(result).toEqual({ status: '', statusReason: '' });
    expect(console.warn).toHaveBeenCalledWith(
      expect.stringContaining('Unknown Routing')
    );
  });
});

// ── getFinalStatus ────────────────────────────────────────────────────────────
describe('getFinalStatus', () => {
  test('overrides to "In Progress" for Tolling Case + No + "Tolled Case"', () => {
    expect(getFinalStatus('', 'Tolling Case', 'No', 'Tolled Case')).toBe('In Progress');
  });

  test('overrides to "In Progress" for Tolling Case + No + "Tolled case and resent RFI..."', () => {
    expect(
      getFinalStatus('', 'Tolling Case', 'No', 'Tolled case and resent RFI letter with updated due date/time.')
    ).toBe('In Progress');
  });

  test('does not override when supportingStatement is "Yes"', () => {
    expect(getFinalStatus('Toll Pending', 'Tolling Case', 'Yes', 'Tolled Case')).toBe('Toll Pending');
  });

  test('does not override for non-Tolling routing', () => {
    expect(getFinalStatus('Approved', 'Approved', 'No', 'Tolled Case')).toBe('Approved');
  });

  test('returns the original status when no condition matches', () => {
    expect(getFinalStatus('In Progress', 'Sent to RFI', 'Yes', '')).toBe('In Progress');
  });
});

// ── getFinalStatusReason ──────────────────────────────────────────────────────
describe('getFinalStatusReason', () => {
  test('maps "Pending Additional Information" to "Pending Submission of Evidence" for Redetermination', () => {
    expect(
      getFinalStatusReason('Sent to RFI', 'Redetermination', 'Pending Additional Information', 'Yes', '')
    ).toBe('Pending Submission of Evidence');
  });

  test('maps "Pending Additional Information" to "Pending Submission of Evidence" for "RD"', () => {
    expect(
      getFinalStatusReason('Sent to RFI', 'RD', 'Pending Additional Information', 'Yes', '')
    ).toBe('Pending Submission of Evidence');
  });

  test('does not remap for non-RD request types', () => {
    expect(
      getFinalStatusReason('Sent to RFI', 'Prior Authorization', 'Pending Additional Information', 'Yes', '')
    ).toBe('Pending Additional Information');
  });

  test('maps to "Pending Supp Stmt/Hospice" for Tolling Case + No + Tolled Case', () => {
    expect(
      getFinalStatusReason('Tolling Case', 'PA', 'Pending Additional Information', 'No', 'Tolled Case')
    ).toBe('Pending Supp Stmt/Hospice');
  });

  test('returns the original statusReason when no condition matches', () => {
    expect(
      getFinalStatusReason('Approved', 'PA', 'Criteria Met', 'Yes', '')
    ).toBe('Criteria Met');
  });
});

// ── getYesOrNoByAddlInfoRequired ──────────────────────────────────────────────
describe('getYesOrNoByAddlInfoRequired', () => {
  test('returns "Yes" for "Pending Additional Information"', () => {
    expect(getYesOrNoByAddlInfoRequired('Pending Additional Information')).toBe('Yes');
  });

  test('returns "Yes" for "Pending Submission of Evidence"', () => {
    expect(getYesOrNoByAddlInfoRequired('Pending Submission of Evidence')).toBe('Yes');
  });

  test('returns empty string for any other value', () => {
    expect(getYesOrNoByAddlInfoRequired('Criteria Met')).toBe('');
    expect(getYesOrNoByAddlInfoRequired('')).toBe('');
  });
});

// ── getYesOrNoBySupportingStatementRequired ───────────────────────────────────
describe('getYesOrNoBySupportingStatementRequired', () => {
  test('returns "No" for "Pending Supp Stmt/Hospice"', () => {
    expect(getYesOrNoBySupportingStatementRequired('Pending Supp Stmt/Hospice')).toBe('No');
  });

  test('returns empty string for any other value', () => {
    expect(getYesOrNoBySupportingStatementRequired('Criteria Met')).toBe('');
    expect(getYesOrNoBySupportingStatementRequired('Pending Additional Information')).toBe('');
    expect(getYesOrNoBySupportingStatementRequired('')).toBe('');
  });
});
