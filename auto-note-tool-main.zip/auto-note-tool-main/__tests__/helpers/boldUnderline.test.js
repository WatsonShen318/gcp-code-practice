const boldUnderline = require('../../helpers/boldUnderline');

describe('boldUnderline helper', () => {
  test('wraps "Clinical Review" in a bold-underline span', () => {
    expect(boldUnderline('Clinical Review required')).toContain(
      '<span class="fw-bold"><u>Clinical Review</u></span>'
    );
  });

  test('wraps "Forward to RFI" in a bold-underline span', () => {
    expect(boldUnderline('Forward to RFI now')).toContain(
      '<span class="fw-bold"><u>Forward to RFI</u></span>'
    );
  });

  test('wraps "Approve" in a bold-underline span', () => {
    expect(boldUnderline('Approve the request')).toContain(
      '<span class="fw-bold"><u>Approve</u></span>'
    );
  });

  test('wraps "Return to Question" in a bold-underline span', () => {
    expect(boldUnderline('Return to Question 3')).toContain(
      '<span class="fw-bold"><u>Return to Question</u></span>'
    );
  });

  test('wraps "select BvD guideline below" in a bold-underline span', () => {
    expect(boldUnderline('select BvD guideline below and continue')).toContain(
      '<span class="fw-bold"><u>select BvD guideline below</u></span>'
    );
  });

  test('is case-insensitive', () => {
    expect(boldUnderline('CLINICAL REVIEW required')).toContain(
      '<span class="fw-bold"><u>CLINICAL REVIEW</u></span>'
    );
  });

  test('leaves unmatched words unchanged', () => {
    expect(boldUnderline('nothing special here')).toBe('nothing special here');
  });

  test('does not modify an empty string', () => {
    expect(boldUnderline('')).toBe('');
  });
});
