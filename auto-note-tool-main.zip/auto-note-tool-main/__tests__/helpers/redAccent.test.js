const redAccent = require('../../helpers/redAccent');

describe('redAccent helper', () => {
  test('wraps "ONLY" in a text-primary span', () => {
    expect(redAccent('Use ONLY this option')).toContain(
      '<span class="text-primary">ONLY</span>'
    );
  });

  test('is case-insensitive — wraps lowercase "only"', () => {
    expect(redAccent('only here')).toContain(
      '<span class="text-primary">only</span>'
    );
  });

  test('is case-insensitive — wraps mixed-case "Only"', () => {
    expect(redAccent('Only available')).toContain(
      '<span class="text-primary">Only</span>'
    );
  });

  test('leaves unmatched words unchanged', () => {
    expect(redAccent('nothing special here')).toBe('nothing special here');
  });

  test('does not modify an empty string', () => {
    expect(redAccent('')).toBe('');
  });
});
