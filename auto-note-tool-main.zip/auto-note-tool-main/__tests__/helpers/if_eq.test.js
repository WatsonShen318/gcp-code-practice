const ifEq = require('../../helpers/if_eq');

describe('if_eq helper', () => {
  function makeOptions(fnResult = 'match', inverseResult = 'no-match') {
    return {
      fn: jest.fn(() => fnResult),
      inverse: jest.fn(() => inverseResult),
    };
  }

  test('calls options.fn when both arguments are equal strings', () => {
    const options = makeOptions();
    const result = ifEq('foo', 'foo', options);
    expect(result).toBe('match');
    expect(options.fn).toHaveBeenCalledTimes(1);
    expect(options.inverse).not.toHaveBeenCalled();
  });

  test('calls options.inverse when arguments are not equal', () => {
    const options = makeOptions();
    const result = ifEq('foo', 'bar', options);
    expect(result).toBe('no-match');
    expect(options.inverse).toHaveBeenCalledTimes(1);
    expect(options.fn).not.toHaveBeenCalled();
  });

  test('calls options.fn for equal numbers', () => {
    const options = makeOptions();
    ifEq(42, 42, options);
    expect(options.fn).toHaveBeenCalled();
  });

  test('calls options.inverse for unequal numbers', () => {
    const options = makeOptions();
    ifEq(1, 2, options);
    expect(options.inverse).toHaveBeenCalled();
  });

  test('uses strict equality — string "1" does not equal number 1', () => {
    const options = makeOptions();
    ifEq('1', 1, options);
    expect(options.inverse).toHaveBeenCalled();
  });

  test('calls options.fn when both arguments are undefined', () => {
    const options = makeOptions();
    ifEq(undefined, undefined, options);
    expect(options.fn).toHaveBeenCalled();
  });
});
