const nospace = require('../../helpers/nospace');

describe('nospace helper', () => {
  test('removes spaces from a string', () => {
    expect(nospace('hello world')).toBe('helloworld');
  });

  test('removes all non-alphanumeric characters', () => {
    expect(nospace('hello-world_foo.bar')).toBe('helloworldfoobar');
  });

  test('removes multiple spaces', () => {
    expect(nospace('a b  c   d')).toBe('abcd');
  });

  test('leaves alphanumeric characters intact', () => {
    expect(nospace('abc123')).toBe('abc123');
  });

  test('removes special characters like parentheses and slashes', () => {
    expect(nospace('(foo)/bar')).toBe('foobar');
  });

  test('returns empty string for an empty input', () => {
    expect(nospace('')).toBe('');
  });

  test('returns empty string for a string of only special characters', () => {
    expect(nospace('---')).toBe('');
  });
});
