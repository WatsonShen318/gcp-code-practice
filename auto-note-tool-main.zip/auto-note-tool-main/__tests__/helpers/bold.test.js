const bold = require('../../helpers/bold');

describe('bold helper', () => {
  test('wraps "Type" in a bold span', () => {
    const result = bold('Type of request');
    expect(result).toContain('<span class="fw-bold">Type</span>');
  });

  test('wraps "NOT" in a bold span', () => {
    const result = bold('This is NOT allowed');
    expect(result).toContain('<span class="fw-bold">NOT</span>');
  });

  test('wraps "ALWAYS" in a bold span', () => {
    const result = bold('ALWAYS check the case');
    expect(result).toContain('<span class="fw-bold">ALWAYS</span>');
  });

  test('wraps "Note" in a bold span', () => {
    const result = bold('Note: review required');
    expect(result).toContain('<span class="fw-bold">Note</span>');
  });

  test('leaves unmatched words unchanged', () => {
    expect(bold('hello world')).toBe('hello world');
  });

  test('wraps multiple keywords in the same string', () => {
    const result = bold('Note: ALWAYS check and DO verify');
    expect(result).toContain('<span class="fw-bold">Note</span>');
    expect(result).toContain('<span class="fw-bold">ALWAYS</span>');
  });

  test('does not modify an empty string', () => {
    expect(bold('')).toBe('');
  });
});
