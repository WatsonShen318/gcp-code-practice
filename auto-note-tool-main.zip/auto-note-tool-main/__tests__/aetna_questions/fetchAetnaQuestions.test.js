jest.mock('../../environment/config', () => ({
  getEnvironmentVariables: jest.fn().mockReturnValue({ AUTO_NOTE_BACKEND: 'https://test-backend.example.com' }),
}));

var mockAxiosPost;
jest.mock('axios', () => ({ post: (...args) => mockAxiosPost(...args) }));
var capturedRetryConfig;
jest.mock('axios-retry', () => jest.fn((_, config) => { capturedRetryConfig = config; }));

import fetchAetnaQuestions from '../../src/app/aetna_questions/api/fetchAetnaQuestions';

const QUESTIONS = [
  { index: 0, question: 'Has the patient experienced an intolerance?' },
];

beforeEach(() => {
  jest.clearAllMocks();
  mockAxiosPost = jest.fn().mockResolvedValue({ data: { data: { questions: QUESTIONS } } });
});

describe('fetchAetnaQuestions', () => {
  test('returns the questions array from the response', async () => {
    const result = await fetchAetnaQuestions('75100090100140', '71085008230');
    expect(result).toEqual(QUESTIONS);
  });

  test('posts to the correct backend URL', async () => {
    await fetchAetnaQuestions('75100090100140', '');
    const [url] = mockAxiosPost.mock.calls[0];
    expect(url).toBe('https://test-backend.example.com/aetna-questions/fetch');
  });

  test('sends gpi and ndc in the request body', async () => {
    await fetchAetnaQuestions('75100090100140', '71085008230');
    const [, body] = mockAxiosPost.mock.calls[0];
    expect(body).toEqual({ gpi: '75100090100140', ndc: '71085008230' });
  });

  test('sets timeout to 30000 ms', async () => {
    await fetchAetnaQuestions('75100090100140', '');
    const [, , options] = mockAxiosPost.mock.calls[0];
    expect(options.timeout).toBe(30000);
  });

  test('returns empty array when backend returns no questions', async () => {
    mockAxiosPost = jest.fn().mockResolvedValue({ data: { data: { questions: [] } } });
    const result = await fetchAetnaQuestions('00000000000000', '');
    expect(result).toEqual([]);
  });

  test('throws when axios rejects', async () => {
    mockAxiosPost = jest.fn().mockRejectedValue(new Error('network error'));
    await expect(fetchAetnaQuestions('75100090100140', '')).rejects.toThrow('network error');
  });
});

describe('axiosRetry configuration', () => {
  test('configures axiosRetry with 2 retries', () => {
    expect(capturedRetryConfig.retries).toBe(2);
  });

  test('retryCondition returns true for 5xx errors', () => {
    const { retryCondition } = capturedRetryConfig;
    expect(retryCondition({ response: { status: 500 } })).toBe(true);
    expect(retryCondition({ response: { status: 503 } })).toBe(true);
  });

  test('retryCondition returns false for non-5xx errors', () => {
    const { retryCondition } = capturedRetryConfig;
    expect(retryCondition({ response: { status: 429 } })).toBe(false);
    expect(retryCondition({ response: { status: 404 } })).toBe(false);
    expect(retryCondition({ response: undefined })).toBe(false);
  });

  test('retryDelay returns retryCount * 1000 ms', () => {
    const { retryDelay } = capturedRetryConfig;
    expect(retryDelay(1)).toBe(1000);
    expect(retryDelay(2)).toBe(2000);
  });
});
