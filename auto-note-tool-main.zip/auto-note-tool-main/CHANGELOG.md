# Change Log

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](http://keepachangelog.com/)
and this project adheres to [Semantic Versioning](http://semver.org/).

## [v94.0.0] - 2024-05-09

May 2024 Enhancements

### Removed

- Removed line for 2021 silverscript requests from the smart edit medication note]

### Added

- Added tier 6 to approved tier options
- Added new popup logic for the rejects 90 days out question so the popup triggers in more cases

## [v93.0.0] - 2024-03-14

March 2024 Enhancements

### Added

- Added Member ID flow to intake section, and added to final note

### Removed  

- Removed clients SIHO, Univ of Utah, and Oscar Health
- Removed logic that was tied to Oscar Health

## [v92.0.1] - 2023-11-21

November 2023 Enhancement

### Changed

- Adjusted alert for FEP so the sentences are on different lines

## [v92.0.0] - 2023-11-21

November 2023 Enhancement

### Added

- Add two clients, FEP and Arkansas BCBS
- Add alerts for FEP client based on IBC or Case Queue/ Turn Around Time Selections

## [v91.0.0] - 2023-08-10

August 2023 Enhancement

### Added

- Add red alert message when [Client]=Sharp Health (#127)

## [v90.2.0] - 2023-07-28

KelseyCare gets Reminder card
[July Part D Note Tool Enhancements](https://gitw.cvshealth.com/business-innovation/mhk-note-tools/cda-internal-note-tool/-/milestones/14#tab-issues)

### Added

- Red Reminder verbiage "Refer to KelseyCare Client Specific Work Instruction" added for KelseyCare (#126)

### Fixed

- Prevent `toggleClientName` function to get `isAetnaClient` variable for TAT origin. This is not supposed to run for TAT. Refer to #102

## [v90.1.0] - 2023-06-12

The application will now get deployed to the proper web server.

### Added

- CI/CD process implement for auto deployment to the server based on condition
- bash script for developers to merge code to `main`, create tag and releases

### Changed

- Webpack configuration files are updated to copy artifacts to the web server

## [v90.0.0] - 2023-05-31

CDA Part D Internal Note Tool May Enhancements to add new pop up messages and update question contents

### Added

- Add red note for drug name field
- Add pop-up for Inbound Call [Requested By] = AOR
- Add drugs to the 'Potential Smart edit medication alert'
- Add red alert message after [Drug Name] field

### Changed

- Update note for [Drug Name] = Temazepam, Zolpidem

## [v80.1.0] - 2023-04-28

We added new question for Requested By is AOR and Dismissed case

### Added

- Added new question "Confirmed member outbound call was completed and documented on the Contacts Tab"
- Added new modal for the question

## [v80.0.0] - 2023-02-27

February 2023 Part D Note Tool Enhancements. We made an update to the client 'Healthfirst' note.

### Added

- Add red box alert for drug name tadalafil
- Added new modal for the question

### Changed

- Verbiage Update for Tech Inbound Call
- Updated the verbiage for Healthfirst client note section when it was selected in the client drop down

## [v79.1.0] - 2023-01-31

We made some updates to Tech IBC and Queue

### Added

- Add red box alert for drug name tadalafil
- Added new modal for the question

### Changed

- Update verbiage in existing field: "Is there a denied case on the member's profile in the past 60 days?" TO "Is there a denied case on the member’s current line of eligibility in the past 60 days?"
- Remove Question 'Is there a denied case on the member's profile in 2022?'

## [v79.0.0] - 2023-01-06

We made some updates to Tech IBC and Queue. This is a off-cycle update.

### Added

- Add red box alert for drug name tadalafil
- Added new modal for the question

### Changed

- Update verbiage in existing field: "Is there a denied case on the member's profile in the past 60 days?" TO "Is there a denied case on the member’s current line of eligibility in the past 60 days?"
- Remove Question 'Is there a denied case on the member's profile in 2022?'

## [v78.0.0] - 2022-12-30

We made some update to Intake and Client drop downs

### Changed

- Intake Update for BCBS of MASS
- Client Drop Down Updates

## [v77.0.0] - 2022-12-02

We made some fixes and added new client to the drop down

### Added

- ADD New Client to Client dropdown field

### Fixed

- Reminder pop up for Compass button fix
