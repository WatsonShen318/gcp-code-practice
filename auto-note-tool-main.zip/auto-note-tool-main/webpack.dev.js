const path = require('path');
const { merge } = require('webpack-merge');
const HtmlWebpackPlugin = require('html-webpack-plugin');
const { common, PATHS } = require('./webpack.common');

module.exports = merge(common, {
  mode: 'development',
  output: {
    filename: '[name].bundle.js',
    path: PATHS.dist,
  },
  plugins: [
    new HtmlWebpackPlugin({
      template: path.join(PATHS.src, '/index.hbs'),
      filename: `index.html`,
    }),
    // new HtmlWebpackPlugin({
    //   template: path.join(PATHS.autoNoteExtns, `standard-nf-exception/Standard Non-Formulary Exception Guideline.html`),
    //   filename: `_new_Standard Non-Formulary Exception Guideline.html`
    // }),
    // new HtmlWebpackPlugin({
    //   template: path.join(PATHS.autoNoteExtns, `bvd-nf-exception/BvD Non-Formulary Exception Guideline.html`),
    //   filename: `_new_BvD Non-Formulary Exception Guideline.html`
    // }),
  ],
  module: {
    rules: [
      {
        test: /\.s[ac]ss$/i,
        use: ['style-loader', 'css-loader', 'postcss-loader', 'sass-loader'],
      },
    ],
  },
});
