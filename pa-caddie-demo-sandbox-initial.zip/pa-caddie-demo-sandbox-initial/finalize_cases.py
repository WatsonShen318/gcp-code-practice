#!/usr/bin/env python3
"""Add derived, reviewer-visible fields to cases/<PA>.json (idempotent):
  initial_answers {ordinal: 'T'|'F'}   the PRESCRIBER'S submitted answers (completed qset, ANSWR_TXT 1/0 by ORDEAL_NBR), never the reviewer's final ones
  q_comments {ordinal: text}           prescriber's free-text on a question (EXTN_TXT) - what CAS 2.0 shows under Q4
  fallout {step, reason}               why the ePA stopped (system-generated, visible to the CAS reviewer)
Reads truth/ ONLY for the fallout fields (system data); no reviewer decision data is copied into cases/."""
import json
from pathlib import Path
HERE = Path(__file__).resolve().parent
for f in sorted((HERE / "cases").glob("*.json")):
    c = json.loads(f.read_text()); t = json.loads((HERE / "truth" / f.name).read_text())
    ans, com = {}, {}
    for r in c["prescriber_answers"]:
        o = int(r["ORDEAL_NBR"])
        if r.get("ANSWR_TXT") in ("1", "0"):
            ans[o] = "T" if r["ANSWR_TXT"] == "1" else "F"
        if r.get("EXTN_TXT"):
            com[o] = r["EXTN_TXT"].strip()
    led = (t.get("ledger") or [{}])[0]
    c["initial_answers"], c["q_comments"] = ans, com
    c["fallout"] = dict(step=led.get("ePA_Fallout_Step"), reason=led.get("ePA_Fallout_Reason"))
    f.write_text(json.dumps(c, indent=1, default=str))
    print(f.stem, "".join(ans[k] for k in sorted(ans)), "comments on Q", sorted(com), "fallout", c["fallout"]["step"])
