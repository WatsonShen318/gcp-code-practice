#!/usr/bin/env python3
"""PA Caddie sandbox server (local only, 127.0.0.1).

    ~/miniforge3/envs/um-trend/bin/python3 server.py [--port 8793]

Serves app/index.html and a small JSON API over the cached cases (no SQL at review time):
  GET  /                       the Caddie UI
  GET  /api/cases              cached cases [{pa, drug, asof, done_by:[testers]}]
  GET  /api/case/<pa>          what the reviewer may see (cases/<pa>.json). NEVER includes truth/.
  GET  /api/random?tester=x    random cached case, preferring ones this tester has not done
  GET  /api/pdfs/<pa>          attachment list;  GET /api/pdf/<pa>/<file>  the raw PDF  (pdfs/<pa>/*.pdf)
  POST /api/save               store a finished run (runs/<tester>__<pa>__<ts>.json + runs/audit_log.jsonl)
  GET  /api/runs               saved runs
  GET  /compare?run=<file>     side-by-side of the tester vs what the real CAS reviewer did (uses truth/)
"""
import json, random, sys, re, datetime as dt, html
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from pathlib import Path
from urllib.parse import urlparse, parse_qs, unquote

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import compare as cmp  # noqa: E402

CASES, TRUTH, RUNS, PDFS, APP = HERE / "cases", HERE / "truth", HERE / "runs", HERE / "pdfs", HERE / "app"
RUNS.mkdir(exist_ok=True)
PA_RE = re.compile(r"^\d\d-\d{9}$")
SAFE = re.compile(r"^[A-Za-z0-9_.\-]+$")


def list_runs():
    out = []
    for f in sorted(RUNS.glob("*__*__*.json")):
        try:
            r = json.loads(f.read_text())
            out.append(dict(file=f.name, pa=r.get("pa"), tester=r.get("tester"), decision=r.get("decision", {}).get("label"), elapsed_s=r.get("elapsed_s"), saved=r.get("saved_at")))
        except Exception:
            pass
    return out


class H(BaseHTTPRequestHandler):
    def _send(self, code, body, ctype="application/json"):
        data = body if isinstance(body, bytes) else (json.dumps(body) if ctype == "application/json" else body).encode()
        self.send_response(code)
        self.send_header("Content-Type", ctype + ("; charset=utf-8" if ctype.startswith("text") or ctype == "application/json" else ""))
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(data)

    def log_message(self, *a):  # quiet
        pass

    def do_GET(self):
        u = urlparse(self.path); p = unquote(u.path); q = parse_qs(u.query)
        if p in ("/", "/index.html"):
            return self._send(200, (APP / "index.html").read_bytes(), "text/html")
        if p == "/api/cases":
            done = {}
            for r in list_runs():
                done.setdefault(r["pa"], []).append(r["tester"])
            out = []
            for f in sorted(CASES.glob("*.json")):
                c = json.loads(f.read_text())
                out.append(dict(pa=c["pa"], drug=c["header"].get("prior_athzn_drug_nm"), asof=c["asof"], done_by=done.get(c["pa"], [])))
            return self._send(200, out)
        m = re.match(r"^/api/case/(.+)$", p)
        if m:
            pa = m.group(1)
            f = CASES / f"{pa}.json"
            if not PA_RE.match(pa) or not f.exists():
                return self._send(404, {"error": f"case {pa} is not cached; run pull_cases.py {pa}"})
            return self._send(200, f.read_bytes())
        if p == "/api/random":
            tester = (q.get("tester") or [""])[0]
            done = {r["pa"] for r in list_runs() if r["tester"] == tester}
            pool = [f.stem for f in CASES.glob("*.json")]
            fresh = [x for x in pool if x not in done] or pool
            if not fresh:
                return self._send(404, {"error": "no cached cases"})
            return self._send(200, {"pa": random.choice(fresh), "fresh": bool([x for x in pool if x not in done])})
        m = re.match(r"^/api/pdfs/(.+)$", p)
        if m:
            d = PDFS / m.group(1)
            return self._send(200, sorted(x.name for x in d.glob("*.pdf")) if PA_RE.match(m.group(1)) and d.is_dir() else [])
        m = re.match(r"^/api/pdf/([^/]+)/([^/]+)$", p)
        if m and PA_RE.match(m.group(1)) and SAFE.match(m.group(2)):
            f = PDFS / m.group(1) / m.group(2)
            if f.exists():
                return self._send(200, f.read_bytes(), "application/pdf")
            return self._send(404, {"error": "no such pdf"})
        if p == "/api/runs":
            return self._send(200, list_runs())
        if p == "/compare":
            runs = list_runs()
            name = (q.get("run") or [runs[-1]["file"] if runs else ""])[0]
            if not SAFE.match(name or "x") or not (RUNS / name).exists():
                return self._send(200, "<h3>No saved runs yet.</h3>" if not runs else "<h3>Unknown run.</h3>" + "".join(f'<p><a href="/compare?run={html.escape(r["file"])}">{html.escape(r["file"])}</a></p>' for r in runs), "text/html")
            run = json.loads((RUNS / name).read_text())
            tf = TRUTH / f"{run['pa']}.json"
            truth = json.loads(tf.read_text()) if tf.exists() else None
            return self._send(200, cmp.render_html(run, truth, runs, name), "text/html")
        return self._send(404, {"error": "not found"})

    def do_POST(self):
        if urlparse(self.path).path != "/api/save":
            return self._send(404, {"error": "not found"})
        n = int(self.headers.get("Content-Length", "0"))
        try:
            run = json.loads(self.rfile.read(n))
        except Exception:
            return self._send(400, {"error": "bad json"})
        pa, tester = str(run.get("pa", "")), re.sub(r"[^A-Za-z0-9_.\-]", "_", str(run.get("tester") or "anon"))[:40]
        if not PA_RE.match(pa):
            return self._send(400, {"error": "bad pa"})
        stamp = dt.datetime.now().strftime("%Y%m%dT%H%M%S")
        run["saved_at"] = dt.datetime.now().isoformat(timespec="seconds")
        name = f"{tester}__{pa}__{stamp}.json"
        (RUNS / name).write_text(json.dumps(run, indent=1))
        with open(RUNS / "audit_log.jsonl", "a") as fh:  # one line per run, flat enough to diff by eye
            fh.write(json.dumps(dict(saved_at=run["saved_at"], tester=tester, pa=pa, decision=run.get("decision"), answers=run.get("answers"),
                                     elapsed_s=run.get("elapsed_s"), n_events=len(run.get("events", [])), file=name)) + "\n")
        return self._send(200, {"ok": True, "file": name, "compare": f"/compare?run={name}"})


if __name__ == "__main__":
    port = int(sys.argv[sys.argv.index("--port") + 1]) if "--port" in sys.argv else 8793
    print(f"Caddie sandbox on http://127.0.0.1:{port}  ({len(list(CASES.glob('*.json')))} cached cases)")
    ThreadingHTTPServer(("127.0.0.1", port), H).serve_forever()
