"""Compare a sandbox run against what the real CAS reviewer did (truth/<PA>.json).

compare_run(run, truth) -> dict;  render_html(...) -> page;  CLI:  python compare.py runs/<file>.json
Scope: decision, Q answers, approval term, time on task, and an audit-log side-by-side. Notes are intentionally NOT compared.
"""
import json, sys, html
from pathlib import Path
from collections import Counter

HERE = Path(__file__).resolve().parent
CODE_NAMES = {  # see memory reference_pa_audit_log; others are shown as bare codes
    "A0001": "opened PA", "A0408": "queue move", "A0436": "ePA fallout recorded", "A0509": "model decision", "A0510": "model decision",
    "A0475": "mock claim run", "A0518": "data field changed", "A0557": "criteria answers edited", "A0430": "PA class changed",
    "A0528": "RFI", "A0003": "RFI", "A0040": "internal denial",
}
# TASK-level comparison: the tester is compared with the first Loop-2 task (Work Queues, timed) the real Technician did, using the ledger's outcome_status.
OUTCOME_TO_LABEL = {"EPAAPPROVE": "approve", "APPROVE": "approve", "INTERNALDENIAL": "internal", "FAXCRITERIA": "rfi", "PENDINGDENIAL": "pending",
                    "PENDINGSOFTDENIAL": "pending", "SETTOPENDING": "pending", "DENY": "deny", "CANCELLED": "abort", "ABORT": "abort"}
LABEL_NAMES = {"approve": "Approve", "internal": "Internal denial", "rfi": "RFI", "pending": "Pending", "deny": "Deny", "abort": "Abort"}


def first_task(truth):
    """The real reviewer's first timed Loop-2 task: [row, start_ts, end_ts] (UTC, naive)."""
    import datetime as dt
    rows = [r for r in (truth.get("ledger") or []) if r.get("type_of_productivity") == "Work Queues" and (r.get("total_time_seconds") or 0) > 0]
    rows.sort(key=lambda r: str(r.get("opened_ts")))
    if not rows:
        return None, None, None
    r = rows[0]; t0 = dt.datetime.fromisoformat(str(r["opened_ts"]).replace("Z", "+00:00")).replace(tzinfo=None)
    return r, t0, t0 + dt.timedelta(seconds=int(r["total_time_seconds"]))


def compare_run(run, truth):
    out = dict(pa=run["pa"], tester=run.get("tester"))
    if not truth:
        return dict(out, error="no truth file for this PA")
    fin = truth["final"]; real_pa = (fin.get("prior_athzn_rsltn_drvd_cd") or "").upper()
    task, t0, t1 = first_task(truth)
    real_lbl = OUTCOME_TO_LABEL.get(str((task or {}).get("outcome_status") or "").upper(), "?")
    mine_lbl = run.get("decision", {}).get("label") or "none"
    out["decision"] = dict(tester=LABEL_NAMES.get(mine_lbl, mine_lbl), real=LABEL_NAMES.get(real_lbl, real_lbl), real_raw=(task or {}).get("outcome_status"),
                           match=(mine_lbl == real_lbl), final_pa=real_pa)
    t_ans = {int(k): v for k, v in (run.get("answers") or {}).items()}
    r_ans = {int(r["ordinal_nbr"]): ("T" if r["user_answr_txt"] == "1" else "F") for r in truth["final_qset"] if r["user_answr_txt"] in ("1", "0")}
    rows = []
    for q in sorted(set(t_ans) | set(r_ans)):
        rows.append(dict(q=q, tester=t_ans.get(q), real=r_ans.get(q), match=(t_ans.get(q) == r_ans.get(q))))
    out["answers"] = dict(rows=rows, path_match=(set(t_ans) == set(r_ans)), n_mismatch=sum(1 for r in rows if not r["match"]),
                          score_tester=run.get("score"), score_real=truth["final"].get("rsltn_cd"))
    days = fin.get("aprv_drtn_day_nbr"); mo = run.get("approve_months")
    out["term"] = dict(tester_months=mo, real_days=days, match=(mo is not None and days is not None and abs(mo * 30.5 - float(days)) <= 31)) if days else dict(tester_months=mo, real_days=None, match=None)
    led = task or {}
    out["time"] = dict(tester_s=run.get("elapsed_s"), real_s=led.get("total_time_seconds"), real_user=led.get("cas_user_id"), real_role=led.get("uma_job_title"))
    # audit side-by-side: only the reviewer's own actions (not SYSTEM_SERVICES / batch users)
    import datetime as dt
    def _in_task(a):
        if not t0:
            return a["CRTE_BY_USER_ID"] == led.get("cas_user_id")
        ts = dt.datetime.fromisoformat(str(a["CRTE_TS"]).replace("Z", ""))
        return a["CRTE_BY_USER_ID"] == led.get("cas_user_id") and t0 - dt.timedelta(seconds=5) <= ts <= t1 + dt.timedelta(seconds=5)
    human = [a for a in truth.get("audit", []) if _in_task(a)]
    codes = Counter(a["ACTVY_CD"] for a in human)
    ev = Counter(e["type"] for e in run.get("events", []))
    changed = sum(1 for q, v in t_ans.items() if (run.get("initial_answers") or {}).get(str(q), (run.get("initial_answers") or {}).get(q)) not in (None, v))
    out["audit"] = dict(real_codes=[(c, CODE_NAMES.get(c, ""), n) for c, n in sorted(codes.items())],
                        tester_equiv=dict(mock_claims_run=ev.get("runMockClaim", 0), drug_edits=ev.get("s1SaveDrug", 0), answers_changed=changed,
                                          docs_opened=ev.get("openDoc", 0), history_opened=ev.get("openTool", 0), calc_used=ev.get("confirmCalc", 0), notes_generated=ev.get("genNoteV3", 0)))
    return out


def _b(ok):
    return '<span style="color:#059669;font-weight:700">✓ match</span>' if ok else ('<span style="color:#b91c1c;font-weight:700">✗ differs</span>' if ok is False else "—")


def render_html(run, truth, runs, name):
    c = compare_run(run, truth); e = html.escape
    sel = "".join(f'<option value="{e(r["file"])}"{" selected" if r["file"] == name else ""}>{e(r["file"])}</option>' for r in runs)
    h = [f"""<!doctype html><meta charset=utf-8><title>Caddie run vs CAS</title><style>
body{{font:14px -apple-system,Segoe UI,sans-serif;margin:24px;color:#0f172a;max-width:980px}}h2{{margin:0 0 4px}}h3{{margin:22px 0 6px}}
table{{border-collapse:collapse;margin:6px 0}}td,th{{border:1px solid #e2e8f0;padding:5px 10px;text-align:left;font-size:13px}}th{{background:#f8fafc}}
.sub{{color:#64748b;font-size:12px}}.bad{{background:#fef2f2}}</style>
<h2>Sandbox run vs the real CAS reviewer</h2><div class=sub>PA {e(str(c['pa']))} · tester {e(str(c.get('tester')))} · notes are not compared · local only, contains PHI</div>
<p><select onchange="location='/compare?run='+this.value">{sel}</select></p>"""]
    if c.get("error"):
        h.append(f"<p>{e(c['error'])}</p>"); return "".join(h)
    d = c["decision"]
    h.append(f"<h3>Task decision</h3><table><tr><th>Tester</th><th>Real first Loop-2 task</th><th></th></tr><tr><td>{e(str(d['tester']))}</td><td>{e(str(d['real']))} <span class=sub>({e(str(d['real_raw']))})</span></td><td>{_b(d['match'])}</td></tr></table><div class=sub>For context only: the PA's final resolution was {e(str(d['final_pa']))} (later tasks included).</div>")
    a = c["answers"]
    h.append(f"<h3>Criteria answers</h3><div class=sub>Same path: {_b(a['path_match'])} · answer differences: {a['n_mismatch']} · score tester {e(str(a['score_tester']))} vs real {e(str(a['score_real']))}</div>"
             "<table><tr><th>Q</th><th>Tester</th><th>Real</th><th></th></tr>" +
             "".join(f"<tr class={'bad' if not r['match'] else ''}><td>Q{r['q']}</td><td>{r['tester'] or '—'}</td><td>{r['real'] or '—'}</td><td>{_b(r['match'])}</td></tr>" for r in a["rows"]) + "</table>")
    t = c["term"]
    h.append(f"<h3>Approval term</h3><table><tr><th>Tester</th><th>Real</th><th></th></tr><tr><td>{t['tester_months']} months</td><td>{t['real_days']} days</td><td>{_b(t['match'])}</td></tr></table>")
    tm = c["time"]
    h.append(f"<h3>Time on task</h3><table><tr><th>Tester</th><th>Real ({e(str(tm['real_user']))}, {e(str(tm['real_role']))})</th></tr><tr><td>{tm['tester_s']} s</td><td>{tm['real_s']} s</td></tr></table>"
             "<div class=sub>The tester starts cold on an unfamiliar case; the real reviewer's time is the ledger task time. Not a like-for-like AHT.</div>")
    au = c["audit"]
    h.append("<h3>Audit log, side by side</h3><div class=sub>Real events are the reviewer's own, inside the first Loop-2 task window (±5 s).</div><table><tr><th>Real reviewer's CAS audit events</th><th>n</th></tr>" +
             "".join(f"<tr><td>{e(code)} {e(nm)}</td><td>{n}</td></tr>" for code, nm, n in au["real_codes"]) + "</table>"
             "<table><tr><th>Tester (sandbox)</th><th>n</th></tr>" + "".join(f"<tr><td>{e(k.replace('_', ' '))}</td><td>{v}</td></tr>" for k, v in au["tester_equiv"].items()) + "</table>")
    h.append(f"<h3>Tester event trail</h3><div class=sub>{len(run.get('events', []))} events; full list is in the run JSON.</div><table><tr><th>t (s)</th><th>event</th><th>detail</th></tr>" +
             "".join(f"<tr><td>{e['t']/1000:.1f}</td><td>{html.escape(e['type'])}</td><td>{html.escape(json.dumps(e.get('d'))[:120])}</td></tr>" for e in run.get("events", [])[:200]) + "</table>")
    return "".join(h)


if __name__ == "__main__":
    run = json.loads(Path(sys.argv[1]).read_text())
    tf = HERE / "truth" / f"{run['pa']}.json"
    print(json.dumps(compare_run(run, json.loads(tf.read_text()) if tf.exists() else None), indent=1))
