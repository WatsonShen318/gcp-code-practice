// ───────────────────────────────────────────────────────────────────────────────
// PA Caddie SANDBOX layer. Inlined by build_app.py AFTER the v4 engine, so it can override engine functions.
// Loads one cached historical case from the local server, builds the engine's data structures from it, records every
// reviewer action, and saves the run for comparison with what the real CAS reviewer did. No reviewer-decision data is
// ever sent to the browser (the server only serves cases/, never truth/).
// ───────────────────────────────────────────────────────────────────────────────
(function(){
'use strict';
let TESTER=''; try{TESTER=localStorage.getItem('caddie_tester')||'';}catch(e){}
let RUN=null, D=null, HIST_ALL=true, LAST_TOOL=null;
const EV=[];

// ── helpers ─────────────────────────────────────────────────────────────────────
const $=id=>document.getElementById(id);
const esc=s=>String(s==null?'':s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
const d10=s=>String(s||'').slice(0,10);
function mdy(iso){const s=d10(iso);if(!/^\d{4}-\d\d-\d\d$/.test(s))return s||'—';return s.slice(5,7)+'/'+s.slice(8,10)+'/'+s.slice(0,4);}
function mdy2(iso){const s=mdy(iso);return s.length===10?s.slice(0,6)+s.slice(8):s;}
function ageAt(dob,asof){const b=new Date(d10(dob)),a=new Date(d10(asof));let n=a.getFullYear()-b.getFullYear();const m=a.getMonth()-b.getMonth();if(m<0||(m===0&&a.getDate()<b.getDate()))n--;return n;}
function ndc11(s){const x=String(s||'').split('.')[0].replace(/\D/g,'');return x?x.padStart(11,'0'):null;}
function logEv(type,d){ if(!RUN)return; EV.push({t:Date.now()-RUN.t0,type,d:d===undefined?null:d}); }
function prettyDrug(n){
  n=String(n||'').toUpperCase();
  if(/HD|7\.2/.test(n))return'Wegovy HD Injection (semaglutide)';
  if(/TAB/.test(n))return'Wegovy Tablet (semaglutide)';
  if(/WEGOVY/.test(n))return'Wegovy Injection (semaglutide)';
  return n.replace(/\b\w/g,c=>c.toUpperCase()).toLowerCase().replace(/\b\w/g,c=>c.toUpperCase());
}
const gpi8=g=>String(g||'').slice(0,8);

// ── data → engine structures ─────────────────────────────────────────────────────
function buildSK(qset){
  const sk={}, tgt=v=>{v=String(v==null?'':v).trim();return (v==='A'||v==='D')?v:(v===''?null:Number(v));};
  qset.forEach(q=>{ sk[q.ordinal_nbr]={T:tgt(q.true_rspns_cd),F:tgt(q.false_rspns_cd)}; });
  return sk;
}
function buildCase(Dj){
  const h=Dj.header, asof=Dj.asof, sub=(Dj.submission||[]).slice().sort((a,b)=>String(a.CRTE_DT).localeCompare(String(b.CRTE_DT)));
  const s0=sub[0]||{}, drug=prettyDrug(h.prior_athzn_drug_nm), gpi=gpi8(h.gpi10_cd||h.prior_athzn_gpi_cd);
  const ndc=ndc11(s0.RX_REP_NDC_NBR);
  // history rows, flagged as the same drug as the PA (GPI-8 = base drug; related drugs are hidden by the toggle)
  const paHist=[{pa:Dj.pa,drug:h.prior_athzn_drug_nm,date:mdy2(asof),sort:d10(asof),outcome:null,same:true,term:'',current:true}]
    .concat((Dj.pa_history||[]).map(p=>({pa:p.prior_athzn_nbr,drug:p.prior_athzn_drug_nm||p.drvd_temp_drug_nm,date:mdy2(p.prior_athzn_crte_ts),sort:d10(p.prior_athzn_crte_ts),
      outcome:(String(p.prior_athzn_rsltn_drvd_cd||'').toUpperCase()==='APPROVAL')?'A':(String(p.prior_athzn_rsltn_drvd_cd||'').toUpperCase().includes('DENIAL')?'D':null),
      same:gpi8(p.gpi10_cd||p.prior_athzn_gpi_cd)===gpi, term:p.aprv_drtn_day_nbr?`${p.aprv_drtn_day_nbr}d`:'', end:d10(p.prior_athzn_aprv_end_dt), pac:p.pac_cd})))
    .sort((a,b)=>b.sort.localeCompare(a.sort));
  const clm=(Dj.claim_history||[]).map(c=>{
    const st=c.CLM_STUS_CD, rev=!!c.RVRSL_DT&&c.RVRSL_DT!=='NaT';
    return{dt:mdy2(c.FILL_DT),sort:d10(c.FILL_DT),drug:[c.DRUG_BRND_NM||c.DRUG_LBL_NM,c.DRUG_STRGH_NM].filter(Boolean).join(' ')||c.DRUG_LBL_NM||'—',
      qty:c.DSPNS_UNT_QTY!=null?String(parseFloat(c.DSPNS_UNT_QTY)):'—',days:c.DAY_SPLY_QTY!=null?Math.round(c.DAY_SPLY_QTY):'—',
      status:st==='P'?(rev?'Reversed':'Paid'):st==='R'?'Rejected':st==='V'?'Reversed':String(st||'—'),
      rjct:[c.NCPDP_RJCT1_CD,c.NCPDP_RJCT2_CD,c.NCPDP_RJCT3_CD].filter(Boolean).join(','),pharm:c.PHMCY_NM||'',same:gpi8(c.GPI10_CD||c.GPI_CD)===gpi};
  }).sort((a,b)=>b.sort.localeCompare(a.sort));
  // evidence we can compute from the data
  const age=ageAt(h.mbr_brth_dt,asof);
  const lo=new Date(d10(asof));lo.setMonth(lo.getMonth()-6);
  const paid6=clm.filter(c=>c.same&&c.status==='Paid'&&c.sort>=d10(lo.toISOString())&&c.sort<=d10(asof)).sort((a,b)=>a.sort.localeCompare(b.sort));
  const paid24=clm.filter(c=>c.same&&c.status==='Paid').length;
  const notes={2:`DOB: ${mdy(h.mbr_brth_dt)}. Age: ${age} years. ${age>=18?'Meets 18+ threshold.':'Does NOT meet the 18+ threshold.'}`};
  notes[3]=paid6.length?`Claims history: ${paid6.length} paid fill${paid6.length>1?'s':''} of ${drug.split(' (')[0]} in the 6 months before this PA (${mdy(paid6[0].sort)} to ${mdy(paid6[paid6.length-1].sort)}); ${paid24} paid fills of this drug in the last 24 months.`
    :`Claims history: no paid fills of this drug found in the 6 months before this PA; ${paid24} paid fills in the last 24 months.`;
  // PA history note: active approval for the same drug?
  const act=paHist.filter(p=>!p.current&&p.same&&p.outcome==='A'&&p.end&&p.end>=d10(asof));
  const nPrior=paHist.filter(p=>!p.current).length;
  const phNote=act.length?`⚠ Active approved PA found for this member and drug: ${act[0].pa} (approved through ${mdy(act[0].end)}). Check whether this request overlaps it.`
    :`✓ No active approved PA found for this member and drug. ${nPrior} prior PA${nPrior===1?'':'s'} on file for this member.`;
  // mock claims → tabs (reviewer's own run when present; else the system's intake run)
  const mk=(Dj.mock_claims||[]).slice();
  const human=mk.filter(r=>!/SYSTEM/i.test(r.CRTE_BY_USER_ID||''));
  const use=(human.length?human:mk).slice().sort((a,b)=>String(a.CRTE_TS).localeCompare(String(b.CRTE_TS)));
  const byFill={}; use.forEach(r=>{byFill[d10(r.FILL_DT)]=r;});
  const fills=Object.keys(byFill).sort();
  const tabs=['msg','d30','d60','d90'], mcRes={};
  tabs.forEach((t,i)=>{
    const r=byFill[fills[Math.min(i,fills.length-1)]]; if(!r)return;
    mcRes[t]={result:(r.MOCK_STUS_CD==='PAID'?'Paid':(r.RJCT_MSG_TXT||('Reject '+r.RJCT_CD))),settlement:'—',code:r.RJCT_CD||(r.MOCK_STUS_CD==='PAID'?'paid':'—'),label:r.RJCT_CD==='75'?'PA Required':(r.MOCK_STUS_CD==='PAID'?'Paid':'Reject')};
  });
  const sysRow=mk.find(r=>String(r.INITL_MOCK_IND)==='1')||use[0]||{};
  const qtyReject=mk.some(r=>/(^|,)\s*76\b/.test(r.RJCT_CD||''));
  const claim={code:sysRow.RJCT_CD||'—',msg:sysRow.RJCT_CD==='75'?'Prior Authorization Required':String(sysRow.RJCT_MSG_TXT||'').split(',')[0].slice(0,60),dt:d10(sysRow.FILL_DT||asof),
               drug:String(s0.RX_DESC_TXT||h.prior_athzn_drug_nm).toUpperCase(),qty:`${s0.RX_QTY_NBR!=null?Math.round(s0.RX_QTY_NBR):'—'} ${/TAB/i.test(h.prior_athzn_drug_nm)?'tablets':'units'}`,days:String(s0.RX_DAYS_SPLY_NBR||'—')};
  const mcDef={qty:s0.RX_QTY_NBR!=null?String(Math.round(s0.RX_QTY_NBR)):'',days:String(s0.RX_DAYS_SPLY_NBR||''),pharmacyId:sysRow.PHMCY_ID||'',fillDate:mdy(asof),physicianId:'',psc:'0',drugName:claim.drug,ndc:ndc||''};
  const f=Dj.fallout||{}, reason=String(f.reason||'').toLowerCase();
  const fallout=f.step?(reason.includes('outcome code')?`Automated ePA review stopped at step ${f.step} — could not validate the outcome code from the criteria form. Case routed to Pending Approval for a manual Verify Criteria Form check.`
                                                       :`Automated ePA review stopped at step ${f.step} — ${f.reason||'see CAS'}.`):'';
  const pdfs=Dj._pdfs||[], atts=Dj.attachments||[];
  if(atts.length){ const a0=atts[0], t=String(a0.CRTE_TS||'').replace('T',' ');
    const hm=t.slice(11,16); const hh=parseInt(hm.slice(0,2)); const ap=hh>=12?'PM':'AM';
    notes[5]=`${atts.length} ePA attachment${atts.length>1?'s':''} on file, received ${mdy(a0.CRTE_TS)} ${((hh%12)||12)}${hm.slice(2)} ${ap}.`; }
  const leg={role:'Technician',rev:(TESTER||'tester'),aht:'',ahtS:0,queue:'Pending Approval',isAgent:false,fallout,
    initAns:Object.assign({},Dj.initial_answers||{}),comments:Dj.q_comments&&Dj.q_comments[4]?{4:Dj.q_comments[4]}:{},notes,
    docs:atts.length?{3:'att',4:'att',5:'att'}:{},pdfs,
    dupNote:(pdfs.length||!atts.length)?'':(atts.length?`${atts.length} attachment${atts.length>1?'s are':' is'} on file in CAS but the PDF has not been downloaded into the sandbox yet (expected: pdfs/${Dj.pa}/${atts[0].filename}).`:'No attachment on file for this case.')};
  const cs={id:Dj.pa,
    meta:{drug,submittedDrug:s0.RX_DESC_TXT||h.prior_athzn_drug_nm,requestedDrug:drug,cls:`${h.pac_cd} — ${h.pac_desc||''}`,dx:h.icd_dx_cd_desc||h.icd_dx_cd||'',lob:'Commercial',origin:'ePA',
          ref:h.rfrnc_nbr,name:h.qset_desc||'',client:h.dsply_pag_nm||h.pag_nm,qset:String(h.qset_nbr||''),ndc:ndc||'',gpi:h.prior_athzn_gpi_cd||h.gpi10_cd||'',urgent:!!Number(h.urg_prior_athzn_ind)},
    member:{id:h.mbr_acct_id,name:`${h.mbr_frst_nm||''} ${h.mbr_last_nm||''}`.trim(),dob:mdy(h.mbr_brth_dt),sex:h.mbr_gndr_cd==='F'?'Female':h.mbr_gndr_cd==='M'?'Male':(h.mbr_gndr_cd||'—'),pag:h.pag_nm||h.dsply_pag_nm},
    claim,phNote,legs:[leg]};
  return{cs,tool:{paHistory:paHist,claimHistory:clm},mcRes,mcDef,qtyReject,drug};
}

async function loadCase(pa){
  const r=await fetch('/api/case/'+encodeURIComponent(pa)); if(!r.ok){alert('Case not cached: '+pa);return;}
  const Dj=await r.json();
  try{Dj._pdfs=await (await fetch('/api/pdfs/'+encodeURIComponent(pa))).json();}catch(e){Dj._pdfs=[];}
  D=Dj; const B=buildCase(Dj);
  SK=buildSK(Dj.qset);
  // question text straight from the data for anything the hand-written metadata lacks
  Dj.qset.forEach(q=>{ if(!QM[q.ordinal_nbr])QM[q.ordinal_nbr]={s:String(q.qstn_txt).slice(0,48),f:q.qstn_txt}; });
  if(QM[6]){ QM[6].ev=B.qtyReject?'Test claim returned a quantity-limit reject (76). Check the request against the plan allowance.':'Test claim: no quantity reject returned, so the request is within the plan allowance.'; }
  if(QM[19]){ QM[19].ev=`Drug on the PA: ${B.drug}.`; }
  CASES.length=0; CASES.push(B.cs); curCase=0; curLeg=0;
  TOOL_DATA={}; TOOL_DATA[pa]=B.tool; MC_RESULTS={}; MC_RESULTS[pa]=B.mcRes; MOCK_CLAIM_DEFS={}; MOCK_CLAIM_DEFS[pa]=B.mcDef; CASE_NOTES={};
  sa=[[Object.assign({},B.cs.legs[0].initAns)]]; wfSt=[[mkWfSt()]];
  HIST_ALL=true; EV.length=0; PANE_TAB=0;
  if($('doc-pane')){$('doc-pane').classList.remove('open');$('layout').classList.remove('pane-open');}
  RUN={pa,t0:Date.now(),started:new Date().toISOString(),initial_answers:Object.assign({},B.cs.legs[0].initAns)};
  const toast=$('sb-toast'); if(toast)toast.style.display='none';
  const sel=$('case-sel'); if(sel)sel.value=pa; const inp=$('pa-in'); if(inp)inp.value=pa;
  try{history.replaceState(null,'','#'+pa);}catch(e){}
  renderAll(); logEv('caseLoaded',{pa});
}
window.sbLoadCase=loadCase;

// ── history tables with an "other drugs" toggle ──────────────────────────────────
function togBar(all,hidden){
  return`<label style="display:flex;align-items:center;gap:7px;font-size:12px;margin:0 0 8px;color:#475569;cursor:pointer"><input type="checkbox" ${all?'checked':''} onchange="sbToggleOther(this.checked)"> Show other drugs${all?'':` <span style="color:#94a3b8">(${hidden} hidden)</span>`}</label>`;
}
window.sbToggleOther=function(v){ HIST_ALL=v; logEv('toggleOtherDrugs',{show:v}); if(LAST_TOOL&&$('tool-modal')&&$('tool-modal').style.display!=='none')openTool(LAST_TOOL); renderWorkflow(); };
window.buildPAHistoryTbl=function(history,currentId){
  const rows=history.filter(h=>HIST_ALL||h.same), hidden=history.length-rows.length;
  const body=rows.map(h=>{
    const cur=h.pa===currentId, badge=h.outcome==='A'?'<span class="tb-a">✓ Approved</span>':h.outcome==='D'?'<span class="tb-d">✗ Denied</span>':'<span class="tb-r">● In Review</span>';
    return`<tr class="${cur?'tr-cur':''}"><td>${h.pa}${cur?' <span class="tr-cur-chip">current</span>':''}</td><td>${esc(h.drug)}${h.same?'':' <span style="color:#94a3b8;font-size:10px">(other drug)</span>'}</td><td>${h.date}</td><td>${badge}</td><td>${esc(h.term||'')}</td></tr>`;}).join('');
  return togBar(HIST_ALL,hidden)+`<table class="tool-table"><thead><tr><th>PA Number</th><th>Drug</th><th>Created</th><th>Status</th><th>Term</th></tr></thead><tbody>${body}</tbody></table>`;
};
window.buildPAHistStep=function(history,currentId){
  const rows=history.filter(h=>HIST_ALL||h.same), hidden=history.length-rows.length;
  const body=rows.map(h=>{
    const cur=h.pa===currentId, badge=h.outcome==='A'?'<span class="ph-a">✓ Approved</span>':h.outcome==='D'?'<span class="ph-d">✗ Denied</span>':'<span class="ph-r">● In Review</span>';
    return`<tr class="${cur?'ph-cur':''}"><td>${h.pa}${cur?' <span class="ph-cur-chip">current</span>':''}</td><td>${esc(h.drug)}${h.same?'':' <span style="color:#94a3b8;font-size:10px">(other drug)</span>'}</td><td>${h.date}</td><td>${badge}</td></tr>`;}).join('');
  return togBar(HIST_ALL,hidden)+`<table class="ph-table"><thead><tr><th>PA Number</th><th>Drug</th><th>Date</th><th>Status</th></tr></thead><tbody>${body}</tbody></table>`;
};
window.buildClaimHistoryTbl=function(history){
  const rows=history.filter(h=>HIST_ALL||h.same), hidden=history.length-rows.length;
  const body=rows.map(h=>{
    const badge=h.status==='Paid'?'<span class="tb-a">✓ Paid</span>':h.status==='Rejected'?`<span class="tb-d">✗ Rejected${h.rjct?` (${esc(h.rjct)})`:''}</span>`:`<span class="tb-r">↺ ${esc(h.status)}</span>`;
    return`<tr><td>${h.dt}</td><td>${esc(h.drug)}${h.same?'':' <span style="color:#94a3b8;font-size:10px">(other drug)</span>'}</td><td>${esc(h.qty)}</td><td>${h.days}d</td><td>${badge}</td><td>${esc(h.pharm)}</td></tr>`;}).join('');
  return togBar(HIST_ALL,hidden)+`<table class="tool-table"><thead><tr><th>Fill date</th><th>Drug</th><th>Qty</th><th>Days</th><th>Status</th><th>Pharmacy</th></tr></thead><tbody>${body}</tbody></table>`;
};

// ── attachments: raw PDF in a resizable side pane (criteria stay visible while you read the document) ──
const css=document.createElement('style');
css.textContent=`
#layout.pane-open .left-rail{width:240px}
#doc-pane{display:none;flex:0 0 var(--pane-w,40%);min-width:360px;max-width:70%;position:sticky;top:var(--layout-top);height:calc(100vh - var(--layout-top));background:#fff;border-left:1px solid #cbd5e1;box-shadow:-4px 0 14px rgba(15,23,42,.08);flex-direction:column;z-index:150}
#doc-pane.open{display:flex}
#doc-pane .dp-hdr{display:flex;align-items:center;gap:8px;padding:8px 12px;border-bottom:1px solid #e2e8f0;background:#f8fafc}
#doc-pane .dp-ttl{font-size:12px;font-weight:700;color:#0f172a;flex:1;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
#doc-pane .dp-btn{border:1px solid #cbd5e1;background:#fff;border-radius:5px;padding:3px 8px;font-size:11px;cursor:pointer;color:#334155;text-decoration:none}
#doc-pane .dp-btn:hover{background:#f1f5f9}
#doc-pane .dp-tabs{display:flex;gap:4px;padding:6px 12px 0;background:#f8fafc;overflow-x:auto}
#doc-pane .dp-tab{padding:4px 10px;font-size:11px;border:1px solid #e2e8f0;border-bottom:0;border-radius:6px 6px 0 0;background:#fff;cursor:pointer;color:#475569;white-space:nowrap}
#doc-pane .dp-tab.act{background:#2563eb;color:#fff;border-color:#2563eb}
#doc-pane iframe{flex:1;border:0;width:100%}
#doc-pane .dp-empty{padding:28px 20px;color:#64748b;font-size:12px;line-height:1.6}
#doc-pane .dp-grip{position:absolute;left:-4px;top:0;bottom:0;width:8px;cursor:col-resize}
#doc-btn{padding:4px 10px;border-radius:5px;border:1px solid #475569;background:#334155;color:#e2e8f0;font-size:11px;cursor:pointer}
#doc-btn.on{background:#2563eb;border-color:#2563eb;color:#fff}
#bar-role{display:none}
.appbar .bar-right{flex:1 1 auto;min-width:0;justify-content:flex-end;gap:8px}
.appbar .bar-right>*{flex:0 1 auto;min-width:0}
#case-sel{width:clamp(110px,16vw,230px)}
#tester-in{width:clamp(70px,9vw,120px)}
#pa-in{width:clamp(70px,8vw,105px)}
@media (max-width:1150px){.bar-title,.bar-sep{display:none}}
@media (max-width:950px){#pa-in,#pa-load{display:none}}
@media (max-width:1100px){#doc-pane{position:fixed;right:0;top:var(--layout-top);width:80%;max-width:none;flex:none}}`;
document.head.appendChild(css);
let PANE_TAB=0;
function ensurePane(){
  if($('doc-pane'))return;
  const p=document.createElement('aside'); p.id='doc-pane';
  p.innerHTML='<div class="dp-grip" id="dp-grip"></div><div class="dp-hdr"><div class="dp-ttl" id="dp-ttl">Documents</div><a class="dp-btn" id="dp-new" target="_blank">Open in new tab ↗</a><button class="dp-btn" onclick="sbPane(false)">✕</button></div><div class="dp-tabs" id="dp-tabs"></div><div id="dp-body" style="flex:1;display:flex;flex-direction:column;min-height:0"></div>';
  $('layout').appendChild(p);
  const g=$('dp-grip'); let drag=false;  // drag the left edge to resize
  g.addEventListener('mousedown',e=>{drag=true;e.preventDefault();});
  window.addEventListener('mouseup',()=>{drag=false;document.querySelectorAll('#doc-pane iframe').forEach(f=>f.style.pointerEvents='');});
  window.addEventListener('mousemove',e=>{ if(!drag)return; document.querySelectorAll('#doc-pane iframe').forEach(f=>f.style.pointerEvents='none');
    const w=Math.min(window.innerWidth*0.7,Math.max(360,window.innerWidth-e.clientX)); document.documentElement.style.setProperty('--pane-w',w+'px'); });
  const bar=document.querySelector('.bar-right'); const b=document.createElement('button'); b.id='doc-btn'; b.onclick=()=>sbPane(!$('doc-pane').classList.contains('open')); bar.insertBefore(b,bar.firstChild);
}
function paneRender(){
  ensurePane(); const leg=CASES.length?getLeg():null; if(!leg)return;
  const atts=(D&&D.attachments)||[], have=leg.pdfs||[];
  $('doc-btn').textContent=`📄 Documents (${atts.length})`;
  $('doc-btn').classList.toggle('on',$('doc-pane').classList.contains('open'));
  $('dp-tabs').innerHTML=atts.map((a,i)=>`<div class="dp-tab${i===PANE_TAB?' act':''}" onclick="sbPaneTab(${i})">${esc(a.ATCHM_DESC||a.IMAGE_TYP_CD||'Attachment')} ${i+1} · ${esc(String(a.CRTE_TS||'').slice(5,16).replace('T',' '))}</div>`).join('');
  const a=atts[PANE_TAB], body=$('dp-body');
  if(!a){ $('dp-ttl').textContent='Documents'; body.innerHTML='<div class="dp-empty">No attachment on file for this case.</div>'; return; }
  $('dp-ttl').textContent=`Q4/Q5 evidence · ${a.filename}`;
  const url=`/api/pdf/${encodeURIComponent(D.pa)}/${encodeURIComponent(a.filename)}`;
  $('dp-new').href=url; $('dp-new').style.display=have.includes(a.filename)?'':'none';
  body.innerHTML=have.includes(a.filename)?`<iframe src="${url}"></iframe>`:`<div class="dp-empty"><b>Attachment on file in CAS, PDF not downloaded yet.</b><br>Expected file: <code>pdfs/${esc(D.pa)}/${esc(a.filename)}</code><br>Run <code>python fetch_pdfs.py ${esc(D.pa)}</code> or drop the file there; it appears here on reload.</div>`;
}
window.sbPane=function(open){ ensurePane(); $('doc-pane').classList.toggle('open',open); $('layout').classList.toggle('pane-open',open); logEv(open?'paneOpen':'paneClose'); paneRender(); };
window.sbPaneTab=function(i){ PANE_TAB=i; logEv('paneTab',{i}); paneRender(); };
window.openDoc=function(qno){ PANE_TAB=0; logEv('openDoc',{q:qno}); ensurePane(); $('doc-pane').classList.add('open'); $('layout').classList.add('pane-open'); paneRender(); };
const _rAll=window.renderAll; window.renderAll=function(){ _rAll.apply(this,arguments); try{paneRender();}catch(e){} };

// ── instrumentation: every reviewer action goes in the trail ─────────────────────
const NAMES=['toggleStep','toggleQ','setAnsV3','confirmCalc','openTool','runMockClaim','setMcTab','s1SaveDrug','s1ToggleEdit','genNoteV3','decYes','decNo','decSelectAlt','decGoBack','s4ToggleEdit','cancelAllV3','s3ToggleExp','s2Toggle'];
NAMES.forEach(n=>{
  const f=window[n]; if(typeof f!=='function')return;
  window[n]=function(){
    const a=[].slice.call(arguments); let d=a.length?a:undefined;
    if(n==='confirmCalc'){d={q:a[0],w0:getWf().calc.w0,w1:getWf().calc.w1};}
    if(n==='openTool')LAST_TOOL=a[0];
    if(n==='s1SaveDrug'){const s=$('drug-sel');d={drug:s?DRUG_LIST[parseInt(s.value)].label:null};}
    if(n==='runMockClaim'){d={qty:$('mc-qty')&&$('mc-qty').value,days:$('mc-days')&&$('mc-days').value,fill:$('mc-fill')&&$('mc-fill').value};}
    logEv(n,d);
    return f.apply(this,arguments);
  };
});

// ── finishing a case: record the decision and save the run ───────────────────────
function snapshot(label,extra){
  const ans=sa[0][0], sc=score(ans), pruned=prune(ans);
  return Object.assign({pa:D.pa,tester:TESTER||'anon',started:RUN.started,finished:new Date().toISOString(),elapsed_s:Math.round((Date.now()-RUN.t0)/1000),
    initial_answers:RUN.initial_answers,answers:pruned,score:sc,verified:getWf().verified,calc:getWf().calc,drug_requested:getCase().meta.requestedDrug,
    notes_text:getWf().s5Text||'',decision:{label,alt:getWf().s6AltOpt||null},approve_months:null,events:EV.slice()},extra||{});
}
async function saveRun(run){
  try{
    const r=await fetch('/api/save',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(run)}); const j=await r.json();
    let t=$('sb-toast'); if(!t){t=document.createElement('div');t.id='sb-toast';t.style.cssText='position:fixed;right:18px;bottom:18px;background:#0f172a;color:#fff;padding:12px 16px;border-radius:10px;font-size:13px;z-index:99;box-shadow:0 6px 24px rgba(0,0,0,.25)';document.body.appendChild(t);}
    t.style.display='block'; t.innerHTML=j.ok?`Saved ✓ &nbsp;<a style="color:#93c5fd" href="${j.compare}" target="_blank">Compare with CAS ↗</a> &nbsp;·&nbsp; <a style="color:#93c5fd;cursor:pointer" onclick="sbRandom()">Next case →</a>`:'Save failed: '+esc(j.error||'');
  }catch(e){alert('Save failed: '+e);}
}
const _approve=window.decConfirmApprove, _alt=window.decConfirmAlt;
window.decConfirmApprove=function(){
  const s=$('term-sel'); const months=s?parseInt(s.value):12;
  logEv('decConfirmApprove',{months});
  const run=snapshot('approve',{approve_months:months}); _approve.apply(this,arguments); saveRun(run);
};
window.decConfirmAlt=function(){
  const opt=getWf().s6AltOpt; logEv('decConfirmAlt',{opt});
  const run=snapshot(opt||'alt'); _alt.apply(this,arguments); saveRun(run);
};

// ── case picker (typed PA or random; random is the default) ──────────────────────
window.sbRandom=async function(){ const j=await (await fetch('/api/random?tester='+encodeURIComponent(TESTER))).json(); if(j.pa)loadCase(j.pa); else alert(j.error||'no cases'); };
window.sbLoadTyped=function(){ const v=($('pa-in').value||'').trim(); if(v)loadCase(v); };
window.sbSetTester=function(v){ TESTER=v.trim(); try{localStorage.setItem('caddie_tester',TESTER);}catch(e){} if(CASES.length)CASES[0].legs[0].rev=TESTER||'tester'; };

document.addEventListener('DOMContentLoaded',async()=>{
  const ti=$('tester-in'); if(ti){ti.value=TESTER;}
  try{
    const cases=await (await fetch('/api/cases')).json(), sel=$('case-sel');
    if(sel)sel.innerHTML='<option value="">Choose a cached case…</option>'+cases.map(c=>`<option value="${c.pa}">${c.pa} · ${esc(prettyDrug(c.drug))}${c.done_by.length?' ✓':''}</option>`).join('');
    const hash=(location.hash||'').replace('#','');
    if(/^\d\d-\d{9}$/.test(hash))loadCase(hash); else if(cases.length)sbRandom();
    else $('wf-steps').innerHTML='<div style="padding:30px;color:#64748b">No cached cases yet. Run pull_cases.py.</div>';
  }catch(e){ $('wf-steps').innerHTML='<div style="padding:30px;color:#b91c1c">Could not reach the sandbox server.</div>'; }
});
})();
