#!/usr/bin/env python3
"""Pool of PAC131011 PAs whose FIRST timed Loop-2 task ('Work Queues') was done by a Technician, from the task ledger only (BigQuery).
No Infosys/Digobs, screenshot or Splunk dependency: those can be layered on later (see _external/, git-excluded).

    python build_pool.py [--since 2026-07-20]     ->  .raw/pool_tech_first_l2.pkl
Ledger: edp-pdev-restrict-pbmstorage.edp_pssuma_cns.cso_task_level. opened_ts is Central time typed as UTC (kept as-is here)."""
import sys, warnings; warnings.filterwarnings("ignore")
from pathlib import Path
import pandas as pd
from google.cloud import bigquery
HERE = Path(__file__).resolve().parent
SINCE = sys.argv[sys.argv.index("--since") + 1] if "--since" in sys.argv else "2026-07-20"
c = bigquery.Client(project="edp-pdev-restrict-pssuma"); L = "`edp-pdev-restrict-pbmstorage.edp_pssuma_cns.cso_task_level`"
sql = f"""
WITH x AS (
  SELECT prior_athzn_nbr, pac_cd, cas_user_id, uma_job_title, UPPER(outcome_status) o, prior_athzn_rsltn_drvd_cd res, opened_ts, total_time_seconds, drug_name,
         ROW_NUMBER() OVER (PARTITION BY prior_athzn_nbr ORDER BY opened_ts) rn
  FROM {L} WHERE type_of_productivity='Work Queues' AND total_time_seconds>0 AND crte_dt >= @since)
SELECT prior_athzn_nbr, pac_cd, cas_user_id, uma_job_title, o, res, opened_ts AS first, total_time_seconds, drug_name
FROM x WHERE rn=1 AND pac_cd='PAC131011' AND uma_job_title='Technician'"""
df = c.query(sql, job_config=bigquery.QueryJobConfig(query_parameters=[bigquery.ScalarQueryParameter("since", "DATE", SINCE)])).result().to_dataframe()
(HERE / ".raw").mkdir(exist_ok=True); df.to_pickle(HERE / ".raw" / "pool_tech_first_l2.pkl")
print(f"first-Loop-2 Technician PAC131011 tasks since {SINCE}: {len(df):,} PAs, {df.cas_user_id.nunique()} reviewers")
print("first-task outcome:", df.o.value_counts().to_dict()); print("final resolution:", df.res.value_counts().to_dict())
