# PA Caddie sandbox

Local tool: pull a **historical** Wegovy ePA case (PAC131011, qset 255357) from BigQuery, let a reviewer work it in the Caddie UI, save the
decision, and compare it with what the real CAS Technician did on the same first Loop-2 task. Cases are cached on disk, so reviewing needs no SQL.

```bash
python3 server.py        # http://127.0.0.1:8793  (random case by default; PA # box + dropdown also work)
```

| step | command | what it does |
|---|---|---|
| pool | `python build_pool.py [--since 2026-07-20]` | PAC131011 PAs whose first timed Loop-2 task was a Technician's (ledger only) |
| select | `python select_cases.py 50 [--qset 255357]` | diverse, seeded pick across initial qset path x drug form x first-task outcome x final resolution |
| pull | `python pull_cases.py [PA ...]` | BigQuery -> `cases/<PA>.json` (reviewer-visible, as of case creation) and `truth/<PA>.json` (what the real reviewer did, incl. CAS audit log). Raw results cached in `.raw/`; `--dry` prints scan sizes; 3 TB/query cap. The audit-log scan is ~200 GB (~$1.3) per batch |
| derive | `python finalize_cases.py` | prescriber's initial answers, Q comments, ePA fallout |
| attachments | `CADDIE_DOC_API_KEY=... python fetch_pdfs.py` | PDFs into `pdfs/<PA>/` (TIFF scans are converted). Key comes from DE; never stored |
| build UI | `python build_app.py` | strips demo data from the engine (`engine/pa_caddie_engine.html`, committed) and inlines `sandbox.js` -> `app/index.html` |
| compare | `/compare` page, or `python compare.py runs/<file>.json` | task decision, Q answers, approval term, time on task, and the real reviewer's audit events beside the tester's actions. Notes are not compared |

Needs: Python 3.13 with `google-cloud-bigquery pandas pyarrow pymupdf requests`; `gcloud auth application-default login`. SQL is billed to `edp-pdev-restrict-pssuma`.

Member data lives in `cases/ truth/ runs/ pdfs/ .raw/ picked_cases.json` and is git-ignored. Do not commit, email or upload it.

Not in this repo (kept separate until needed): Infosys/Digobs click trails and screenshots, Splunk server-call timings, Aternity. See `HANDOFF.md` §7.
