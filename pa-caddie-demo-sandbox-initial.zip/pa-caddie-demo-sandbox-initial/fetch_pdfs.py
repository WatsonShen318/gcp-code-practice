#!/usr/bin/env python3
"""Download the ePA attachment PDFs listed in pdfs/manifest.csv into pdfs/<PA>/<filename> via the PA doc-reviewer API.

    ~/miniforge3/envs/um-trend/bin/python3 fetch_pdfs.py [PA ...]     # default: every PA in the manifest, skips files already present

The DB path is `\\\\shea-x400s01\\cas_storage\\...`; the API wants the FQDN host (`shea-x400s01.CAREMARKRX.NET`), so we try that first, then the path as stored. Files are verified to start with %PDF. pdfs/ is git-excluded (PHI)."""
import sys, csv, time
from pathlib import Path
from urllib.parse import quote
import requests

HERE = Path(__file__).resolve().parent
import os
# The old dev API (pss-dev.aig.aetna.com) is gone. Current endpoint sits behind the PA Ops Streamlit host and needs a bearer key from DE;
# pass it as CADDIE_DOC_API_KEY in the environment for the run. Never write the key into this file or the repo.
API = os.environ.get("CADDIE_DOC_API_URL", "https://paops-streamlit.pdev.cvshealth.com/api/doc-reviewer/download_pa_doc")
HDRS = {"Authorization": "Bearer " + os.environ["CADDIE_DOC_API_KEY"]} if os.environ.get("CADDIE_DOC_API_KEY") else {}
want = set(a for a in sys.argv[1:] if not a.startswith("--"))
rows = list(csv.DictReader(open(HERE / "pdfs" / "manifest.csv")))
if want:
    rows = [r for r in rows if r["prior_athzn_nbr"] in want]

def variants(p):
    """FQDN host first (what DE says the API needs), then the path exactly as stored in V_PRIOR_ATHZN_ATCHM."""
    if "CAREMARKRX" not in p.upper():
        yield p.replace("shea-x400s01\\", "shea-x400s01.CAREMARKRX.NET\\", 1)
    yield p

ok = bad = skip = 0
for r in rows:
    out = HERE / "pdfs" / r["prior_athzn_nbr"] / r["filename"]
    if out.exists() and out.stat().st_size > 1000:
        skip += 1; continue
    done = False
    for fp in variants(r["IMAGE_PATH_TXT"]):
        try:
            resp = requests.post(f"{API}?filepath={quote(fp)}", headers=HDRS, timeout=60)
        except Exception as e:
            print(f"  {r['prior_athzn_nbr']}: request error {type(e).__name__}: {str(e)[:120]}"); continue
        body = resp.content
        if resp.status_code == 200 and body[:4] in (b"II*\x00", b"MM\x00*"):      # some "pdf" attachments are really multipage TIFF scans: convert so the viewer can show them
            import pymupdf
            body = pymupdf.open(stream=body, filetype="tiff").convert_to_pdf()
        if resp.status_code == 200 and body[:4] == b"%PDF":
            out.parent.mkdir(parents=True, exist_ok=True); out.write_bytes(body)
            resp._content = body
            print(f"  {r['prior_athzn_nbr']}: ok {len(resp.content)/1024:.0f} KB"); ok += 1; done = True; break
        print(f"  {r['prior_athzn_nbr']}: {resp.status_code} {resp.text[:100]!r} (path form: {'fqdn' if 'CAREMARKRX' in fp.upper() else 'as stored'})")
    if not done:
        bad += 1
    time.sleep(0.2)
print(f"downloaded {ok}, already present {skip}, failed {bad}")
