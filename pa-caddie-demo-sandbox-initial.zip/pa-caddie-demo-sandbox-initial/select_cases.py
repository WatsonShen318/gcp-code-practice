#!/usr/bin/env python3
"""Select N diverse cases for the Caddie sandbox.

Universe: the ledger-only pool from build_pool.py: PAC131011 PAs whose FIRST timed Loop-2 task was done by a Technician (no Infosys/Splunk requirement).
Diversity strata = (prescriber's initial qset path class) x (drug form) x (first-task outcome) x (final PA resolution).
Greedy: take the rarest strata first, one case each, then keep cycling strata until N. Seeded.
    ~/miniforge3/envs/um-trend/bin/python3 select_cases.py [N] [--since 2026-07-20] [--qset 255357] [--out DIR]
"""
import sys, json, random, warnings; warnings.filterwarnings("ignore")
from pathlib import Path
import pandas as pd
from google.cloud import bigquery
HERE = Path(__file__).resolve().parent
N = int(next((a for a in sys.argv[1:] if a.isdigit()), 50)); SINCE = sys.argv[sys.argv.index("--since") + 1] if "--since" in sys.argv else "2026-07-20"
OUT = sys.argv[sys.argv.index("--out") + 1] if "--out" in sys.argv else None   # --out DIR: write picks there instead of picked_cases.json/.raw (for dry tries)
pool = pd.read_pickle(HERE / ".raw" / "pool_tech_first_l2.pkl")
pool = pool[pd.to_datetime(pool["first"]).dt.tz_localize(None) >= pd.Timestamp(SINCE)].copy()
print(f"pool since {SINCE}: {len(pool):,} tasks, {pool.prior_athzn_nbr.nunique():,} PAs")
if len(pool) > 6000:                                               # keep the qset-path lookup request small; seeded so it is reproducible
    pool = pool.sample(6000, random_state=20261027).copy(); print("  pre-sampled to 6,000 for the path lookup")
c = bigquery.Client(project="edp-pdev-restrict-pssuma"); P = "`edp-prod-restrict-pbmstorage"
pas = sorted(pool.prior_athzn_nbr.unique().tolist()); prm = [bigquery.ArrayQueryParameter("p", "STRING", pas)]
paths = c.query(f"""SELECT t.CAS_PRIOR_ATHZN_NBR prior_athzn_nbr,
  STRING_AGG(CONCAT(CAST(SAFE_CAST(q.ORDEAL_NBR AS INT64) AS STRING), ':', IF(a.ANSWR_TXT='1','T','F')), '|' ORDER BY SAFE_CAST(q.ORDEAL_NBR AS INT64)) ipath,
  ANY_VALUE(t.RX_DESC_TXT) rx_desc
  FROM {P}.edp_customer_pbmedh_cnsv.V_PRIOR_ATHZN_TXN_DAT` t
  JOIN {P}.edp_customer_pbmedh_cnsv.V_CAS_CAS_COMPLETEDQSET` cq ON CAST(cq.TXN_DAT_ID AS STRING)=CAST(t.ROW_KEY_NBR AS STRING)
  JOIN {P}.edp_customer_pbmedh_cnsv.V_CAS_COMPLETEDQSET_QUEST` q ON CAST(q.CMPLT_QSET_ID AS STRING)=CAST(cq.ROW_KEY_NBR AS STRING)
  JOIN {P}.edp_customer_pbmedh_cnsv.V_CAS_COMPLETEDQSET_ANSWERS` a ON CAST(a.CMPLT_QSET_QSTN_ID AS STRING)=CAST(q.ROW_KEY_NBR AS STRING)
  WHERE t.CAS_PRIOR_ATHZN_NBR IN UNNEST(@p) AND a.ANSWR_TXT IN ('0','1') GROUP BY 1""", job_config=bigquery.QueryJobConfig(query_parameters=prm)).result().to_dataframe()
hdr = c.query(f"""SELECT prior_athzn_nbr, prior_athzn_drug_nm, qset_nbr, icd_dx_cd FROM {P}.edp_abcpssprdcteng_appv.v_pa_denorm` WHERE prior_athzn_nbr IN UNNEST(@p)""",
              job_config=bigquery.QueryJobConfig(query_parameters=prm)).result().to_dataframe()
d = pool.merge(paths, on="prior_athzn_nbr", how="left").merge(hdr, on="prior_athzn_nbr", how="left")
print("with initial path:", d.ipath.notna().mean().round(3), "| qset_nbr:", d.qset_nbr.astype(str).value_counts().to_dict())
QSET = sys.argv[sys.argv.index("--qset") + 1] if "--qset" in sys.argv else "255357"   # the sandbox UI's question metadata is hand-written for this qset only
d = d[d.ipath.notna() & (d.qset_nbr.astype(str) == QSET)].copy()
print(f"restricted to qset {QSET}: {len(d):,} PAs")
def pclass(p):
    q = dict(x.split(":") for x in p.split("|"))
    if q.get("3") == "T": return "continuation"
    if q.get("22") == "T" or q.get("12") == "T" and False: return "adolescent"
    first = p.split("|")[:3]
    return "initial:" + "".join(x.split(":")[1] for x in p.split("|")[:4]) if len(p) < 40 else "initial-other"
d["pclass"] = d.ipath.map(lambda p: "continuation(Q3=Y)" if dict(x.split(":") for x in p.split("|")).get("3") == "T" else ("cv/mash(Q1=N)" if dict(x.split(":") for x in p.split("|")).get("1") == "F" else "initial-BMI(Q3=N)"))
d["form"] = d.prior_athzn_drug_nm.str.upper().map(lambda s: "tablet" if "TAB" in str(s) else ("HD" if "HD" in str(s) or "7.2" in str(s) else "injection"))
d["stratum"] = d.pclass + " | " + d.form + " | " + d.o + " | " + d.res.astype(str)
sz = d.stratum.value_counts(); print(f"{len(sz)} strata; largest {sz.max():,}, smallest {sz.min()}")
rng = random.Random(20261023); chosen = []
bystrat = {s: sorted(g.prior_athzn_nbr.tolist()) for s, g in d.groupby("stratum")}
for s in bystrat: rng.shuffle(bystrat[s])
order = sorted(bystrat, key=lambda s: (len(bystrat[s]), s))            # rarest first
while len(chosen) < N and any(bystrat.values()):
    for s in order:
        if bystrat[s] and len(chosen) < N: chosen.append(bystrat[s].pop())
sel = d[d.prior_athzn_nbr.isin(chosen)].drop_duplicates("prior_athzn_nbr")
_o = Path(OUT) if OUT else None
if _o: _o.mkdir(parents=True, exist_ok=True)
(( _o or HERE) / "picked_cases.json").write_text(json.dumps(sorted(chosen), indent=1))
sel[["prior_athzn_nbr", "cas_user_id", "first", "pclass", "form", "o", "res", "stratum"]].to_csv(( _o or HERE / ".raw") / "selected_cases.csv", index=False)
print(f"\nselected {len(sel)}:"); 
for col in ["pclass", "form", "o", "res"]: print(f"  {col}:", sel[col].value_counts().to_dict())
print("  distinct strata:", sel.stratum.nunique(), "| users:", sel.cas_user_id.nunique())
