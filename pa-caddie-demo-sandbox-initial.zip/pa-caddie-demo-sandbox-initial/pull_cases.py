#!/usr/bin/env python3
"""Pull everything the Caddie sandbox needs for a batch of historical PAs and cache it locally (no live SQL at review time).

  python pull_cases.py [--dry] [PA ...]      # default PAs = picked_cases.json

Writes  cases/<PA>.json  (what the reviewer is allowed to see: as-of the moment the case was created / reviewed)
        truth/<PA>.json  (what the real reviewer did: final decision, final qset answers, audit events, ledger task)  -- NEVER shown in the UI.
Both folders are git-excluded (PHI). Billing project edp-pdev-restrict-pssuma; sources under edp-prod-restrict-pbmstorage.
Run with ~/miniforge3/envs/um-trend/bin/python3.
"""
import sys, json, warnings, datetime as dt
warnings.filterwarnings("ignore")
from pathlib import Path
import pandas as pd
from google.cloud import bigquery

HERE = Path(__file__).resolve().parent
P = "`edp-prod-restrict-pbmstorage"
APP, CUST, CLNT, CLM = f"{P}.edp_abcpssprdcteng_appv", f"{P}.edp_customer_pbmedh_cnsv", f"{P}.edp_clntspclt_pbmedh_cnsv", f"{P}.edp_claim_pbmedh_cnsv"
LEDGER = "`edp-pdev-restrict-pbmstorage.edp_pssuma_cns.cso_task_level`"
HIST_DAYS = 730
c = bigquery.Client(project="edp-pdev-restrict-pssuma")
args = [a for a in sys.argv[1:] if not a.startswith("--")]
DRY = "--dry" in sys.argv
PAS = args or json.loads((HERE / "picked_cases.json").read_text())

RAW = HERE / ".raw"; RAW.mkdir(exist_ok=True)
REFRESH = "--refresh" in sys.argv
def run(label, sql, params=None):
    key = RAW / (("".join(ch if ch.isalnum() else "_" for ch in label)) + "." + __import__("hashlib").md5("|".join(PAS).encode()).hexdigest()[:8] + ".pkl")
    if not DRY and not REFRESH and key.exists():
        df = pd.read_pickle(key); print(f"  {label}: {len(df):,} rows (cached)"); return df
    cfg = bigquery.QueryJobConfig(query_parameters=params or [], dry_run=DRY, maximum_bytes_billed=int(3e12))  # hard cap ~$18 per query
    j = c.query(sql, job_config=cfg)
    if DRY:
        print(f"  [dry] {label}: {(j.total_bytes_processed or 0)/1e9:,.1f} GB"); return pd.DataFrame()
    df = j.result().to_dataframe(); print(f"  {label}: {len(df):,} rows, {(j.total_bytes_processed or 0)/1e9:,.1f} GB", flush=True)
    df.to_pickle(key); return df

def arr(name, vals, typ="STRING"): return bigquery.ArrayQueryParameter(name, typ, list(vals))
def clean(df):
    out = df.copy()
    for col in out.columns:
        if str(out[col].dtype).startswith(("datetime", "dbdate")) or out[col].dtype == object:
            out[col] = out[col].map(lambda v: None if (v is None or (not isinstance(v, (list, dict)) and pd.isna(v))) else (v.isoformat() if hasattr(v, "isoformat") else (str(v) if not isinstance(v, (int, float, str, bool)) else v)))
    return out.where(out.notna(), None)
def recs(df): return clean(df).to_dict("records") if len(df) else []

print(f"{len(PAS)} PAs{' (DRY RUN)' if DRY else ''}")
pa_p = [arr("pas", PAS)]
hdr = run("header (v_pa_denorm)", f"""SELECT prior_athzn_nbr, mbr_acct_id, mbr_acct_gid, case_id, prior_athzn_drug_nm, drvd_temp_drug_nm, prior_athzn_gpi_cd, gpi10_cd, ndc_calc_nbr, drug_brnd_nm,
  spclt_drug_cls_nm, icd_dx_cd, icd_dx_cd_desc, urg_prior_athzn_ind, prior_athzn_orgn_cd, prior_athzn_intake_mthd_drvd_cd, epa_ind, pag_cd, pag_nm, dsply_pag_nm, pac_cd, pac_desc, qset_nbr, qset_desc, rfrnc_nbr,
  lvl1_acct_id, lvl2_acct_id, lvl3_acct_id, clnt_typ_cd, mbr_frst_nm, mbr_last_nm, mbr_brth_dt, mbr_gndr_cd, mbr_addr_1_txt, mbr_addr_2_txt, mbr_city_nm, mbr_st_cd, mbr_zip5_cd,
  physn_id, physn_frst_nm, physn_last_nm, physn_addr_line_1_txt, physn_addr_city_nm, physn_st_cd, physn_zip5_cd, physn_phone_1_nbr, physn_fax_nbr,
  prior_athzn_crte_ts, prior_athzn_rsltn_ts, prior_athzn_aprv_strt_dt, prior_athzn_aprv_end_dt, aprv_drtn_day_nbr, prior_athzn_rsltn_drvd_cd, rsltn_cd, slctd_outc_cd, outc_cd, outc_desc,
  rsltn_rsn_drvd_txt, english_rsltn_note_txt, rsltn_dcsn_note_txt, rsltn_by_user_id, user_typ_cd
  FROM {APP}.v_pa_denorm` WHERE prior_athzn_nbr IN UNNEST(@pas)""", pa_p)
qs = run("qset (v_pa_qset_denorm)", f"""SELECT prior_athzn_nbr, qset_nbr, qset_desc, SAFE_CAST(ordinal_nbr AS INT64) ordinal_nbr, qstn_txt, qstn_typ_cd, user_answr_txt, answr_txt, extn_answr_txt,
  true_rspns_cd, false_rspns_cd, score_val_nbr, rsltn_cd FROM {APP}.v_pa_qset_denorm` WHERE prior_athzn_nbr IN UNNEST(@pas) ORDER BY 1, 4""", pa_p)
txn = run("prescriber submission (TXN_DAT)", f"""SELECT CAS_PRIOR_ATHZN_NBR prior_athzn_nbr, ROW_KEY_NBR txn_row, TXN_ID, CRTE_DT, AUTO_SCORE_RSLT_TXT, RX_DESC_TXT, RX_REP_NDC_NBR, RX_QTY_NBR, RX_DAYS_SPLY_NBR, RX_DX_CD, RX_DX_QLFR_CD,
  PRVDR_NPI_NBR, PRVDR_FRST_NM, PRVDR_LAST_NM, PRVDR_CLNC_NM, PRVDR_PHONE_NBR, PRVDR_FAX_NBR, PHMCY_NCPDP_ID, EPA_LOB_ID, PRTY_IND
  FROM {CUST}.V_PRIOR_ATHZN_TXN_DAT` WHERE CAS_PRIOR_ATHZN_NBR IN UNNEST(@pas) OR EPA_PRIOR_ATHZN_NBR IN UNNEST(@pas) ORDER BY 1, CRTE_DT""", pa_p)
cq = run("prescriber qset answers + comments", f"""SELECT t.CAS_PRIOR_ATHZN_NBR prior_athzn_nbr, q.ORDEAL_NBR, q.QSTN_TEST_TXT, a.ANSWR_TXT, a.EXTN_TXT, a.NMRC_VAL_1_TXT, a.FREE_TXT_IND, c.PRVDR_CMNT_TXT, t.ROW_KEY_NBR txn_row
  FROM {CUST}.V_PRIOR_ATHZN_TXN_DAT` t
  JOIN {CUST}.V_CAS_CAS_COMPLETEDQSET` c ON CAST(c.TXN_DAT_ID AS STRING)=CAST(t.ROW_KEY_NBR AS STRING)
  JOIN {CUST}.V_CAS_COMPLETEDQSET_QUEST` q ON CAST(q.CMPLT_QSET_ID AS STRING)=CAST(c.ROW_KEY_NBR AS STRING)
  LEFT JOIN {CUST}.V_CAS_COMPLETEDQSET_ANSWERS` a ON CAST(a.CMPLT_QSET_QSTN_ID AS STRING)=CAST(q.ROW_KEY_NBR AS STRING)
  WHERE t.CAS_PRIOR_ATHZN_NBR IN UNNEST(@pas) OR t.EPA_PRIOR_ATHZN_NBR IN UNNEST(@pas) ORDER BY 1, SAFE_CAST(q.ORDEAL_NBR AS INT64)""", pa_p)
mock = run("mock claim results", f"""SELECT PRIOR_ATHZN_NBR prior_athzn_nbr, ATMPT_NBR, PHMCY_ID, NDC_CD, FILL_DT, MOCK_STUS_CD, RJCT_CD, RJCT_MSG_TXT, INITL_MOCK_IND, MOCK_SRC_CD, USE_FUTR_DT_IND, CRTE_TS, CRTE_BY_USER_ID, UNEXPCT_FAIL_IND
  FROM {CUST}.V_PRIOR_ATHZN_MOCK_CLM_RSLT` WHERE PRIOR_ATHZN_NBR IN UNNEST(@pas) ORDER BY 1, CRTE_TS""", pa_p)
led = run("ledger task row (truth)", f"""SELECT prior_athzn_nbr, cas_user_id, uma_job_title, opened_ts, total_time_seconds, outcome_status, task_vs_touch, type_of_productivity, qset_final_score,
  n_qset_edits, this_task_edited_qset, n_pac_changes, ePA_Fallout_Step, ePA_Fallout_Reason, has_rfi
  FROM {LEDGER} WHERE prior_athzn_nbr IN UNNEST(@pas) ORDER BY 1, opened_ts""", pa_p)
aud = run("audit log (truth)", f"""SELECT PRIOR_ATHZN_NBR prior_athzn_nbr, ACTVY_CD, CRTE_BY_USER_ID, CRTE_TS, SRC_SYSTM_NM
  FROM {CLNT}.V_PRIOR_ATHZN_ACTVY_AUDT_LOG` WHERE PRIOR_ATHZN_NBR IN UNNEST(@pas) ORDER BY 1, CRTE_TS""", pa_p)
atc = run("attachments (V_PRIOR_ATHZN_ATCHM)", f"""SELECT PRIOR_ATHZN_NBR prior_athzn_nbr, ATCHM_ID, IMAGE_PATH_TXT, IMAGE_TYP_CD, CNTNT_TYP_CD, ATCHM_DESC, CRTE_BY_USER_ID, CRTE_TS
  FROM {CUST}.V_PRIOR_ATHZN_ATCHM` WHERE PRIOR_ATHZN_NBR IN UNNEST(@pas) ORDER BY 1, CRTE_TS""", pa_p)
if DRY: sys.exit(0)

mb = hdr.set_index("prior_athzn_nbr")
gids = sorted({str(int(v)) for v in hdr.mbr_acct_gid.dropna()})
# Member-level history: ALL of the member's PAs and claims up to the case-creation date (nothing the reviewer could not have seen).
mp = [arr("gids", gids, "STRING")]
hist_pa = run("member PA history", f"""SELECT CAST(mbr_acct_gid AS STRING) mbr_acct_gid, prior_athzn_nbr, prior_athzn_drug_nm, drvd_temp_drug_nm, gpi10_cd, prior_athzn_gpi_cd, pac_cd, pac_desc, prior_athzn_crte_ts, prior_athzn_rsltn_ts,
  prior_athzn_rsltn_drvd_cd, prior_athzn_aprv_strt_dt, prior_athzn_aprv_end_dt, aprv_drtn_day_nbr, rsltn_rsn_drvd_txt, icd_dx_cd, prior_athzn_orgn_cd
  FROM {APP}.v_pa_denorm` WHERE CAST(mbr_acct_gid AS STRING) IN UNNEST(@gids)""", mp)
def naive(x): return pd.to_datetime(x, utc=True).dt.tz_localize(None) if hasattr(x, "dt") else pd.Timestamp(x).tz_convert("UTC").tz_localize(None) if pd.Timestamp(x).tzinfo else pd.Timestamp(x)
lo = (naive(mb.prior_athzn_crte_ts).min() - pd.Timedelta(days=HIST_DAYS)).date().isoformat()
hi = naive(mb.prior_athzn_crte_ts).max().date().isoformat()
hist_clm = run("member claim history", f"""SELECT CAST(k.MBR_ACCT_GID AS STRING) mbr_acct_gid, k.CLM_NBR, k.FILL_DT, k.CLM_STUS_CD, k.RVRSL_DT, k.DSPNS_UNT_QTY, k.DAY_SPLY_QTY, k.RX_NBR, k.NEW_REFIL_CD, k.BILL_NDC_ID,
  k.NCPDP_RJCT1_CD, k.NCPDP_RJCT2_CD, k.NCPDP_RJCT3_CD, k.PRIOR_ATHZN_TYP_CD, k.PRIOR_ATHZN_APPLD_STUS_CD, k.MBR_TOT_COST_AMT, k.CLNT_BILL_AMT, k.PHMCY_CLM_REC_ADD_TS,
  d.DRUG_LBL_NM, d.DRUG_BRND_NM, d.DRUG_STRGH_NM, d.DSG_FORM_ABBR_NM, d.GPI_CD, d.GPI10_CD, d.GPI_CLS_NM, ph.PHMCY_NM, ph.NCPDP_PRVDR_ID
  FROM {CLM}.V_PHMCY_CLM` k
  LEFT JOIN {CLNT}.V_DRUG_DENORM` d ON d.DRUG_PROD_GID = k.DRUG_PROD_GID
  LEFT JOIN {CLNT}.V_PHMCY_DENORM` ph ON ph.PHMCY_PTY_GID = k.PHMCY_PTY_GID
  WHERE k.FILL_DT BETWEEN @lo AND @hi AND CAST(k.MBR_ACCT_GID AS STRING) IN UNNEST(@gids)""",
  mp + [bigquery.ScalarQueryParameter("lo", "DATE", lo), bigquery.ScalarQueryParameter("hi", "DATE", hi)])

(HERE / "cases").mkdir(exist_ok=True); (HERE / "truth").mkdir(exist_ok=True)
for pa in PAS:
    if pa not in mb.index: print("  !! header missing for", pa); continue
    h = mb.loc[pa]; created = naive(h.prior_athzn_crte_ts); resolved = naive(h.prior_athzn_rsltn_ts)
    gid = str(int(h.mbr_acct_gid))
    hp = hist_pa[(hist_pa.mbr_acct_gid == gid) & (hist_pa.prior_athzn_nbr != pa) & (naive(hist_pa.prior_athzn_crte_ts) < created)]
    hc = hist_clm[(hist_clm.mbr_acct_gid == gid)]
    # nothing the reviewer could not have seen: earlier fill dates, or same-day rows loaded before the PA was created
    hc = hc[(pd.to_datetime(hc.FILL_DT) < created.normalize()) | ((pd.to_datetime(hc.FILL_DT) == created.normalize()) & (pd.to_datetime(hc.PHMCY_CLM_REC_ADD_TS) < created))]
    mk = mock[(mock.prior_athzn_nbr == pa) & (pd.to_datetime(mock.CRTE_TS) < resolved)]
    # prescriber's initial answers: what the qset looked like BEFORE the reviewer (completed-qset), plus the question tree from the qset table
    case = dict(pa=pa, asof=created.isoformat(), header=recs(hdr[hdr.prior_athzn_nbr == pa].drop(columns=["rsltn_cd", "slctd_outc_cd", "outc_cd", "outc_desc", "rsltn_rsn_drvd_txt", "english_rsltn_note_txt", "rsltn_dcsn_note_txt", "rsltn_by_user_id", "user_typ_cd", "prior_athzn_rsltn_ts", "prior_athzn_aprv_strt_dt", "prior_athzn_aprv_end_dt", "aprv_drtn_day_nbr", "prior_athzn_rsltn_drvd_cd"]))[0],
                qset=recs(qs[qs.prior_athzn_nbr == pa][["ordinal_nbr", "qstn_txt", "qstn_typ_cd", "true_rspns_cd", "false_rspns_cd", "score_val_nbr"]]),
                submission=recs(txn[txn.prior_athzn_nbr == pa]), prescriber_answers=recs(cq[cq.prior_athzn_nbr == pa]),
                mock_claims=recs(mk), pa_history=recs(hp), claim_history=recs(hc),
                attachments=[dict(a, filename=str(a["IMAGE_PATH_TXT"]).replace("\\", "/").split("/")[-1]) for a in recs(atc[atc.prior_athzn_nbr == pa])])
    truth = dict(pa=pa, final=recs(hdr[hdr.prior_athzn_nbr == pa][["prior_athzn_rsltn_drvd_cd", "rsltn_cd", "slctd_outc_cd", "outc_cd", "outc_desc", "prior_athzn_rsltn_ts", "prior_athzn_aprv_strt_dt", "prior_athzn_aprv_end_dt", "aprv_drtn_day_nbr", "rsltn_by_user_id", "user_typ_cd"]])[0],
                 final_qset=recs(qs[qs.prior_athzn_nbr == pa][["ordinal_nbr", "user_answr_txt", "rsltn_cd"]]), ledger=recs(led[led.prior_athzn_nbr == pa]),
                 audit=recs(aud[aud.prior_athzn_nbr == pa]), mock_claims_all=recs(mock[mock.prior_athzn_nbr == pa]))
    (HERE / "cases" / f"{pa}.json").write_text(json.dumps(case, indent=1, default=str)); (HERE / "truth" / f"{pa}.json").write_text(json.dumps(truth, indent=1, default=str))
    print(f"  {pa}: {len(case['attachments'])} attachment(s), qset {len(case['qset'])} q, history {len(hp)} PAs / {len(hc)} claims, mock {len(mk)} rows, audit {len(truth['audit'])} events")

# manifest for whoever fetches the files: drop each file at pdfs/<PA>/<filename> and the sandbox serves it
(HERE / "pdfs").mkdir(exist_ok=True)
m = atc.assign(filename=atc.IMAGE_PATH_TXT.astype(str).str.replace("\\", "/").str.split("/").str[-1])[["prior_athzn_nbr", "ATCHM_ID", "filename", "IMAGE_PATH_TXT", "CRTE_TS", "CNTNT_TYP_CD"]]
m.to_csv(HERE / "pdfs" / "manifest.csv", index=False); print("  pdfs/manifest.csv:", len(m), "attachments")
