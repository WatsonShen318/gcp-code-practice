#!/usr/bin/env python3
"""Build app/index.html: the Caddie UI engine with every demo/case data removed, plus sandbox.js inlined.

    python build_app.py

Source of the engine, in priority order:
  1. ../demos/pa_caddie_v4.html   — Jamie's local working copy (git-excluded: carries one real case's clinical values)
  2. engine/pa_caddie_engine.html — a generic copy with no case data, committed to the repo

Whichever is used, this script FIRST strips every demo case and writes the result to engine/pa_caddie_engine.html
(safe to commit — asserted free of case data below), THEN inlines sandbox.js on top of that to produce app/index.html.
So engine/pa_caddie_engine.html is always regenerated from whichever source exists; DE can rebuild from it alone even
without ever having ../demos/pa_caddie_v4.html.

If the engine's HTML structure changes enough that a patch below no longer matches, this fails loudly instead of
producing a half-patched app.
"""
import re
from pathlib import Path

HERE = Path(__file__).resolve().parent
V4 = HERE.parent / "demos" / "pa_caddie_v4.html"
ENGINE_PATH = HERE / "engine" / "pa_caddie_engine.html"
SOURCE = V4 if V4.exists() else ENGINE_PATH
if not SOURCE.exists():
    raise SystemExit(f"no engine source found: neither {V4} nor {ENGINE_PATH} exists")
src = SOURCE.read_text(encoding="utf-8")
print(f"building from {SOURCE.relative_to(HERE.parent.parent)}")


def sub(old, new, count=1):
    global src
    n = src.count(old)
    assert n == count, f"patch anchor not found {count}x (found {n}): {old[:80]!r}"
    src = src.replace(old, new)


# ---- Phase 1: strip every demo case down to a generic engine (this result is what gets committed) ----

# 1. drop the hard-coded demo case + its documents; keep DRUG_LIST; data arrives at runtime
a = src.index("// ── CLINICAL DOCUMENT TEMPLATES")
b = src.index("const CASES=[")
c = src.index("const DRUG_LIST=[")
d = src.index("const MOCK_CLAIM_DEFS={")
e = src.index("</script>", d)
drug_list = src[c:d]
src = src[:a] + "let CASES=[];\n" + drug_list + "let MOCK_CLAIM_DEFS={}, MC_RESULTS={}, CASE_NOTES={};\n\n" + src[e:]

# 2. tool data (PA / claim history) is runtime data too
a = src.index("// ── TOOL DATA")
b = src.index("function openTool(name){")
src = src[:a] + "let TOOL_DATA={};\n" + src[b:]

# 3. skip logic comes from the qset table at runtime; the engine only needs it to be reassignable
sub("const SK={", "let SK={")

# 4. the original bootstrap would render an empty case; the sandbox layer boots itself
sub("document.addEventListener('DOMContentLoaded',()=>renderAll());", "")

# 5. the recommendation text asserted things the reviewer had not checked yet; keep it to what the data supports
if "All criteria verified. Documentation complete. Approval is supported." in src:
    sub("All criteria verified. Documentation complete. Approval is supported.", "The criteria score to Approval on the answers shown.")
if src.count("All criteria verified.") == 1:
    sub("All criteria verified.", "Criteria score to Approval.")

# Sanity check: no case-specific data should survive the strip. If this fires, a new demo case field leaked through.
leaked = re.findall(r"id:\"[\w-]+\"|rev:\"[A-Z0-9]+\"|name:\"[A-Z][a-z]+ [A-Z][a-z]+\"", src)
assert not leaked, f"demo case data leaked into the stripped engine: {leaked[:5]}"

ENGINE_PATH.parent.mkdir(exist_ok=True)
ENGINE_PATH.write_text(src, encoding="utf-8")
print(f"wrote {ENGINE_PATH.relative_to(HERE.parent.parent)} ({len(src):,} bytes) — safe to commit")

# ---- Phase 2: add the sandbox layer (local app only, not committed as part of the engine) ----

sub('<span class="bar-role" id="bar-role">Role: Technician &nbsp;|&nbsp; Queue: Pending Approval</span>',
    '''<span class="bar-role" id="bar-role" style="margin-right:10px">Role: Technician &nbsp;|&nbsp; Queue: Pending Approval</span>
    <input id="tester-in" placeholder="Your name / ID" oninput="sbSetTester(this.value)" style="padding:4px 7px;border-radius:5px;border:1px solid #475569;background:#1e293b;color:#e2e8f0;font-size:11px">
    <select id="case-sel" onchange="if(this.value)sbLoadCase(this.value)" style="padding:4px 6px;border-radius:5px;border:1px solid #475569;background:#1e293b;color:#e2e8f0;font-size:11px"></select>
    <input id="pa-in" placeholder="PA #" style="padding:4px 7px;border-radius:5px;border:1px solid #475569;background:#1e293b;color:#e2e8f0;font-size:11px" onkeydown="if(event.key==='Enter')sbLoadTyped()">
    <button id="pa-load" onclick="sbLoadTyped()" style="padding:4px 9px;border-radius:5px;border:1px solid #475569;background:#334155;color:#e2e8f0;font-size:11px;cursor:pointer">Load</button>
    <button onclick="sbRandom()" style="padding:4px 9px;border-radius:5px;border:0;background:#2563eb;color:#fff;font-size:11px;font-weight:600;cursor:pointer">Random case</button>''')
if "<title>" in src:
    sub("<title>", "<title>[Sandbox] ", 1)

# approval term picker inside the approve-confirmation box (the real reviewer sets a term; the stripped engine has no opinion)
sub('<div class="dec-confirm-ttl">Please confirm that you intend to approve this PA.</div>',
    '<div class="dec-confirm-ttl">Please confirm that you intend to approve this PA.</div>'
    '<div style="margin:8px 0;font-size:12px;color:#334155">Approval term <select id="term-sel" style="margin-left:6px;padding:3px 6px;font-size:12px">'
    '<option value="3">3 months</option><option value="6">6 months</option><option value="12" selected>12 months</option></select></div>')

js = (HERE / "sandbox.js").read_text(encoding="utf-8")
sub("</body>", "<script>\n" + js + "\n</script>\n</body>")

(HERE / "app").mkdir(exist_ok=True)
(HERE / "app" / "index.html").write_text(src, encoding="utf-8")
print(f"wrote app/index.html ({len(src):,} bytes)")
